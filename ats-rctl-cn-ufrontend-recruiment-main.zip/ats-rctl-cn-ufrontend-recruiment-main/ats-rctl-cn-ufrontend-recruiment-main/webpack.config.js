const Dotenv = require('dotenv-webpack')
const { merge } = require('webpack-merge')
const singleSpaDefaults = require('webpack-config-single-spa-react-ts')
const TsconfigPathsPlugin = require('tsconfig-paths-webpack-plugin')

module.exports = (webpackConfigEnv, argv) => {
  const defaultConfig = singleSpaDefaults({
    orgName: 'joyit',
    projectName: 'recruitment',
    webpackConfigEnv,
    argv,
  })

  return merge(defaultConfig, {
    // modify the webpack config however you'd like to by adding to this object
    module: {
      rules: [
        {
          test: /\.css$/i,
          use: ['postcss-loader'],
        },
      ],
    },
    externals: ['@joyit/layout', '@joyit/user-management'],
    resolve: {
      plugins: [new TsconfigPathsPlugin({ configFile: './tsconfig.json' })],
    },
    plugins: [new Dotenv()],
  })
}
