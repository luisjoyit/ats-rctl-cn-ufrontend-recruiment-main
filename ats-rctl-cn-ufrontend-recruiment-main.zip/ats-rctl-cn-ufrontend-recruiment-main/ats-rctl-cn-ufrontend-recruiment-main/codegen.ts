import { CodegenConfig } from '@graphql-codegen/cli'
import { GRAPHQL_ENDPOINT } from './src/constants'

const config: CodegenConfig = {
  schema: GRAPHQL_ENDPOINT,
  documents: [
    'src/**/*.tsx',
    'src/**/*.ts',
    'src/service/*.ts',
    'src/aplicant/*.ts',
    'src/aplicant/*.tsx',
  ],
  ignoreNoDocuments: true, // for better experience with the watcher
  generates: {
    './src/gql/': {
      preset: 'client',
    },
  },
}

export default config
