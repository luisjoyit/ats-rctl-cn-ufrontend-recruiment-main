Estructura de Ramas

- **main** (default): Rama principal que contiene el código listo para producción.
- **dev**: Rama de desarrollo donde se integran los pull requests antes de pasar a `main`.

# Requisitos para Levantar el Microservicio ats-rctl-cn-micro-recruiment

Para poder levantar este microservicio de manera adecuada, es necesario seguir los siguientes pasos:

## Dependencias usadas

- [React](https://es.react.dev/)
- [typeScript](https://www.typescriptlang.org/)
- [Tailwindcss](https://tailwindcss.com/) -> para los estilos
- [ChadCN](https://ui.shadcn.com/) -> reutilizacion de componentes
- [FKA React Query](https://tanstack.com/query/latest) -> traer datos asíncronos
- [codeGen](https://the-guild.dev/graphql/codegen/plugins/typescript/typescript-react-query) -> generar esquemas de graphQl
- [tabler icons](https://tabler.io/icons) -> Iconos para la aplicacion
- [framer-motion](https://www.framer.com/motion/) -> para animaciones
- [sonner](https://sonner.emilkowal.ski/) -> para mensajes toast
- [zod](https://zod.dev/) -> para validaciones de formularios
- [react-hook-form](https://react-hook-form.com/) -> para manejar formularios

## Clonación de Microservicios

Es imprescindible clonar los siguientes microservicios para asegurar el correcto funcionamiento del sistema:

- [ats-rctl-cn-micro-root](https://github.com/joyitoficial/ats-rctl-cn-micro-root)
- [ats-rctl-cn-micro-layout](https://github.com/joyitoficial/ats-rctl-cn-micro-layout)
- [ats-rctl-cn-micro-recruiment](https://github.com/joyitoficial/ats-rctl-cn-micro-recruiment)
- [ats-rctl-cn-micro-user-management](https://github.com/joyitoficial/ats-rctl-cn-micro-user-management)

Asegúrese de clonar cada uno de estos microservicios en un entorno local o en el servidor donde se pretende ejecutar el microservicio principal.

## Ejecutar el backend mock (django)

Hay varias vistas que ya estan usando el backend, para poder levantar el backend clonarse el siguiente repositorio :

- [ats-rctl-mock-data](https://github.com/joyitoficial/ats-rctl-mock-data)

> [!NOTE]  
> Seguir las instrucciones del repositorio para poder levantar el backend

## Configuración y Ejecución

Una vez que se han clonado los microservicios necesarios, siga estos pasos para levantar el microservicio principal:

1. **Instalación de PNPM**:
   Asegúrese de tener PNPM instalado globalmente en su sistema. Si no lo tiene instalado, puede ejecutar el siguiente comando `npm install -g pnpm`

2. **Instalación de Dependencias**:
   Navegue a cada uno de los directorios de los microservicios clonados y ejecute el siguiente comando para instalar las dependencias necesarias utilizando PNPM:

```bash
pnpm i
```

Repita este paso para cada uno de los microservicios clonados.

3. **Inicio de los Microservicios**:
   Una vez instaladas las dependencias, ejecute el siguiente comando en cada uno de los microservicios para iniciarlos:

```bash
pnpm start
```

Este comando iniciará el servidor para cada microservicio, asegurando su disponibilidad para ser utilizado por el microservicio principal.

### **Iniciar Sesion**

Momentaneamente hay un inicio de sesion para proteger las url en produccion
las credenciales son las siguiente :

```
email: "cagnopespi@joyit.com",
password: "MX5mQCUbSHZ47JsA6X%a9X",
```

Con estos pasos completados, el microservicio principal debería poder acceder y utilizar los microservicios clonados para su funcionamiento correcto.

> [!IMPORTANT]  
> Asegúrese de que todos los microservicios estén en funcionamiento antes de utilizar el microservicio principal en su entorno de producción.

### Crear una nueva ruta

Para la creacion de rutas se usa [React Router Dom](https://reactrouter.com/en/main)

#### Crear ruta de aplicant

1. Para la creacion de una ruta nueva o modificar ubicarse dentro del archivo `src/aplicant/index.tsx` dentro se encuentra las rutas creadas con su respectivos paginas a mostrar

```javascript
<Route
  path="/recruitment/candidate/myProfile" // url a mostrar
  element={<MyProfilePage />} // pagina a mostrar
/>
```

2. Crear un **Template** en `src/aplicant/components/template` ejm:`MyProfile`.
3. Crear una nueva **pagina** en `src/aplicant/pages` con la notacion de **Page**, ejm: `MyProfilePage` e importar el **template** creado.
4. Finalmente importar la pagina creada en la ruta creada en `index.tsx`

## Para generar los esquemas de las consultas de graphQl

Cuando se genera una consulta de graphQl debe tener activo este comando en otra terminal:

```bash
pnpm graphql-codegen --watch
```

> [!NOTE]  
> Dentro de la consola se marcara si la conbsulta de graphQl esta bien o tiene errores.

> [!NOTE]  
> Ejecutar el comando solo si se hace una query al backend

## Agregar I18n(traduccion)

para poder agregar la traduccion que estan en los json de `layout` debe importar :

```
//@ts-ignore
import { t, useLanguage } from '@joyit/layout'
```

> [!IMPORTANT]  
> Debera de usar este hook en caso no reconozca la traduccion en el componente `const { handleChangeLanguage } = useLanguage()`

## Acceso al Microservicio Principal

Una vez que todos los microservicios estén en funcionamiento, puede acceder al microservicio principal a través de su navegador web siguiendo estos pasos:

1. Iniciar Microservicios:
   Asegúrese de que todos los microservicios clonados estén en funcionamiento siguiendo las instrucciones proporcionadas anteriormente.

2. Acceso al Microservicio Principal:
   Abra su navegador web y navegue a la siguiente URL:

```bash
http://localhost:9000/recruitment
```

Esta URL proporcionará acceso al microservicio principal, que está configurado para el puerto 9000 en localhost y la ruta '/recruitment'.

## Organizacion de carpetas

Se esta usando [feature-sliced-design](https://dev.to/m_midas/feature-sliced-design-the-best-frontend-architecture-4noj) para la organizacion de las carpetas

```
src/
├── components/          # Componentes reutilizables a nivel global
│   ├── atoms/
│   ├── molecules/
│   ├── organisms/
│   └── templates/
├── constants/           # Constantes globales
├── gql/                 # Esquemas y configuracion de GraphQL
├── helpers/             # Funciones de ayuda globales
├── hooks/               # Custom Hooks reutilizables
├── lib/                 # Bibliotecas y utilidades globales
├── service/             # Servicios comunes (ej. configuración de API)
└── static/              # Archivos estáticos
└── svg/             # Iconos SVG
└── aplicant/
      ├── components/      # Componentes específicos de la funcionalidad "aplicant"
      │   ├── atoms/
      │   ├── molecules/
      │   ├── organisms/
      │   └── templates/
      ├── pages/           # Páginas de la funcionalidad "aplicant"
      ├── service/         # Servicios específicos para "aplicant" (ej. GraphQL)
      └── index.tsx        # Rutas y punto de entrada para la funcionalidad "aplicant"
├── index.css                # Estilos globales
└── index.tsx
```
