# CONTRIBUTING.md

### Buenas prácticas 🌟

- **Revisa los issues abiertos** antes de abrir una PR, si crees que puedes solucionarlo y no hay ninguna otra PR ya abierta, usa `#numero-de-la-issue` en tu commit para que se añada a la issue. No está demás dejar algún comentario para que se sepa que PR está siendo usada para la issue.
- **Revisa los PRs abiertos** para asegurarte de que no estás trabajando en algo que ya está en progreso. Siempre puedes ayudar en PRs ya abiertas, aportando cambios, comentarios, revisiones, etc..
- **Mantén tus commits limpios y descriptivos**.
- **Sigue las convenciones de código del proyecto**.
- **Actualiza tu rama con frecuencia** para mantenerla al día con la rama principal del proyecto.
- **Participa en las discusiones** de tu PR si hay comentarios o sugerencias.

Para una mejor organización y claridad en los commits, utiliza los siguientes prefijos:

- `feat`: una nueva funcionalidad.
- `fix`: reparación de un problema.
- `chore`: tareas repetitivas o de mantenimiento.
- `update`: actualizaciones generales.
- `refactor`: refactorización de código sin cambios en la funcionalidad.
