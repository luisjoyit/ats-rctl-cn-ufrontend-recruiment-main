import config from '../../tailwind.config'

export const screenIs = (screen = '') => {
  const screens = config.theme?.extend?.screens ?? config.theme?.screens ?? {}

  const matches = Object.entries(screens).reduce(
    (results: any, [name, size]) => {
      const mediaQuery =
        typeof size === 'string'
          ? `(min-width: ${size})`
          : `(max-width: ${size.max})`

      results[name] = window.matchMedia(mediaQuery).matches

      return results
    },
    {},
  )

  if (screen === '') {
    return matches
  }

  if (!screens[screen as keyof typeof screens]) {
    console.error(`No match for "${screen}"`)

    return false
  }

  return matches[screen]
}
