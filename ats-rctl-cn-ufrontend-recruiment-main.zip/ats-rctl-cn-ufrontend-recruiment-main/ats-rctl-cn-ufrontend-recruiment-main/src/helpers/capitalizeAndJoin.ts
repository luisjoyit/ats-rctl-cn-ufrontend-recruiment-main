export function capitalizeAndJoin(input: string, separator: string): string {
  return input
    .split(separator)
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
    .join(' ')
}
