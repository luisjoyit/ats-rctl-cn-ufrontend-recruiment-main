export const categoryFaq = [
  {
    id: 1,
    title: 'Preguntas Frecuentes',
    subTitles:
      'Encuentra respuestas a las preguntas más comunes sobre el uso general del ATS.',
    subcategory: [
      {
        id: 1,
        title: '¿Cómo puedo crear una cuenta?',
        subTitles:
          'Aquí te explicamos los pasos para crear una cuenta desde el inicio, incluyendo los datos necesarios y las verificaciones que debes realizar para asegurar que tu cuenta esté configurada correctamente.',
      },
      {
        id: 2,
        title: '¿Dónde puedo cambiar mi contraseña?',
        subTitles:
          'Te mostramos cómo cambiar tu contraseña fácilmente desde el panel de usuario, incluyendo pasos para restablecerla si la has olvidado, y consejos para crear una contraseña segura.',
      },
      {
        id: 3,
        title: '¿Cómo elimino mi cuenta?',
        subTitles:
          'Sigue estos pasos para eliminar tu cuenta de manera definitiva. Asegúrate de haber respaldado toda tu información importante antes de proceder con la eliminación.',
      },
      {
        id: 4,
        title: '¿Cómo contacto al soporte?',
        subTitles:
          'Te explicamos las diversas formas de contactar al soporte técnico, incluyendo correo electrónico, chat en vivo y línea telefónica, para que puedas recibir ayuda rápidamente.',
      },
      {
        id: 5,
        title: '¿Qué tipos de cuenta puedo crear?',
        subTitles:
          'Explicación detallada de los diferentes tipos de cuentas disponibles y sus características distintivas, para que puedas elegir la opción que mejor se adapte a tus necesidades.',
      },
      {
        id: 6,
        title: '¿Cómo cambio la configuración de privacidad?',
        subTitles:
          'Instrucciones paso a paso para ajustar la configuración de privacidad de tu cuenta, incluyendo quién puede ver tu información y qué acciones de seguridad puedes tomar.',
      },
      {
        id: 7,
        title: '¿Cómo puedo actualizar mi dirección de correo electrónico?',
        subTitles:
          'Pasos para cambiar o actualizar la dirección de correo electrónico asociada a tu cuenta, garantizando que recibas comunicaciones importantes de manera efectiva.',
      },
    ],
  },
  {
    id: 2,
    title: 'Búsqueda de Empleo',
    subTitles:
      'Descubre cómo publicar vacantes y buscar candidatos de manera eficiente.',
    subcategory: [
      {
        id: 1,
        title: '¿Cómo busco empleo en el portal?',
        subTitles:
          'Pasos y consejos para buscar empleo en nuestro portal, incluyendo el uso de filtros y palabras clave para refinar tu búsqueda y encontrar las ofertas más relevantes para ti.',
      },
      {
        id: 2,
        title: '¿Cómo aplico a una oferta de trabajo?',
        subTitles:
          'Te mostramos cómo aplicar a ofertas de trabajo, desde la preparación de tu perfil y currículum hasta la presentación de tu solicitud y el seguimiento de tu postulación.',
      },
      {
        id: 3,
        title: '¿Cómo subo mi currículum?',
        subTitles:
          'Instrucciones detalladas para subir tu currículum al portal, incluyendo los formatos aceptados y cómo asegurarte de que tu currículum sea visible para los empleadores.',
      },
      {
        id: 4,
        title: '¿Puedo guardar búsquedas de empleo?',
        subTitles:
          'Te explicamos cómo guardar tus búsquedas de empleo para acceder a ellas fácilmente en el futuro, y cómo recibir alertas cuando se publiquen nuevas ofertas que coincidan con tus criterios.',
      },
      {
        id: 5,
        title: '¿Cómo puedo destacar mi perfil?',
        subTitles:
          'Consejos para optimizar tu perfil en el portal y aumentar tus posibilidades de ser visto por los reclutadores, incluyendo cómo agregar palabras clave relevantes y actualizar tu experiencia.',
      },
      {
        id: 6,
        title: '¿Cómo puedo recibir notificaciones de nuevas ofertas?',
        subTitles:
          'Configuración de alertas y notificaciones para estar al tanto de las nuevas oportunidades laborales que coincidan con tus preferencias y habilidades.',
      },
      {
        id: 7,
        title:
          '¿Cómo puedo solicitar retroalimentación después de una entrevista?',
        subTitles:
          'Pasos para solicitar comentarios constructivos después de una entrevista de trabajo, incluyendo cómo enviar un seguimiento adecuado y mejorar para futuras oportunidades.',
      },
    ],
  },
  {
    id: 3,
    title: 'Proceso de Selección',
    subTitles:
      'Aprende sobre las etapas del proceso de selección y cómo gestionar candidatos.',
    subcategory: [
      {
        id: 1,
        title: '¿Cuánto dura el proceso de selección?',
        subTitles:
          'Información sobre la duración del proceso de selección, desde la presentación de la solicitud hasta la decisión final, y qué puedes esperar en cada etapa del proceso.',
      },
      {
        id: 2,
        title: '¿Qué documentos necesito?',
        subTitles:
          'Lista completa de documentos necesarios para el proceso de selección, incluyendo identificaciones, certificados, y otros documentos relevantes que debes tener listos.',
      },
      {
        id: 3,
        title: '¿Cómo puedo prepararme para la entrevista?',
        subTitles:
          'Consejos y tips para prepararte para la entrevista, incluyendo cómo investigar sobre la empresa, practicar preguntas comunes y cómo presentar tus habilidades de la mejor manera.',
      },
      {
        id: 4,
        title: '¿Cómo me notifican el resultado?',
        subTitles:
          'Te explicamos cómo recibirás la notificación del resultado, ya sea por correo electrónico, llamada telefónica o a través de tu cuenta en el portal, y qué hacer después de recibir la notificación.',
      },
      {
        id: 5,
        title: '¿Cómo puedo saber si fui seleccionado?',
        subTitles:
          'Indicadores clave para identificar si has sido seleccionado para avanzar en el proceso de selección, incluyendo los tiempos típicos de respuesta y cómo gestionar múltiples entrevistas.',
      },
      {
        id: 6,
        title: '¿Qué pasa después de la entrevista final?',
        subTitles:
          'Pasos a seguir después de la entrevista final, incluyendo cómo enviar una nota de agradecimiento, qué hacer si no recibes noticias y cómo evaluar las ofertas recibidas.',
      },
      {
        id: 7,
        title: '¿Cómo puedo prepararme para una evaluación de habilidades?',
        subTitles:
          'Consejos para prepararte eficazmente para una evaluación de habilidades durante el proceso de selección, incluyendo recursos recomendados y prácticas sugeridas.',
      },
    ],
  },
  {
    id: 4,
    title: 'Mis Evaluaciones',
    subTitles:
      'Obtén ayuda con problemas técnicos y aprende cómo contactar al soporte.',
    subcategory: [
      {
        id: 1,
        title: '¿Cómo reporto un problema técnico?',
        subTitles:
          'Pasos para reportar un problema técnico, incluyendo cómo describir el problema, qué información adicional proporcionar y cómo hacer seguimiento a tu reporte.',
      },
      {
        id: 2,
        title: '¿Qué hago si la página no carga?',
        subTitles:
          'Soluciones para cuando la página no carga, incluyendo comprobaciones de tu conexión a internet, borrado de caché del navegador y otros pasos para solucionar problemas comunes.',
      },
      {
        id: 3,
        title: '¿Cómo actualizo mis datos personales?',
        subTitles:
          'Instrucciones para actualizar tus datos personales en el portal, desde cambiar tu dirección de correo electrónico hasta actualizar tu número de teléfono y otra información importante.',
      },
      {
        id: 4,
        title: '¿Cómo recupero mi contraseña?',
        subTitles:
          'Pasos para recuperar tu contraseña, incluyendo cómo solicitar un enlace de restablecimiento y qué hacer si no recibes el correo electrónico con las instrucciones.',
      },
      {
        id: 5,
        title: '¿Cómo puedo solicitar una actualización de software?',
        subTitles:
          'Procedimiento para solicitar y recibir actualizaciones de software relevantes para mejorar la experiencia del usuario y corregir problemas técnicos conocidos.',
      },
      {
        id: 6,
        title: '¿Dónde puedo encontrar la documentación de soporte?',
        subTitles:
          'Localización y acceso a la documentación de soporte técnico, incluyendo manuales de usuario, guías de solución de problemas y preguntas frecuentes para autoayuda.',
      },
      {
        id: 7,
        title: '¿Cómo puedo cambiar el idioma de la plataforma?',
        subTitles:
          'Instrucciones para ajustar la configuración de idioma de la plataforma para adaptarse a tus preferencias y necesidades lingüísticas.',
      },
    ],
  },
]
