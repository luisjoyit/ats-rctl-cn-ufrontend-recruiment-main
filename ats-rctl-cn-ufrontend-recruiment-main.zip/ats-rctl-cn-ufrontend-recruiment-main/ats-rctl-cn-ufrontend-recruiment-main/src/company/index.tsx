import { Outlet, Route, Routes } from 'react-router-dom'
import HomeDemoPage from './pages/HomeDemoPage'
import CreateJobPage from './pages/CreateJobPage'
import MyCompanyPage from './pages/MyCompanyPage'
import CompanyDashboardPage from './pages/CompanyDashboardPage'
import OffersPage from './pages/OffersPage'
import OfferIdPage from './pages/OfferIdPage'
import OfferDetailPage from './pages/OfferDetailPage'
import MyProcessesStagesDetail from './pages/MyProcessesStagesPage'
import MyEvaluationsPage from './pages/MyEvaluationsPage'
import MyEvaluationIdPage from './pages/MyEvaluationIdPage'
import Account from './components/organism/Settings/Account'
import SettingsLayoutPage from './pages/SettingsLayoutPage'
import Privacy from './components/organism/Settings/Privacy'
import Billing from './components/organism/Settings/Billing'
import Notifications from './components/organism/Settings/Notifications'
import Visibility from './components/organism/Settings/Visibility'
import MyProcessesPage from './pages/MyProcessesPage'
import FaqCompanyPage from './pages/FaqCompanyPage'
import FaqTicketPage from './pages/FaqTicketPage'
import FaqSeeTicketPage from './pages/FaqSeeTicketPage'
import FaqUpdatePage from './pages/FaqUpdatePage'
import MyReportsPage from './pages/MyReportsPage'
import MessagesPage from './pages/MessagesPage'
import MessageId from './components/templates/MessageId'
import MessageDetail from './components/templates/MessageDetail'
import MyProcessesInfoPage from './pages/MyProcessesInfoPage'
import MyProcessesActivityPage from './pages/MyProcessesActivityPage'
import MyProcessesMetricsPage from './pages/MyProcessesMetricsPage'
import MyProcessesIdPage from './pages/MyProcessesIdPage'
import MyNewEvaluationPage from './pages/MyNewEvaluationPage'
import { ProtectedLayout } from '@/protected-route'

export default function CompanyPages(props) {
  return (
    <Routes>
      <Route element={<ProtectedLayout roles={['recruiter']} />}>
        <Route path="home" element={<HomeDemoPage />} />
        <Route path="myCompany" element={<MyCompanyPage />} />
        <Route path="faq" element={<FaqCompanyPage />} />
        <Route path="faq/ticket" element={<FaqTicketPage />} />
        <Route path="faq/ticket/seeticket" element={<FaqSeeTicketPage />} />
        <Route path="faq/ticket/update" element={<FaqUpdatePage />} />
        <Route path="myProcesses/createJob" element={<CreateJobPage />} />
        <Route path="Dashboard" element={<CompanyDashboardPage />} />
        <Route path="offers" element={<OffersPage />} />
        <Route path="myReports" element={<MyReportsPage />} />
        <Route path="offers/:offerId" element={<OfferIdPage />}>
          <Route index element={<OfferDetailPage />} />
        </Route>
        <Route path="myProcesses" element={<MyProcessesPage />} />
        <Route path="myProcesses/:processesId" element={<MyProcessesIdPage />}>
          <Route index path="stages" element={<MyProcessesStagesDetail />} />
          <Route path="info" element={<MyProcessesInfoPage />} />
          <Route path="activity" element={<MyProcessesActivityPage />} />
          <Route path="metrics" element={<MyProcessesMetricsPage />} />
        </Route>
        <Route path="myEvaluations" element={<MyEvaluationsPage />} />
        <Route path="myNewEvaluation" element={<MyNewEvaluationPage />} />
        <Route
          path="myEvaluations/:evaluationId"
          element={<MyEvaluationIdPage />}
        />
        <Route path="settings" element={<SettingsLayoutPage />}>
          <Route index path="account" element={<Account />} />
          <Route path="visibility" element={<Visibility />} />
          <Route path="privacy" element={<Privacy />} />
          <Route path="billing" element={<Billing />} />
          <Route path="notifications" element={<Notifications />} />
        </Route>
        <Route path="messages" element={<MessagesPage />} />
        <Route path="messages/:messageId" element={<MessageId />}>
          <Route index element={<MessageDetail />} />
        </Route>
      </Route>
      <Route path="*" element={<div>Not Found</div>} />
    </Routes>
  )
}
