import useMediaQuery from '@/hooks/useMediaQuery'
import {
  IconAlignJustified,
  IconCircle,
  IconCircleDot,
  IconCopy,
  IconGripVertical,
  IconTrash,
} from '@tabler/icons-react'
import React, { useState } from 'react'
import SelectUi from '@/components/SelectUi'
import {
  FieldErrors,
  UseFormRegister,
  UseFormSetValue,
  UseFormTrigger,
} from 'react-hook-form'
import { EvaluationFormSchema } from '@/company/validations/evaluationFormSchema'

interface Question {
  id?: number
  titleQuestion?: string
  typeAnswer?: 'short' | 'several'
  answers?: string[]
}

interface Props {
  question: Question
  index: number
  deleteQuestion: (id: number) => void
  register: UseFormRegister<EvaluationFormSchema>
  errors: FieldErrors<EvaluationFormSchema>
  setValue: UseFormSetValue<EvaluationFormSchema>
  trigger: UseFormTrigger<EvaluationFormSchema>
}

const initialAnswer = ['']

export default function NewQuestionCard({
  question,
  index,
  deleteQuestion,
  register,
  errors,
  setValue,
  trigger,
}: Props) {
  const [selectedType, setSelectedType] = useState(
    question?.typeAnswer || 'short',
  )
  const listAnswers = question?.answers

  const isMobile = useMediaQuery('(max-width: 640px)')

  const changeTypeAnswer = (name, value) => {
    setSelectedType(value)
    setValue(`questions.${index}.typeAnswer`, value)

    if (value === 'short') {
      setValue(`questions.${index}.answers`, [])
    }
  }

  const addOption = () => {
    setValue(`questions.${index}.answers`, [...listAnswers, ''])
    trigger(`questions.${index}`)
  }

  const handleAnswerChange = (
    e: React.ChangeEvent<HTMLInputElement>,
    index: number,
  ) => {
    const newAnswers = [...listAnswers]
    newAnswers[index] = e.target.value
    setValue(`questions.${index}.answers`, newAnswers)
  }

  const getIcon = () => {
    if (selectedType === 'short') {
      return <IconCircleDot className="mr-2 text-secondary-500" size={16} />
    }
    if (selectedType === 'several') {
      return (
        <IconAlignJustified className="mr-2 text-secondary-500" size={16} />
      )
    }
    return null
  }

  return (
    <div className="flex flex-row gap-1">
      {!isMobile && (
        <div className="flex items-center justify-center">
          <IconGripVertical stroke={2} size={24} fill="#263658" />
        </div>
      )}
      <div className="w-full min-h-[213px] xs:p-3.5 sm:p-6 rounded-4xl border-2 flex flex-col gap-6">
        <div className="flex xs:flex-col sm:flex-row w-full justify-between gap-6">
          <div className="flex flex-col gap-1 w-full">
            <input
              id="underline-input"
              type="text"
              className="w-full block border-0 border-b-[0.5px] border-accent-700 focus:ring-0 outline-none bg-transparent"
              name="titleQuestion"
              placeholder="Describa la evaluación, puede añadir pautas y datos que se mostrarán al usuario"
              {...register(`questions.${index}.titleQuestion` as const, {
                required: 'La pregunta es obligatoria',
              })}
            />
            {errors?.questions?.[index]?.titleQuestion && (
              <span className="text-xs text-destructive-500">
                {errors.questions[index]?.titleQuestion?.message}
              </span>
            )}
          </div>
          <div className="inline-flex items-center">
            <SelectUi
              name="typeAnswer"
              items={[
                { value: 'short', label: 'Respuesta Corta' },
                { value: 'several', label: 'Varias opciones' },
              ]}
              value={selectedType}
              placeholder="Pregunta"
              onChange={changeTypeAnswer}
              icon={getIcon()}
              className="shadow-input h-[37px] w-[230px] justify-between"
            />
          </div>
        </div>
        <div className="w-full flex xs:flex-col sm:flex-row h-full xs:gap-3 sm:gap-0">
          {selectedType === 'short' ? (
            <div className="flex xs:w-full sm:w-3/4 items-center">
              <div className="text-muted-300 border-b-[1px] border-b-accent-700 w-full h-[30px]">
                <span className="cursor-default">Texto de respuesta corta</span>
              </div>
            </div>
          ) : (
            <div className="flex xs:w-full sm:w-3/4 items-start flex-col gap-2">
              {listAnswers.map((answer, answerIndex) => (
                <div key={answerIndex} className="flex flex-col gap-1">
                  <div className="flex flex-row gap-2 w-full items-center">
                    <IconCircle
                      stroke={1.5}
                      size={15}
                      className="text-secondary-500 dark:text-white"
                    />
                    <input
                      id="underline-input"
                      type="text"
                      className="mt-1 block w-full border-b-[0.5px] border-accent-700 focus:ring-0 outline-none bg-transparent"
                      name=""
                      placeholder={`Opción ${answerIndex + 1}`}
                      value={answer}
                      onChange={(e) => handleAnswerChange(e, answerIndex)}
                      {...register(`questions.${index}.answers.${answerIndex}`)}
                    />
                  </div>
                  {errors?.questions?.[index]?.answers?.[answerIndex]
                    ?.message && (
                    <span className="text-xs text-destructive-500">
                      {errors.questions[index].answers[answerIndex]?.message}
                    </span>
                  )}
                </div>
              ))}
              <div className="flex flex-row gap-2 w-full items-center">
                <IconCircle
                  stroke={1.5}
                  size={15}
                  className="text-secondary-500 dark:text-white"
                />
                <span
                  className="text-accent-700 cursor-pointer"
                  role="button"
                  tabIndex={0}
                  onClick={addOption}
                >
                  + Añadir opción
                </span>
              </div>
            </div>
          )}
          <div className="flex flex-row gap-4 items-end justify-end h-full xs:w-full sm:w-1/4">
            <div
              className="rounded-[14px] border border-secondary 
                                xs:w-[34px] sm:w-[43px] xs:h-[35px] sm:h-[44px] flex items-center justify-center"
            >
              <IconCopy
                stroke={1.5}
                size={isMobile ? 16 : 24}
                className="cursor-pointer text-secondary-500 dark:text-white"
              />
            </div>
            <div
              className="rounded-[14px] border border-secondary
                                xs:w-[34px] sm:w-[43px] xs:h-[35px] sm:h-[44px] flex items-center justify-center"
            >
              <IconTrash
                stroke={1.5}
                size={isMobile ? 16 : 24}
                className="cursor-pointer text-secondary-500 dark:text-white"
                onClick={() => deleteQuestion(question.id)}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
