import React from 'react'
import { CardEvaluations } from '../../templates/MyEvaluations'
import { IconTrash, IconUserCheck } from '@tabler/icons-react'
import { Link } from 'react-router-dom'

interface CardsProps {
  card: CardEvaluations
}

export default function EvaluationsCards({ card }: CardsProps) {
  return (
    <div className="xs:w-full md:w-[316px] h-[106px] bg-[#E7F0FF] rounded-[11px] p-3 flex flex-col gap-1.5 text-secondary-500">
      <div className="flex w-full flex-row justify-between">
        <span className="font-medium">{card.name}</span>
        <IconTrash stroke={1.5} size={24} />
      </div>
      <div className="flex flex-row gap-1.5">
        <IconUserCheck stroke={2} size={16} />
        <span className="font-medium text-sm">{card.amount}</span>
      </div>
      <div className="flex flex-row justify-between text-[10px]">
        {card.source !== 'joyIT' && (
          <Link to={`${card.id}`}>
            <button className="bg-[#F7FAFF] w-[98px] h-[20px] rounded-4xl hover:bg-primary hover:text-white">
              Editar Evaluación
            </button>
          </Link>
        )}
        <button className="bg-primary w-[98px] h-[20px] rounded-4xl text-white">
          Ver Evaluación
        </button>
      </div>
    </div>
  )
}
