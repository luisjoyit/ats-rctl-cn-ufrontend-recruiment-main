import {
  AlertDialog,
  AlertDialogCancel,
  AlertDialogAction,
  AlertDialogContent,
  AlertDialogFooter,
  AlertDialogTrigger,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import { Input } from '@/components/ui/input'
import { IconPlus, IconX } from '@tabler/icons-react'
import React, { useState } from 'react'
import { string } from 'zod'

type Links = {
  facebook: string
  github: string
  instagram: string
  linkedin: string
  url: string
  other: string
}

interface ILinks {
  links: Links
  setLinks: React.Dispatch<React.SetStateAction<Links>>
}
const FormSocialMedia = ({ links, setLinks }: ILinks) => {
  const [open, setOpen] = useState(false)

  return (
    <AlertDialog open={open} onOpenChange={setOpen}>
      <AlertDialogTrigger>
        <button className="h-[39px] w-[39px] rounded-lg border border-secondary-500 bg-white flex justify-center items-center">
          <IconPlus className="text-secondary-500" />
        </button>
      </AlertDialogTrigger>
      <AlertDialogContent style={{ gap: 0 }}>
        <AlertDialogTitle />
        <div className="flex justify-end">
          <IconX
            stroke={1.5}
            size={20}
            className="cursor-pointer text-secondary-500"
            onClick={() => setOpen(false)}
          />
        </div>
        <div className="flex flex-col gap-4 text-secondary-500">
          <span className="text-center text-lg font-semibold">
            Vincular cuentas a tu perfil
          </span>
          <span className="text-start font-medium">
            Copia y pega las URL' de tus redes sociales
          </span>
          <div className="grid grid-cols-[90px_1fr] gap-2">
            <span>Facebook</span>
            <Input
              placeholder="Escribe el URL aquí"
              value={links.facebook}
              onChange={(e) =>
                setLinks((prev) => ({ ...prev, facebook: e.target.value }))
              }
            />
            <span>Github</span>
            <Input
              placeholder="Escribe el URL aquí"
              value={links.github}
              onChange={(e) =>
                setLinks((prev) => ({ ...prev, github: e.target.value }))
              }
            />
            <span>Instagram</span>
            <Input
              placeholder="Escribe el URL aquí"
              value={links.instagram}
              onChange={(e) =>
                setLinks((prev) => ({ ...prev, instagram: e.target.value }))
              }
            />
            <span>Linkedin</span>
            <Input
              placeholder="Escribe el URL aquí"
              value={links.linkedin}
              onChange={(e) =>
                setLinks((prev) => ({ ...prev, linkedin: e.target.value }))
              }
            />
            <span>Url</span>
            <Input
              placeholder="Escribe el URL aquí"
              value={links.url}
              onChange={(e) =>
                setLinks((prev) => ({ ...prev, url: e.target.value }))
              }
            />
            <span>X</span>
            <Input
              placeholder="Escribe el URL aquí"
              value={links.other}
              onChange={(e) =>
                setLinks((prev) => ({ ...prev, other: e.target.value }))
              }
            />
          </div>
        </div>
        <AlertDialogFooter className="w-full flex flex-row sm:justify-around xs:gap-4 md:gap-6 pt-8">
          <AlertDialogCancel>Cancelar</AlertDialogCancel>
          <AlertDialogAction>Guardar</AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  )
}

export default FormSocialMedia
