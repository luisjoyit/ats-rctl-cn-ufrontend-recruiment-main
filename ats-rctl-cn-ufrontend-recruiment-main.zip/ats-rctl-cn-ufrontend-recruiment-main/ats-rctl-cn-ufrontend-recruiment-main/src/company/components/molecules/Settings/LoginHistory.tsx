const dataLoginHistory = [
  {
    id: '001',
    date: '30 Jun 2024',
    hour: '21:13:58',
    ubication: 'Lima, PE',
    device: 'Windows 11',
  },
  {
    id: '002',
    date: '17 Jun 2024',
    hour: '20:13:58',
    ubication: 'Pucallpa, PE',
    device: 'Windows 11',
  },
  {
    id: '003',
    date: '30 Jun 2024',
    hour: '21:13:58',
    ubication: 'Lima, PE',
    device: 'Windows 11',
  },
  {
    id: '004',
    date: '17 Jun 2024',
    hour: '20:13:58',
    ubication: 'Pucallpa, PE',
    device: 'Windows 11',
  },
]

export default function LoginHistory({ setView }) {
  return (
    <div className="flex flex-col gap-5 text-secondary dark:text-white font-inter">
      <div
        className="bg-backgroundF-100 rounded-4xl flex justify-center items-center text-xs font-medium w-[101px] h-[23px]"
        role="button"
        tabIndex={0}
        onClick={() => setView('main')}
      >
        Volver
      </div>
      <span className="text-xl font-semibold">
        Historial de inicio de sesión
      </span>
      <p className="text-sm">
        Historial de inicio de sesión para acceso a la cuenta de la empresa,
        sirve para controlar la ubicación, fecha, hora y dispositivo mediante el
        cual se accedió a la cuenta para poder tener un mejor control del acceso
        a la misma.
      </p>
      <div>
        <div className="grid xs:grid-cols-[40px_1fr_1fr_1fr] sm:grid-cols-[100px_1fr_1fr_1fr] xs:gap-2 sm:gap-4 p-3 text-center">
          <span className="font-semibold">N°</span>
          <span className="font-semibold">Fecha y hora</span>
          <span className="font-semibold">Ubicación</span>
          <span className="font-semibold">Dispositivo</span>
        </div>
        <div className="bg-primary-foreground border-[1px] border-secondary-300 flex flex-col p-3 gap-4 text-secondary-500">
          {dataLoginHistory?.map((data, index) => (
            <div
              key={data.id}
              className="grid xs:grid-cols-[40px_1fr_1fr_1fr] sm:grid-cols-[100px_1fr_1fr_1fr] xs:gap-2 sm:gap-4 items-center  text-center"
            >
              <span className="xs:text-sm sm:text-base">{`${index + 1}°`}</span>
              <div className="flex flex-col items-center">
                <span className="xs:text-sm sm:text-base">{data.date}</span>
                <span className="xs:text-sm sm:text-base">{data.hour}</span>
              </div>
              <span className="xs:text-sm sm:text-base">{data.ubication}</span>
              <span className="xs:text-sm sm:text-base">{data.device}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
