import {
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form'
import { Input } from '@/components/ui/input'
import { Control, FieldPath, useFormState } from 'react-hook-form'
import { z, ZodSchema } from 'zod'

interface FormChangeProps<TSchema extends ZodSchema> {
  name: FieldPath<z.infer<TSchema>>
  label?: string
  placeholder: string
  description?: string
  inputType?: string
  formControl: Control<z.infer<TSchema>, any>
  schema: TSchema
}

export default function FormChange<TSchema extends ZodSchema>({
  name,
  label,
  placeholder,
  description,
  inputType,
  formControl,
}: FormChangeProps<TSchema>) {
  const { errors } = useFormState({ control: formControl })
  const hasError = !!errors[name]

  return (
    <FormField
      control={formControl}
      name={name}
      render={({ field }) => (
        <FormItem className="space-y-1 font-inter xs:w-full sm:w-[85%]">
          <FormLabel className="text-muted-500 text-xs">{label}</FormLabel>
          <FormControl style={{ display: 'flex', justifyContent: 'center' }}>
            <Input
              //style={hasError ? {border: "solid 1px"} : {border: 'none'}}
              variant="floatingLabel"
              label={placeholder}
              className={`w-full ${
                hasError ? 'border border-red-500 text-red-500' : ''
              }`}
              //placeholder={placeholder}
              type={inputType || 'text'}
              {...field}
            />
          </FormControl>
          {description && <FormDescription>{description}</FormDescription>}
          <FormMessage className="text-[10px]" />
        </FormItem>
      )}
    />
  )
}
