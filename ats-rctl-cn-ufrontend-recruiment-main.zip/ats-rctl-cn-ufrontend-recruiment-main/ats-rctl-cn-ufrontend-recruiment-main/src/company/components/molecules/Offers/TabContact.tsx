import {
  IconBrandGithub,
  IconBrandLinkedin,
  IconBrandWhatsapp,
  IconDeviceMobile,
  IconMail,
} from '@tabler/icons-react'

export default function TabContact({ offer }) {
  return (
    <div className="bg-card p-5 flex flex-col gap-4 rounded-b-[16px] font-inter text-secondary-500 dark:text-white">
      <div className="flex flex-col gap-2">
        <span className="xs:text-sm sm:text-base font-medium">Sobre mí</span>
        <p className="text-xs text-justify">{offer?.aboutMe}</p>
      </div>
      <div className="flex flex-col gap-2">
        <span className="xs:text-sm sm:text-base font-medium">Contáctame</span>
        <div className="flex flex-wrap gap-3 dark:text-secondary-500">
          <div className="flex flex-row gap-2 bg-[#F0F2F4] rounded-[20px] items-center px-3 h-8">
            <IconMail stroke={1.5} size={16} />
            <span className="xs:text-xs sm:text-sm">{offer?.email}</span>
          </div>
          <div className="flex flex-row gap-2 bg-[#F0F2F4] rounded-[20px] items-center px-3 h-8">
            <IconDeviceMobile stroke={1.5} size={16} />
            <span className="xs:text-xs sm:text-sm">{offer?.phone}</span>
          </div>
        </div>
      </div>
      <div className="flex flex-col gap-2">
        <span className="xs:text-sm sm:text-base font-medium">Links</span>
        <div className="flex flex-wrap gap-3 dark:text-secondary-500">
          <div className="flex flex-row gap-2 bg-[#F0F2F4] rounded-[20px] items-center px-3 h-8 cursor-pointer">
            <IconBrandLinkedin stroke={1.5} size={16} />
            <span className="xs:text-xs sm:text-sm">Linkedln</span>
          </div>
          <div className="flex flex-row gap-2 bg-[#F0F2F4] rounded-[20px] items-center px-3 h-8 cursor-pointer">
            <IconBrandGithub stroke={1.5} size={16} />
            <span className="xs:text-xs sm:text-sm">Github</span>
          </div>
          <div className="flex flex-row gap-2 bg-[#F0F2F4] rounded-[20px] items-center px-3 h-8 cursor-pointer">
            <IconBrandWhatsapp stroke={1.5} size={16} />
            <span className="xs:text-xs sm:text-sm">Whatsapp</span>
          </div>
        </div>
      </div>
    </div>
  )
}
