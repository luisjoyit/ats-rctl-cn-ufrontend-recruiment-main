import { IconCertificate } from '@tabler/icons-react'

export default function TabEducation({ education, certificates }) {
  return (
    <div className="bg-card p-5 flex flex-col gap-3 rounded-b-[16px] font-inter text-secondary-500 dark:text-white">
      <span className="xs:text-sm sm:text-base font-medium pb-1">
        Educación
      </span>
      <div className="relative">
        {education?.map((item, index) => (
          <div key={index} className="relative flex pb-5">
            <div className="absolute inset-0 flex items-center">
              {index !== education?.length - 1 && (
                <div className="w-0.5 h-full bg-secondary-500 dark:bg-white ml-[6.5px] mt-2 z-0"></div>
              )}
            </div>
            <div className="flex-shrink-0 z-10 w-3.5 h-3.5 rounded-full bg-white border-2 border-secondary-500 mt-1"></div>
            <div className="ml-4 flex flex-col gap-1.5">
              <span className="font-medium text-sm">{item.name}</span>
              <span className="text-[#5A5A5A] text-xs">{`${item.date[0]} - ${item.date[1]}`}</span>
            </div>
          </div>
        ))}
      </div>
      <div className="flex flex-col gap-3">
        <span className="xs:text-sm sm:text-base font-medium">
          Certificados
        </span>
        {certificates?.map((item, index) => (
          <div key={index} className="flex flex-row gap-2">
            <div className="w-4.5">
              <IconCertificate
                stroke={1.5}
                size={18}
                className="text-secondary-500 dark:text-white"
              />
            </div>
            <span className="xs:text-xs sm:text-sm font-medium">
              {item.name}
            </span>
          </div>
        ))}
      </div>
    </div>
  )
}
