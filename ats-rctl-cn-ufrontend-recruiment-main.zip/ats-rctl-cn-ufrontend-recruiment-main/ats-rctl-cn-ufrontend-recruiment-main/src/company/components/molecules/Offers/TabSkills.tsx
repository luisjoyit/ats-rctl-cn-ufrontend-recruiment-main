export default function TabSkills({ skills, habilities }) {
  return (
    <div className="bg-card p-5 flex flex-col gap-4 rounded-b-[16px] font-inter text-secondary-500">
      <div className="flex flex-col gap-3">
        <span className="xs:text-sm sm:text-base font-medium dark:text-white">
          Stack Tech
        </span>
        <div className="flex flex-wrap gap-3">
          {skills.map((item, index) => (
            <span
              key={index}
              className="bg-[#F0F2F4] rounded-[30px] xs:text-xs sm:text-sm text-center px-3 h-[33px] w-auto flex items-center"
            >
              {item}
            </span>
          ))}
        </div>
      </div>
      <div className="flex flex-col gap-3">
        <span className="xs:text-sm sm:text-base font-medium dark:text-white">
          Habilidades blandas
        </span>
        <div className="flex flex-wrap gap-3">
          {habilities.map((item, index) => (
            <span
              key={index}
              className="bg-[#F0F2F4] rounded-[30px] xs:text-xs sm:text-sm text-center px-3 h-[33px] w-auto flex items-center"
            >
              {item}
            </span>
          ))}
        </div>
      </div>
    </div>
  )
}
