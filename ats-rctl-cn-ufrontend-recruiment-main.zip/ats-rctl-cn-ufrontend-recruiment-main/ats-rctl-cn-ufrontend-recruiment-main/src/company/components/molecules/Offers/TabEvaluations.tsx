import { IconMoodUp } from '@tabler/icons-react'

export default function TabEvaluations({ evaluations }) {
  const getColorIconEvaluations = (score: number) => {
    switch (true) {
      case score < 50:
        return { stroke: 'red' }
      case 50 <= score && score < 75:
        return { stroke: '#FC8862' }
      case score >= 75:
        return { stroke: '#10A330' }
    }
  }

  return (
    <div className="bg-card p-5 flex flex-col gap-4 rounded-b-[16px] font-inter text-secondary-500 dark:text-white">
      <span className="xs:text-sm sm:text-base font-medium pb-1">
        Evaluaciones
      </span>
      {evaluations?.map((item, index) => (
        <div key={index} className="flex flex-row gap-3">
          <div className="w-7">
            <IconMoodUp
              stroke={1.5}
              style={getColorIconEvaluations(item.score)}
            />
          </div>
          <span className="xs:text-sm sm:text-base w-44">{item.name}</span>
          <span className="xs:text-sm sm:text-base font-medium">{`${item.score}%`}</span>
        </div>
      ))}
    </div>
  )
}
