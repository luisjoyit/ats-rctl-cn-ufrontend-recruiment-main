import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import React, { useState } from 'react'
import {
  IconAdjustmentsHorizontal,
  IconMapPin,
  IconX,
} from '@tabler/icons-react'
import InputWithIcon from '@/components/inputWithIcon'
import Tags from '@/components/tags'
import {
  AlertDialog,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog'
import FiltersStacks from '@/aplicant/components/molecules/FiltersStacks'
import SelectUi from '@/components/SelectUi'
import Slider from 'rc-slider'
import { Checkbox } from '@/components/ui/checkbox'

const initialValuesFilters = {
  profile: '',
  country: '',
  city: '',
  modality: '',
  salary: [500, 2500],
  order: '',
  levelExperience: '',
  stackTech: [],
  adHonorem: false,
  language: '',
}

export default function FiltersTalent() {
  const [open, setOpen] = useState(false)
  const [dataFilters, setDataFilters] = useState(initialValuesFilters)
  const [sliderKey, setSliderKey] = useState(Date.now())
  const [rangeSalary, setRangeSalary] = useState(dataFilters.salary)

  const handleFiltersChange = (name: string, value: any) => {
    setDataFilters({ ...dataFilters, [name]: value })
  }

  const handleRangeSalary = (newRange) => {
    setRangeSalary(newRange)
    setDataFilters((prevState) => ({ ...prevState, salary: newRange }))
  }

  const handleSubmit = () => {
    setOpen(false)
  }

  const cleanFilters = () => {
    setDataFilters(initialValuesFilters)
    setRangeSalary([500, 2500])
    setOpen(false)
  }

  const itemsOrder = [
    {
      value: 'moreRelevant',
      label: 'Más relevante',
    },
    {
      value: 'latest',
      label: 'Más reciente',
    },
  ]

  const itemsProfile = [
    {
      value: 'mobile',
      label: 'Mobile',
    },
    {
      value: 'frontend',
      label: 'Frontend',
    },
    {
      value: 'backend',
      label: 'Backend',
    },
    {
      value: 'itManagement',
      label: 'IT Management',
    },
    {
      value: 'data',
      label: 'Data',
    },
    {
      value: 'devops',
      label: 'DevOps',
    },
    {
      value: 'web3',
      label: 'Web3',
    },
    {
      value: 'qa',
      label: 'QA',
    },
    {
      value: 'sap',
      label: 'SAP',
    },
    {
      value: 'product',
      label: 'Producto',
    },
    {
      value: 'others',
      label: 'Others',
    },
  ]

  const itemsModality = [
    {
      value: 'remote',
      label: 'Remoto',
    },
    {
      value: 'hybrid',
      label: 'Híbrido',
    },
    {
      value: 'inPerson',
      label: 'Presencial',
    },
    {
      value: 'freelance',
      label: 'Freelance',
    },
  ]

  const stackSuggestions = [
    { value: 'html', label: 'HTML' },
    { value: 'javascript', label: 'JavaScript' },
    { value: 'css', label: 'CSS' },
    { value: 'angular', label: 'Angular' },
    { value: 'nodejs', label: 'Node.JS' },
  ]

  const itemsLanguage = [
    {
      value: 'spanish',
      label: 'Español',
    },
    {
      value: 'english',
      label: 'Inglés',
    },
  ]

  return (
    <div className="flex flex-col gap-4">
      <div className="flex justify-between font-inter text-secondary-500 w-full">
        <div className="flex gap-3 w-full justify-between">
          <InputWithIcon
            placeholder="Nombre del empleo"
            className="lg:w-[50%]"
            heightInput="h-[31px]"
          />
          <InputWithIcon
            placeholder="Ubicación"
            icon={<IconMapPin className="w-full h-full" stroke={1.5} />}
            className="lg:w-[30%]"
            heightInput="h-[31px]"
          />
          <AlertDialog open={open} onOpenChange={setOpen}>
            <AlertDialogTrigger>
              <Button variant="primary" size="sm" className="w-[84px] gap-3">
                <IconAdjustmentsHorizontal stroke={1} size={18} />
                Filtros
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent style={{ gap: 0 }} className="max-w-[540px]">
              <AlertDialogHeader>
                <div className="flex justify-end">
                  <IconX
                    stroke={1.5}
                    size={20}
                    color="#263658"
                    className="close text-2xl cursor-pointer"
                    onClick={cleanFilters}
                  />
                </div>
                <AlertDialogTitle
                  className="text-start font-semibold text-secondary-500"
                  style={{ marginTop: 0 }}
                >
                  Filtros
                </AlertDialogTitle>
              </AlertDialogHeader>
              <AlertDialogDescription className="text-secondary-500 flex flex-col gap-6">
                <div className="flex flex-col gap-3 pt-2">
                  <span className="text-start font-medium text-sm">
                    Ordenar por
                  </span>
                  <div className="flex flex-wrap gap-y-3 gap-x-2">
                    {itemsOrder.map((item, id) => (
                      <button
                        key={id}
                        className={`h-[31px] w-auto px-3 rounded-[50px] ${dataFilters.order === item.value ? 'bg-secondary-500 text-white' : 'bg-accent-200 dark:bg-[#EAEFF0]'}`}
                        onClick={() => handleFiltersChange('order', item.value)}
                      >
                        {item.label}
                      </button>
                    ))}
                  </div>
                </div>
                <div className="flex flex-col gap-3">
                  <span className="text-start font-medium text-sm">Perfil</span>
                  <div className="flex flex-wrap gap-y-3 gap-x-2">
                    {itemsProfile.map((item, id) => (
                      <button
                        key={id}
                        className={`h-[31px] w-auto px-3 rounded-[50px] ${dataFilters.profile === item.value ? 'bg-secondary-500 text-white' : 'bg-accent-200 dark:bg-[#EAEFF0]'}`}
                        onClick={() =>
                          handleFiltersChange('profile', item.value)
                        }
                      >
                        {item.label}
                      </button>
                    ))}
                  </div>
                </div>
                <div className="flex flex-col gap-3">
                  <span className="text-start font-medium text-sm">
                    Modalidad
                  </span>
                  <div className="flex flex-wrap gap-y-3 gap-x-2">
                    {itemsModality.map((item, id) => (
                      <button
                        key={id}
                        className={`h-[31px] w-auto px-3 rounded-[50px] ${dataFilters.modality === item.value ? 'bg-secondary-500 text-white' : 'bg-accent-200 dark:bg-[#EAEFF0]'}`}
                        onClick={() =>
                          handleFiltersChange('modality', item.value)
                        }
                      >
                        {item.label}
                      </button>
                    ))}
                  </div>
                </div>
                <div className="flex flex-col gap-3">
                  <span className="text-start font-medium text-sm">
                    Stack Tech
                  </span>
                  <FiltersStacks
                    name="stackTech"
                    value={dataFilters.stackTech}
                    onChange={handleFiltersChange}
                    suggestions={stackSuggestions}
                  />
                </div>
                <div className="flex flex-col gap-3">
                  <span className="text-start font-medium text-sm">Nivel</span>
                  <SelectUi
                    placeholder="Seleccionar"
                    items={[
                      { value: 'trainee', label: 'Trainee' },
                      { value: 'junior', label: 'Junior' },
                      { value: 'semiSenior', label: 'Semi Senior' },
                      { value: 'senior', label: 'Senior' },
                    ]}
                    name="levelExperience"
                    value={dataFilters.levelExperience}
                    onChange={handleFiltersChange}
                    className="border border-muted-100 w-full"
                  />
                </div>
                <div className="flex xs:gap-3 md:gap-6 w-full">
                  <div className="flex flex-col gap-3 w-full">
                    <span className="text-start font-medium text-sm">País</span>
                    <SelectUi
                      placeholder="Seleccionar"
                      value={dataFilters.country}
                      onChange={handleFiltersChange}
                      items={[
                        { value: 'peru', label: 'Perú' },
                        { value: 'bolivia', label: 'Bolivia' },
                        { value: 'chile', label: 'Chile' },
                        { value: 'colombia', label: 'Colombia' },
                      ]}
                      name="country"
                      className="border border-muted-100 xs:w-full md:w-[229px] placeholder:muted-300"
                    />
                  </div>
                  <div className="flex flex-col gap-3 w-full">
                    <span className="text-start font-medium text-sm">
                      Ciudad
                    </span>
                    <SelectUi
                      placeholder="Seleccionar"
                      value={dataFilters.city}
                      onChange={handleFiltersChange}
                      items={[
                        { value: 'lima', label: 'Lima' },
                        { value: 'bogota', label: 'Bogotá' },
                        { value: 'sucre', label: 'Sucre' },
                        { value: 'santiago', label: 'Santiago' },
                      ]}
                      name="city"
                      className="border border-muted-100 xs:w-full md:w-[229px] placeholder:muted-300"
                    />
                  </div>
                </div>
                <div className="flex flex-col gap-3">
                  <span className="text-start font-medium text-sm">Idioma</span>
                  <div className="flex flex-wrap gap-y-3 gap-x-2">
                    {itemsLanguage.map((item, id) => (
                      <button
                        key={id}
                        className={`h-[31px] w-auto px-3 rounded-[50px] ${dataFilters.language === item.value ? 'bg-secondary-500 text-white' : 'bg-accent-200 dark:bg-[#EAEFF0]'}`}
                        onClick={() =>
                          handleFiltersChange('language', item.value)
                        }
                      >
                        {item.label}
                      </button>
                    ))}
                  </div>
                </div>
                <div className="flex flex-col gap-3">
                  <span className="text-start font-medium text-sm">
                    Expectativa Salarial
                  </span>
                  <div className="flex flex-col gap-4 w-full">
                    <Slider
                      key={sliderKey}
                      min={0}
                      max={20000}
                      step={100}
                      range
                      value={rangeSalary}
                      onChange={(newRange) => handleRangeSalary(newRange)}
                      className="slider-salary-job slider-range-filters w-full"
                    />
                    <div className="flex items-center w-full justify-between">
                      <div className="flex xs:gap-2 md:gap-4 items-center">
                        <span className="text-sm">de</span>
                        <div className="w-[85px]">
                          <Input
                            value={dataFilters.salary[0]}
                            preffix="$"
                            onChange={(e) =>
                              handleRangeSalary([
                                Number(e.target.value),
                                dataFilters.salary[1],
                              ])
                            }
                            className="h-[31px] w-full rounded-[50px]"
                          />
                        </div>
                        <span className="text-sm">a</span>
                        <div className="w-[85px]">
                          <Input
                            value={dataFilters.salary[1]}
                            preffix="$"
                            onChange={(e) =>
                              handleRangeSalary([
                                dataFilters.salary[0],
                                Number(e.target.value),
                              ])
                            }
                            className="h-[31px] w-full rounded-[50px]"
                          />
                        </div>
                      </div>
                      <div className="flex gap-2 items-center">
                        <Checkbox
                          checked={dataFilters.adHonorem}
                          onCheckedChange={(checked) =>
                            handleFiltersChange('adHonorem', checked)
                          }
                          className="mr-1"
                        />
                        <label
                          className={`xs:text-sm md:text-base text-muted-300 md:whitespace-nowrap ${dataFilters.adHonorem && 'text-secondary-500 dark:text-white'}`}
                        >
                          Ad honorem
                        </label>
                      </div>
                    </div>
                  </div>
                </div>
              </AlertDialogDescription>
              <AlertDialogFooter className="xs:w-full flex-row xs:justify-around sm:justify-around mt-8">
                <Button
                  variant="secondary"
                  size="sm"
                  className="xs:w-24 sm:w-36"
                  onClick={cleanFilters}
                >
                  Limpiar todo
                </Button>
                <Button
                  variant="primary"
                  size="sm"
                  className="xs:w-24 sm:w-36"
                  onClick={handleSubmit}
                >
                  Aplicar
                </Button>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      </div>
      <Tags tags={[{ id: 1, name: 'Frontend' }]} />
    </div>
  )
}
