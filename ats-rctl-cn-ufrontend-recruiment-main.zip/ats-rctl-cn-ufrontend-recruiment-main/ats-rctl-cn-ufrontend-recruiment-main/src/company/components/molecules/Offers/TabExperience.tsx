import { IconPointFilled } from '@tabler/icons-react'

export default function TabExperience({ experience }) {
  return (
    <div className="bg-card p-5 flex flex-col gap-4 rounded-b-[16px] font-inter text-secondary-500 dark:text-white">
      <div className="relative">
        {experience?.map((item, index) => (
          <div key={index} className="relative flex pb-5">
            <div className="absolute inset-0 flex items-center">
              {index !== experience?.length - 1 && (
                <div className="w-0.5 h-full bg-secondary-500 dark:bg-white ml-[6.5px] mt-2 z-0"></div>
              )}
            </div>
            <div className="flex-shrink-0 z-10 w-3.5 h-3.5 rounded-full bg-white border-2 border-secondary-500 mt-1"></div>
            <div className="ml-4 flex flex-col gap-1.5">
              <span className="font-medium text-sm">{item.position}</span>
              <span className="text-[#5A5A5A] text-xs">{`${item.dates[0]} - ${item.dates[1]}`}</span>
              <div className="flex flex-col">
                {item.activities.map((element, idx) => (
                  <div key={idx} className="flex flex-row gap-0.5 items-center">
                    <IconPointFilled size={12} />
                    <span className="text-xs">{element}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
