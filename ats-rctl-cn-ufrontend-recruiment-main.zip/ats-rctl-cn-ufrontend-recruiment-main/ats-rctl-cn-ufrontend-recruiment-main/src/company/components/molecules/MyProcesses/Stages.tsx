import { Checkbox } from '@/components/ui/checkbox'
import { IconPlus, IconSortDescending } from '@tabler/icons-react'
import Cards from './Cards'
import { useMemo, useState } from 'react'
import { Card, Stage } from '@/company/types'
import { SortableContext, useSortable } from '@dnd-kit/sortable'
import { CSS } from '@dnd-kit/utilities'
import useMediaQuery from '@/hooks/useMediaQuery'

interface StagesProps {
  stage: Stage
  cards: Card[]
  setCards: React.Dispatch<React.SetStateAction<Card[]>>
  selectedCardId: number | string | null
  onSelectCard: (id: number | string) => void
}

export default function Stages({
  stage,
  cards,
  setCards,
  selectedCardId,
  onSelectCard,
}: StagesProps) {
  const [isChecked, setIsChecked] = useState(false)

  const isMobile = useMediaQuery('(max-width: 640px)')

  const handleCheckboxChange = (event) => {
    setIsChecked(event)
  }

  const cardsIds = useMemo(() => {
    return cards.map((card) => card.id)
  }, [cards])

  const { setNodeRef, transform, transition } = useSortable({
    id: stage.id,
    data: {
      type: 'Stage',
      stage,
    },
  })

  const style = {
    transition,
    transform: CSS.Transform.toString(transform),
  }

  const stagesOrder: string[] = [
    'applicants',
    'evaluations',
    'interviews',
    'offers',
  ]

  const moveCardStage = (id: number | string) => {
    setCards((prevCards) => {
      return prevCards.map((card) => {
        if (card.id === id) {
          const currentStageIndex = stagesOrder.indexOf(card.stageId as string)
          const nextStageIndex = currentStageIndex + 1
          if (nextStageIndex < stagesOrder.length) {
            card.stageId = stagesOrder[nextStageIndex]
          }
        }
        return card
      })
    })
  }

  const getHeaderStage = () => {
    const card = cards.find((card) => card.id === selectedCardId)
    if (card?.stageId === stage.id)
      return (
        <div
          className={`flex flex-row text-secondary-500 ${
            isMobile ? 'justify-between' : 'justify-end'
          }`}
        >
          {isMobile && stage.id !== 'offers' && (
            <div
              className="flex items-center bg-backgroundF-500 rounded-4xl px-2 h-[23px] cursor-pointer"
              role="button"
              tabIndex={0}
              onClick={() => moveCardStage(selectedCardId)}
            >
              <span className="font-medium text-xs">Siguiente Etapa</span>
            </div>
          )}
          <div className="flex items-center bg-backgroundF-500 rounded-4xl px-2 h-[23px] cursor-pointer">
            <span className="font-medium text-xs">Rechazar Postulación</span>
          </div>
        </div>
      )
    else
      return (
        <div className="flex flex-row justify-between text-secondary-500">
          <div className="flex flex-row gap-1.5 items-center">
            <Checkbox
              id={stage?.name}
              checked={isChecked}
              onCheckedChange={handleCheckboxChange}
            />
            <span className="text-sm">{stage?.name}</span>
          </div>
          <div className="flex flex-row gap-2">
            {stage.id === 'applicants' && !isChecked && (
              <button className="flex flex-row items-center bg-backgroundF-500 rounded-4xl h-[23px] xs:gap-0.5 sm:gap-1 xs:px-1 sm:px-2 text-xs">
                <IconPlus stroke={2} size={12} />
                Añadir candidato
              </button>
            )}
            {isChecked && (
              <button className="flex items-center bg-backgroundF-500 rounded-4xl h-[23px] w-[93px] px-2 text-xs">
                Cerrar Etapa
              </button>
            )}
            {!isChecked && (
              <div className="bg-[#F0F2F4] rounded-4xl h-[23px] px-2 flex items-center">
                <IconSortDescending stroke={2} size={14} />
              </div>
            )}
          </div>
        </div>
      )
  }

  return (
    <div
      ref={setNodeRef}
      style={style}
      className="flex flex-col h-[714px] xs:w-[290px] sm:w-[327px] xs:min-w-[290px] sm:min-w-[327px] bg-white 
                rounded-4xl px-4 py-6 text-secondary-500 gap-4"
    >
      {getHeaderStage()}
      <div className="flex flex-row justify-between font-inter">
        <div className="flex gap-2 items-end">
          <span className="text-xl font-semibold">32</span>
          <span className="text-sm font-semibold text-accent-600 relative bottom-[2px]">
            Rechazados
          </span>
        </div>
        <div className="flex flex-row gap-2 items-end">
          <span className="text-xl font-semibold">68</span>
          <span className="text-sm font-semibold text-accent-600 relative bottom-[2px]">
            Total
          </span>
        </div>
      </div>
      <hr
        className={`border-[2px] rounded-4xl`}
        style={stage.color && { borderColor: stage.color }}
      ></hr>
      <div
        className="w-full h-full flex flex-col gap-4 items-center 
                overflow-y-auto scrollbar-thin scrollbar-thumb-gray-400 scrollbar-track-gray-200
                py-1 px-2"
      >
        <SortableContext items={cardsIds}>
          {cards.map((card) => (
            <Cards
              key={card.id}
              card={card}
              isSelected={selectedCardId === card.id}
              selectCard={onSelectCard}
            />
          ))}
        </SortableContext>
      </div>
    </div>
  )
}
