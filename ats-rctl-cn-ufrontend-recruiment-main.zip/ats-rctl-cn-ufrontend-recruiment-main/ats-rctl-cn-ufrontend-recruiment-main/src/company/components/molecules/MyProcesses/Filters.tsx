import {
  AlertDialog,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog'
import { Button } from '@/components/ui/button'
import { IconAdjustmentsHorizontal, IconX } from '@tabler/icons-react'
import React, { useState } from 'react'

const initialValuesFilters = {
  order: '',
  profile: '',
  modality: '',
  stage: '',
}

export default function Filters() {
  const [open, setOpen] = useState(false)
  const [dataFilters, setDataFilters] = useState(initialValuesFilters)

  const handleFiltersChange = (name: string, value: any) => {
    setDataFilters({ ...dataFilters, [name]: value })
  }

  const handleSubmit = () => {
    setOpen(false)
  }

  const cleanFilters = () => {
    setDataFilters(initialValuesFilters)
    //setOpen(false)
  }

  const itemsOrder = [
    { value: 'latest', label: 'Más reciente' },
    { value: 'oldest', label: 'Más antiguo' },
  ]

  const itemsProfile = [
    { value: 'mobile', label: 'Mobile' },
    { value: 'frontend', label: 'Frontend' },
    { value: 'backend', label: 'Backend' },
    { value: 'itManagement', label: 'IT Management' },
    { value: 'data', label: 'Data' },
    { value: 'devops', label: 'DevOps' },
    { value: 'web3', label: 'Web3' },
    { value: 'qa', label: 'QA' },
    { value: 'sap', label: 'SAP' },
    { value: 'product', label: 'Producto' },
    { value: 'others', label: 'Otros' },
  ]

  const itemsModality = [
    { value: 'remote', label: 'Remoto' },
    { value: 'hybrid', label: 'Híbrido' },
    { value: 'inPerson', label: 'Presencial' },
    { value: 'freelance', label: 'Freelance' },
  ]

  const itemsStage = [
    { value: 'postulated', label: 'Postulados' },
    { value: 'inProgress', label: 'En Progreso' },
    { value: 'finished', label: 'Finalizado' },
  ]

  return (
    <AlertDialog open={open} onOpenChange={setOpen}>
      <AlertDialogTrigger>
        <Button variant="primary" size="sm" className="justify-around w-[90px]">
          <IconAdjustmentsHorizontal stroke={1} size={18} />
          Filtros
        </Button>
      </AlertDialogTrigger>
      <AlertDialogContent style={{ gap: 0 }} className="max-w-[540px]">
        <AlertDialogHeader>
          <div className="flex justify-between items-center">
            <AlertDialogTitle className="text-start font-semibold text-secondary-500">
              Filtros
            </AlertDialogTitle>
            <IconX
              stroke={1.5}
              size={20}
              color="#263658"
              className="close text-2xl cursor-pointer"
              onClick={() => setOpen(false)}
            />
          </div>
        </AlertDialogHeader>
        <AlertDialogDescription className="text-secondary-500 flex flex-col gap-6">
          <div className="flex flex-col gap-3 pt-2">
            <span className="text-start font-medium text-sm">Ordenar por</span>
            <div className="flex flex-wrap gap-y-3 gap-x-2">
              {itemsOrder.map((item, id) => (
                <button
                  key={id}
                  className={`h-[31px] w-auto px-3 rounded-[50px] ${
                    dataFilters.order === item.value
                      ? 'bg-secondary-500 text-white'
                      : 'bg-accent-200 dark:bg-[#EAEFF0]'
                  }`}
                  onClick={() => handleFiltersChange('order', item.value)}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>
          <div className="flex flex-col gap-3">
            <span className="text-start font-medium text-sm">Perfil</span>
            <div className="flex flex-wrap gap-y-3 gap-x-2">
              {itemsProfile.map((item, id) => (
                <button
                  key={id}
                  className={`h-[31px] w-auto px-3 rounded-[50px] ${
                    dataFilters.profile === item.value
                      ? 'bg-secondary-500 text-white'
                      : 'bg-accent-200 dark:bg-[#EAEFF0]'
                  }`}
                  onClick={() => handleFiltersChange('profile', item.value)}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>
          <div className="flex flex-col gap-3">
            <span className="text-start font-medium text-sm">Modalidad</span>
            <div className="flex flex-wrap gap-y-3 gap-x-2">
              {itemsModality.map((item, id) => (
                <button
                  key={id}
                  className={`h-[31px] w-auto px-3 rounded-[50px] ${
                    dataFilters.modality === item.value
                      ? 'bg-secondary-500 text-white'
                      : 'bg-accent-200 dark:bg-[#EAEFF0]'
                  }`}
                  onClick={() => handleFiltersChange('modality', item.value)}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>
          <div className="flex flex-col gap-3">
            <span className="text-start font-medium text-sm">Etapa</span>
            <div className="flex flex-wrap gap-y-3 gap-x-2">
              {itemsStage.map((item, id) => (
                <button
                  key={id}
                  className={`h-[31px] w-auto px-3 rounded-xl ${
                    dataFilters.stage === item.value
                      ? 'bg-secondary-500 text-white'
                      : 'bg-accent-200 dark:bg-[#EAEFF0]'
                  }`}
                  onClick={() => handleFiltersChange('stage', item.value)}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>
        </AlertDialogDescription>
        <AlertDialogFooter className="xs:w-full flex-row xs:justify-between sm:justify-between mt-8">
          <Button
            variant="secondary"
            size="sm"
            className="xs:w-24 sm:w-36"
            onClick={cleanFilters}
          >
            Limpiar todo
          </Button>
          <Button
            variant="primary"
            size="sm"
            className="xs:w-24 sm:w-36"
            onClick={handleSubmit}
          >
            Aplicar
          </Button>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  )
}
