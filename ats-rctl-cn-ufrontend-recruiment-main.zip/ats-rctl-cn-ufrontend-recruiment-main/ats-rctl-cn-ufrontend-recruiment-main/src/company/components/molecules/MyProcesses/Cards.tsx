import React, { useEffect, useState } from 'react'
import { Card } from '@/company/types'
import { useSortable } from '@dnd-kit/sortable'
import { CSS } from '@dnd-kit/utilities'
import useMediaQuery from '@/hooks/useMediaQuery'

interface CardsProps {
  card: Card
  isSelected?: boolean
  selectCard?: (id: number | string) => void
}

export default function Cards({ card, isSelected, selectCard }: CardsProps) {
  const [mouseDown, setMouseDown] = useState(false)
  const isDesktop = useMediaQuery('(min-width: 640px)')

  const {
    setNodeRef,
    attributes,
    listeners,
    transform,
    transition,
    isDragging,
  } = useSortable({
    id: card.id,
    data: {
      type: 'Card',
      card,
    },
  })

  const style = {
    transition,
    transform: CSS.Transform.toString(transform),
  }

  const handleMouseDown = (e) => {
    e.stopPropagation()
    setMouseDown(true)
  }

  const handleMouseUp = (e) => {
    if (mouseDown) {
      e.stopPropagation()
      selectCard(card.id)
      setMouseDown(false)
    }
  }

  const handleMouseLeave = (e) => {
    if (mouseDown) {
      setMouseDown(false)
    }
  }

  return (
    <div
      ref={isDesktop ? setNodeRef : null}
      style={style}
      {...attributes}
      {...listeners}
      className={`
                w-full xs:h-auto sm:h-[95px] flex flex-row 
                gap-3 rounded-[22px] p-4 
                shadow-[0px_0px_2.1px_0px_#00000040]
                cursor-pointer
                ${isSelected ? 'bg-backgroundF-500' : 'bg-white'}
                ${isDragging && 'border-2 border-primary opacity-75'}
            `}
      role="button"
      tabIndex={0}
      onMouseDown={handleMouseDown}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseLeave}
    >
      <div className="flex items-center">
        <div className="relative h-16 w-16 items-center">
          <img
            src={card.imgProfile}
            alt=""
            className="h-[62px] w-[62px] rounded-full object-cover"
          />
          <img
            src={card.countryImg}
            alt=""
            className="absolute bottom-0 right-0 w-[17.5px] h-[17.5px] rounded-full object-cover"
          />
        </div>
      </div>
      <div className="text-secondary-500 font-inter flex flex-col gap-1 w-full">
        <div className="flex flex-row justify-between items-center">
          <span className="text-sm font-medium">{card.name}</span>
          {card.recent && (
            <div className="bg-[#F0F2F4] rounded-4xl px-2 w-[42px] h-[21px] flex items-center">
              <span className="text-xs font-medium">New</span>
            </div>
          )}
        </div>
        <span
          className={`text-xs ${
            isSelected ? 'text-secondary-500' : 'text-accent-600'
          }`}
        >
          {card.position}
        </span>
        <span className="text-xs">{`$${card.salary}/mes`}</span>
      </div>
    </div>
  )
}
