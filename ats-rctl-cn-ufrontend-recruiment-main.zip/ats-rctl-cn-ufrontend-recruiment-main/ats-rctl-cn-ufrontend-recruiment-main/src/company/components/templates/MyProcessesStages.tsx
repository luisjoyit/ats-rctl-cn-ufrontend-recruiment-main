import Stages from '../molecules/MyProcesses/Stages'
import { useState } from 'react'
import { DndContext, DragOverEvent, DragStartEvent } from '@dnd-kit/core'
import { Card, Stage } from '@/company/types'
import { arrayMove } from '@dnd-kit/sortable'
import { useNavigate } from 'react-router-dom'

export const dataApplicants = [
  {
    id: 1,
    stageId: 'applicants',
    name: 'Sofía Alvarado',
    position: 'Frontend',
    salary: 3000,
    imgProfile: 'https://avatars.githubusercontent.com/u/124599?v=4',
    countryImg:
      'https://w7.pngwing.com/pngs/205/835/png-transparent-flag-of-peru-national-flag-flag-of-scotland-portugal-miscellaneous-flag-text.png',
    recent: true,
  },
  {
    id: 2,
    stageId: 'applicants',
    name: 'Sofía Alvarado',
    position: 'Frontend',
    salary: 3000,
    imgProfile: 'https://avatars.githubusercontent.com/u/124599?v=4',
    countryImg:
      'https://w7.pngwing.com/pngs/205/835/png-transparent-flag-of-peru-national-flag-flag-of-scotland-portugal-miscellaneous-flag-text.png',
    recent: true,
  },
  {
    id: 3,
    stageId: 'applicants',
    name: 'Sofía Alvarado',
    position: 'Frontend',
    salary: 3000,
    imgProfile: 'https://avatars.githubusercontent.com/u/124599?v=4',
    countryImg:
      'https://w7.pngwing.com/pngs/205/835/png-transparent-flag-of-peru-national-flag-flag-of-scotland-portugal-miscellaneous-flag-text.png',
    recent: false,
  },
  {
    id: 4,
    stageId: 'applicants',
    name: 'Sofía Alvarado',
    position: 'Frontend',
    salary: 3000,
    imgProfile: 'https://avatars.githubusercontent.com/u/124599?v=4',
    countryImg:
      'https://w7.pngwing.com/pngs/205/835/png-transparent-flag-of-peru-national-flag-flag-of-scotland-portugal-miscellaneous-flag-text.png',
    recent: false,
  },
  {
    id: 5,
    stageId: 'evaluations',
    name: 'Sofía Alvarado',
    position: 'Frontend',
    salary: 3000,
    imgProfile: 'https://avatars.githubusercontent.com/u/124599?v=4',
    countryImg:
      'https://w7.pngwing.com/pngs/205/835/png-transparent-flag-of-peru-national-flag-flag-of-scotland-portugal-miscellaneous-flag-text.png',
    recent: true,
  },
  {
    id: 6,
    stageId: 'evaluations',
    name: 'Sofía Alvarado',
    position: 'Frontend',
    salary: 3000,
    imgProfile: 'https://avatars.githubusercontent.com/u/124599?v=4',
    countryImg:
      'https://w7.pngwing.com/pngs/205/835/png-transparent-flag-of-peru-national-flag-flag-of-scotland-portugal-miscellaneous-flag-text.png',
    recent: true,
  },
  {
    id: 7,
    stageId: 'evaluations',
    name: 'Sofía Alvarado',
    position: 'Frontend',
    salary: 3000,
    imgProfile: 'https://avatars.githubusercontent.com/u/124599?v=4',
    countryImg:
      'https://w7.pngwing.com/pngs/205/835/png-transparent-flag-of-peru-national-flag-flag-of-scotland-portugal-miscellaneous-flag-text.png',
    recent: false,
  },
  {
    id: 8,
    stageId: 'evaluations',
    name: 'Sofía Alvarado',
    position: 'Frontend',
    salary: 3000,
    imgProfile: 'https://avatars.githubusercontent.com/u/124599?v=4',
    countryImg:
      'https://w7.pngwing.com/pngs/205/835/png-transparent-flag-of-peru-national-flag-flag-of-scotland-portugal-miscellaneous-flag-text.png',
    recent: false,
  },
  {
    id: 9,
    stageId: 'interviews',
    name: 'Sofía Alvarado',
    position: 'Frontend',
    salary: 3000,
    imgProfile: 'https://avatars.githubusercontent.com/u/124599?v=4',
    countryImg:
      'https://w7.pngwing.com/pngs/205/835/png-transparent-flag-of-peru-national-flag-flag-of-scotland-portugal-miscellaneous-flag-text.png',
    recent: false,
  },
  {
    id: 10,
    stageId: 'interviews',
    name: 'Sofía Alvarado',
    position: 'Frontend',
    salary: 3000,
    imgProfile: 'https://avatars.githubusercontent.com/u/124599?v=4',
    countryImg:
      'https://w7.pngwing.com/pngs/205/835/png-transparent-flag-of-peru-national-flag-flag-of-scotland-portugal-miscellaneous-flag-text.png',
    recent: false,
  },
  {
    id: 11,
    stageId: 'offers',
    name: 'Sofía Alvarado',
    position: 'Frontend',
    salary: 3000,
    imgProfile: 'https://avatars.githubusercontent.com/u/124599?v=4',
    countryImg:
      'https://w7.pngwing.com/pngs/205/835/png-transparent-flag-of-peru-national-flag-flag-of-scotland-portugal-miscellaneous-flag-text.png',
    recent: false,
  },
]

const dataStage = [
  {
    id: 'applicants',
    name: 'Aplicantes',
    color: '#00C851',
  },
  {
    id: 'evaluations',
    name: 'Evaluaciones',
    color: '#9C99FF',
  },
  {
    id: 'interviews',
    name: 'Entrevista',
    color: '#FFC898',
  },
  {
    id: 'offers',
    name: 'Oferta',
    color: '#FFA6F6',
  },
]

export default function MyProcessesStages() {
  const [selectedCardId, setSelectedCardId] = useState(null)

  const [stages, setStages] = useState<Stage[]>(dataStage)
  const [cards, setCards] = useState<Card[]>(dataApplicants)

  const [activeCard, setActiveCard] = useState<Card | null>(null)

  const handleSelectCard = (id) => {
    setSelectedCardId(selectedCardId === id ? null : id)
  }

  function onDragStart(event: DragStartEvent) {
    if (event.active.data.current?.type === 'Card') {
      setActiveCard(event.active.data.current.card)
      return
    }
  }

  function onDragOver(event: DragOverEvent) {
    const { active, over } = event
    if (!over) return

    const activeId = active.id
    const overId = over.id

    if (activeId === overId) return

    const isActiveACard = active.data.current?.type === 'Card'
    const isOverACard = over.data.current?.type === 'Card'

    if (!isActiveACard) return

    if (isActiveACard && isOverACard) {
      setCards((cards) => {
        const activeIndex = cards.findIndex((t) => t.id === activeId)
        const overIndex = cards.findIndex((t) => t.id === overId)

        cards[activeIndex].stageId = cards[overIndex].stageId

        return arrayMove(cards, activeIndex, overIndex)
      })
    }

    const isOverAStage = over.data.current?.type === 'Stage'

    if (isActiveACard && isOverAStage) {
      setCards((cards) => {
        const activeIndex = cards.findIndex((t) => t.id === activeId)

        cards[activeIndex].stageId = overId

        return arrayMove(cards, activeIndex, activeIndex)
      })
    }
  }

  return (
    <div className="flex flex-col font-inter text-secondary-500 gap-3">
      <div className="flex flex-row justify-start gap-4 overflow-x-auto scrollbar-regular scrollbar-thumb-gray-400 scrollbar-track-gray-200 pb-4">
        <DndContext onDragStart={onDragStart} onDragOver={onDragOver}>
          {stages.map((stage) => (
            <Stages
              key={stage.id}
              stage={stage}
              cards={cards.filter((card) => card.stageId === stage.id)}
              setCards={setCards}
              selectedCardId={selectedCardId}
              onSelectCard={handleSelectCard}
            />
          ))}
        </DndContext>
      </div>
    </div>
  )
}
