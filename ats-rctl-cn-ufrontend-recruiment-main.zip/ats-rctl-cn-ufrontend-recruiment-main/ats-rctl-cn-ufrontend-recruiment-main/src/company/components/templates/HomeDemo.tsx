export default function HomeDemo() {
  return <h1>Home company</h1>
}
