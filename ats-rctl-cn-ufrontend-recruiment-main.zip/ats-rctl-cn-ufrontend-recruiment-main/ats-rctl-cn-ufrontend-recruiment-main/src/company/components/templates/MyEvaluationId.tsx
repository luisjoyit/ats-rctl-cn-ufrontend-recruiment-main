import React, { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import { CardEvaluations, dataEvaluations } from './MyEvaluations'
import MyNewEvaluation from './MyNewEvaluation'

export default function MyEvaluationId() {
  const { evaluationId } = useParams()

  const [evaluation, setEvaluation] = useState<CardEvaluations | undefined>(
    undefined,
  )

  useEffect(() => {
    const foundEvaluation = dataEvaluations.find(
      (evaluation) => evaluation.id === evaluationId,
    )
    if (foundEvaluation) {
      setEvaluation(foundEvaluation)
    }
  }, [evaluationId])

  return (
    <div className="flex flex-col w-full min-h-screen font-inter">
      <MyNewEvaluation dataEvaluation={evaluation} update={true} />
    </div>
  )
}
