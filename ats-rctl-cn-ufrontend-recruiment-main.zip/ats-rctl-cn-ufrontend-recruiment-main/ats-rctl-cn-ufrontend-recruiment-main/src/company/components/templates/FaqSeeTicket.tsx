import React from 'react'
import { IconChevronLeft } from '@tabler/icons-react'
import { Card, CardHeader, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Link } from 'react-router-dom'

export default function FaqSeeTicket() {
  return (
    <div className="font-inter max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="mb-6 pt-4">
        <Link
          to="http://localhost:9000/recruitment/company/faq/ticket"
          className="flex items-center text-sm text-gray-600"
        >
          <IconChevronLeft className="w-4 h-4 mr-1" />
          <span>Regresar a mis tickets</span>
        </Link>
      </div>

      <Card className="w-full">
        <CardHeader className="p-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-2">
            <h2 className="text-lg font-semibold">
              Asunto:{' '}
              <span className="font-normal">
                No puedo guardar cambios en mi perfil
              </span>
            </h2>
            <Badge
              variant="secondary"
              className="mt-2 sm:mt-0 text-xs text-[#6C0000] bg-[#FFE0E0] px-2 py-1 rounded-[50px] w-[104px] h-[31px] flex items-center justify-center"
            >
              Cerrado
            </Badge>
          </div>
          <div className="text-sm text-gray-600">
            <p>Tipo de consulta: Mi perfil</p>
            <p>Ticket ID: N0002190319</p>
          </div>
        </CardHeader>

        <CardContent className="p-6">
          <div className="flex flex-col space-y-4 lg:flex-row lg:space-y-0 lg:space-x-4">
            <Card className="bg-gray-100 p-4 rounded-[11px] lg:w-1/2">
              <p className="text-sm text-gray-800">
                Gracias por contactarnos. Hemos revisado tu caso y parece que el
                problema se debe a una actualización reciente en nuestro
                sistema. Te recomendamos borrar la caché del navegador e
                intentar nuevamente. Si el problema persiste, por favor háznos
                saber para continuar investigando.
              </p>
              <p className="text-xs text-gray-500 mt-2 text-right">
                04 Jul 2024, 23:09
              </p>
            </Card>

            <Card className="bg-[#263658] p-4 rounded-[11px] lg:w-1/2">
              <p className="text-sm text-white">
                Intento realizar cambios en mi perfil dentro del sistema
                (actualización de información personal y cambio de foto de
                perfil), pero al hacer clic en "Guardar" la página no responde.
                He probado en diferentes navegadores y dispositivos, pero el
                problema persiste. Además, no aparece ningún mensaje de error,
                simplemente no guarda los cambios.
              </p>
              <p className="text-xs text-gray-300 mt-2 text-right">
                04 Jul 2024, 23:08
              </p>
            </Card>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
