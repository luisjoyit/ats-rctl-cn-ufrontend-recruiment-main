import { useEffect, useState } from 'react'
import { dataTalent } from './Offers'
import { Outlet, useNavigate, useSearchParams } from 'react-router-dom'
import { Card, CardContent, CardHeader } from '@/components/ui/card'
import { IconHeart, IconHeartFilled, IconMapPin } from '@tabler/icons-react'
import FiltersTalent from '../molecules/Offers/FiltersTalent'
import useMediaQuery from '@/hooks/useMediaQuery'
import { Pagination } from '@/components/ui/pagination'

export function OfferId() {
  const data = dataTalent

  const [hoveredIndex, setHoveredIndex] = useState(null)
  const [selectedIndex, setSelectedIndex] = useState(0)

  // Manejo del estado para el uso del Drawer (Modal) en vista de celular
  const [open, setOpen] = useState(false)
  const [favorite, setFavorite] = useState({
    id: 0,
    fill: true,
  })

  const [searchParams, setSearchParams] = useSearchParams()
  const navigate = useNavigate()

  const currentPage = parseInt(searchParams.get('page') || '1', 10)
  const isDesktop = useMediaQuery('(min-width: 640px)')

  const handleCardClick = (id) => {
    if (id !== null) {
      setOpen((prevDrawerOpen) => !prevDrawerOpen)
      const page = searchParams.get('page') || '1'
      setSelectedIndex(id)
      navigate(`/company/offers/${id}?page=${page}`)
    }
  }

  const handleCloseDrawer = () => {
    setOpen(false)
  }

  const handleToggleFavorite = (id) => {
    setFavorite((prevState) => ({
      id,
      fill: !prevState.fill,
    }))
  }

  const handlePageChange = (page) => {
    setSearchParams({ page: page.toString() })
  }

  const itemsPerPage = 6

  const currentData = data.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage,
  )

  useEffect(() => {
    //@ts-ignore
    setSearchParams((prevSearchParams) => ({
      ...prevSearchParams,
      page: currentPage.toString(),
    }))
  }, [currentPage, setSearchParams])

  const styleCard = (isHovered, isSelected) => {
    return {
      boxShadow: '0px 0px 2px 0px #00000040',
      outline: isHovered || isSelected ? '1px solid #00B7DA' : 'none',
    }
  }

  const buttonSkill = (skill: string, id?: number) => (
    <span
      key={id}
      className="text-[10px] bg-[#F0F2F4] rounded-[30px] px-2 flex items-center dark:text-secondary-500"
    >
      {skill}
    </span>
  )

  return (
    <div className="grid gap-7 xs:grid-cols-1 md:grid-cols-2 font-inter text-secondary">
      <div className="w-full flex flex-col gap-4">
        <FiltersTalent />
        <div className="flex flex-col gap-3">
          <div className="pt-3">
            <span className="font-semibold dark:text-primary-foreground">
              Disponible 1,200 candidatos
            </span>
          </div>
          <div className="flex flex-col gap-3">
            {data &&
              currentData?.map((offer, index) => (
                <Card
                  key={index}
                  className="flex flex-row w-full h-auto rounded-[16px] p-3 font-inter text-secondary-500 dark:text-white cursor-pointer gap-4 bg-card"
                  style={styleCard(
                    hoveredIndex === index,
                    selectedIndex === index,
                  )}
                  onMouseEnter={() => setHoveredIndex(index)}
                  onMouseLeave={() => setHoveredIndex(null)}
                  onClick={() => handleCardClick(offer.id)}
                >
                  <div className="flex items-center">
                    <div className="relative h-16.5 w-16.5 items-center">
                      <img
                        src={offer.img}
                        alt=""
                        className="h-16 w-16 rounded-full object-cover"
                      />
                      <img
                        src="https://w7.pngwing.com/pngs/205/835/png-transparent-flag-of-peru-national-flag-flag-of-scotland-portugal-miscellaneous-flag-text.png"
                        alt=""
                        className="absolute xs:-bottom-2 sm:bottom-0 right-0 xs:w-5 sm:w-6 xs:h-5 sm:h-6 rounded-full object-cover"
                      />
                    </div>
                  </div>
                  <div className="w-full flex flex-col">
                    <CardHeader className="p-0 space-y-0">
                      <div className=" flex xs:flex-col sm:flex-row xs:gap-2 sm:gap-0 justify-between">
                        <span className="text-sm font-semibold text-start">
                          {offer.name}
                        </span>
                        <div className="flex flex-row gap-2 items-center xs:justify-between sm:justify-normal">
                          <div className="text-[10px] bg-[#F0F2F4] h-[23px] rounded-[30px] px-2 flex items-center justify-center dark:text-secondary-500">
                            {offer.modality}
                          </div>
                          <div className="flex flex-row gap-2 items-center">
                            <IconMapPin stroke={1} size={18} />
                            <span className="text-xs text-center">{`${offer.city}, ${offer.country}`}</span>
                          </div>
                          <IconHeart
                            size={20}
                            onClick={(e) => {
                              e.stopPropagation()
                              handleToggleFavorite(offer.id)
                            }}
                            className="stroke-[#263658]"
                            fill={
                              favorite.id === offer.id && favorite.fill
                                ? '#263658'
                                : 'white'
                            }
                          />
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="p-0 xs:pt-2 ms:pt-0">
                      <span className="text-xs">{offer.position}</span>
                      <div className="flex flex-row gap-2 pt-3 justify-between w-full">
                        <div className="w-3/4 flex flex-wrap gap-2">
                          {isDesktop ? (
                            <>
                              {offer.skills
                                .slice(0, 5)
                                .map((skills, id) => buttonSkill(skills, id))}
                              {offer.skills.length > 5 && buttonSkill('+5')}
                            </>
                          ) : (
                            <>
                              {offer.skills
                                .slice(0, 3)
                                .map((skills, id) => buttonSkill(skills, id))}
                              {offer.skills.length > 3 && buttonSkill('+7')}
                            </>
                          )}
                        </div>
                        <div className="w-1/4 flex justify-end">
                          <span className="text-xs text-end">{`$${offer.salary}/mes`}</span>
                        </div>
                      </div>
                    </CardContent>
                  </div>
                </Card>
              ))}
          </div>
        </div>
        <Pagination
          currentPage={currentPage}
          totalItems={data ? data.length : 2}
          itemsPerPage={itemsPerPage}
          onPageChange={handlePageChange}
          className="py-7"
        />
      </div>
      <div>
        <Outlet context={{ open, handleCardClick, handleCloseDrawer }} />
      </div>
    </div>
  )
}
