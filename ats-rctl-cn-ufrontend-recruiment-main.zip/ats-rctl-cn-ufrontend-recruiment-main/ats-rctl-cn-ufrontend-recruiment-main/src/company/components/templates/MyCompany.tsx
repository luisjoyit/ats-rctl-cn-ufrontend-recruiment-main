import AvatarUpload from '@/components/AvatarUpload'
import EditorDemo from '@/components/editorText/editorDemo'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Separator } from '@/components/ui/separator'
import {
  IconBrandLinkedin,
  IconBrandGithub,
  IconBrandWhatsapp,
  IconPlus,
  IconBrandFacebook,
  IconBrandInstagram,
  IconQuestionMark,
} from '@tabler/icons-react'
import { useState } from 'react'
import FormSocialMedia from '../molecules/MyCompany/FormSocialMedia'

function MyCompany() {
  const [links, setLinks] = useState({
    facebook: '',
    github: '',
    instagram: '',
    linkedin: '',
    url: '',
    other: '',
  })

  const getIcons = (value) => {
    switch (value) {
      case 'facebook':
        return <IconBrandFacebook className="mr-2 size-5" stroke={1} />
      case 'github':
        return <IconBrandGithub className="mr-2 size-5" stroke={1} />
      case 'instagram':
        return <IconBrandInstagram className="mr-2 size-5" stroke={1} />
      case 'linkedin':
        return <IconBrandLinkedin className="mr-2 size-5" stroke={1} />
      case 'url':
        return <IconQuestionMark className="mr-2 size-5" stroke={1} />
      default:
        return <IconQuestionMark className="mr-2 size-5" stroke={1} />
    }
  }

  const capitalizeFirstLetter = (string) => {
    return string.charAt(0).toUpperCase() + string.slice(1)
  }

  return (
    <div className="flex flex-col items-end xs:gap-4 md:gap-8 font-inter">
      <div className="flex justify-end items-center">
        <Button variant="tertiary" size="md">
          Vista previa
        </Button>
        <Button variant="primary" size="md">
          Guardar Cambios
        </Button>
      </div>
      <div className="w-full xs:h-auto md:h-[296px] bg-card rounded-[11px] p-6 shadow-cards flex flex-col gap-6">
        <div className="flex flex-col gap-1 text-secondary-500 dark:text-white">
          <h1 className="font-semibold text-xl">
            Información básica de empresa
          </h1>
          <h2 className="text-sm">Completa tu información más relevante</h2>
        </div>
        <div className="flex xs:flex-col md:flex-row xs:gap-4 lg:gap-8 items-center xs:pt-0 md:pt-4">
          <div className="flex flex-col gap-2">
            <AvatarUpload />
            <p className="text-xs text-center text-secondary-500 dark:text-white">
              Foto de perfil
            </p>
          </div>
          <div className="w-full flex flex-col xs:gap-4 lg:gap-6 xs:pl-0 lg:pl-12">
            <Input
              type="email"
              className="h-[36px] rounded-[11px]"
              variant="floatingLabel"
              label="Nombre de empresa"
            />
            <Input
              type="text"
              className="h-[36px] rounded-[11px]"
              variant="floatingLabel"
              label="Rubro de la empresa"
            />
          </div>
          <Separator orientation="vertical" className="hidden md:block" />
          <div className="w-full flex flex-col xs:gap-4 lg:gap-6">
            <Input
              type="email"
              className="h-[36px] rounded-[11px]"
              variant="floatingLabel"
              label="Pais"
            />
            <Input
              type="text"
              className="h-[36px] rounded-[11px]"
              variant="floatingLabel"
              label="Telefono "
            />
          </div>
          <Separator orientation="vertical" className="hidden md:block" />
          <div className="w-full flex flex-col xs:gap-4 lg:gap-6">
            <Input
              type="email"
              className="h-[36px] rounded-[11px]"
              variant="floatingLabel"
              label="Pagina Web"
            />
            <Input
              type="text"
              className="h-[36px] rounded-[11px]"
              variant="floatingLabel"
              label="Pagina de Linkedin"
            />
          </div>
        </div>
      </div>
      <div className="w-full gap-5 grid xs:grid-cols-1 md:grid-cols-2">
        <div className="xs:h-auto md:min-h-[347px] bg-card rounded-[11px] p-6 shadow-cards flex flex-col gap-6">
          <div className="flex flex-col gap-1 text-secondary-500 dark:text-white pb-2">
            <h1 className="font-semibold text-xl">Descripción de empresa</h1>
            <p className="text-sm">
              Esto puede ser visible para los candidatos
            </p>
          </div>
          <div className="dark:text-secondary-500">
            <EditorDemo isHeaderEnd />
          </div>
        </div>
        <div className="xs:h-auto md:min-h-[347px] bg-card rounded-[11px] p-6 shadow-cards flex flex-col gap-6">
          <div className="flex flex-col gap-1 text-secondary-500 dark:text-white pb-2">
            <h1 className="font-semibold text-xl">
              Mensaje para los candidatos
            </h1>
            <p className="text-sm">
              Esto puede ser visible para los candidatos
            </p>
          </div>
          <div className="dark:text-secondary-500">
            <EditorDemo isHeaderEnd />
          </div>
        </div>
      </div>
      <div className="w-full xs:h-auto md:h-[177px] bg-card rounded-[11px] p-6 shadow-cards flex flex-col gap-6">
        <h1 className="font-semibold text-xl text-secondary-500 dark:text-white">
          Redes sociales
        </h1>
        <div className="xs:pt-0 md:pt-4 flex flex-wrap xs:gap-3 md:gap-6">
          {Object.entries(links).map(
            ([key, value], index) =>
              value && (
                <div
                  key={index}
                  className={`rounded-lg border border-secondary-500 bg-white flex flex-row justify-center items-center text-secondary-500 p-2 xs:text-sm md:text-base`}
                >
                  {getIcons(key)}
                  <span>{capitalizeFirstLetter(key)}</span>
                </div>
              ),
          )}
          <FormSocialMedia links={links} setLinks={setLinks} />
        </div>
      </div>
    </div>
  )
}

export default MyCompany
