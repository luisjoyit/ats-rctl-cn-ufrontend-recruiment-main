import { IconShieldLock } from '@tabler/icons-react'
import React from 'react'

const infoJob = {
  description:
    'Estamos en la búsqueda de un Backend Developer para crear y mantener servicios backend escalables y eficientes. El candidato ideal dominará lenguajes como Python, Java o Node.js, y será capaz de manejar tanto bases de datos relacionales como no relacionales. Será responsable de implementar APIs RESTful, optimizar el rendimiento del sistema y colaborar con equipos multidisciplinarios. La experiencia en microservicios, Docker, Kubernetes y la integración de servicios en la nube es altamente valorada.',
  functions: [
    'Desarrollo de endpoints de API RESTful utilizando Node.js y Express.js.',
    'Integración de bases de datos relacionales y no relacionales, como MySQL, MongoDB, etc.',
    'Optimización del rendimiento del backend mediante técnicas como la optimización de consultas y la implementación de cachés.',
    'Implementación de medidas de seguridad en la API, como autenticación y autorización de usuarios.',
    'Trabajo en colaboración con otros desarrolladores, tanto del equipo de backend como del frontend.',
    'Creación y mantenimiento de documentación técnica detallada.',
    'Identificación y resolución de problemas técnicos y de rendimiento en el backend de la aplicación.',
  ],
  requirements: [
    'Experiencia demostrada en desarrollo backend utilizando Node.js.',
    'Conocimiento sólido de JavaScript y frameworks de desarrollo backend como Express.js.',
    'Experiencia en el desarrollo de APIs RESTful.',
    'Familiaridad con bases de datos relacionales y no relacionales como MySQL, MongoDB, etc.',
    'Capacidad para trabajar de forma independiente y en equipo.',
    'Excelentes habilidades de comunicación y resolución de problemas.',
  ],
  benefits: [
    {
      title: 'Seguro Médico',
      description:
        'Seguro médico empresarial que protege a empleados y familias con atención integral.',
    },
    {
      title: 'Desarrollo Profesional',
      description:
        'Oportunidades de desarrollo profesional para crecer y avanzar en tu carrera con nosotros.',
    },
    {
      title: 'Acceso a eventos',
      description:
        'Acceso exclusivo a eventos para fomentar el networking y el desarrollo profesional.',
    },
    {
      title: 'Horario Flexible',
      description:
        'Horarios flexibles para equilibrar tu vida personal y profesional con comodidad.',
    },
    {
      title: 'Seguro Médico',
      description:
        'Seguro médico empresarial que protege a empleados y familias con atención integral.',
    },
  ],
  stackTech: [
    'AWS',
    'Docker',
    'Inglés',
    'Javascript',
    'Micorservicios',
    'Typescript',
    'Vue JS',
  ],
}

const MyProcessesInfo = () => {
  return (
    <div className="flex flex-col gap-6 text-secondary-500 dark:text-white font-inter">
      <div className="flex flex-col gap-2">
        <span className="font-semibold">Descripción</span>
        <div className="rounded-lg bg-card xs:p-3 sm:px-6 sm:py-5">
          <p className="text-sm">{infoJob.description}</p>
        </div>
      </div>
      <div className="flex flex-col gap-2">
        <span className="font-semibold">Funciones:</span>
        <div className="rounded-lg bg-card xs:p-3 sm:px-6 sm:py-5">
          <ul className="list-disc pl-4">
            {infoJob.functions.map((element, id) => (
              <li key={id} className="text-sm">
                {element}
              </li>
            ))}
          </ul>
        </div>
      </div>
      <div className="flex flex-col gap-2">
        <span className="font-semibold">Requisitos</span>
        <div className="rounded-lg bg-card xs:p-3 sm:px-6 sm:py-5">
          <ul className="list-disc pl-4">
            {infoJob.requirements.map((element, id) => (
              <li key={id} className="text-sm">
                {element}
              </li>
            ))}
          </ul>
        </div>
      </div>
      <div className="flex flex-col gap-2">
        <span className="font-semibold">Beneficios</span>
        <div className="rounded-lg bg-card xs:p-3 sm:px-6 sm:py-5 flex flex-wrap xs:gap-3 sm:gap-x-6 sm:gap-y-4">
          {infoJob.benefits.map((element, id) => (
            <div
              key={id}
              className="flex gap-2 text-sm shadow-cards dark:border rounded-lg xs:p-2 sm:p-3 xs:w-auto sm:w-[260px]"
            >
              <div className="pt-[2px]">
                <IconShieldLock stroke={1} size={15} />
              </div>
              <div className="flex flex-col gap-2">
                <span className="font-medium">{element.title}</span>
                <p className="text-sm xs:hidden sm:flex">
                  {element.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
      <div className="flex flex-col gap-2">
        <span className="font-semibold">Stack tech</span>
        <div className="rounded-lg bg-card xs:p-3 sm:px-6 sm:py-5 xs:gap-3 sm:gap-10 flex flex-wrap">
          {infoJob.stackTech.map((element, id) => (
            <span key={id} className="font-medium">
              {element}
            </span>
          ))}
        </div>
      </div>
    </div>
  )
}

export default MyProcessesInfo
