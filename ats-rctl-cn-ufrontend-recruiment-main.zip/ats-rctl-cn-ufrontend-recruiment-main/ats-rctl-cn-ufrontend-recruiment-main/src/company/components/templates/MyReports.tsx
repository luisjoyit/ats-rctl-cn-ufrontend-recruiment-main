import React, { useState } from 'react'
import ReportCard from '../atoms/MyReports/ReportCard'
import GraphicalReport from '../atoms/MyReports/GraphicalReport'
//@ts-ignore
import { t, useLanguage } from '@joyit/layout'
import { IconChevronLeft, IconChevronRight } from '@tabler/icons-react'

const IntervalButtons = ({ activeInterval, onIntervalChange }) => (
  <div className="inline-flex rounded-[30px] bg-card p-1 shadow-cards">
    {['daily', 'biweekly', 'monthly', 'annual'].map((interval) => (
      <button
        key={interval}
        className={`px-4 py-2 rounded-[30px] focus:outline-none transition-colors duration-200 text-xs ${
          t(`myReports.${interval}`) === t(`myReports.${activeInterval}`)
            ? 'bg-secondary text-white'
            : 'text-secondary hover:bg-gray-100'
        }`}
        onClick={() => onIntervalChange(interval)}
      >
        {t(`myReports.${interval}`)}
      </button>
    ))}
  </div>
)

export default function MyReports() {
  const [intervals, setIntervals] = useState({
    Nuevas: 'daily',
    EnProceso: 'daily',
    Rechazadas: 'daily',
  })

  const updateInterval = (card, interval) => {
    setIntervals((prev) => ({ ...prev, [card]: interval }))
  }

  const { handleChangeLanguage } = useLanguage()

  return (
    <div className="flex flex-col xs:gap-4 md:gap-8">
      <h1 className="text-xl font-bold text-secondary-500 dark:text-white">
        {t('myReports.reports')}
      </h1>
      <div className="relative text-secondary-500">
        <button className="absolute -left-5 top-1/2 transform -translate-y-1/2 bg-card rounded-lg p-2 shadow-md z-10 hover:bg-gray-100 hidden lg:block">
          <IconChevronLeft stroke={2} className="text-secondary-500" />
        </button>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {[
            { key: 'Nuevas', label: 'new' },
            { key: 'EnProceso', label: 'inProgress' },
            { key: 'Rechazadas', label: 'rejected' },
          ].map(({ key, label }) => (
            <div key={key} className="flex flex-col gap-3 items-center">
              <div className="w-full flex justify-center">
                <IntervalButtons
                  activeInterval={intervals[key]}
                  onIntervalChange={(interval) => updateInterval(key, interval)}
                />
              </div>
              <ReportCard
                title={t(`myReports.${label}`)}
                count="135"
                percentage="+98.9%"
                time="09:00 - 10:00"
                interval={intervals[key]}
              />
            </div>
          ))}
        </div>
        <button className="absolute -right-5 top-1/2 transform -translate-y-1/2 bg-card rounded-lg p-2 shadow-md z-10 hover:bg-gray-100 hidden lg:block">
          <IconChevronRight stroke={2} />
        </button>
      </div>
      <GraphicalReport />
    </div>
  )
}
