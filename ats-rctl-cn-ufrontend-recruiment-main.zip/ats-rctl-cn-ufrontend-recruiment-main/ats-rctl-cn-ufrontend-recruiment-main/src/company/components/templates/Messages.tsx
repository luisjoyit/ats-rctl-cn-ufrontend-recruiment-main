import InputWithIcon from '@/components/inputWithIcon'
import { Separator } from '@/components/ui/separator'
import useMediaQuery from '@/hooks/useMediaQuery'
import {
  IconCheck,
  IconChecks,
  IconMessage,
  IconPhone,
  IconSearch,
  IconSquareRoundedNumber1,
} from '@tabler/icons-react'
import { useNavigate } from 'react-router-dom'

export const messagesData = [
  {
    id: '001',
    avatar: 'https://avatars.githubusercontent.com/u/124599?v=4',
    name: 'Liset Cardenas',
    skills: ['UX/UI Designer', 'Figma', 'SFC'],
    stateUser: 'online', //estado de usuario dos opciones: online y disconnected
    messages: [
      {
        id: '001',
        name: 'Liset Cardenas',
        message:
          'Hello JoyIT Ad dolore elit fugiat dolore. Cupidatat adipisicing veniam aute pariatur sint cillum.',
        date: '13/04/2024',
        hour: '7:45:33 a. m.',
        stateMessage: 'read', //estado en tres opciones: sent, delivered y read.
      },
      {
        id: '002',
        name: 'JoyIT',
        message:
          'Hello Liset, Ad dolore elit fugiat dolore. Cupidatat adipisicing veniam aute pariatur sint cillum.',
        date: '13/04/2024',
        hour: '7:45:33 a. m.',
        stateMessage: 'delivered', //estado en tres opciones: sent, delivered y read.
      },
    ],
  },
  {
    id: '002',
    avatar: 'https://avatars.githubusercontent.com/u/124599?v=4',
    name: 'Ken Murakami',
    skills: ['Balsamiq', 'Adobe', 'Figma', 'SFC'],
    stateUser: 'online', //estado de usuario dos opciones: online y disconnected
    messages: [
      {
        id: '001',
        name: 'Ken Murakami',
        message:
          'Hello JoyIT, Ad dolore elit fugiat dolore. Cupidatat adipisicing veniam aute pariatur sint cillum. Occaecat voluptate esse ut enim veniam officia proident ad dolor nulla. Excepteur ut ex ex ipsum aliquip nostrud sunt reprehenderit est.',
        date: '13/04/2024',
        hour: '7:45:33 a. m.',
        stateMessage: 'sent', //estado en tres opciones: sent, delivered y read.
      },
    ],
  },
  {
    id: '003',
    avatar: 'https://avatars.githubusercontent.com/u/124599?v=4',
    name: 'Cecilia del Carmen',
    skills: ['QA Engineer', 'Selenium', 'Postman', 'Jmeter'],
    stateUser: 'disconnected', //estado de usuario dos opciones: online y disconnected
    messages: [
      {
        id: '001',
        name: 'Cecilia del Carmen',
        message:
          'Hello JoyIT, Ad dolore elit fugiat dolore. Cupidatat adipisicing veniam aute pariatur sint cillum. Occaecat voluptate esse ut enim veniam officia proident ad dolor nulla. Excepteur ut ex ex ipsum aliquip nostrud sunt reprehenderit est.',
        date: '13/04/2024',
        hour: '7:45:33 a. m.',
        stateMessage: 'delivered', //estado en tres opciones: sent, delivered y read.
      },
    ],
  },
  {
    id: '004',
    avatar: 'https://avatars.githubusercontent.com/u/124599?v=4',
    name: 'Luismi Yanamango',
    skills: ['Insomnia', 'Backend', 'K6', 'Jmeter'],
    stateUser: 'online', //estado de usuario dos opciones: online y disconnected
    messages: [
      {
        id: '001',
        name: 'Luismi Yanamango',
        message:
          'Hello JoyIT, Ad dolore elit fugiat dolore. Cupidatat adipisicing veniam aute pariatur sint cillum. Occaecat voluptate esse ut enim veniam officia proident ad dolor nulla. Excepteur ut ex ex ipsum aliquip nostrud sunt reprehenderit est.',
        date: '13/04/2024',
        hour: '7:45:33 a. m.',
        stateMessage: 'read', //estado en tres opciones: sent, delivered y read.
      },
    ],
  },
  {
    id: '005',
    avatar: 'https://avatars.githubusercontent.com/u/124599?v=4',
    name: 'Alan Court',
    skills: ['Angular', 'Nest Js', 'MySQL', 'Fullstack'],
    stateUser: 'disconnected', //estado de usuario dos opciones: online y disconnected
    messages: [
      {
        id: '001',
        name: 'Alan Court',
        message:
          'Hello JoyIT, Ad dolore elit fugiat dolore. Cupidatat adipisicing veniam aute pariatur sint cillum. Occaecat voluptate esse ut enim veniam officia proident ad dolor nulla. Excepteur ut ex ex ipsum aliquip nostrud sunt reprehenderit est.',
        date: '13/04/2024',
        hour: '7:45:33 a. m.',
        stateMessage: 'read', //estado en tres opciones: sent, delivered y read.
      },
    ],
  },
  {
    id: '006',
    avatar: 'https://avatars.githubusercontent.com/u/124599?v=4',
    name: 'Noe Perales',
    skills: ['Front Dev', 'JS', 'Angular', 'Figma'],
    stateUser: 'online', //estado de usuario dos opciones: online y disconnected
    messages: [
      {
        id: '001',
        name: 'Noe Perales',
        message:
          'Hello JoyIT, Ad dolore elit fugiat dolore. Cupidatat adipisicing veniam aute pariatur sint cillum. Occaecat voluptate esse ut enim veniam officia proident ad dolor nulla. Excepteur ut ex ex ipsum aliquip nostrud sunt reprehenderit est.',
        date: '13/0/2024',
        hour: '7:45:33 a. m.',
        stateMessage: 'delivered', //estado en tres opciones: sent, delivered y read.
      },
    ],
  },
]

interface Message {
  id: number | string
  avatar: string
  name: string
  skills: string[]
  stateUser: string
  messages: {
    id: number | string
    name: string
    message: string
    date: string
    hour: string
    stateMessage: string
  }[]
}

interface MessagesProps {
  narrow?: boolean //estrecho
  handleChatMobile?: (id: string | number) => void
}

export default function Messages({
  narrow: propNarrow,
  handleChatMobile,
}: MessagesProps) {
  const isMobile = useMediaQuery('(max-width:640px)')
  const narrow = propNarrow || isMobile

  const data: Message[] = messagesData

  const navigate = useNavigate()
  const openDetailMessage = (id) => {
    navigate(`/company/messages/${id}`)
    handleChatMobile?.(id)
  }

  const getLastMessage = (msg) => {
    //considerar mi usuario = JoyIT
    const user = 'JoyIT'
    const lastMessage = msg.length - 1
    let icon
    switch (msg[lastMessage].stateMessage) {
      case 'sent':
        icon = <IconCheck stroke={2} size={24} />
        break
      case 'delivered':
        icon =
          msg[lastMessage].name === user ? (
            <IconChecks stroke={2} size={24} />
          ) : (
            <IconSquareRoundedNumber1 stroke={2} size={24} />
          )
        break
      case 'read':
        icon = <IconChecks stroke={2} color="#8BB77B" size={24} />
        break
      default:
        icon = <IconChecks stroke={2} size={24} />
        break
    }

    return (
      <div className="flex flex-row xs:gap-1 sm:gap-3 items-center">
        <div className="flex items-center w-[20px]">{icon}</div>
        <p className={`text-sm text-[#6B6B6B] ${narrow && 'truncate text-xs'}`}>
          {msg[lastMessage]?.message}
        </p>
      </div>
    )
  }

  return (
    <div className="flex flex-col text-secondary-500 dark:text-white font-inter">
      <div
        className={`flex flex-col w-full gap-3 h-auto ${narrow ? 'border-b-[1px] border-muted-100 justify-between' : 'mb-2'}`}
      >
        <div className="flex w-full justify-center">
          <div className={`xs:w-full sm:w-3/4 ${narrow && 'w-full'}`}>
            <InputWithIcon className="lg:w-full" placeholder="Buscar" />
          </div>
        </div>
        <div>
          <h1 className="text-[32px] font-semibold">Mensajes</h1>
        </div>
        {narrow && (
          <div className="flex flex-row justify-around pb-2">
            <div className="flex flex-row gap-1 items-center cursor-pointer">
              <IconMessage
                stroke={2}
                size={18}
                className="text-secondary dark:text-white"
              />
              <span className="text-secondary-500 dark:text-white text-[13px]">
                Chats
              </span>
            </div>
            <div className="flex flex-row gap-1 items-center cursor-pointer">
              <IconPhone stroke={2} color="#9A9A9A" size={18} />
              <span className="text-[#9A9A9A] text-[13px]">Llamadas</span>
            </div>
          </div>
        )}
      </div>
      <div className="mt-4 w-full bg-card xs:p-3 sm:p-6 rounded-[13px] shadow-cards">
        {data?.map((message, index) => (
          <div
            className="flex flex-col cursor-pointer"
            key={message.id}
            tabIndex={0}
            role="button"
            onClick={() => openDetailMessage(message.id)}
          >
            <div
              className={`flex w-full flex-row ${narrow ? 'gap-2' : 'gap-5'}`}
            >
              <div
                className={`flex flex-none ${narrow ? 'xs:min-w-[55px] w-[65px]' : 'w-[100px]'}`}
              >
                <img
                  src={message?.avatar}
                  alt=""
                  className={`rounded-full object-cover xs:h-14 xs:w-14 ${narrow ? 'sm:h-16 sm:w-16' : 'sm:h-20 sm:w-20'}`}
                />
              </div>
              <div
                className={`flex flex-col gap-1 flex-grow min-w-0 ${narrow ? 'w-[260px]' : 'w-full'}`}
              >
                <div className="w-full flex flex-row justify-between">
                  <span
                    className={`font-bold ${narrow ? 'text-[13px]' : 'text-xl'}`}
                  >
                    {message.name}
                  </span>
                  <span className={narrow ? 'text-xs' : 'text-sm'}>12:54</span>
                </div>
                <div className="flex flex-row truncate">
                  {message?.skills?.map((skill, id) => (
                    <div key={id} className="flex flex-row">
                      <span
                        className={`font-semibold ${narrow ? 'text-xs' : 'text-base'}`}
                      >
                        {skill}
                      </span>
                      {message.skills.length - 1 !== id && (
                        <Separator
                          className="mx-2 border-[1px] border-secondary-500"
                          orientation="vertical"
                        />
                      )}
                    </div>
                  ))}
                </div>
                {getLastMessage(message?.messages)}
              </div>
            </div>
            {messagesData.length - 1 !== index && (
              <Separator className="my-4" />
            )}
          </div>
        ))}
      </div>
    </div>
  )
}
