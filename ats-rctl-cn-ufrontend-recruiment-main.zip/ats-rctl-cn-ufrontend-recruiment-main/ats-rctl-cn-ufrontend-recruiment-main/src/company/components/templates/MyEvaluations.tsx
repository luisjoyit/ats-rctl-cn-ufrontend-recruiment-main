import { IconSearch } from '@tabler/icons-react'
import React, { useState } from 'react'
import EvaluationsCards from '../molecules/MyEvaluations/EvaluationsCards'
import MyNewEvaluation from './MyNewEvaluation'
import AlertNewEvaluations from '../organism/AlertDialogs/AlertNewEvaluations'
import { Button } from '@/components/ui/button'
import { useNavigate } from 'react-router-dom'

export const dataEvaluations = [
  {
    id: '0001',
    source: 'joyIT', //tipo de evaluacion, considerando dos: joyIt y general
    name: 'Test de Inglés',
    amount: 450,
    questions: [
      {
        id: 1,
        titleQuestion: 'Question 1',
        typeAnswer: 'several',
        answers: ['Answer 1', 'Answer 2'],
      },
    ],
    description: 'Test de nivel de Inglés',
    valueTime: 20,
    unitTime: 'minutes',
  },
  {
    id: '0002',
    source: 'joyIT',
    name: 'Coding Challenge',
    amount: 6850,
    questions: [
      {
        id: 1,
        titleQuestion: 'Question 1',
        typeAnswer: 'short',
        answers: [],
      },
      {
        id: 2,
        titleQuestion: 'Question 2',
        typeAnswer: 'short',
        answers: [],
      },
    ],
    description: 'Reto de nivel de conocimiento de programación',
    valueTime: 1,
    unitTime: 'hours',
  },
  {
    id: '0003',
    source: 'joyIT',
    name: 'Test psicométrico',
    amount: 846,
    questions: [
      {
        id: 1,
        titleQuestion: 'Question 1',
        typeAnswer: 'several',
        answers: ['Option 1', 'Option 2'],
      },
    ],
    description: 'Test para medición de capacidades cognitivas',
    valueTime: 40,
    unitTime: 'minutes',
  },
  {
    id: '0004',
    source: 'joyIT',
    name: 'Habilidades Blandas',
    amount: 630,
    questions: [
      {
        id: 1,
        titleQuestion: 'Question 1',
        typeAnswer: 'short',
        answers: [],
      },
    ],
    description: 'Test sobre tus habilidades como persona',
    valueTime: 15,
    unitTime: 'minutes',
  },
  {
    id: '0005',
    source: 'joyIT',
    name: 'Test de Inglés',
    amount: 1470,
    questions: [
      {
        id: 1,
        titleQuestion: 'Question 1',
        typeAnswer: 'short',
        answers: [],
      },
      {
        id: 2,
        titleQuestion: 'Question 2',
        typeAnswer: 'several',
        answers: ['Option 1', 'Option 2'],
      },
    ],
    description: 'Test para medición de capacidades cognitivas',
    valueTime: 35,
    unitTime: 'minutes',
  },
  {
    id: '0006',
    source: 'general',
    name: 'Coding Challenge',
    amount: 6850,
    questions: [
      {
        id: 1,
        titleQuestion: 'Question 1',
        typeAnswer: 'short',
        answers: [],
      },
    ],
    description: 'Reto de nivel de conocimiento de programación',
    valueTime: 1,
    unitTime: 'hours',
  },
  {
    id: '0007',
    source: 'general',
    name: 'Test psicométrico',
    amount: 846,
    questions: [
      {
        id: 1,
        titleQuestion: 'Question 1',
        typeAnswer: 'short',
        answers: [],
      },
      {
        id: 2,
        titleQuestion: 'Question 2',
        typeAnswer: 'several',
        answers: ['Option 1', 'Option 2'],
      },
    ],
    description: 'Test para medición de capacidades cognitivas',
    valueTime: 40,
    unitTime: 'minutes',
  },
  {
    id: '0008',
    source: 'general',
    name: 'Habilidades Blandas',
    amount: 630,
    questions: [
      {
        id: 1,
        titleQuestion: 'Question 1',
        typeAnswer: 'short',
        answers: [],
      },
    ],
    description: 'Test sobre tus habilidades como persona',
    valueTime: 15,
    unitTime: 'minutes',
  },
  {
    id: '0009',
    source: 'general',
    name: 'Test de Inglés',
    amount: 1470,
    questions: [
      {
        id: 1,
        titleQuestion: 'Question 1',
        typeAnswer: 'short',
        answers: [],
      },
      {
        id: 2,
        titleQuestion: 'Question 2',
        typeAnswer: 'several',
        answers: ['Option 1', 'Option 2'],
      },
    ],
    description: 'Test para medición de capacidades cognitivas',
    valueTime: 35,
    unitTime: 'minutes',
  },
]

export type QuestionsEvaluations = {
  id: number
  titleQuestion: string
  typeAnswer: string
  answers: string[]
}

export type CardEvaluations = {
  id: string
  name: string
  amount: number
  source: string
  questions: QuestionsEvaluations[]
  description: string
  valueTime: number
  unitTime: string
}

export default function MyEvaluations() {
  const [data, setData] = useState<CardEvaluations[]>(dataEvaluations)
  const [switchOption, setSwitchOption] = useState('myEvaluations')

  const navigate = useNavigate()

  const buttons = [
    {
      name: 'myEvaluations',
      label: 'Mis Evaluaciones',
    },
    {
      name: 'joyIT',
      label: 'JoyIT Evaluaciones',
    },
  ]

  const filteredData = data.filter((item) => {
    if (switchOption === 'myEvaluations') {
      return item.source === 'general'
    } else if (switchOption === 'joyIT') {
      return item.source === 'joyIT'
    }
    return true
  })

  return (
    <div className="flex flex-col w-full min-h-screen max-w-[1540px] mx-auto font-inter xs:gap-5 sm:gap-0">
      <div className="flex w-full justify-start h-auto">
        <span className="text-secondary dark:text-white font-semibold text-xl">
          Evaluaciones
        </span>
      </div>
      <div className="flex w-full justify-end gap-2 items-center">
        <Button
          variant="primary"
          size="lg"
          className="text-primary-foreground"
          onClick={() => navigate('/company/myNewEvaluation')}
        >
          Crear evaluación
        </Button>
      </div>
      <>
        <div className="flex w-full justify-start xs:pl-0 md:pl-3">
          <div className="rounded-4xl gap-1 w-auto bg-[#ECF4F5]">
            {buttons.map((option, index) => (
              <button
                key={index}
                className={`text-center xs:text-xs sm:text-sm 
                      xs:w-[125px] sm:w-[169px] h-[39px] rounded-4xl
                      ${
                        switchOption === option.name
                          ? 'bg-secondary-500 text-primary-foreground'
                          : 'bg-[#ECF4F5] text-secondary-500'
                      }
                    `}
                onClick={() => setSwitchOption(option.name)}
              >
                {option.label}
              </button>
            ))}
          </div>
        </div>
        {data.length === 0 ? (
          <div className="flex h-[70vh] items-center justify-center">
            <div className="flex w-[757px] gap-3 items-center">
              <IconSearch stroke={1.5} color="#9A9A9A" size={54} />
              <div className="w-auto">
                <span className="text-muted-500 text-[40px]">
                  Aún no tienes evaluaciones existentes.
                </span>
              </div>
            </div>
          </div>
        ) : (
          <div className="flex w-full flex-wrap xs:p-0 md:pt-6 md:pl-3 xs:gap-5 md:gap-10">
            {filteredData.map((item) => (
              <EvaluationsCards key={item.id} card={item} />
            ))}
          </div>
        )}
      </>
    </div>
  )
}
