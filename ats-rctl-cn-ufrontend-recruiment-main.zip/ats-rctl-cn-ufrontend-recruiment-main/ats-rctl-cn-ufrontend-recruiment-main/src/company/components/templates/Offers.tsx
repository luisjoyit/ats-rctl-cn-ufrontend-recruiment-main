import { useEffect, useState } from 'react'
import { Navigate } from 'react-router-dom'

export const dataTalent = [
  {
    id: 0,
    name: 'Sofía Alvarado',
    position: 'Frontend',
    modality: 'Remoto',
    city: 'Lima',
    country: 'Perú',
    skills: [
      'JavaScript',
      'Typescritp',
      'HTML',
      'CSS',
      'React',
      'Vue.js',
      'Mongo DB',
      'GitHub',
    ],
    habilities: [
      'Comunicación',
      'Trabajo en Equipo',
      'Proactividad',
      'Liderazgo',
    ],
    salary: 3000,
    img: 'https://avatars.githubusercontent.com/u/124599?v=4',
    experience: [
      {
        position: 'Frontend Developer a Joyit S.A.C.',
        dates: ['Ene 2024', 'Actualidad'],
        activities: [
          'Desarrollo de Interfaces de Usuario (UI/UX)',
          'Implementación de Diseños Responsivos',
          'Integración de API y servicios backend',
          'Optimización de Rendimiento y Carga',
          'Pruebas y Depuración',
        ],
      },
      {
        position: 'Frontend Developer a Joyit S.A.C.',
        dates: ['May 2023', 'Dic 2023'],
        activities: [
          'Desarrollo de Interfaces de Usuario (UI/UX)',
          'Implementación de Diseños Responsivos',
          'Integración de API y servicios backend',
          'Optimización de Rendimiento y Carga',
          'Pruebas y Depuración',
        ],
      },
      {
        position: 'Frontend Developer a Joyit S.A.C.',
        dates: ['Ene 2020', 'Mar 2022'],
        activities: [
          'Desarrollo de Interfaces de Usuario (UI/UX)',
          'Implementación de Diseños Responsivos',
          'Integración de API y servicios backend',
          'Optimización de Rendimiento y Carga',
          'Pruebas y Depuración',
        ],
      },
    ],
    education: [
      {
        name: 'Backend Developer',
        institution: 'Coder House',
        date: ['Ene 2018', 'Dic 2019'],
      },
      {
        name: 'Fronted Developer',
        institution: 'Platzi',
        date: ['Ene 2019', 'Dic 2020'],
      },
    ],
    certificates: [
      {
        name: 'Microsoft Certified Solutions Developer',
      },
      {
        name: 'Certified Secure Software Lifecycle Professional (CSSLP)',
      },
    ],
    evaluations: [
      {
        name: 'Test de inglés',
        score: 98,
      },
      {
        name: 'Coding Challenge',
        score: 74,
      },
      {
        name: 'Test Psicométrico',
        score: 94,
      },
    ],
    aboutMe:
      '¡Soy Sofía, una desarrolladora Front-end entusiasta y creativa con más de cinco años de experiencia en la industria! Mi pasión por el diseño y la tecnología me ha permitido contribuir al éxito de diversos proyectos, destacando por mi habilidad para transformar ideas en interfaces de usuario atractivas y funcionales.',
    email: 'lisetcardenas007@gmail.com',
    phone: '+51943132859',
    linkedln:
      'https://www.linkedin.com/company/joyit-soluciones/posts/?feedView=all',
    github: 'https://github.com/joyitoficial',
    whatsApp: '+51943132859',
  },
  {
    id: 1,
    name: 'Javier Hernandez',
    position: 'Backend',
    modality: 'Híbrido',
    city: 'Tacna',
    country: 'Perú',
    skills: [
      'JavaScript',
      'Typescritp',
      'HTML',
      'CSS',
      'React',
      'Vue.js',
      'Mongo DB',
      'GitHub',
    ],
    habilities: [
      'Proactividad',
      'Liderazgo',
      'Comunicación',
      'Trabajo en Equipo',
    ],
    salary: 3000,
    img: 'https://avatars.githubusercontent.com/u/124599?v=4',
    experience: [
      {
        position: 'Frontend Developer a Joyit S.A.C.',
        dates: ['Ene 2024', 'Actualidad'],
        activities: [
          'Desarrollo de Interfaces de Usuario (UI/UX)',
          'Implementación de Diseños Responsivos',
          'Integración de API y servicios backend',
          'Optimización de Rendimiento y Carga',
          'Pruebas y Depuración',
        ],
      },
      {
        position: 'Frontend Developer a Joyit S.A.C.',
        dates: ['May 2023', 'Dic 2023'],
        activities: [
          'Desarrollo de Interfaces de Usuario (UI/UX)',
          'Implementación de Diseños Responsivos',
          'Integración de API y servicios backend',
          'Optimización de Rendimiento y Carga',
          'Pruebas y Depuración',
        ],
      },
      {
        position: 'Frontend Developer a Joyit S.A.C.',
        dates: ['Ene 2020', 'Mar 2022'],
        activities: [
          'Desarrollo de Interfaces de Usuario (UI/UX)',
          'Implementación de Diseños Responsivos',
          'Integración de API y servicios backend',
          'Optimización de Rendimiento y Carga',
          'Pruebas y Depuración',
        ],
      },
    ],
    education: [
      {
        name: 'Backend Developer',
        institution: 'Coder House',
        date: ['Ene 2018', 'Dic 2019'],
      },
      {
        name: 'Fronted Developer',
        institution: 'Platzi',
        date: ['Ene 2019', 'Dic 2020'],
      },
    ],
    certificates: [
      {
        name: 'Microsoft Certified Solutions Developer',
      },
      {
        name: 'Certified Secure Software Lifecycle Professional (CSSLP)',
      },
    ],
    evaluations: [
      {
        name: 'Test de inglés',
        score: 98,
      },
      {
        name: 'Coding Challenge',
        score: 74,
      },
      {
        name: 'Test Psicométrico',
        score: 94,
      },
    ],
    aboutMe:
      '¡Soy Sofía, una desarrolladora Front-end entusiasta y creativa con más de cinco años de experiencia en la industria! Mi pasión por el diseño y la tecnología me ha permitido contribuir al éxito de diversos proyectos, destacando por mi habilidad para transformar ideas en interfaces de usuario atractivas y funcionales.',
    email: 'lisetcardenas007@gmail.com',
    phone: '+51943132859',
    linkedln:
      'https://www.linkedin.com/company/joyit-soluciones/posts/?feedView=all',
    github: 'https://github.com/joyitoficial',
    whatsApp: '+51943132859',
  },
  {
    id: 2,
    name: 'Sofía Alvarado',
    position: 'Frontend',
    modality: 'Remoto',
    city: 'Lima',
    country: 'Perú',
    skills: [
      'JavaScript',
      'Typescritp',
      'HTML',
      'CSS',
      'React',
      'Vue.js',
      'Mongo DB',
      'GitHub',
    ],
    habilities: [
      'Comunicación',
      'Trabajo en Equipo',
      'Proactividad',
      'Liderazgo',
    ],
    salary: 3000,
    img: 'https://avatars.githubusercontent.com/u/124599?v=4',
    experience: [
      {
        position: 'Frontend Developer a Joyit S.A.C.',
        dates: ['Ene 2024', 'Actualidad'],
        activities: [
          'Desarrollo de Interfaces de Usuario (UI/UX)',
          'Implementación de Diseños Responsivos',
          'Integración de API y servicios backend',
          'Optimización de Rendimiento y Carga',
          'Pruebas y Depuración',
        ],
      },
      {
        position: 'Frontend Developer a Joyit S.A.C.',
        dates: ['May 2023', 'Dic 2023'],
        activities: [
          'Desarrollo de Interfaces de Usuario (UI/UX)',
          'Implementación de Diseños Responsivos',
          'Integración de API y servicios backend',
          'Optimización de Rendimiento y Carga',
          'Pruebas y Depuración',
        ],
      },
      {
        position: 'Frontend Developer a Joyit S.A.C.',
        dates: ['Ene 2020', 'Mar 2022'],
        activities: [
          'Desarrollo de Interfaces de Usuario (UI/UX)',
          'Implementación de Diseños Responsivos',
          'Integración de API y servicios backend',
          'Optimización de Rendimiento y Carga',
          'Pruebas y Depuración',
        ],
      },
    ],
    education: [
      {
        name: 'Backend Developer',
        institution: 'Coder House',
        date: ['Ene 2018', 'Dic 2019'],
      },
      {
        name: 'Fronted Developer',
        institution: 'Platzi',
        date: ['Ene 2019', 'Dic 2020'],
      },
    ],
    certificates: [
      {
        name: 'Microsoft Certified Solutions Developer',
      },
      {
        name: 'Certified Secure Software Lifecycle Professional (CSSLP)',
      },
    ],
    evaluations: [
      {
        name: 'Test de inglés',
        score: 98,
      },
      {
        name: 'Coding Challenge',
        score: 74,
      },
      {
        name: 'Test Psicométrico',
        score: 94,
      },
    ],
    aboutMe:
      '¡Soy Sofía, una desarrolladora Front-end entusiasta y creativa con más de cinco años de experiencia en la industria! Mi pasión por el diseño y la tecnología me ha permitido contribuir al éxito de diversos proyectos, destacando por mi habilidad para transformar ideas en interfaces de usuario atractivas y funcionales.',
    email: 'lisetcardenas007@gmail.com',
    phone: '+51943132859',
    linkedln:
      'https://www.linkedin.com/company/joyit-soluciones/posts/?feedView=all',
    github: 'https://github.com/joyitoficial',
    whatsApp: '+51943132859',
  },
  {
    id: 3,
    name: 'Javier Hernandez',
    position: 'Backend',
    modality: 'Híbrido',
    city: 'Tacna',
    country: 'Perú',
    skills: [
      'JavaScript',
      'Typescritp',
      'HTML',
      'CSS',
      'React',
      'Vue.js',
      'Mongo DB',
      'GitHub',
    ],
    habilities: [
      'Proactividad',
      'Liderazgo',
      'Comunicación',
      'Trabajo en Equipo',
    ],
    salary: 3000,
    img: 'https://avatars.githubusercontent.com/u/124599?v=4',
    experience: [
      {
        position: 'Frontend Developer a Joyit S.A.C.',
        dates: ['Ene 2024', 'Actualidad'],
        activities: [
          'Desarrollo de Interfaces de Usuario (UI/UX)',
          'Implementación de Diseños Responsivos',
          'Integración de API y servicios backend',
          'Optimización de Rendimiento y Carga',
          'Pruebas y Depuración',
        ],
      },
      {
        position: 'Frontend Developer a Joyit S.A.C.',
        dates: ['May 2023', 'Dic 2023'],
        activities: [
          'Desarrollo de Interfaces de Usuario (UI/UX)',
          'Implementación de Diseños Responsivos',
          'Integración de API y servicios backend',
          'Optimización de Rendimiento y Carga',
          'Pruebas y Depuración',
        ],
      },
      {
        position: 'Frontend Developer a Joyit S.A.C.',
        dates: ['Ene 2020', 'Mar 2022'],
        activities: [
          'Desarrollo de Interfaces de Usuario (UI/UX)',
          'Implementación de Diseños Responsivos',
          'Integración de API y servicios backend',
          'Optimización de Rendimiento y Carga',
          'Pruebas y Depuración',
        ],
      },
    ],
    education: [
      {
        name: 'Backend Developer',
        institution: 'Coder House',
        date: ['Ene 2018', 'Dic 2019'],
      },
      {
        name: 'Fronted Developer',
        institution: 'Platzi',
        date: ['Ene 2019', 'Dic 2020'],
      },
    ],
    certificates: [
      {
        name: 'Microsoft Certified Solutions Developer',
      },
      {
        name: 'Certified Secure Software Lifecycle Professional (CSSLP)',
      },
    ],
    evaluations: [
      {
        name: 'Test de inglés',
        score: 98,
      },
      {
        name: 'Coding Challenge',
        score: 74,
      },
      {
        name: 'Test Psicométrico',
        score: 94,
      },
    ],
    aboutMe:
      '¡Soy Sofía, una desarrolladora Front-end entusiasta y creativa con más de cinco años de experiencia en la industria! Mi pasión por el diseño y la tecnología me ha permitido contribuir al éxito de diversos proyectos, destacando por mi habilidad para transformar ideas en interfaces de usuario atractivas y funcionales.',
    email: 'lisetcardenas007@gmail.com',
    phone: '+51943132859',
    linkedln:
      'https://www.linkedin.com/company/joyit-soluciones/posts/?feedView=all',
    github: 'https://github.com/joyitoficial',
    whatsApp: '+51943132859',
  },
  {
    id: 4,
    name: 'Sofía Alvarado',
    position: 'Frontend',
    modality: 'Remoto',
    city: 'Lima',
    country: 'Perú',
    skills: [
      'JavaScript',
      'Typescritp',
      'HTML',
      'CSS',
      'React',
      'Vue.js',
      'Mongo DB',
      'GitHub',
    ],
    habilities: [
      'Comunicación',
      'Trabajo en Equipo',
      'Proactividad',
      'Liderazgo',
    ],
    salary: 3000,
    img: 'https://avatars.githubusercontent.com/u/124599?v=4',
    experience: [
      {
        position: 'Frontend Developer a Joyit S.A.C.',
        dates: ['Ene 2024', 'Actualidad'],
        activities: [
          'Desarrollo de Interfaces de Usuario (UI/UX)',
          'Implementación de Diseños Responsivos',
          'Integración de API y servicios backend',
          'Optimización de Rendimiento y Carga',
          'Pruebas y Depuración',
        ],
      },
      {
        position: 'Frontend Developer a Joyit S.A.C.',
        dates: ['May 2023', 'Dic 2023'],
        activities: [
          'Desarrollo de Interfaces de Usuario (UI/UX)',
          'Implementación de Diseños Responsivos',
          'Integración de API y servicios backend',
          'Optimización de Rendimiento y Carga',
          'Pruebas y Depuración',
        ],
      },
      {
        position: 'Frontend Developer a Joyit S.A.C.',
        dates: ['Ene 2020', 'Mar 2022'],
        activities: [
          'Desarrollo de Interfaces de Usuario (UI/UX)',
          'Implementación de Diseños Responsivos',
          'Integración de API y servicios backend',
          'Optimización de Rendimiento y Carga',
          'Pruebas y Depuración',
        ],
      },
    ],
    education: [
      {
        name: 'Backend Developer',
        institution: 'Coder House',
        date: ['Ene 2018', 'Dic 2019'],
      },
      {
        name: 'Fronted Developer',
        institution: 'Platzi',
        date: ['Ene 2019', 'Dic 2020'],
      },
    ],
    certificates: [
      {
        name: 'Microsoft Certified Solutions Developer',
      },
      {
        name: 'Certified Secure Software Lifecycle Professional (CSSLP)',
      },
    ],
    evaluations: [
      {
        name: 'Test de inglés',
        score: 98,
      },
      {
        name: 'Coding Challenge',
        score: 74,
      },
      {
        name: 'Test Psicométrico',
        score: 94,
      },
    ],
    aboutMe:
      '¡Soy Sofía, una desarrolladora Front-end entusiasta y creativa con más de cinco años de experiencia en la industria! Mi pasión por el diseño y la tecnología me ha permitido contribuir al éxito de diversos proyectos, destacando por mi habilidad para transformar ideas en interfaces de usuario atractivas y funcionales.',
    email: 'lisetcardenas007@gmail.com',
    phone: '+51943132859',
    linkedln:
      'https://www.linkedin.com/company/joyit-soluciones/posts/?feedView=all',
    github: 'https://github.com/joyitoficial',
    whatsApp: '+51943132859',
  },
  {
    id: 5,
    name: 'Javier Hernandez',
    position: 'Backend',
    modality: 'Híbrido',
    city: 'Tacna',
    country: 'Perú',
    skills: [
      'JavaScript',
      'Typescritp',
      'HTML',
      'CSS',
      'React',
      'Vue.js',
      'Mongo DB',
      'GitHub',
    ],
    habilities: [
      'Proactividad',
      'Liderazgo',
      'Comunicación',
      'Trabajo en Equipo',
    ],
    salary: 3000,
    img: 'https://avatars.githubusercontent.com/u/124599?v=4',
    experience: [
      {
        position: 'Frontend Developer a Joyit S.A.C.',
        dates: ['Ene 2024', 'Actualidad'],
        activities: [
          'Desarrollo de Interfaces de Usuario (UI/UX)',
          'Implementación de Diseños Responsivos',
          'Integración de API y servicios backend',
          'Optimización de Rendimiento y Carga',
          'Pruebas y Depuración',
        ],
      },
      {
        position: 'Frontend Developer a Joyit S.A.C.',
        dates: ['May 2023', 'Dic 2023'],
        activities: [
          'Desarrollo de Interfaces de Usuario (UI/UX)',
          'Implementación de Diseños Responsivos',
          'Integración de API y servicios backend',
          'Optimización de Rendimiento y Carga',
          'Pruebas y Depuración',
        ],
      },
      {
        position: 'Frontend Developer a Joyit S.A.C.',
        dates: ['Ene 2020', 'Mar 2022'],
        activities: [
          'Desarrollo de Interfaces de Usuario (UI/UX)',
          'Implementación de Diseños Responsivos',
          'Integración de API y servicios backend',
          'Optimización de Rendimiento y Carga',
          'Pruebas y Depuración',
        ],
      },
    ],
    education: [
      {
        name: 'Backend Developer',
        institution: 'Coder House',
        date: ['Ene 2018', 'Dic 2019'],
      },
      {
        name: 'Fronted Developer',
        institution: 'Platzi',
        date: ['Ene 2019', 'Dic 2020'],
      },
    ],
    certificates: [
      {
        name: 'Microsoft Certified Solutions Developer',
      },
      {
        name: 'Certified Secure Software Lifecycle Professional (CSSLP)',
      },
    ],
    evaluations: [
      {
        name: 'Test de inglés',
        score: 98,
      },
      {
        name: 'Coding Challenge',
        score: 74,
      },
      {
        name: 'Test Psicométrico',
        score: 94,
      },
    ],
    aboutMe:
      '¡Soy Sofía, una desarrolladora Front-end entusiasta y creativa con más de cinco años de experiencia en la industria! Mi pasión por el diseño y la tecnología me ha permitido contribuir al éxito de diversos proyectos, destacando por mi habilidad para transformar ideas en interfaces de usuario atractivas y funcionales.',
    email: 'lisetcardenas007@gmail.com',
    phone: '+51943132859',
    linkedln:
      'https://www.linkedin.com/company/joyit-soluciones/posts/?feedView=all',
    github: 'https://github.com/joyitoficial',
    whatsApp: '+51943132859',
  },
  {
    id: 6,
    name: 'Sofía Alvarado',
    position: 'Frontend',
    modality: 'Remoto',
    city: 'Lima',
    country: 'Perú',
    skills: [
      'JavaScript',
      'Typescritp',
      'HTML',
      'CSS',
      'React',
      'Vue.js',
      'Mongo DB',
      'GitHub',
    ],
    habilities: [
      'Comunicación',
      'Trabajo en Equipo',
      'Proactividad',
      'Liderazgo',
    ],
    salary: 3000,
    img: 'https://avatars.githubusercontent.com/u/124599?v=4',
    experience: [
      {
        position: 'Frontend Developer a Joyit S.A.C.',
        dates: ['Ene 2024', 'Actualidad'],
        activities: [
          'Desarrollo de Interfaces de Usuario (UI/UX)',
          'Implementación de Diseños Responsivos',
          'Integración de API y servicios backend',
          'Optimización de Rendimiento y Carga',
          'Pruebas y Depuración',
        ],
      },
      {
        position: 'Frontend Developer a Joyit S.A.C.',
        dates: ['May 2023', 'Dic 2023'],
        activities: [
          'Desarrollo de Interfaces de Usuario (UI/UX)',
          'Implementación de Diseños Responsivos',
          'Integración de API y servicios backend',
          'Optimización de Rendimiento y Carga',
          'Pruebas y Depuración',
        ],
      },
      {
        position: 'Frontend Developer a Joyit S.A.C.',
        dates: ['Ene 2020', 'Mar 2022'],
        activities: [
          'Desarrollo de Interfaces de Usuario (UI/UX)',
          'Implementación de Diseños Responsivos',
          'Integración de API y servicios backend',
          'Optimización de Rendimiento y Carga',
          'Pruebas y Depuración',
        ],
      },
    ],
    education: [
      {
        name: 'Backend Developer',
        institution: 'Coder House',
        date: ['Ene 2018', 'Dic 2019'],
      },
      {
        name: 'Fronted Developer',
        institution: 'Platzi',
        date: ['Ene 2019', 'Dic 2020'],
      },
    ],
    certificates: [
      {
        name: 'Microsoft Certified Solutions Developer',
      },
      {
        name: 'Certified Secure Software Lifecycle Professional (CSSLP)',
      },
    ],
    evaluations: [
      {
        name: 'Test de inglés',
        score: 98,
      },
      {
        name: 'Coding Challenge',
        score: 74,
      },
      {
        name: 'Test Psicométrico',
        score: 94,
      },
    ],
    aboutMe:
      '¡Soy Sofía, una desarrolladora Front-end entusiasta y creativa con más de cinco años de experiencia en la industria! Mi pasión por el diseño y la tecnología me ha permitido contribuir al éxito de diversos proyectos, destacando por mi habilidad para transformar ideas en interfaces de usuario atractivas y funcionales.',
    email: 'lisetcardenas007@gmail.com',
    phone: '+51943132859',
    linkedln:
      'https://www.linkedin.com/company/joyit-soluciones/posts/?feedView=all',
    github: 'https://github.com/joyitoficial',
    whatsApp: '+51943132859',
  },
  {
    id: 7,
    name: 'Javier Hernandez',
    position: 'Backend',
    modality: 'Híbrido',
    city: 'Tacna',
    country: 'Perú',
    skills: [
      'JavaScript',
      'Typescritp',
      'HTML',
      'CSS',
      'React',
      'Vue.js',
      'Mongo DB',
      'GitHub',
    ],
    habilities: [
      'Proactividad',
      'Liderazgo',
      'Comunicación',
      'Trabajo en Equipo',
    ],
    salary: 3000,
    img: 'https://avatars.githubusercontent.com/u/124599?v=4',
    experience: [
      {
        position: 'Frontend Developer a Joyit S.A.C.',
        dates: ['Ene 2024', 'Actualidad'],
        activities: [
          'Desarrollo de Interfaces de Usuario (UI/UX)',
          'Implementación de Diseños Responsivos',
          'Integración de API y servicios backend',
          'Optimización de Rendimiento y Carga',
          'Pruebas y Depuración',
        ],
      },
      {
        position: 'Frontend Developer a Joyit S.A.C.',
        dates: ['May 2023', 'Dic 2023'],
        activities: [
          'Desarrollo de Interfaces de Usuario (UI/UX)',
          'Implementación de Diseños Responsivos',
          'Integración de API y servicios backend',
          'Optimización de Rendimiento y Carga',
          'Pruebas y Depuración',
        ],
      },
      {
        position: 'Frontend Developer a Joyit S.A.C.',
        dates: ['Ene 2020', 'Mar 2022'],
        activities: [
          'Desarrollo de Interfaces de Usuario (UI/UX)',
          'Implementación de Diseños Responsivos',
          'Integración de API y servicios backend',
          'Optimización de Rendimiento y Carga',
          'Pruebas y Depuración',
        ],
      },
    ],
    education: [
      {
        name: 'Backend Developer',
        institution: 'Coder House',
        date: ['Ene 2018', 'Dic 2019'],
      },
      {
        name: 'Fronted Developer',
        institution: 'Platzi',
        date: ['Ene 2019', 'Dic 2020'],
      },
    ],
    certificates: [
      {
        name: 'Microsoft Certified Solutions Developer',
      },
      {
        name: 'Certified Secure Software Lifecycle Professional (CSSLP)',
      },
    ],
    evaluations: [
      {
        name: 'Test de inglés',
        score: 98,
      },
      {
        name: 'Coding Challenge',
        score: 74,
      },
      {
        name: 'Test Psicométrico',
        score: 94,
      },
    ],
    aboutMe:
      '¡Soy Sofía, una desarrolladora Front-end entusiasta y creativa con más de cinco años de experiencia en la industria! Mi pasión por el diseño y la tecnología me ha permitido contribuir al éxito de diversos proyectos, destacando por mi habilidad para transformar ideas en interfaces de usuario atractivas y funcionales.',
    email: 'lisetcardenas007@gmail.com',
    phone: '+51943132859',
    linkedln:
      'https://www.linkedin.com/company/joyit-soluciones/posts/?feedView=all',
    github: 'https://github.com/joyitoficial',
    whatsApp: '+51943132859',
  },
  {
    id: 8,
    name: 'Sofía Alvarado',
    position: 'Frontend',
    modality: 'Remoto',
    city: 'Lima',
    country: 'Perú',
    skills: [
      'JavaScript',
      'Typescritp',
      'HTML',
      'CSS',
      'React',
      'Vue.js',
      'Mongo DB',
      'GitHub',
    ],
    habilities: [
      'Comunicación',
      'Trabajo en Equipo',
      'Proactividad',
      'Liderazgo',
    ],
    salary: 3000,
    img: 'https://avatars.githubusercontent.com/u/124599?v=4_',
    experience: [
      {
        position: 'Frontend Developer a Joyit S.A.C.',
        dates: ['Ene 2024', 'Actualidad'],
        activities: [
          'Desarrollo de Interfaces de Usuario (UI/UX)',
          'Implementación de Diseños Responsivos',
          'Integración de API y servicios backend',
          'Optimización de Rendimiento y Carga',
          'Pruebas y Depuración',
        ],
      },
      {
        position: 'Frontend Developer a Joyit S.A.C.',
        dates: ['May 2023', 'Dic 2023'],
        activities: [
          'Desarrollo de Interfaces de Usuario (UI/UX)',
          'Implementación de Diseños Responsivos',
          'Integración de API y servicios backend',
          'Optimización de Rendimiento y Carga',
          'Pruebas y Depuración',
        ],
      },
      {
        position: 'Frontend Developer a Joyit S.A.C.',
        dates: ['Ene 2020', 'Mar 2022'],
        activities: [
          'Desarrollo de Interfaces de Usuario (UI/UX)',
          'Implementación de Diseños Responsivos',
          'Integración de API y servicios backend',
          'Optimización de Rendimiento y Carga',
          'Pruebas y Depuración',
        ],
      },
    ],
    education: [
      {
        name: 'Backend Developer',
        institution: 'Coder House',
        date: ['Ene 2018', 'Dic 2019'],
      },
      {
        name: 'Fronted Developer',
        institution: 'Platzi',
        date: ['Ene 2019', 'Dic 2020'],
      },
    ],
    certificates: [
      {
        name: 'Microsoft Certified Solutions Developer',
      },
      {
        name: 'Certified Secure Software Lifecycle Professional (CSSLP)',
      },
    ],
    evaluations: [
      {
        name: 'Test de inglés',
        score: 98,
      },
      {
        name: 'Coding Challenge',
        score: 74,
      },
      {
        name: 'Test Psicométrico',
        score: 94,
      },
    ],
    aboutMe:
      '¡Soy Sofía, una desarrolladora Front-end entusiasta y creativa con más de cinco años de experiencia en la industria! Mi pasión por el diseño y la tecnología me ha permitido contribuir al éxito de diversos proyectos, destacando por mi habilidad para transformar ideas en interfaces de usuario atractivas y funcionales.',
    email: 'lisetcardenas007@gmail.com',
    phone: '+51943132859',
    linkedln:
      'https://www.linkedin.com/company/joyit-soluciones/posts/?feedView=all',
    github: 'https://github.com/joyitoficial',
    whatsApp: '+51943132859',
  },
  {
    id: 9,
    name: 'Javier Hernandez',
    position: 'Backend',
    modality: 'Híbrido',
    city: 'Tacna',
    country: 'Perú',
    skills: [
      'JavaScript',
      'Typescritp',
      'HTML',
      'CSS',
      'React',
      'Vue.js',
      'Mongo DB',
      'GitHub',
    ],
    habilities: [
      'Proactividad',
      'Liderazgo',
      'Comunicación',
      'Trabajo en Equipo',
    ],
    salary: 3000,
    img: 'https://avatars.githubusercontent.com/u/124599?v=4',
    experience: [
      {
        position: 'Frontend Developer a Joyit S.A.C.',
        dates: ['Ene 2024', 'Actualidad'],
        activities: [
          'Desarrollo de Interfaces de Usuario (UI/UX)',
          'Implementación de Diseños Responsivos',
          'Integración de API y servicios backend',
          'Optimización de Rendimiento y Carga',
          'Pruebas y Depuración',
        ],
      },
      {
        position: 'Frontend Developer a Joyit S.A.C.',
        dates: ['May 2023', 'Dic 2023'],
        activities: [
          'Desarrollo de Interfaces de Usuario (UI/UX)',
          'Implementación de Diseños Responsivos',
          'Integración de API y servicios backend',
          'Optimización de Rendimiento y Carga',
          'Pruebas y Depuración',
        ],
      },
      {
        position: 'Frontend Developer a Joyit S.A.C.',
        dates: ['Ene 2020', 'Mar 2022'],
        activities: [
          'Desarrollo de Interfaces de Usuario (UI/UX)',
          'Implementación de Diseños Responsivos',
          'Integración de API y servicios backend',
          'Optimización de Rendimiento y Carga',
          'Pruebas y Depuración',
        ],
      },
    ],
    education: [
      {
        name: 'Backend Developer',
        institution: 'Coder House',
        date: ['Ene 2018', 'Dic 2019'],
      },
      {
        name: 'Fronted Developer',
        institution: 'Platzi',
        date: ['Ene 2019', 'Dic 2020'],
      },
    ],
    certificates: [
      {
        name: 'Microsoft Certified Solutions Developer',
      },
      {
        name: 'Certified Secure Software Lifecycle Professional (CSSLP)',
      },
    ],
    evaluations: [
      {
        name: 'Test de inglés',
        score: 98,
      },
      {
        name: 'Coding Challenge',
        score: 74,
      },
      {
        name: 'Test Psicométrico',
        score: 94,
      },
    ],
    aboutMe:
      '¡Soy Sofía, una desarrolladora Front-end entusiasta y creativa con más de cinco años de experiencia en la industria! Mi pasión por el diseño y la tecnología me ha permitido contribuir al éxito de diversos proyectos, destacando por mi habilidad para transformar ideas en interfaces de usuario atractivas y funcionales.',
    email: 'lisetcardenas007@gmail.com',
    phone: '+51943132859',
    linkedln:
      'https://www.linkedin.com/company/joyit-soluciones/posts/?feedView=all',
    github: 'https://github.com/joyitoficial',
    whatsApp: '+51943132859',
  },
  {
    id: 10,
    name: 'Sofía Alvarado',
    position: 'Frontend',
    modality: 'Remoto',
    city: 'Lima',
    country: 'Perú',
    skills: [
      'JavaScript',
      'Typescritp',
      'HTML',
      'CSS',
      'React',
      'Vue.js',
      'Mongo DB',
      'GitHub',
    ],
    habilities: [
      'Comunicación',
      'Trabajo en Equipo',
      'Proactividad',
      'Liderazgo',
    ],
    salary: 3000,
    img: 'https://avatars.githubusercontent.com/u/124599?v=4',
    experience: [
      {
        position: 'Frontend Developer a Joyit S.A.C.',
        dates: ['Ene 2024', 'Actualidad'],
        activities: [
          'Desarrollo de Interfaces de Usuario (UI/UX)',
          'Implementación de Diseños Responsivos',
          'Integración de API y servicios backend',
          'Optimización de Rendimiento y Carga',
          'Pruebas y Depuración',
        ],
      },
      {
        position: 'Frontend Developer a Joyit S.A.C.',
        dates: ['May 2023', 'Dic 2023'],
        activities: [
          'Desarrollo de Interfaces de Usuario (UI/UX)',
          'Implementación de Diseños Responsivos',
          'Integración de API y servicios backend',
          'Optimización de Rendimiento y Carga',
          'Pruebas y Depuración',
        ],
      },
      {
        position: 'Frontend Developer a Joyit S.A.C.',
        dates: ['Ene 2020', 'Mar 2022'],
        activities: [
          'Desarrollo de Interfaces de Usuario (UI/UX)',
          'Implementación de Diseños Responsivos',
          'Integración de API y servicios backend',
          'Optimización de Rendimiento y Carga',
          'Pruebas y Depuración',
        ],
      },
    ],
    education: [
      {
        name: 'Backend Developer',
        institution: 'Coder House',
        date: ['Ene 2018', 'Dic 2019'],
      },
      {
        name: 'Fronted Developer',
        institution: 'Platzi',
        date: ['Ene 2019', 'Dic 2020'],
      },
    ],
    certificates: [
      {
        name: 'Microsoft Certified Solutions Developer',
      },
      {
        name: 'Certified Secure Software Lifecycle Professional (CSSLP)',
      },
    ],
    evaluations: [
      {
        name: 'Test de inglés',
        score: 98,
      },
      {
        name: 'Coding Challenge',
        score: 74,
      },
      {
        name: 'Test Psicométrico',
        score: 94,
      },
    ],
    aboutMe:
      '¡Soy Sofía, una desarrolladora Front-end entusiasta y creativa con más de cinco años de experiencia en la industria! Mi pasión por el diseño y la tecnología me ha permitido contribuir al éxito de diversos proyectos, destacando por mi habilidad para transformar ideas en interfaces de usuario atractivas y funcionales.',
    email: 'lisetcardenas007@gmail.com',
    phone: '+51943132859',
    linkedln:
      'https://www.linkedin.com/company/joyit-soluciones/posts/?feedView=all',
    github: 'https://github.com/joyitoficial',
    whatsApp: '+51943132859',
  },
]

export default function Offers() {
  const [navigateTo, setNavigateTo] = useState('')

  useEffect(() => {
    if (dataTalent && dataTalent.length > 0) {
      setNavigateTo(`/company/offers/${dataTalent[0].id}`)
    }
  }, [])

  if (navigateTo) {
    return <Navigate to={navigateTo} replace />
  }

  return null
}
