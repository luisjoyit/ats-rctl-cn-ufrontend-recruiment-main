import SelectUi from '@/components/SelectUi'
import { Line, Doughnut } from 'react-chartjs-2'
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  ArcElement,
} from 'chart.js'
import ChartDataLabels from 'chartjs-plugin-datalabels'

import useMediaQuery from '@/hooks/useMediaQuery'
import { useState } from 'react'

// Registramos los componentes necesarios de Chart.js
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  ArcElement,
  Title,
  Tooltip,
  Legend,
  ChartDataLabels,
)

const dataAllProcesses = {
  labels: ['05/09', '06/09', '07/09', '08/09', '09/09', '10/09'],
  datasets: [
    {
      label: 'Postulaciones',
      data: [180, 160, 140, 130, 120, 110],
      borderColor: '#A7F1C0',
      backgroundColor: '#FFFFFF',
      borderWidth: 1.5,
      tension: 0.1,
    },
    {
      label: 'Evaluaciones',
      data: [120, 110, 90, 80, 60, 50],
      borderColor: '#A9A7F1',
      backgroundColor: '#FFFFFF',
      borderWidth: 1.5,
      tension: 0.1,
    },
    {
      label: 'Entrevistas',
      data: [40, 35, 30, 25, 20, 15],
      borderColor: '#F1CAA7',
      backgroundColor: '#FFFFFF',
      borderWidth: 1.5,
      tension: 0.1,
    },
    {
      label: 'Evaluación II',
      data: [20, 15, 20, 15, 10, 12],
      borderColor: '#A9A7F1',
      backgroundColor: '#FFFFFF',
      borderWidth: 1.5,
      tension: 0.1,
    },
    {
      label: 'Oferta',
      data: [5, 10, 5, 10, 15, 20],
      borderColor: '#F1A7EA',
      backgroundColor: '#FFFFFF',
      borderWidth: 1.5,
      tension: 0.1,
    },
  ],
}

const dataApplicants = {
  labels: ['05/09', '06/09', '07/09', '08/09', '09/09'],
  datasets: [
    {
      label: 'Con EXP.',
      data: [12, 15, 25, 30, 40],
      borderColor: '#263658',
      backgroundColor: '#FFFFFF',
      borderWidth: 1,
      tension: 0.1,
    },
    {
      label: 'Sin EXP.',
      data: [8, 10, 22, 30, 36],
      borderColor: '#2BB7DC',
      backgroundColor: '#FFFFFF',
      borderWidth: 1,
      tension: 0.1,
    },
  ],
}

const dataApplicantDesist = {
  labels: ['05/09', '06/09', '07/09', '08/09', '09/09'],
  datasets: [
    {
      label: 'Postulantes',
      data: [5, 2, 3, 1, 0],
      borderColor: '#263658',
      backgroundColor: '#FFFFFF',
      borderWidth: 1,
      tension: 0.1, // Para suavizar las líneas
    },
  ],
}

const totalPostulantes = 70
const evaluados = 37
const sinEvaluar = totalPostulantes - evaluados

const dataApplicantProcess = {
  labels: ['Evaluados', 'Sin Evaluar'],
  datasets: [
    {
      data: [evaluados, sinEvaluar],
      backgroundColor: ['#263658', '#2BB7DC'],
      borderColor: ['#263658', '#2BB7DC'],
      borderWidth: 1,
    },
  ],
}

const MyProcessesMetrics = () => {
  const [selectStage, setSelectStage] = useState('all')

  const isMobile = useMediaQuery('(max-width: 640px)')
  const chartAllHeight = isMobile ? 300 : 420 // Altura condicional

  const changeSelect = (name, value) => {
    setSelectStage(value)
  }

  const optionsChartLines = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'bottom' as const,
        labels: {
          usePointStyle: true,
          pointStyle: 'circle',
          font: {
            size: 12,
          },
          boxWidth: 6,
          boxHeight: 6,
          padding: 25,
          color: '#263658',
        },
      },
      tooltip: {
        enabled: true,
      },
      datalabels: {
        display: false,
      },
    },
    elements: {
      point: {
        radius: 5,
        hoverRadius: 7,
      },
    },
    scales: {
      y: {
        beginAtZero: true, // El eje Y comienza en 0
        //max: 200, // Limitar el eje Y
      },
    },
  }

  const optionsChartCircle = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'right' as const,
        labels: {
          usePointStyle: true,
          pointStyle: 'circle',
          font: {
            size: 12,
          },
          boxWidth: 6,
          boxHeight: 6,
          padding: 25,
          color: '#263658',
        },
      },
      tooltip: {
        enabled: true,
      },
      datalabels: {
        display: true,
        color: (context) => {
          const index = context.dataIndex
          return index === 0 ? 'white' : '#263658'
        },
        formatter: (value, context) => {
          const label = context.chart.data.labels[context.dataIndex]
          return `${label}: ${value}`
        },
      },
    },
    cutout: '0%',
  }

  return (
    <div className="text-secondary-500 font-inter flex flex-col gap-8">
      <p className="text-sm dark:text-white">
        Visualiza el estado actual del proceso de selección a través de métricas
        clave. Este panel te permite monitorear cuántos postulantes han sido
        evaluados, rechazados, avanzados a la siguiente etapa, y cuántas ofertas
        de trabajo han sido extendidas. Utiliza estas métricas para obtener una
        visión clara y en tiempo real del progreso de cada convocatoria.
      </p>
      <SelectUi
        items={[
          { value: 'all', label: 'Todas' },
          { value: 'applicants', label: 'Postulaciones' },
          { value: 'interviews', label: 'Entrevistas' },
          { value: 'evaluations', label: 'Evaluaciones' },
          { value: 'offers', label: 'Ofertas' },
        ]}
        placeholder="Seleccionar"
        name="option"
        value={selectStage}
        onChange={changeSelect}
      />
      {selectStage === 'all' ? (
        <div className="shadow-cards rounded-[11px] bg-primary-foreground xs:p-3 sm:px-5 sm:py-8">
          <div
            style={{
              width: '100%',
              height: `${chartAllHeight}px`,
              margin: '0 auto',
            }}
            //style={{ maxWidth: '1000px', margin: '0 auto' }}
          >
            <Line data={dataAllProcesses} options={optionsChartLines} />
          </div>
        </div>
      ) : (
        <div className="flex flex-wrap justify-between xs:gap-8 lg:gap-0">
          <div className="shadow-cards rounded-[11px] bg-primary-foreground xs:p-3 sm:px-5 sm:py-8 flex flex-col gap-4 xs:w-full sm:w-[340px]">
            <div className="flex flex-col gap-2">
              <span className="text-sm">Cantidad de postulantes</span>
              <span className="font-medium">73</span>
            </div>
            <div style={{ width: '100%', height: '210px', margin: '0 auto' }}>
              <Line data={dataApplicants} options={optionsChartLines} />
            </div>
          </div>
          <div className="shadow-cards rounded-[11px] bg-primary-foreground xs:p-3 sm:px-5 sm:py-8 flex flex-col gap-4 xs:w-full sm:w-[340px]">
            <div className="flex flex-col gap-2">
              <span className="text-sm">Cantidad de procesados</span>
              <span className="font-medium">73</span>
            </div>
            <div>
              <Doughnut
                data={dataApplicantProcess}
                options={optionsChartCircle}
                height={200}
              />
            </div>
          </div>
          <div className="shadow-cards rounded-[11px] bg-primary-foreground xs:p-3 sm:px-5 sm:py-8 flex flex-col gap-4 xs:w-full sm:w-[340px]">
            <div className="flex flex-col gap-2">
              <span className="text-sm">
                Cantidad de postulantes que desistieron
              </span>
              <span className="font-medium">73</span>
            </div>
            <div style={{ width: '100%', height: '210px', margin: '0 auto' }}>
              <Line data={dataApplicantDesist} options={optionsChartLines} />
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default MyProcessesMetrics
