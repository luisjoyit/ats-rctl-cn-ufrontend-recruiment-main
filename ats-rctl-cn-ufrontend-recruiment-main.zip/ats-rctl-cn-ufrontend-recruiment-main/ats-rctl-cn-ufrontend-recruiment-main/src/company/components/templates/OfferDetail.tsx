import { useOutletContext, useParams } from 'react-router-dom'
import { dataTalent } from './Offers'
import { useEffect, useState } from 'react'
import {
  IconFlame,
  IconHeartFilled,
  IconLink,
  IconMapPin,
  IconX,
} from '@tabler/icons-react'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import TabSkills from '../molecules/Offers/TabSkills'
import TabExperience from '../molecules/Offers/TabExperience'
import TabEducation from '../molecules/Offers/TabEducation'
import TabEvaluations from '../molecules/Offers/TabEvaluations'
import TabContact from '../molecules/Offers/TabContact'
import useMediaQuery from '@/hooks/useMediaQuery'
import { Drawer, DrawerContent } from '@/components/ui/drawer'
import { Button } from '@/components/ui/button'

interface Experience {
  position: string
  dates: string[]
  activities: string[]
}

interface Education {
  name: string
  institution: string
  date: string[]
}

interface Certificates {
  name: string
}

interface Evaluations {
  name: string
  score: number
}

interface Offer {
  id: number
  name: string
  position: string
  modality: string
  city: string
  country: string
  skills: string[]
  habilities: string[]
  salary: number
  img: string
  experience: Experience[]
  education: Education[]
  certificates: Certificates[]
  evaluations: Evaluations[]
  aboutMe: string
  email: string
  phone: string
  linkedln: string
  github: string
  whatsApp: string
}

interface OutletContextType {
  open: boolean
  handleCardClick: (id: string | null) => void
  handleCloseDrawer: () => void
}

export default function OfferDetail() {
  const data: Offer[] = dataTalent

  const { offerId } = useParams<{ offerId: string }>()
  const offerIdNumber = Number(offerId)

  //Busqueda de id en la data
  const [offer, setOffer] = useState<Offer | undefined>(undefined)

  const isDesktop = useMediaQuery('(min-width: 768px)')
  const [activeTab, setActiveTab] = useState('skills')

  const handleTabChange = (value) => {
    setActiveTab(value)
  }

  useEffect(() => {
    const searchData = data.find((item) => item.id === offerIdNumber)
    setOffer(searchData)
  }, [offerIdNumber, data])

  const { open, handleCardClick, handleCloseDrawer } =
    useOutletContext<OutletContextType>()

  const dataTabsTrigger = [
    {
      value: 'skills',
      name: 'Skills',
    },
    {
      value: 'experience',
      name: 'Experiencia',
    },
    {
      value: 'education',
      name: 'Educación',
    },
    {
      value: 'evaluations',
      name: 'Evaluaciones',
    },
    {
      value: 'contact',
      name: 'Contacto',
    },
  ]

  const content = (
    <div>
      {offer && (
        <div className="flex flex-col font-inter text-secondary-500 dark:text-primary-foreground gap-4">
          <div className="flex flex-row w-full gap-3">
            <div className="flex items-center">
              <div className="relative w-20 items-center">
                <img
                  src={offer.img}
                  alt=""
                  className="h-20 w-20 rounded-full object-cover"
                />
                <img
                  src="https://w7.pngwing.com/pngs/205/835/png-transparent-flag-of-peru-national-flag-flag-of-scotland-portugal-miscellaneous-flag-text.png"
                  alt=""
                  className="absolute bottom-0 right-0  xs:w-5 sm:w-6 xs:h-5 sm:h-6 rounded-full object-cover"
                />
              </div>
            </div>
            <div className="flex flex-col w-full gap-2">
              <div className="flex xs:flex-col md:flex-row justify-between gap-2">
                <span className="font-medium xs:text-xl md:text-2xl">
                  {offer.name}
                </span>
                <div className="flex flex-row gap-2 xs:justify-between md:justify-normal">
                  <span className="text-sm bg-accent-200 w-[83px] h-[25px] rounded-[11px] px-2 flex items-center justify-center">
                    {offer.modality}
                  </span>
                  <IconHeartFilled size={20} />
                </div>
              </div>
              <div className="flex flex-row justify-between text-sm">
                <span>{offer.position}</span>
                <span>{`$${offer.salary}/mes`}</span>
              </div>
              <div className="flex xs:flex-col md:flex-row justify-between text-sm gap-2">
                <div className="flex flex-row gap-1">
                  <IconMapPin stroke={1} size={18} />
                  <span>{`${offer.city}, ${offer.country}`}</span>
                </div>
                <span>5 años de experiencia</span>
              </div>
            </div>
          </div>
          <div className="flex flex-row justify-between">
            <div className="flex flex-row justify-start gap-2">
              <Button variant="primary" size="sm" className="w-[78px]">
                Ver CV
              </Button>
              <Button variant="secondary" size="sm" className="w-[49px]">
                <IconLink stroke={2} size={16} />
              </Button>
            </div>
            <Button
              variant="primary"
              size="sm"
              className="xs:w-[120px] md:w-[139px]"
            >
              Invitar a empleo
            </Button>
          </div>
          <div className="flex flex-row gap-1 justify-start items-center">
            <IconFlame
              stroke={2}
              size={18}
              style={{ fill: '#FC8862', stroke: '#FC8862' }}
            />
            <span className="text-xs">{`${offer.name} se encuentra en 2 procesos de selección`}</span>
          </div>
          <div className="">
            <Tabs
              defaultValue="skills"
              className="w-full font-inter text-secondary-500"
              onValueChange={handleTabChange}
            >
              <TabsList
                className={`grid w-full grid-cols-5 font-medium overflow-x-auto tabsOffer-list`}
              >
                {dataTabsTrigger.map((tab, index) => (
                  <TabsTrigger
                    key={index}
                    value={tab.value}
                    style={
                      isDesktop
                        ? { fontSize: '14px', justifyContent: 'center' }
                        : { fontSize: '12px', justifyContent: 'start' }
                    }
                    className={`px-2 md:px-6 dark:text-secondary-500 ${
                      activeTab === tab.value
                        ? 'tabsOffer-trigger-active'
                        : 'tabsOffer-trigger-inactive'
                    }`}
                  >
                    {tab.name}
                  </TabsTrigger>
                ))}
              </TabsList>
              <TabsContent value="skills" className="mt-0">
                <TabSkills
                  skills={offer.skills}
                  habilities={offer.habilities}
                />
              </TabsContent>
              <TabsContent value="experience" className="mt-0">
                <TabExperience experience={offer.experience} />
              </TabsContent>
              <TabsContent value="education" className="mt-0">
                <TabEducation
                  education={offer.education}
                  certificates={offer.certificates}
                />
              </TabsContent>
              <TabsContent value="evaluations" className="mt-0">
                <TabEvaluations evaluations={offer.evaluations} />
              </TabsContent>
              <TabsContent value="contact" className="mt-0">
                <TabContact offer={offer} />
              </TabsContent>
            </Tabs>
          </div>
        </div>
      )}
    </div>
  )

  return (
    <>
      {isDesktop ? (
        content
      ) : (
        <Drawer
          open={open}
          onOpenChange={() => handleCardClick(null)}
          onClose={handleCloseDrawer}
        >
          <DrawerContent className="xs:p-2 sm:p-6 h-[100vh] overflow-y-auto">
            <div className="flex justify-end">
              <IconX size={18} stroke={1} onClick={handleCloseDrawer} />
            </div>
            {content}
          </DrawerContent>
        </Drawer>
      )}
    </>
  )
}
