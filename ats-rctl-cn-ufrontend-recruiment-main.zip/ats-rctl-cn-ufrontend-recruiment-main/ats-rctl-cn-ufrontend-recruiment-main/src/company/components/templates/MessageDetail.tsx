import React, { useEffect, useRef, useState } from 'react'
import { useNavigate, useOutletContext, useParams } from 'react-router-dom'
import { messagesData } from './Messages'
import {
  IconChecks,
  IconCircleFilled,
  IconFile,
  IconInfoCircle,
  IconMicrophone,
  IconPhoneCall,
  IconPhoto,
  IconSend2,
  IconVideo,
  IconX,
} from '@tabler/icons-react'
import { Input } from '@/components/ui/input'
import useMediaQuery from '@/hooks/useMediaQuery'
import { Drawer, DrawerContent } from '@/components/ui/drawer'
import { DialogTitle } from '@/components/ui/dialog'

interface Message {
  id: number | string
  avatar: string
  name: string
  skills: string[]
  stateUser: string
  messages: {
    id: number | string
    name: string
    message: string
    date: string
    hour: string
    stateMessage: string
  }[]
}

interface OutletContextType {
  openDrawerMobile: boolean
  handleChat: (id: string | null) => void
  handleCloseDrawer: () => void
}

export default function MessageDetail() {
  const data: Message[] = messagesData

  const { messageId } = useParams<{ messageId: string }>()
  const navigate = useNavigate()

  const [message, setMessage] = useState<Message | undefined>(undefined)
  const [newMessage, setNewMessage] = useState<string>('')

  const isDesktop = useMediaQuery('(min-width: 768px)')
  const messagesEndRef = useRef(null)

  useEffect(() => {
    const searchData = data.find((item) => item.id === messageId)
    setMessage(searchData)
  }, [messageId, data])

  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' })
    }
  }, [message])

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleSendMessage()
    }
  }

  const handleSendMessage = () => {
    if (message && newMessage !== '') {
      const now = new Date()
      const newMessageObj = {
        id: message.messages.length + 1,
        name: 'User', // Nombre simulado del usuario que envía
        message: newMessage,
        date: now.toLocaleDateString(),
        hour: now.toLocaleTimeString(),
        stateMessage: 'sent', // Valor por default al enviar el mensaje
      }

      setMessage((prevMessage) => {
        if (prevMessage) {
          return {
            ...prevMessage,
            messages: [...prevMessage.messages, newMessageObj],
          }
        }
        return prevMessage
      })
      setNewMessage('')
    }
  }

  const getStateMessage = () => {
    return <IconChecks stroke={2} size={16} />
  }

  const { openDrawerMobile, handleChat, handleCloseDrawer } =
    useOutletContext<OutletContextType>()

  const content = (
    <div className="bg-card h-full flex flex-col font-inter">
      <div className="flex flex-row w-full justify-between h-[110px] p-3 border-b-[1px] border-[#D4D4D4]">
        <div className="flex flex-row w-full">
          <div className="flex xs:w-[80px] sm:w-[100px] xs:pl-0 sm:pl-5">
            <img
              src={message?.avatar}
              alt=""
              className="xs:h-16 sm:h-20 xs:w-16 sm:w-20 rounded-full object-cover"
            />
          </div>
          <div className="flex flex-row flex-1 items-center justify-between">
            <div className="flex flex-col xs:pl-0 sm:pl-4">
              <span className="font-bold xs:text-lg sm:text-2xl text-secondary-500 dark:text-white">
                {message?.name}
              </span>
              <div className="flex flex-row items-center">
                <IconCircleFilled
                  color={
                    message?.stateUser === 'online' ? '#00A743' : '#B0B0B0'
                  }
                  size={isDesktop ? 16 : 12}
                />
                <span
                  className={`xs:text-base sm:text-xl font-semibold pl-2 ${message?.stateUser === 'online' ? 'text-[#00A743]' : 'text-[#B0B0B0]'}`}
                >
                  {message?.stateUser === 'online' ? 'Online' : 'Desconectado'}
                </span>
              </div>
            </div>
            <div className="flex flex-row xs:gap-2 sm:gap-4 items-center">
              <IconPhoneCall
                stroke={2}
                color="#B0B0B0"
                size={isDesktop ? 24 : 20}
                className="cursor-pointer"
              />
              <IconVideo
                stroke={2}
                color="#B0B0B0"
                size={isDesktop ? 24 : 20}
                className="cursor-pointer"
              />
              <IconInfoCircle
                stroke={2}
                color="#B0B0B0"
                size={isDesktop ? 24 : 20}
                className="cursor-pointer"
              />
            </div>
          </div>
        </div>
        {isDesktop && (
          <IconX
            stroke={1.5}
            size={18}
            className="cursor-pointer text-secondary-500 dark:text-white"
            onClick={() => navigate('/company/messages')}
          />
        )}
      </div>
      <div className="container-messages flex-1 overflow-y-auto p-3 w-full">
        {message?.messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex flex-col mb-4 w-full ${message.name === msg.name ? 'items-start' : 'items-end'}`}
          >
            <div className="flex flex-col w-[60%] gap-2">
              <div className="flex flex-col ml-4">
                <span className="font-bold text-xs">{msg.date}</span>
                <span className="font-bold text-xs text-[#8E8E8E]">
                  {msg.hour}
                </span>
              </div>
              <div
                className={`p-4 rounded-4xl xs:font-semibold sm:font-bold flex flex-col
                  ${message.name === msg.name ? 'bg-[#EAECEE] text-secondary-500' : 'bg-primary-900 text-white'}`}
              >
                <p className="xs:text-xs sm:text-sm">{msg.message}</p>
                <div className="flex justify-end">{getStateMessage()}</div>
              </div>
            </div>
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>
      <div className="flex flex-row items-center xs:p-2 sm:p-6 gap-4 w-full">
        <div className="flex flex-row xs:gap-1 sm:gap-2">
          <IconMicrophone
            stroke={2}
            color="#383FE9"
            size={isDesktop ? 28 : 24}
            className="cursor-pointer"
          />
          <IconPhoto
            stroke={2}
            color="#383FE9"
            size={isDesktop ? 28 : 24}
            className="cursor-pointer"
          />
          <IconFile
            stroke={2}
            color="#383FE9"
            size={isDesktop ? 28 : 24}
            className="cursor-pointer"
          />
        </div>
        <div className="w-full">
          <Input
            placeholder="Aa"
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            onKeyDown={handleKeyDown}
          />
        </div>
        <div>
          <IconSend2
            stroke={2}
            color="#383FE9"
            size={28}
            className="cursor-pointer"
            onClick={handleSendMessage}
          />
        </div>
      </div>
    </div>
  )

  return (
    <>
      {isDesktop ? (
        content
      ) : (
        <Drawer
          open={openDrawerMobile}
          onOpenChange={() => handleChat(null)}
          onClose={handleCloseDrawer}
        >
          <DialogTitle />
          <DrawerContent className="xs:p-2 sm:p-6 h-[100vh] overflow-y-auto">
            <div className="flex justify-end">
              <IconX size={18} stroke={1} onClick={handleCloseDrawer} />
            </div>
            {content}
          </DrawerContent>
        </Drawer>
      )}
    </>
  )
}
