import {
  IconArrowLeft,
  IconArrowUpRight,
  IconClockHour10,
  IconUserPlus,
  IconPointFilled,
} from '@tabler/icons-react'
import {
  Link,
  Outlet,
  useLocation,
  useNavigate,
  useParams,
} from 'react-router-dom'

const MyProcessesId = () => {
  const navigate = useNavigate()
  const location = useLocation()
  const { processesId } = useParams()

  const links = [
    {
      name: 'Info',
      url: `/company/myProcesses/${processesId}/info`,
    },
    {
      name: 'Etapas',
      url: `/company/myProcesses/${processesId}/stages`,
    },
    {
      name: 'Actividad',
      url: `/company/myProcesses/${processesId}/activity`,
    },
    {
      name: 'Métricas',
      url: `/company/myProcesses/${processesId}/metrics`,
    },
  ]

  return (
    <div>
      <div className="flex flex-col font-inter text-secondary-500 xs:gap-2 sm:gap-4">
        <div className="flex xs:flex-col sm:flex-row xs:gap-3 sm:gap-10 w-full xs:items-start sm:items-center">
          <div>
            <button
              className="flex bg-backgroundF-500 rounded-4xl w-auto h-[23px] px-3 items-center gap-2 text-secondary-500 text-xs font-medium"
              onClick={() => navigate('/company/myProcesses')}
            >
              <IconArrowLeft stroke={1.5} size={14} />
              Todos los procesos
            </button>
          </div>
          <div className="flex flex-row gap-3 items-center">
            <div className="flex flex-row gap-1 items-center">
              <span className="font-semibold text-xl dark:text-primary-foreground">
                Backend Developer
              </span>
              <IconArrowUpRight
                stroke={1.5}
                size={16}
                className="text-secondary"
              />
            </div>
            <span className="bg-[#F0F2F4] rounded-4xl px-2 h-[23px] text-xs font-medium flex items-center">
              Remoto
            </span>
          </div>
        </div>
        <div className="flex flex-col gap-3">
          <div className="flex xs:flex-col sm:flex-row xs:gap-2 sm:gap-6">
            <span className="text-accent-600 text-sm font-medium">
              Software Development
            </span>
            <div className="flex xs:gap-3 sm:gap-6 font-medium xs:text-xs sm:text-sm text-secondary-500 dark:text-white">
              <span className="">$1,500 - $2,000</span>
              <span>Senior</span>
              <div className="flex xs:gap-1 sm:gap-2 items-center">
                <IconClockHour10
                  stroke={1}
                  size={16}
                  className="text-secondary"
                />
                <span>Full time</span>
              </div>
              <div className="flex xs:gap-1 sm:gap-2 items-center">
                <IconUserPlus stroke={1} size={16} className="text-secondary" />
                <span>Perú</span>
              </div>
            </div>
          </div>
          <div className="flex flex-row gap-1.5 items-center">
            <IconPointFilled size={14} stroke="#00C851" fill="#00C851" />
            <span className="text-success text-sm font-medium ">Activo</span>
          </div>
        </div>
        <div className="flex xs:flex-col sm:flex-row w-full justify-between xs:gap-3 sm:gap-0 text-[#3E5254] text-sm h-[50px]">
          <div className="flex flex-row justify-between xs:gap-6 md:gap-16">
            {links.map((link, id) => (
              <div key={id} className="flex flex-col h-full">
                <Link to={link.url} className="font-bold text-sm">
                  {link.name}
                </Link>
                {location.pathname === link.url && (
                  <hr className="border-2 border-grafic dark:border-white w-full mt-2" />
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
      <div className="xs:pt-3 sm:pt-5">
        <Outlet />
      </div>
    </div>
  )
}

export default MyProcessesId
