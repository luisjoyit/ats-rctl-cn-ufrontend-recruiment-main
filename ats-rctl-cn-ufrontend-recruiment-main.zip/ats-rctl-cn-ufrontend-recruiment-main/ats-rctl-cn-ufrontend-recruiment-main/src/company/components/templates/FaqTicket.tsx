import { useState, useEffect } from 'react'
import {
  IconSearch,
  IconAdjustmentsHorizontal,
  IconChevronLeft,
  IconX,
} from '@tabler/icons-react'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Pagination } from '@/components/ui/pagination'
import { Link } from 'react-router-dom'
import { Drawer, DrawerContent, DrawerClose } from '@/components/ui/drawer'
import InputWithIcon from '@/components/inputWithIcon'

export default function FaqTicket() {
  const [allTickets, setAllTickets] = useState([
    {
      id: 'N0002190319',
      asunto: 'No puedo guardar cambios en mi perfil',
      tipo: 'Buscar talento',
      estado: 'Abierto',
      fecha: '04 Jul 2024',
    },
    {
      id: 'N0002190320',
      asunto: 'No puedo usar filtros',
      tipo: 'Buscar talento',
      estado: 'Abierto',
      fecha: '04 Jul 2024',
    },
    {
      id: 'N0002190321',
      asunto: 'Ayuda sobre cv de postulante',
      tipo: 'Buscar talento',
      estado: 'En progreso',
      fecha: '04 Jul 2024',
    },
    {
      id: 'N0002190322',
      asunto: 'Como descargar mis reportes',
      tipo: 'Buscar talento',
      estado: 'En progreso',
      fecha: '04 Jul 2024',
    },
    {
      id: 'N0002190323',
      asunto: 'No puedo guardar cambios en mi perfil',
      tipo: 'Mis Evaluaciones',
      estado: 'En progreso',
      fecha: '04 Jul 2024',
    },
    {
      id: 'N0002190324',
      asunto: 'No puedo guardar cambios en mi perfil',
      tipo: 'Buscar talento',
      estado: 'En progreso',
      fecha: '04 Jul 2024',
    },
    {
      id: 'N0002190325',
      asunto: 'No puedo guardar cambios en mi perfil',
      tipo: 'Mi perfil',
      estado: 'Finalizado',
      fecha: '04 Jul 2024',
    },
    {
      id: 'N0002190326',
      asunto: 'No puedo guardar cambios en mi perfil',
      tipo: 'Mi perfil',
      estado: 'Finalizado',
      fecha: '04 Jul 2024',
    },
  ])

  const [filteredTickets, setFilteredTickets] = useState(allTickets)
  const [currentPage, setCurrentPage] = useState(1)
  const [isDrawerOpen, setIsDrawerOpen] = useState(false)
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [selectedStates, setSelectedStates] = useState([])
  const [isMobile, setIsMobile] = useState(false)
  const itemsPerPage = 5
  const totalPages = Math.ceil(filteredTickets.length / itemsPerPage)

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 768)
    }

    window.addEventListener('resize', handleResize)
    handleResize()

    return () => window.removeEventListener('resize', handleResize)
  }, [])

  const handlePageChange = (page: number) => {
    setCurrentPage(page)
  }

  const openFilters = () => {
    if (isMobile) {
      setIsDrawerOpen(true)
    } else {
      setIsModalOpen(true)
    }
  }

  const closeFilters = () => {
    setIsDrawerOpen(false)
    setIsModalOpen(false)
  }

  const handleStateSelection = (state: string) => {
    setSelectedStates((prevStates) => {
      if (prevStates.includes(state)) {
        return prevStates.filter((s) => s !== state)
      } else {
        return [...prevStates, state]
      }
    })
  }

  const applyFilter = () => {
    if (selectedStates.length > 0) {
      const filteredTickets = allTickets.filter((ticket) =>
        selectedStates.includes(ticket.estado),
      )
      setFilteredTickets(filteredTickets)
    } else {
      setFilteredTickets(allTickets)
    }
    setCurrentPage(1)
    closeFilters()
  }

  const clearFilters = () => {
    setSelectedStates([])
    setFilteredTickets(allTickets)
    setCurrentPage(1)
  }

  const renderTicketStatus = (estado) => {
    const statusClasses = {
      Abierto: 'bg-green-100 text-green-800',
      'En progreso': 'bg-[#F9E8D9] text-yellow-800',
      Finalizado: 'bg-red-100 text-red-800',
    }

    return (
      <span
        className={`inline-flex items-center justify-center w-[104px] h-[31px] rounded-[8px] text-xs font-semibold ${statusClasses[estado]}`}
      >
        {estado}
      </span>
    )
  }

  const renderFilterContent = () => (
    <div className="space-y-6">
      <div>
        <h3 className="text-base font-semibold mb-2 text-secondary-500">
          Ordenar por
        </h3>
        <div className="flex flex-wrap gap-2 font-inter">
          <Button className="w-[106px] h-[31px] rounded-[50px] bg-neutral-200 text-secondary-500 hover:text-white">
            Más Reciente
          </Button>
          <Button className="w-[106px] h-[31px] rounded-[50px] bg-neutral-200 text-secondary-500 hover:text-white">
            Más Antiguo
          </Button>
        </div>
      </div>

      <div>
        <h3 className="text-base font-semibold mb-2 text-secondary-500">
          Tipo
        </h3>
        <div className="flex flex-wrap gap-2 font-inter">
          <Button className="w-[79px] h-[31px] rounded-[50px] bg-neutral-200 text-secondary-500 hover:text-white">
            Mi perfil
          </Button>
          <Button className="w-[129px] h-[31px] rounded-[50px] bg-neutral-200 text-secondary-500 hover:text-white">
            Mis evaluaciones
          </Button>
          <Button className="w-[114px] h-[31px] rounded-[50px] bg-neutral-200 text-secondary-500 hover:text-white">
            Buscar talento
          </Button>
          <Button className="w-[104px] h-[31px] rounded-[50px] bg-neutral-200 text-secondary-500 hover:text-white">
            Mis reportes
          </Button>
        </div>
      </div>

      <div>
        <h3 className="text-base font-semibold mb-2 text-secondary-500">
          Estado
        </h3>
        <div className="flex flex-wrap gap-2 font-inter">
          <button
            className={`w-[98px] h-[31px] rounded-[8px] text-sm ${
              selectedStates.includes('Abierto')
                ? 'bg-[#008536] text-white'
                : 'bg-[#D9F9E4] text-[#0E5827]'
            }`}
            onClick={() => handleStateSelection('Abierto')}
          >
            Abierto
          </button>
          <button
            className={`w-[98px] h-[31px] rounded-[8px] text-sm ${
              selectedStates.includes('En progreso')
                ? 'bg-[#CC8800] text-white'
                : 'bg-tags-yellow-50 text-[#58310E]'
            }`}
            onClick={() => handleStateSelection('En progreso')}
          >
            En progreso
          </button>
          <button
            className={`w-[98px] h-[31px] rounded-[8px] text-sm ${
              selectedStates.includes('Finalizado')
                ? 'bg-[#D70000] text-white'
                : 'bg-[#FFE0E0] text-[#6C0000]'
            }`}
            onClick={() => handleStateSelection('Finalizado')}
          >
            Finalizado
          </button>
        </div>
      </div>
    </div>
  )

  return (
    <div className="max-w-6xl mx-auto min-h-screen p-4 md:p-6 font-inter">
      <div className="mb-6 flex items-center text-sm text-gray-600">
        <Link
          to="http://localhost:9000/recruitment/company/faq"
          className="flex items-center"
        >
          <IconChevronLeft className="w-4 h-4 mr-1" />
          <span>Regresar al centro de ayuda</span>
        </Link>
      </div>

      <h1 className="text-2xl font-bold mb-4">Ver mis tickets</h1>

      <div className="flex xs:flex-col md:flex-row justify-between items-center mb-4 gap-2">
        <div className="flex xs:flex-col md:flex-row items-center gap-2">
          {/* //Input de buscar*/}
          <InputWithIcon className="lg:w-[315px]" />

          {/* //Boton de filtros*/}
          <Button size="sm" variant="primary" onClick={openFilters}>
            <IconAdjustmentsHorizontal className="mr-2" size={14} />
            Filtros
          </Button>
        </div>

        {/* //Crear nuevo ticket*/}
        <Link
          to="http://localhost:9000/recruitment/company/faq/ticket/update"
          className="md:w-[163px]"
        >
          <Button
            variant="default"
            className="w-full md:w-[163px] h-[31px] bg-[#263658] text-white hover:bg-[#263658]"
          >
            Crear nuevo ticket
          </Button>
        </Link>
      </div>

      {isMobile ? (
        <div className="space-y-4">
          {filteredTickets.map((ticket) => (
            <div
              key={ticket.id}
              className="bg-white p-4 rounded-lg shadow-sm border border-gray-200 w-full"
            >
              <Link
                to="http://localhost:9000/recruitment/company/faq/ticket/seeticket"
                className="font-semibold text-secondary-500 hover:underline"
              >
                {ticket.asunto}
              </Link>
              <p className="text-sm text-gray-600 mt-1">Tipo: {ticket.tipo}</p>
              <div className="mt-2">{renderTicketStatus(ticket.estado)}</div>
              <p className="text-sm text-gray-600 mt-2">
                Fecha de creación: {ticket.fecha}
              </p>
              <p className="text-sm text-gray-600 mt-1">
                Ticket ID: {ticket.id}
              </p>
            </div>
          ))}
        </div>
      ) : (
        <div className="bg-white rounded-md shadow overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                <th className="px-6 py-3">Asunto</th>
                <th className="px-6 py-3">Tipo</th>
                <th className="px-6 py-3">Estado</th>
                <th className="px-6 py-3">Fecha de creación</th>
                <th className="px-6 py-3">Ticket ID</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredTickets.map((ticket) => (
                <tr key={ticket.id}>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-secondary-500">
                    <Link
                      to="http://localhost:9000/recruitment/company/faq/ticket/seeticket"
                      className="hover:underline"
                    >
                      {ticket.asunto}
                    </Link>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-secondary-500">
                    {ticket.tipo}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {renderTicketStatus(ticket.estado)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-secondary-500">
                    {ticket.fecha}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-secondary-500">
                    {ticket.id}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <div className="mt-4 flex justify-center">
        <Pagination
          totalItems={filteredTickets.length}
          itemsPerPage={itemsPerPage}
          currentPage={currentPage}
          onPageChange={handlePageChange}
        />
      </div>

      {isMobile ? (
        <Drawer open={isDrawerOpen} onOpenChange={setIsDrawerOpen}>
          <DrawerContent className="p-6 font-inter max-h-[95vh] mt-[5vh] rounded-t-[20px] overflow-y-auto">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold font-inter text-secondary-500">
                Filtros
              </h2>
              <DrawerClose asChild>
                <button className="text-gray-500 hover:text-gray-700">
                  <IconX size={20} />
                </button>
              </DrawerClose>
            </div>

            {renderFilterContent()}

            <div className="mt-6 flex justify-between items-center">
              <button
                className="text-secondary-500 text-sm"
                onClick={clearFilters}
              >
                Limpiar todo
              </button>
              <Button
                className="w-[140px] h-[37px] bg-secondary-500 text-white rounded-[8px] text-sm"
                onClick={applyFilter}
              >
                Aplicar
              </Button>
            </div>
          </DrawerContent>
        </Drawer>
      ) : (
        isModalOpen && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg w-[540px] h-[434px] p-6 relative">
              <button
                onClick={closeFilters}
                className="absolute top-4 right-4 text-gray-500 hover:text-gray-700"
              >
                <IconX size={20} />
              </button>
              <h2 className="text-xl font-bold mb-4 font-inter mt-4 text-secondary-500">
                Filtros
              </h2>

              {renderFilterContent()}

              <div className="mt-10 flex justify-between items-center">
                <div className="flex-grow font-inter">
                  <button
                    className="text-secondary-500 text-sm ml-6"
                    onClick={clearFilters}
                  >
                    Limpiar todo
                  </button>
                </div>
                <button
                  className="w-[140px] h-[37px] bg-secondary-500 text-white rounded-[8px] text-sm"
                  onClick={applyFilter}
                >
                  Aplicar
                </button>
              </div>
            </div>
          </div>
        )
      )}
    </div>
  )
}
