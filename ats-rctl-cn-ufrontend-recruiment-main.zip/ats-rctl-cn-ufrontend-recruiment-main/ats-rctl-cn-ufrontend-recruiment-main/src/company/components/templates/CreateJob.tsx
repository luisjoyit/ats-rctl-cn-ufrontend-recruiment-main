import { useState } from 'react'
import PostAJob from '../atoms/CreateJob/PostAJob'
import Features from '../atoms/CreateJob/Features'
import Visibility from '../atoms/CreateJob/Visibility'
import Questions from '../atoms/CreateJob/Questions'
//@ts-ignore
import { t, useLanguage } from '@joyit/layout'
import { Button } from '@/components/ui/button'
import { toast } from 'sonner'
import {
  jobFormSchema,
  JobFormSchema,
} from '@/company/validations/jobFormSchema'
import { SubmitHandler, useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import {
  AlertDialog,
  AlertDialogContent,
  AlertDialogFooter,
  AlertDialogTitle,
  AlertDialogTrigger,
  AlertDialogAction,
  AlertDialogCancel,
} from '@/components/ui/alert-dialog'
import { IconX } from '@tabler/icons-react'
import { useNavigate } from 'react-router-dom'
import ViewPreviewJob from '../atoms/CreateJob/ViewPreviewJob'
import ModalFinishPostAJob from '../atoms/CreateJob/ModalFinishPostAJob'
import { useJobsCompany } from '@/company/hooks/service-hoooks/useJobsCompany'
import { QuestionType, WorkMode } from '@/gql/graphql'

const initialValues: JobFormSchema = {
  jobName: '',
  //jobArea: '',
  levelExperience: { value: '', label: '' },
  nameProfile: { value: '', label: '' },
  availablePositions: 1,
  modality: { value: '', label: '' },
  workSchedule: { value: '', label: '' },
  countryCity: { value: '', label: '' },
  language: { value: '', label: '' },
  levelLanguage: { value: '', label: '' },
  rangeSalarity: [500, 1500],
  fixedSalary: false,
  fixedSalaryAmount: undefined,
  adHonorem: false,
  stackTech: [],
  jobDescription: '',
  jobResponsabilities: '',
  jobAdditional: '',
  benefits: [],
  showCompanyName: false,
  onlyVerifiedProfiles: false,
  questions: [],
}

const CreateJob = () => {
  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
    setValue,
    getValues,
    watch,
    trigger,
    clearErrors,
  } = useForm<JobFormSchema>({
    resolver: zodResolver(jobFormSchema),
    defaultValues: initialValues,
    mode: 'onChange',
  })
  const { createJob } = useJobsCompany()

  const [alertSaveDraft, setAlertSaveDraft] = useState(false)
  const [alertPreview, setAlertPreview] = useState(false)
  const [alertFinish, setAlertFinish] = useState(false)

  const navigate = useNavigate()

  const handleSaveAsDraft = () => {
    // const data = getValues()
    //guardar en BD
    // console.log("Guardando en BD", data)
    setAlertSaveDraft(false)
    navigate('/company/myProcesses')
    toast.success('Se creo la oferta correctamente')
  }

  const handlePreview = (data: JobFormSchema) => {
    setAlertPreview(true)
    // Lógica para mostrar vista previa
  }

  const handlePublish = (data: JobFormSchema) => {
    createJob({
      job: {
        benefitsIds: data.benefits.map((benefit) => Number(benefit.value)),
        technologyStackIds: data.stackTech.map((tech) => Number(tech.value)),
        companyId: '1',
        countryId: data.countryCity.value,
        description: data.jobDescription,
        description_functions: data.jobResponsabilities,
        description_functions_additional_requirements: data.jobAdditional,
        workMode: data.modality.label.toUpperCase() as WorkMode, //todo : cambiar a por id de workmode
        visibility_name_company: data.showCompanyName,
        verified_profiles: data.onlyVerifiedProfiles,
        maxSalary: data.rangeSalarity[1],
        minSalary: data.rangeSalarity[0],
        name: data.jobName,
        languageId: Number(data.language.value),
        levelOfExperienceId: Number(data.levelExperience.value),
        profileTypesId: Number(data.nameProfile.value),
        openPositions: data.availablePositions,
        employeerId: 1,
        questions: data.questions.map((question) => ({
          questionText: question.titleQuestion,
          type: question.typeAnswer as QuestionType,
          options: question?.answers?.map((answer) => {
            return {
              optionText: answer,
            }
          }),
        })),
      },
    })
    setAlertFinish(true)
    // Lógica para publicar
  }

  const onError = (errors) => {}

  return (
    <div className="flex flex-col gap-6 font-inter relative">
      <form
        //onSubmit={handleSubmit(onSubmit, onError)}
        className="flex flex-col gap-6"
      >
        <div className="flex xs:flex-col sm:flex-row justify-between gap-4 xs:items-start sm:items-center text-secondary-500 dark:text-white">
          <h1 className="font-semibold text-xl col-span-1 whitespace-nowrap flex-shrink-0">
            {t('createJob.customize')}
          </h1>
          <div className="w-full col-span-1 flex justify-end space-x-2">
            {/* Boton guardar borrador - componente modal */}
            <AlertDialog open={alertSaveDraft} onOpenChange={setAlertSaveDraft}>
              <AlertDialogTrigger asChild>
                <Button variant="tertiary" size="md" type="button">
                  {t('createJob.saveDraft')}
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent
                style={{ gap: '0px' }}
                className="xs:w-full sm:w-[452px] w-[452px]"
              >
                <AlertDialogTitle className="hidden" />
                <div className="flex flex-col text-secondary-500 font-inter">
                  <div className="flex justify-end">
                    <IconX
                      stroke={1.5}
                      size={20}
                      className="close text-2xl cursor-pointer"
                      onClick={() => {
                        setAlertSaveDraft(false)
                      }}
                    />
                  </div>
                  <div className="flex flex-col text-secondary-500 font-inter gap-3 items-center">
                    <span className="text-xl font-medium text-center">
                      Guardar datos como borrador
                    </span>
                    <span className="text-sm text-center">
                      Los datos ingresados serán guardados como borrador
                    </span>
                    <AlertDialogFooter className="w-full">
                      <div className="flex justify-around w-full mt-2">
                        <AlertDialogCancel
                          onClick={() => {
                            setAlertSaveDraft(false)
                          }}
                          className="w-auto h-[30px]"
                        >
                          Seguir editando
                        </AlertDialogCancel>
                        <AlertDialogAction
                          onClick={handleSaveAsDraft}
                          className="w-auto h-[30px]"
                        >
                          Guardar borrador
                        </AlertDialogAction>
                      </div>
                    </AlertDialogFooter>
                  </div>
                </div>
              </AlertDialogContent>
            </AlertDialog>
            {/* Boton Vista Previa*/}
            <Button
              variant="primary"
              type="button"
              className="h-[39px] xs:w-auto sm:w-[131px] text-regular text-primary-foreground"
              onClick={handleSubmit(handlePreview, onError)}
            >
              {t('createJob.preview')}
            </Button>
            {/* Boton Publicar*/}
            <Button
              variant="primary"
              type="submit"
              className="h-[39px] xs:w-auto sm:w-[103px] text-regular text-primary-foreground"
              onClick={handleSubmit(handlePublish)}
            >
              {t('createJob.publish')}
            </Button>
          </div>
        </div>
        <div>
          <PostAJob
            register={register}
            errors={errors}
            setValue={setValue}
            getValues={getValues}
            watch={watch}
            trigger={trigger}
          />
        </div>
        <div className="flex flex-col gap-6">
          <div className="flex justify-between text-secondary-500 dark:text-white">
            <h2 className="font-semibold xs:text-lg sm:text-xl">
              {t('features.featu')}
            </h2>
            <h2 className="font-semibold xs:text-lg sm:text-xl cursor-pointer">
              Seleccionar pipeline para el puesto
            </h2>
          </div>
          <Features
            errors={errors}
            setValue={setValue}
            watch={watch}
            trigger={trigger}
            clearErrors={clearErrors}
          />
        </div>
        <div>
          <Visibility setValue={setValue} watch={watch} />
        </div>
        <div>
          <Questions
            errors={errors}
            setValue={setValue}
            getValues={getValues}
            watch={watch}
            trigger={trigger}
            register={register}
          />
        </div>
      </form>
      <ViewPreviewJob
        setAlertPreview={setAlertPreview}
        alertPreview={alertPreview}
        data={getValues()}
        handleSubmit={handleSubmit}
        handlePublish={handlePublish}
      />
      <ModalFinishPostAJob
        openModal={alertFinish}
        setOpenModal={setAlertFinish}
      />
    </div>
  )
}

export default CreateJob
