import useMediaQuery from '@/hooks/useMediaQuery'
import {
  IconBellRinging,
  IconEyeCheck,
  IconFileDollar,
  IconLock,
  IconSettings,
} from '@tabler/icons-react'
import React, { useEffect, useState } from 'react'
import { Link, Outlet, useLocation, useNavigate } from 'react-router-dom'

export default function SettingsLayout() {
  const location = useLocation()
  const navigate = useNavigate()

  const isDesktop = useMediaQuery('(min-width:640px)')
  const [viewMenu, setViewMenu] = useState(true)

  const handleViewMenu = () => {
    setViewMenu(true)
  }

  const links = [
    {
      name: 'Administración de la cuenta',
      shortName: 'Cuenta',
      url: '/company/settings/account',
      icon: (
        <IconSettings
          stroke={1.5}
          className="text-secondary-500 dark:text-white"
        />
      ),
    },
    {
      name: 'Visibilidad del perfil',
      shortName: 'Visibilidad',
      url: '/company/settings/visibility',
      icon: (
        <IconEyeCheck
          stroke={1.5}
          className="text-secondary-500 dark:text-white"
        />
      ),
    },
    {
      name: 'Privacidad y seguridad',
      shortName: 'Privacidad',
      url: '/company/settings/privacy',
      icon: (
        <IconLock stroke={1.5} className="text-secondary-500 dark:text-white" />
      ),
    },
    {
      name: 'Facturación',
      shortName: 'Facturación',
      url: '/company/settings/billing',
      icon: (
        <IconFileDollar
          stroke={1.5}
          className="text-secondary-500 dark:text-white"
        />
      ),
    },
    {
      name: 'Notificaciones',
      shortName: 'Notificaciones',
      url: '/company/settings/notifications',
      icon: (
        <IconBellRinging
          stroke={1.5}
          className="text-secondary-500 dark:text-white"
        />
      ),
    },
  ]

  const redirectTo = '/company/settings/account'

  useEffect(() => {
    if (location.pathname === '/company/settings') {
      navigate(redirectTo)
    }
  }, [location.pathname, navigate, redirectTo])

  return (
    <>
      {isDesktop ? (
        <div className="flex flex-row font-inter text-secondary dark:text-white w-full bg-card p-6 pt-12 rounded-[13px] shadow-cards min-h-[87vh]">
          <div className="flex flex-col w-[30%]">
            {links.map((link, id) => (
              <div
                key={id}
                className="h-[90px] w-[170px] flex items-start text-secondary dark:text-white font-medium flex-col gap-2"
              >
                <Link to={link.url}>{link.name}</Link>
                {location.pathname === link.url && (
                  <hr className="border-2 border-secondary dark:border-white w-full" />
                )}
              </div>
            ))}
          </div>
          <div className="w-[70%] flex flex-col gap-6">
            <Outlet context={{ handleViewMenu }} />
          </div>
        </div>
      ) : (
        <div className="bg-card p-6 rounded-[13px] shadow-cards min-h-screen">
          {viewMenu ? (
            <div className="flex flex-col">
              <span className="font-semibold text-lg mb-8 text-secondary dark:text-white">
                Configuración
              </span>
              <div className="grid grid-cols-1 gap-3">
                {links.map((link, id) => (
                  <div
                    key={id}
                    className="h-24 w-full rounded-lg flex items-center justify-center text-secondary dark:text-white font-medium flex-col gap-3 border p-3"
                  >
                    <Link
                      to={link.url}
                      onClick={() => setViewMenu(false)}
                      className="flex flex-col gap-3 items-center"
                    >
                      <div>{link.icon}</div>
                      <span className="text-center">{link.name}</span>
                    </Link>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="flex">
              <Outlet context={{ handleViewMenu }} />
            </div>
          )}
        </div>
      )}
    </>
  )
}
