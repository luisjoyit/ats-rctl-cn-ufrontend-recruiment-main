import { Checkbox } from '@/components/ui/checkbox'
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover'

const calculateProgressStats = (element) => {
  const total = element.firstEvaluation
  const selectionIA = Math.floor(total * 0.7)
  const evaluationI = Math.floor(total * 0.5)
  const interviewI = Math.floor(total * 0.2)
  const evaluationII = Math.floor(total * 0.05)

  return { selectionIA, evaluationI, interviewI, evaluationII }
}

export default function ProcessesTable({
  processes,
  handleProcessClick,
  openPopoverId,
  setOpenPopoverId,
}) {
  return (
    <div className="w-full bg-white rounded-xl shadow">
      <table className="w-full">
        <thead>
          <tr className="text-left text-[#5D7B7E] text-sm">
            <th className="p-4 text-left">
              <Checkbox className="dark:border-white" />
            </th>
            <th className="p-4 text-left">Perfil</th>
            <th className="p-4 text-left">Proceso</th>
            <th className="p-4 text-left">Salario</th>
            <th className="p-4 text-left">Status</th>
            <th className="p-4 text-left">Fecha de publicación</th>
          </tr>
        </thead>
        <tbody>
          {processes.map((element) => {
            const progressStats = calculateProgressStats(element)
            return (
              <tr key={element.id} className="border-b hover:bg-gray-50">
                <td className="p-4">
                  <Checkbox className="dark:border-white" />
                </td>
                <td className="p-4">
                  <div
                    className="flex flex-col cursor-pointer"
                    tabIndex={0}
                    role="button"
                    onClick={() => handleProcessClick(element.id)}
                  >
                    <span className="font-medium dark:text-primary-foreground">
                      {element.nameProcess}
                    </span>
                    <span className="text-sm text-[#ABBFC1]">
                      {element.location}
                    </span>
                  </div>
                </td>
                <td className="p-4">
                  <div className="flex flex-wrap gap-2">
                    <span className="bg-[#D9F9E4] text-[#0E5827] px-5 py-2 rounded-xl text-sm font-medium">
                      {`Postulados: ${element.applicants}`}
                    </span>
                    <Popover
                      open={openPopoverId === element.id}
                      onOpenChange={(open) =>
                        setOpenPopoverId(open ? element.id : null)
                      }
                    >
                      <PopoverTrigger asChild>
                        <span
                          className="bg-[#F9E8D9] text-[#58310E] px-5 py-2 rounded-xl text-sm font-medium cursor-pointer"
                          onMouseEnter={() => setOpenPopoverId(element.id)}
                          onMouseLeave={() => setOpenPopoverId(null)}
                        >
                          {`En Progreso: ${element.firstEvaluation}`}
                        </span>
                      </PopoverTrigger>
                      <PopoverContent
                        className="w-auto p-4 text-secondary text-sm font-inter text-[#263658] rounded-xl"
                        onMouseEnter={() => setOpenPopoverId(element.id)}
                        onMouseLeave={() => setOpenPopoverId(null)}
                      >
                        <div className="space-y-2">
                          <p>Selección IA: {progressStats.selectionIA}</p>
                          <p>Evaluación I: {progressStats.evaluationI}</p>
                          <p>Entrevista I: {progressStats.interviewI}</p>
                          <p>Evaluación II: {progressStats.evaluationII}</p>
                        </div>
                      </PopoverContent>
                    </Popover>
                    <span className="bg-[#F9D9D9] text-[#580E0E] px-5 py-2 rounded-xl text-sm font-medium">
                      {`Finalizado: 0`}
                    </span>
                  </div>
                </td>
                <td className="p-4">{element.salary}</td>
                <td className="p-4">{element.status}</td>
                <td className="p-4">{element.publicationDate}</td>
              </tr>
            )
          })}
        </tbody>
      </table>
    </div>
  )
}
