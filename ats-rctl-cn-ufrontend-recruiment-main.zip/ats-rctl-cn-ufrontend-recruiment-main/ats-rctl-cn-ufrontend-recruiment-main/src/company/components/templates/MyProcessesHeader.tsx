import InputWithIcon from '@/components/inputWithIcon'
import Filters from '../molecules/MyProcesses/Filters'
import Tags from '@/components/tags'

export default function ProcessesHeader({ totalProcesses }) {
  return (
    <div className="flex flex-col gap-4 sm:gap-6 dark:text-primary-foreground">
      <div className="flex xs:flex-col sm:flex-row justify-between xs:items-start sm:items-center">
        <h1 className="font-bold text-xl">Mis procesos: {totalProcesses}</h1>
        <div className="flex sm:items-center xs:justify-between space-x-4 mt-4">
          <InputWithIcon
            placeholder="Nombre del empleo"
            className="lg:w-[241px]"
          />
          <Filters />
        </div>
      </div>
      <div className="flex xs:flex-col sm:flex-row xs:items-start sm:items-center gap-3 w-full">
        <span className="font-semibold text-xl dark:text-primary-foreground">
          Status:
        </span>
        <div className="flex xs:flex-wrap sm:flex-row gap-3">
          <Tags
            tags={[
              { id: 1, name: 'Más relevantes' },
              { id: 2, name: 'Activos' },
              { id: 3, name: 'Perú' },
            ]}
          />
        </div>
      </div>
    </div>
  )
}
