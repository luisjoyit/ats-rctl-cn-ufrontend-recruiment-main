import React, { useState } from 'react'
import Messages from './Messages'
import { Outlet } from 'react-router-dom'
import useMediaQuery from '@/hooks/useMediaQuery'

export default function MessageId() {
  const [openDrawerMobile, setOpenDrawerMobile] = useState(false)
  const isDesktop = useMediaQuery('(min-width: 768px)')

  const handleChat = (id) => {
    if (id !== null) {
      setOpenDrawerMobile((prevDrawerOpen) => !prevDrawerOpen)
    }
  }

  const handleCloseDrawer = () => {
    setOpenDrawerMobile(false)
  }

  return (
    <div className="flex flex-row w-full h-[85vh] gap-10 overflow-hidden">
      <div
        className={`h-full overflow-y-auto xs:py-0 sm:py-1 xs:p-1 sm:pr-4
          scrollbar-thin scrollbar-thumb-gray-400 scrollbar-track-gray-200
          ${isDesktop ? 'w-1/3' : 'w-full'}
        `}
      >
        <Messages narrow handleChatMobile={handleChat} />
      </div>
      <div className={isDesktop ? 'w-2/3' : 'hidden'}>
        <Outlet context={{ openDrawerMobile, handleChat, handleCloseDrawer }} />
      </div>
    </div>
  )
}
