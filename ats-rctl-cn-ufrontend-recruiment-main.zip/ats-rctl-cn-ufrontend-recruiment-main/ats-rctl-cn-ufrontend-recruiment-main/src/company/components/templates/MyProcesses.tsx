import { useEffect, useState } from 'react'
import { useNavigate, useSearchParams } from 'react-router-dom'
import { Pagination } from '@/components/ui/pagination'
import ProcessesHeader from './MyProcessesHeader'
import ProcessesTable from './MyProcessesTable'

const dataSelectionProcess = [
  {
    id: '001',
    nameProcess: 'Frontend Developer',
    categoryProcess: 'Software Development',
    location: 'Remoto',
    applicants: 645,
    firstEvaluation: 346,
    firstInterview: 24,
    offer: 2,
    salary: '$2,500',
    status: 'Activo',
    publicationDate: '04 Jul 2024',
  },
  {
    id: '002',
    nameProcess: 'Frontend Developer',
    categoryProcess: 'Software Development',
    location: 'Remoto',
    applicants: 645,
    firstEvaluation: 346,
    firstInterview: 24,
    offer: 2,
    salary: '$2,500',
    status: 'Activo',
    publicationDate: '04 Jul 2024',
  },
  {
    id: '003',
    nameProcess: 'Frontend Developer',
    categoryProcess: 'Software Development',
    location: 'Remoto',
    applicants: 645,
    firstEvaluation: 346,
    firstInterview: 24,
    offer: 2,
    salary: '$2,500',
    status: 'Activo',
    publicationDate: '04 Jul 2024',
  },
  {
    id: '004',
    nameProcess: 'Frontend Developer',
    categoryProcess: 'Software Development',
    location: 'Remoto',
    applicants: 645,
    firstEvaluation: 346,
    firstInterview: 24,
    offer: 2,
    salary: '$2,500',
    status: 'Activo',
    publicationDate: '04 Jul 2024',
  },
  {
    id: '005',
    nameProcess: 'Frontend Developer',
    categoryProcess: 'Software Development',
    location: 'Remoto',
    applicants: 645,
    firstEvaluation: 346,
    firstInterview: 24,
    offer: 2,
    salary: '$2,500',
    status: 'Activo',
    publicationDate: '04 Jul 2024',
  },
  {
    id: '006',
    nameProcess: 'Frontend Developer',
    categoryProcess: 'Software Development',
    location: 'Remoto',
    applicants: 645,
    firstEvaluation: 346,
    firstInterview: 24,
    offer: 2,
    salary: '$2,500',
    status: 'Activo',
    publicationDate: '04 Jul 2024',
  },
  {
    id: '007',
    nameProcess: 'Frontend Developer',
    categoryProcess: 'Software Development',
    location: 'Remoto',
    applicants: 645,
    firstEvaluation: 346,
    firstInterview: 24,
    offer: 2,
    salary: '$2,500',
    status: 'Activo',
    publicationDate: '04 Jul 2024',
  },
  {
    id: '008',
    nameProcess: 'Frontend Developer',
    categoryProcess: 'Software Development',
    location: 'Remoto',
    applicants: 645,
    firstEvaluation: 346,
    firstInterview: 24,
    offer: 2,
    salary: '$2,500',
    status: 'Activo',
    publicationDate: '04 Jul 2024',
  },
  {
    id: '009',
    nameProcess: 'Frontend Developer',
    categoryProcess: 'Software Development',
    location: 'Remoto',
    applicants: 645,
    firstEvaluation: 346,
    firstInterview: 24,
    offer: 2,
    salary: '$2,500',
    status: 'Activo',
    publicationDate: '04 Jul 2024',
  },
  {
    id: '010',
    nameProcess: 'Frontend Developer',
    categoryProcess: 'Software Development',
    location: 'Remoto',
    applicants: 645,
    firstEvaluation: 346,
    firstInterview: 24,
    offer: 2,
    salary: '$2,500',
    status: 'Activo',
    publicationDate: '04 Jul 2024',
  },
  {
    id: '011',
    nameProcess: 'Frontend Developer',
    categoryProcess: 'Software Development',
    location: 'Remoto',
    applicants: 645,
    firstEvaluation: 346,
    firstInterview: 24,
    offer: 2,
    salary: '$2,500',
    status: 'Activo',
    publicationDate: '04 Jul 2024',
  },
  {
    id: '012',
    nameProcess: 'Frontend Developer',
    categoryProcess: 'Software Development',
    location: 'Remoto',
    applicants: 645,
    firstEvaluation: 346,
    firstInterview: 24,
    offer: 2,
    salary: '$2,500',
    status: 'Activo',
    publicationDate: '04 Jul 2024',
  },
]

export default function MyProcesses() {
  const [searchParams, setSearchParams] = useSearchParams()
  const navigate = useNavigate()
  const [filteredData, setFilteredData] = useState(dataSelectionProcess)
  const [openPopoverId, setOpenPopoverId] = useState(null)

  const currentPage = parseInt(searchParams.get('page') || '1', 10)
  const itemsPerPage = 10

  const handleProcessClick = (id) => {
    if (id !== null) {
      navigate(`/company/myProcesses/${id}/stages`)
    }
  }

  const handlePageChange = (page) => {
    setSearchParams({ page: page.toString() })
  }

  const currentData = filteredData.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage,
  )

  useEffect(() => {
    setSearchParams((prevSearchParams) => {
      const newSearchParams = new URLSearchParams(prevSearchParams.toString())
      newSearchParams.set('page', currentPage.toString())
      return newSearchParams
    })
  }, [currentPage, setSearchParams])

  return (
    <div className="my-processes-page min-h-screen flex flex-col font-inter gap-4 text-secondary">
      <ProcessesHeader totalProcesses={filteredData.length} />
      <ProcessesTable
        processes={currentData}
        handleProcessClick={handleProcessClick}
        openPopoverId={openPopoverId}
        setOpenPopoverId={setOpenPopoverId}
      />
      <Pagination
        currentPage={currentPage}
        totalItems={filteredData.length}
        itemsPerPage={itemsPerPage}
        onPageChange={handlePageChange}
        className="py-7"
        pagLinkClassName="bg-secondary-500 dark:bg-secondary-100 text-secondary-foreground border-transparent font-bold rounded-lg"
      />
    </div>
  )
}
