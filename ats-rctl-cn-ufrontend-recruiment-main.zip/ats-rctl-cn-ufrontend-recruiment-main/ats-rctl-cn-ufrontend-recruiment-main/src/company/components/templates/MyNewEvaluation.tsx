import { IconArrowLeft, IconSquareRoundedPlusFilled } from '@tabler/icons-react'
import { useEffect, useState } from 'react'
import NewQuestionCard from '../molecules/MyEvaluations/NewQuestionCard'
import { CardEvaluations } from './MyEvaluations'
import EditorDemo from '@/components/editorText/editorDemo'
import { useForm } from 'react-hook-form'
import {
  evaluationFormSchema,
  EvaluationFormSchema,
} from '@/company/validations/evaluationFormSchema'
import { zodResolver } from '@hookform/resolvers/zod'
import SelectUi from '@/components/SelectUi'
import { Button } from '@/components/ui/button'
import { useNavigate, useParams } from 'react-router-dom'
import AlertNewEvaluations from '../organism/AlertDialogs/AlertNewEvaluations'
import AlertEditEvaluation from '../organism/AlertDialogs/AlertEditEvaluation'
import AlertSaveDraftEvaluation from '../organism/AlertDialogs/AlertSaveDraftEvaluation'
import useMediaQuery from '@/hooks/useMediaQuery'

interface Question {
  id: number
  titleQuestion: string
  typeAnswer: 'short' | 'several'
  answers: string[]
}

const questionDataInitial: Question = {
  id: Date.now(),
  titleQuestion: '',
  typeAnswer: 'short',
  answers: [],
}

interface MyNewEvaluationProps {
  dataEvaluation?: CardEvaluations
  update?: boolean
}

export default function MyNewEvaluation({
  dataEvaluation,
  update,
}: MyNewEvaluationProps) {
  const {
    register,
    handleSubmit,
    watch,
    formState: { errors },
    reset,
    setValue,
    getValues,
    trigger,
  } = useForm<EvaluationFormSchema>({
    resolver: zodResolver(evaluationFormSchema),
    defaultValues: {
      evaluationName: '',
      unitTime: 'min',
      valueTime: 0,
      description: '',
      questions: [],
    },
    mode: 'onChange',
  })

  const [openAlertCreate, setOpenAlertCreate] = useState(false)
  const [openAlertEdit, setOpenAlertEdit] = useState(false)
  const [openAlertSaveDraft, setOpenAlertSaveDraft] = useState(false)
  const questions = watch('questions') || []

  const navigate = useNavigate()
  const isMobile = useMediaQuery('(max-width: 768px)')

  useEffect(() => {
    if (dataEvaluation) {
      setValue('evaluationName', dataEvaluation.name || '')
      setValue('unitTime', dataEvaluation.unitTime || 'Min')
      setValue('valueTime', dataEvaluation.valueTime || 0)
      setValue('description', dataEvaluation.description || '')
      setValue(
        'questions',
        dataEvaluation.questions.map((q) => ({
          id: q.id,
          titleQuestion: q.titleQuestion,
          typeAnswer: q.typeAnswer as 'short' | 'several',
          answers: q.answers || [],
        })),
      )
    }
  }, [dataEvaluation, setValue])

  const createEvaluation = (data: EvaluationFormSchema) => {
    //console.log('Formulario enviado con éxito:', data)
  }

  const onError = (errors) => {
    //console.log(errors)
  }

  const updateEvaluation = (data: EvaluationFormSchema) => {
    //console.log('Formulario editado con éxito:', data)
    setOpenAlertEdit(true)
  }

  const handleSaveAsDraft = () => {
    setOpenAlertSaveDraft(false)
    navigate('/company/myEvaluations')
  }

  const addQuestion = () => {
    const newQuestion: Question = {
      ...questionDataInitial,
      id: Date.now(),
      answers: [],
    }

    const currentQuestions = getValues('questions') || []
    const updatedQuestions = [...currentQuestions, newQuestion]

    setValue('questions', updatedQuestions)
    trigger('questions')
  }

  const deleteQuestion = (id: number) => {
    const updatedQuestions = questions.filter((q) => q.id !== id)
    setValue('questions', updatedQuestions)
  }

  const getButtons = (
    <div className="flex gap-4 justify-end xs:mt-4 sm:mt-0">
      <Button
        variant="tertiary"
        className=""
        onClick={
          update
            ? () => navigate('/company/myEvaluations')
            : () => setOpenAlertSaveDraft(true)
        }
      >
        {update ? 'Cancelar Edición' : 'Guardar borrador'}
      </Button>
      <Button
        variant="primary"
        size="lg"
        className="text-primary-foreground"
        onClick={
          update
            ? handleSubmit(updateEvaluation, onError)
            : handleSubmit(() => setOpenAlertCreate(true), onError)
        }
      >
        {update ? 'Finalizar edición' : 'Crear evaluación'}
      </Button>
    </div>
  )

  return (
    <div className="flex flex-col xs:gap-4 sm:gap-8 text-secondary-500 dark:text-white">
      <div className="flex flex-col gap-2">
        <button
          onClick={() => navigate('/company/myEvaluations')}
          className="flex bg-backgroundF-500 rounded-4xl gap-2 px-3 items-center text-xs font-medium h-[23px] max-w-max xs:mb-1 sm:mb-4"
        >
          <IconArrowLeft stroke={1.5} size={14} />
          Volver
        </button>
        <span className="text-secondary-500 dark:text-white font-semibold text-xl font-inter">
          {update
            ? `Edición de ${getValues('evaluationName')}`
            : 'Nueva evaluación'}
        </span>
        {getButtons}
      </div>
      <div>
        <form className="space-y-8 xs:pl-0 sm:pl-2">
          <div className="flex flex-col xs:p-3.5 sm:py-5 sm:px-7 bg-card shadow-cards w-full xs:h-auto sm:min-h-[356px] xs:rounded-2xl sm:rounded-4xl">
            <span className="text-xl font-semibold">Datos generales</span>
            <div className="flex xs:flex-col sm:flex-row xs:gap-3 sm:gap-0 xs:w-full sm:w-[85%] justify-between pt-5">
              <div className="flex flex-col gap-1">
                <div className="flex xs:flex-col sm:flex-row gap-2 xs:items-start sm:items-end">
                  <span className="text-sm font-semibold">
                    Nombre de la Evaluación:
                  </span>
                  <input
                    id="underline-input"
                    type="text"
                    className="xs:w-full sm:w-[321px] block border-0 border-b-[0.5px] border-accent-700 focus:ring-0 outline-none bg-transparent"
                    name="name"
                    {...register('evaluationName')}
                  />
                </div>
                {errors.evaluationName && (
                  <span className="text-xs text-destructive-500">
                    {errors.evaluationName.message}
                  </span>
                )}
              </div>
              <div className="flex flex-col gap-1">
                <div className="flex xs:flex-col sm:flex-row gap-2 xs:items-start sm:items-end">
                  <span className="text-sm font-semibold">
                    Establecer duración:
                  </span>
                  <div className="flex gap-2">
                    <input
                      id="underline-input"
                      className="block w-14 border-0 border-b-[0.5px] border-accent-700 focus:ring-0 outline-none bg-transparent"
                      type="text"
                      name="valueTime"
                      {...register('valueTime', {
                        valueAsNumber: true,
                        setValueAs: (value) =>
                          value === '' ? undefined : Number(value),
                      })}
                      onInput={(e) => {
                        const target = e.target as HTMLInputElement
                        target.value = target.value.replace(/[^0-9]/g, '')
                      }}
                    />
                    <SelectUi
                      items={[
                        { value: 'seg', label: 'Seg' },
                        { value: 'min', label: 'Min' },
                        { value: 'hours', label: 'Horas' },
                      ]}
                      name="unitTime"
                      defaultValue="min"
                      placeholder="Seleccione tiempo"
                      className="w-[100px] border"
                      setValue={setValue}
                      trigger={trigger}
                      onlyValue
                    />
                  </div>
                </div>
                {errors.valueTime && (
                  <span className="text-xs text-destructive-500">
                    {errors.valueTime.message}
                  </span>
                )}
              </div>
            </div>
            <div className="flex flex-col gap-1">
              <div className="dark:text-secondary-500 flex flex-col w-full pt-5 gap-4">
                <span className="dark:text-white text-sm font-semibold">
                  Descripción de la evaluación
                </span>
                <EditorDemo
                  name="description"
                  setValue={setValue}
                  trigger={trigger}
                  value={getValues('description')}
                />
              </div>
              {errors.description && (
                <span className="text-xs text-destructive-500">
                  {errors.description.message}
                </span>
              )}
            </div>
          </div>
          <div className="flex flex-col xs:p-3.5 sm:py-5 sm:px-7 bg-card shadow-cards w-full min-h-[153px] xs:rounded-2xl sm:rounded-4xl gap-5">
            <span className="text-xl font-semibold">Preguntas</span>
            {questions?.map((question, index) => (
              <NewQuestionCard
                key={index}
                index={index}
                question={question}
                deleteQuestion={deleteQuestion}
                register={register}
                errors={errors}
                setValue={setValue}
                trigger={trigger}
              />
            ))}
            {errors.questions && (
              <span className="text-xs text-destructive-500">
                {errors.questions.message}
              </span>
            )}
            <div className="flex flex-grow items-center justify-center">
              <IconSquareRoundedPlusFilled
                size={62}
                className="text-secondary-500 dark:text-white cursor-pointer"
                onClick={addQuestion}
              />
            </div>
          </div>
        </form>
      </div>
      <AlertNewEvaluations
        openAlert={openAlertCreate}
        setOpenAlert={setOpenAlertCreate}
        createEvaluation={createEvaluation}
        handleSubmit={handleSubmit}
      />
      <AlertEditEvaluation
        openAlert={openAlertEdit}
        setOpenAlert={setOpenAlertEdit}
      />
      <AlertSaveDraftEvaluation
        open={openAlertSaveDraft}
        setOpen={setOpenAlertSaveDraft}
        handleSaveAsDraft={handleSaveAsDraft}
      />
      {isMobile && getButtons}
    </div>
  )
}
