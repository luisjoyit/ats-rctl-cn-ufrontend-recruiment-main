import React from 'react'
import ActiveJobs from '../atoms/Dashboard/ActiveJobs'
import Calendar from '../atoms/Dashboard/Calendar'
import ActiveProcesses from '../atoms/Dashboard/ActiveProcesses'
import ActiveProcessesPipeline from '../atoms/Dashboard/ActiveprocessPipeline'
//@ts-ignore
import { t, useLanguage } from '@joyit/layout'
import MessagePopover from '../organism/Messages/MessagePopover'
import useMediaQuery from '@/hooks/useMediaQuery'

const Dashboard = () => {
  const { handleChangeLanguage } = useLanguage()
  const isDesktop = useMediaQuery('(min-width:640px)')

  return (
    <div className="">
      <h1 className="text-xl font-semibold text-secondary-500 dark:text-white mb-1">
        {t('companydashboard.welcome')}
      </h1>
      <p className="mb-4 text-secondary-500 dark:text-white">
        {t('companydashboard.youHave')}{' '}
        <span className="text-[#00B7DA]">
          {t('companydashboard.interviews')}
        </span>
      </p>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <ActiveJobs />
          <ActiveProcesses />
        </div>
        <div>
          <Calendar />
        </div>
        <div className="lg:col-span-3">
          <ActiveProcessesPipeline />
        </div>
      </div>
      {isDesktop && <MessagePopover />}
    </div>
  )
}

export default Dashboard
