import { Pagination } from '@/components/ui/pagination'
import { useSearchParams } from 'react-router-dom'

const dataActivity = [
  {
    date: '03/09/24',
    hour: '09:32',
    acction: 'Se pasó a la siguiente etapa al postulante: (Nombre Link)',
  },
  {
    date: '03/09/24',
    hour: '09:27',
    acction: 'Se rechazó al postulante: (Nombre Link)',
  },
  {
    date: '03/09/24',
    hour: '09:24',
    acction: 'Se pasó a la siguiente etapa al postulante: (Nombre Link)',
  },
  {
    date: '03/09/24',
    hour: '09:21',
    acction: 'Se pasó a la siguiente etapa al postulante: (Nombre Link)',
  },
  {
    date: '03/09/24',
    hour: '09:18',
    acction: 'Se pasó a la siguiente etapa al postulante: (Nombre Link)',
  },
  {
    date: '03/09/24',
    hour: '09:18',
    acction: 'Se pasó a la siguiente etapa al postulante: (Nombre Link)',
  },
  {
    date: '03/09/24',
    hour: '09:15',
    acction: 'Se pasó a la siguiente etapa al postulante: (Nombre Link)',
  },
  {
    date: '03/09/24',
    hour: '09:10',
    acction: 'Se pasó a la siguiente etapa al postulante: (Nombre Link)',
  },
  {
    date: '03/09/24',
    hour: '09:08',
    acction: 'Se pasó a la siguiente etapa al postulante: (Nombre Link)',
  },
  {
    date: '03/09/24',
    hour: '09:02',
    acction: 'Se pasó a la siguiente etapa al postulante: (Nombre Link)',
  },
  {
    date: '03/09/24',
    hour: '09:00',
    acction: 'Se pasó a la siguiente etapa al postulante: (Nombre Link)',
  },
  {
    date: '03/09/24',
    hour: '08:52',
    acction: 'Se pasó a la siguiente etapa al postulante: (Nombre Link)',
  },
]

const MyProcessesActivity = () => {
  const [searchParams, setSearchParams] = useSearchParams()

  const handlePageChange = (page) => {
    setSearchParams({ page: page.toString() })
  }

  const itemsPerPage = 9
  const currentPage = parseInt(searchParams.get('page') || '1', 10)

  const currentData = dataActivity.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage,
  )

  return (
    <div>
      <div className="flex flex-col xs:gap-3 sm:gap-0 text-secondary-500 font-inter">
        <div className="dark:text-white grid xs:grid-cols-[70px_50px_1fr] sm:grid-cols-[100px_80px_1fr] xs:px-3 sm:px-6 xs:py-1 sm:pb-4 xs:gap-1 sm:gap-4">
          <span>Fecha</span>
          <span>Hora</span>
          <span>Historial de acciones</span>
        </div>
        <div className="flex flex-col xs:gap-3 sm:gap-5">
          {currentData.map((act, id) => (
            <div
              key={id}
              className="grid xs:grid-cols-[70px_50px_1fr] sm:grid-cols-[100px_80px_1fr] rounded-lg bg-[#E7F0FF] xs:p-3 sm:px-6 sm:py-4 xs:gap-1 sm:gap-4 text-sm"
            >
              <span>{act.date}</span>
              <span>{act.hour}</span>
              <p>{act.acction}</p>
            </div>
          ))}
        </div>
      </div>
      <Pagination
        currentPage={currentPage}
        totalItems={dataActivity ? dataActivity.length : 2}
        itemsPerPage={itemsPerPage}
        onPageChange={handlePageChange}
        className="py-7"
      />
    </div>
  )
}

export default MyProcessesActivity
