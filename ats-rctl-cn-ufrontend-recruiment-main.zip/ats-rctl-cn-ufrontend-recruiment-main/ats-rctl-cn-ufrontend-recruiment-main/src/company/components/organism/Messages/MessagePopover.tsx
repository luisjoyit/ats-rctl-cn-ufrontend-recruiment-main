import { Separator } from '@/components/ui/separator'
import {
  IconCheck,
  IconChecks,
  IconChevronUp,
  IconPencilPlus,
  IconSquareRoundedNumber1,
  IconX,
} from '@tabler/icons-react'
import React, { useEffect, useState } from 'react'
import NewMessagePopover from './NewMessagePopover'
import { messagesData } from '../../templates/Messages'

interface Message {
  id: number | string
  avatar: string
  name: string
  skills: string[]
  stateUser: string
  messages: {
    id: number | string
    name: string
    message: string
    date: string
    hour: string
    stateMessage: string
  }[]
}

export default function MessagePopover() {
  const dataMessage: Message[] = messagesData

  const [isOpen, setIsOpen] = useState(false)
  const [searchTerm, setSearchTerm] = useState('')
  const [chatWith, setChatWith] = useState<Message | null>(null)

  const [message, setMessage] = useState<Message | undefined>(undefined)
  const [newMessage, setNewMessage] = useState<string>('')

  const filteredMessages = dataMessage.filter((message) =>
    message.name.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const toggleDrawer = () => {
    setIsOpen(!isOpen)
  }

  const handleChatClick = (message: Message) => {
    setChatWith(message)
  }

  useEffect(() => {
    if (chatWith !== null) {
      setSearchTerm('')
    }
  }, [chatWith])

  const getTrigger = (
    <div
      className={`
              flex flex-row w-[301px] h-[44px] rounded-t-[6px] shadow-[0px_1px_5.3px_-1px_#00000040] bg-[#FFFFFF] justify-between items-center px-3 cursor-pointer 
              ${isOpen ? 'rounded-none shadow-none' : 'rounded-[6px]'}
          `}
      tabIndex={0}
      role="button"
      onClick={toggleDrawer}
    >
      <div className="flex items-center gap-2">
        <div>
          <img
            src="https://toppng.com/uploads/preview/free-logo-design-11551057495oqoep79juj.png"
            alt=""
            className="rounded-full object-cover xs:h-7 xs:w-7"
          />
        </div>
        <span className="text-secondary-500">Mensajes</span>
      </div>
      <div className="flex flex-row gap-2">
        {/*<IconPencilPlus stroke={2} /> */}
        <IconChevronUp
          stroke={2}
          className={`transition-transform text-secondary-500 ${isOpen ? 'rotate-180' : 'rotate-0'}`}
        />
      </div>
    </div>
  )

  const getLastMessage = (msg) => {
    //considerar mi usuario = JoyIT
    const user = 'JoyIT'
    const lastMessage = msg.length - 1
    let icon
    switch (msg[lastMessage].stateMessage) {
      case 'sent':
        icon = <IconCheck stroke={2} size={14} />
        break
      case 'delivered':
        icon =
          msg[lastMessage].name === user ? (
            <IconChecks stroke={2} size={14} />
          ) : (
            <IconSquareRoundedNumber1 stroke={2} size={14} />
          )
        break
      case 'read':
        icon = <IconChecks stroke={2} color="#8BB77B" size={14} />
        break
      default:
        icon = <IconChecks stroke={2} size={14} />
        break
    }

    return (
      <div className="flex flex-row gap-1 items-center">
        <div className="flex items-center w-[16px]">{icon}</div>
        <p className="text-[#6B6B6B] text-[10px] truncate">
          {msg[lastMessage]?.message}
        </p>
      </div>
    )
  }

  return (
    <div className="fixed bottom-1 right-1">
      {getTrigger}
      <div
        className={`
                fixed bottom-1 right-1 w-[301px] bg-white shadow-lg transition-transform rounded-t-[6px]
                ${isOpen ? 'translate-y-0' : 'translate-y-full'}
            `}
        style={{ transition: 'transform 0.3s ease-in-out' }}
      >
        <div className="flex flex-col text-secondary-500 font-inter shadow-[0px_1px_5.3px_-1px_#00000040] rounded-t-[6px]  max-h-[454px]">
          <div className="pt-1 border-b-[1px] border-[#F1F1F1]">
            {getTrigger}
          </div>
          <div className="px-4 pt-3 h-[42px]">
            <input
              type="text"
              className="py-1 px-2 text-sm outline-none border-[1px] border-[#D4D4D4] w-full h-[31px] rounded-[8px] bg-[#FFFFFF] text-[#B7B7B7]"
              placeholder="Buscar destinatario"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <div className="flex flex-col pt-2 p-4 gap-2 flex-1 overflow-y-auto w-full scrollbar-thin scrollbar-thumb-gray-400 scrollbar-track-gray-200 pr-1">
            {filteredMessages?.map((message) => (
              <div
                key={message.id}
                className="flex flex-row gap-2 h-9 cursor-pointer"
                tabIndex={0}
                role="button"
                onClick={() => handleChatClick(message)}
              >
                <div className="w-9">
                  <img
                    src={message?.avatar}
                    alt=""
                    className="rounded-full object-cover xs:h-8 xs:w-8"
                  />
                </div>
                <div className="flex flex-col flex-1 min-w-0">
                  <span className="text-[#263658] font-bold text-sm">
                    {message.name}
                  </span>
                  {getLastMessage(message?.messages)}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
      {chatWith && (
        <NewMessagePopover message={chatWith} setMessage={setChatWith} />
      )}
    </div>
  )
}
