import { Input } from '@/components/ui/input'
import { Separator } from '@/components/ui/separator'
import {
  IconChecks,
  IconFile,
  IconMicrophone,
  IconPhoto,
  IconSend2,
  IconX,
} from '@tabler/icons-react'
import { useEffect, useRef, useState } from 'react'

export default function NewMessagePopover({ message, setMessage }) {
  const [newMessage, setNewMessage] = useState<string>('')
  const messagesEndRef = useRef(null)

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleSendMessage()
    }
  }

  const handleSendMessage = () => {
    if (message && newMessage !== '') {
      const now = new Date()
      const newMessageObj = {
        id: message.messages.length + 1,
        name: 'User', // Nombre simulado del usuario que envía
        message: newMessage,
        date: now.toLocaleDateString(),
        hour: now.toLocaleTimeString(),
        stateMessage: 'sent', // Valor por default al enviar el mensaje
      }

      setMessage((prevMessage) => {
        if (prevMessage) {
          return {
            ...prevMessage,
            messages: [...prevMessage.messages, newMessageObj],
          }
        }
        return prevMessage
      })
      setNewMessage('')
    }
  }

  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' })
    }
  }, [message])

  const getStateMessage = () => {
    return <IconChecks stroke={2} size={12} />
  }

  return (
    <div className="fixed bottom-1 right-[310px] w-[301px] bg-white shadow-lg transition-transform rounded-t-[6px]">
      <div className="flex flex-col text-[#263658] font-inter shadow-[0px_1px_5.3px_-1px_#00000040] p-4 max-h-[454px] rounded-t-[6px]">
        <div className="flex flex-row items-center gap-2 border-b-[1px] border-[#F1F1F1] pb-2 h-[44px]">
          <img
            src={message.avatar}
            alt=""
            className="rounded-full object-cover xs:h-8 xs:w-8"
          />
          <div className="flex flex-row flex-1 min-w-0">
            <div className="flex flex-col flex-1 min-w-0">
              <span className="text-[#263658] font-bold text-sm">
                {message.name}
              </span>
              <div className="flex flex-row truncate">
                <div className="flex flex-row overflow-hidden text-ellipsis whitespace-nowrap">
                  {message?.skills?.map((skill, id) => (
                    <div key={id} className="flex flex-row">
                      <span className="text-[#263658] font-semibold text-[10px]">
                        {skill}
                      </span>
                      {message.skills.length - 1 !== id && (
                        <Separator
                          className="mx-1 border-[1px] border-[#263658]"
                          orientation="vertical"
                        />
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </div>
            <div className="flex items-start w-[15px]">
              <IconX
                stroke={1.5}
                size={14}
                className="cursor-pointer"
                onClick={() => setMessage(null)}
              />
            </div>
          </div>
        </div>
        <div className="container-messages pt-2 flex-1 overflow-y-auto w-full scrollbar-thin scrollbar-thumb-gray-400 scrollbar-track-gray-200 pr-1">
          {message?.messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex flex-col mb-4 w-full ${message.name === msg.name ? 'items-start' : 'items-end'}`}
            >
              <div className="flex flex-col w-[80%] gap-2">
                <div className="flex flex-col ml-2 font-semibold text-[10px]">
                  <span>{msg.date}</span>
                  <span className="text-[#8E8E8E]">{msg.hour}</span>
                </div>
                <div
                  className={`p-2 rounded-2xl font-medium flex flex-col
                                    ${message.name === msg.name ? 'bg-[#EAECEE] text-[#263658]' : 'bg-[#003D49] text-[#FFFFFF]'}`}
                >
                  <p className="text-xs">{msg.message}</p>
                  <div className="flex justify-end">{getStateMessage()}</div>
                </div>
              </div>
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>
        <div className="flex flex-row items-center gap-2 w-full font-inter h-[30px]">
          <div className="flex flex-row gap-1">
            <IconMicrophone
              stroke={2}
              color="#383FE9"
              size={18}
              className="cursor-pointer"
            />
            <IconPhoto
              stroke={2}
              color="#383FE9"
              size={18}
              className="cursor-pointer"
            />
            <IconFile
              stroke={2}
              color="#383FE9"
              size={18}
              className="cursor-pointer"
            />
          </div>
          <div className="w-full">
            <Input
              placeholder="Aa"
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              onKeyDown={handleKeyDown}
              style={{ height: '30px' }}
            />
          </div>
          <div>
            <IconSend2
              stroke={2}
              color="#383FE9"
              size={18}
              className="cursor-pointer"
              onClick={handleSendMessage}
            />
          </div>
        </div>
      </div>
    </div>
  )
}
