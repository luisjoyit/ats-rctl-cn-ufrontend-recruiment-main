import {
  AlertDialog,
  AlertDialogContent,
  AlertDialogFooter,
  AlertDialogTitle,
  AlertDialogTrigger,
  AlertDialogAction,
  AlertDialogCancel,
} from '@/components/ui/alert-dialog'
import { Button } from '@/components/ui/button'
import { IconX } from '@tabler/icons-react'

const AlertSaveDraftEvaluation = ({ open, setOpen, handleSaveAsDraft }) => {
  return (
    <AlertDialog open={open} onOpenChange={setOpen}>
      <AlertDialogTrigger className="hidden" />
      <AlertDialogContent
        style={{ gap: '0px' }}
        className="xs:w-full sm:w-[452px] w-[452px]"
      >
        <AlertDialogTitle className="hidden" />
        <div className="flex flex-col text-secondary-500 font-inter">
          <div className="flex justify-end">
            <IconX
              stroke={1.5}
              size={20}
              className="close text-2xl cursor-pointer"
              onClick={() => {
                setOpen(false)
              }}
            />
          </div>
          <div className="flex flex-col text-secondary-500 font-inter gap-3 items-center">
            <span className="text-xl font-medium text-center">
              Guardar datos como borrador
            </span>
            <span className="text-sm text-center">
              Los datos ingresados serán guardados como borrador
            </span>
            <AlertDialogFooter className="w-full">
              <div className="flex justify-around w-full mt-2">
                <AlertDialogCancel
                  onClick={() => {
                    setOpen(false)
                  }}
                  className="w-auto h-[30px]"
                >
                  Seguir editando
                </AlertDialogCancel>
                <AlertDialogAction
                  onClick={handleSaveAsDraft}
                  className="w-auto h-[30px]"
                >
                  Guardar borrador
                </AlertDialogAction>
              </div>
            </AlertDialogFooter>
          </div>
        </div>
      </AlertDialogContent>
    </AlertDialog>
  )
}

export default AlertSaveDraftEvaluation
