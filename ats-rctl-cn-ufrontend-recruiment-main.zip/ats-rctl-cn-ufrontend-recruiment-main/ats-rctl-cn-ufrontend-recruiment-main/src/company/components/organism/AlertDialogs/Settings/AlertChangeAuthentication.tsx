import InputOtp from '@/company/components/molecules/Settings/InputOtp'
import {
  AlertDialog,
  AlertDialogContent,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog'
import { Button } from '@/components/ui/button'
import { IconX } from '@tabler/icons-react'
import { useState } from 'react'

export default function AlertChangeAuthentication({
  open,
  setOpen,
  onConfirm,
  onCancel,
}) {
  const [openModalConfirm, setOpenModalConfirm] = useState(false)
  const [viewModal, setViewModal] = useState('confirm')

  const cancelChanges = () => {
    onCancel()
    setOpenModalConfirm(false)
    setViewModal('confirm')
  }

  const confirmChanges = () => {
    onConfirm()
    setViewModal('end')
  }

  return (
    <>
      <AlertDialog open={open} onOpenChange={setOpen}>
        <AlertDialogTrigger asChild></AlertDialogTrigger>
        <AlertDialogContent style={{ gap: '0px' }}>
          <div className="flex justify-end">
            <IconX
              stroke={1.5}
              size={20}
              className="close text-2xl cursor-pointer"
              color="#263658"
              onClick={onCancel}
            />
          </div>
          <div className="flex flex-col text-secondary-500 font-inter gap-3">
            <div className="flex justify-center">
              <span className="text-2xl font-medium">Ingresa el código</span>
            </div>
            <div>
              <p className="text-sm text-center">
                Para cambiar la configuración será necesario verificar su
                identidad, escriba el código enviado al número *** *** *26:
              </p>
            </div>
            <div className="flex flex-col gap-3 items-center w-full h-auto justify-center pt-3">
              <InputOtp />
              <div>
                <Button variant="tertiary" size="sm">
                  Volver a enviar código
                </Button>
              </div>
            </div>
            <div className="flex flex-row justify-around pt-3">
              <Button
                variant="secondary"
                size="md"
                className="xs:w-[120px] sm:w-[188px]"
                onClick={onCancel}
              >
                Cancelar
              </Button>
              <Button
                variant="primary"
                size="md"
                className="xs:w-[120px] sm:w-[188px]"
                onClick={() => {
                  setOpenModalConfirm(true)
                  setOpen(false)
                }}
              >
                Confirmar
              </Button>
            </div>
          </div>
        </AlertDialogContent>
      </AlertDialog>
      <AlertDialog open={openModalConfirm} onOpenChange={setOpenModalConfirm}>
        <AlertDialogTrigger asChild></AlertDialogTrigger>
        <AlertDialogContent style={{ gap: '0px' }}>
          {viewModal === 'confirm' ? (
            <div className="flex flex-col text-secondary-500 font-inter gap-0">
              <div className="flex justify-end">
                <IconX
                  stroke={1.5}
                  size={20}
                  className="close text-2xl cursor-pointer"
                  color="#263658"
                  onClick={cancelChanges}
                />
              </div>
              <div className="flex flex-col text-secondary-500 font-inter gap-3 items-center">
                <span className="text-2xl font-medium">
                  Desactivar autentificación
                </span>
                <span className="text-sm text-center">
                  Estás por desactivar la autentificación en dos pasos
                </span>
                <div className="flex flex-row justify-around pt-3 w-full">
                  <Button
                    variant="secondary"
                    size="md"
                    className="xs:w-[120px] sm:w-[188px]"
                    onClick={cancelChanges}
                  >
                    Cancelar
                  </Button>
                  <Button
                    variant="primary"
                    size="md"
                    className="xs:w-[120px] sm:w-[188px]"
                    onClick={confirmChanges}
                  >
                    Confirmar
                  </Button>
                </div>
              </div>
            </div>
          ) : (
            <div className="flex flex-col text-secondary-500 font-inter">
              <div className="flex justify-end">
                <IconX
                  stroke={1.5}
                  size={20}
                  className="close text-2xl cursor-pointer"
                  onClick={cancelChanges}
                />
              </div>
              <div className="flex flex-col text-secondary-500 font-inter gap-3 items-center">
                <span className="text-2xl font-medium">
                  Configuración guardada
                </span>
                <span className="text-sm text-center">
                  La configuración ha sido guardada correctamente.
                </span>
                <div className="flex flex-row justify-center pt-3">
                  <Button
                    variant="primary"
                    size="md"
                    className="w-[160px]"
                    onClick={() => {
                      setOpenModalConfirm(false)
                      setViewModal('confirm')
                    }}
                  >
                    Ok
                  </Button>
                </div>
              </div>
            </div>
          )}
        </AlertDialogContent>
      </AlertDialog>
    </>
  )
}
