import React, { useState } from 'react'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog'
import { Button } from '@/components/ui/button'

//@ts-ignore
import { t, useLanguage } from '@joyit/layout'
import { IconX } from '@tabler/icons-react'

const AlertAccountDesactivation = () => {
  const { handleChangeLanguage } = useLanguage()
  const [isOpen, setIsOpen] = React.useState(false)

  const handleCloseDialog = () => {
    setIsOpen(false)
  }
  return (
    <AlertDialog open={isOpen} onOpenChange={setIsOpen}>
      <AlertDialogTrigger asChild>
        <Button variant="primary" size="md" className="w-full">
          {t('settingsAccount.deactivateAccount')}
        </Button>
      </AlertDialogTrigger>
      <AlertDialogContent style={{ gap: 0 }}>
        <AlertDialogHeader>
          <div className="flex justify-end">
            <IconX
              stroke={1.5}
              size={20}
              className="cursor-pointer text-secondary-500"
              onClick={handleCloseDialog}
            />
          </div>
          <AlertDialogTitle style={{ marginTop: 0 }}>
            <span className="text-center text-2xl font-medium font-inter text-secondary-500">
              {t('settingsAccount.areYouSure')}
            </span>
          </AlertDialogTitle>
          <AlertDialogDescription>
            <p className="font-inter mt-[5px] text-center text-secondary-500">
              {t('settingsAccount.deactivateConfirmInfo')}
            </p>
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter className="mt-6">
          <div className="flex justify-around items-center w-full">
            <AlertDialogCancel className="text-sm xs:w-[147px] md:w-[160px]">
              {t('settingsAccount.deactivateButton')}
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={handleCloseDialog}
              className="text-sm xs:w-[147px] md:w-[160px]"
            >
              {t('settingsAccount.buttonCancel')}
            </AlertDialogAction>
          </div>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  )
}

export default AlertAccountDesactivation
