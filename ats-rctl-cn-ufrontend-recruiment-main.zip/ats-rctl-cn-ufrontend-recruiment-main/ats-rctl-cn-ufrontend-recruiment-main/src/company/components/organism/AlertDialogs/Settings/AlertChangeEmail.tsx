import InputOtp from '@/company/components/molecules/Settings/InputOtp'
import {
  AlertDialog,
  AlertDialogContent,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog'
import { Form } from '@/components/ui/form'
import { useEffect, useState } from 'react'
import { useForm } from 'react-hook-form'
import { z } from 'zod'
import { zodResolver } from '@hookform/resolvers/zod'
import { IconX } from '@tabler/icons-react'
import FormChange from '@/company/components/molecules/Settings/FormChange'
import { Button } from '@/components/ui/button'

export default function AlertChangeEmail() {
  const [open, setOpen] = useState(false)
  const [viewForm, setViewForm] = useState(false)

  const [alertEnd, setAlertEnd] = useState(false)

  const openAlertForm = () => {
    setViewForm(true)
  }

  const emailSchema = z
    .object({
      currentEmail: z
        .string()
        .email({ message: 'Correo electrónico incorrecto' }),
      newEmail: z
        .string()
        .email({ message: 'Nuevo correo electrónico incorrecto' }),
      confirmNewEmail: z.string().email({
        message: 'Confirmación de nuevo correo electrónico incorrecto',
      }),
    })
    .refine((data) => data.newEmail === data.confirmNewEmail, {
      message: 'Correos electrónicos no coinciden',
      path: ['confirmNewEmail'], // path of error message
    })

  const form = useForm<z.infer<typeof emailSchema>>({
    resolver: zodResolver(emailSchema),
    defaultValues: {
      currentEmail: '',
      newEmail: '',
      confirmNewEmail: '',
    },
  })

  const onSubmit = (data) => {
    setTimeout(() => {
      setOpen(false)
      setAlertEnd(true)
    }, 1000)
  }

  useEffect(() => {
    if (!open) {
      form.reset()
    }
  }, [open, form])

  return (
    <>
      <AlertDialog open={open} onOpenChange={setOpen}>
        <AlertDialogTrigger asChild>
          <Button
            variant="tertiary"
            size="sm"
            className="w-auto"
            onClick={() => setOpen(true)}
          >
            Cambiar
          </Button>
        </AlertDialogTrigger>
        <AlertDialogContent style={{ gap: '0px' }}>
          <div className="flex justify-end">
            <IconX
              stroke={1.5}
              size={20}
              color="#263658"
              className="close text-2xl cursor-pointer"
              onClick={() => {
                setViewForm(false)
                setOpen(false)
              }}
            />
          </div>
          <div className="flex flex-col text-secondary-500 font-inter gap-3">
            <div className="flex justify-center">
              <span className="xs:tex-xl sm:text-2xl font-medium text-start">
                {viewForm ? 'Cambiar correo electrónico' : 'Ingresa el código'}
              </span>
            </div>
            {!viewForm ? (
              <>
                <div className="text-center">
                  <p className="text-sm">
                    Para cambiar el correo electrónico será necesario verificar
                    su identidad, escriba el código enviado al número *** ***
                    *71
                  </p>
                </div>
                <div className="flex flex-col gap-3 items-center w-full h-auto justify-center pt-3">
                  <InputOtp />
                  <div>
                    <Button variant="tertiary" size="sm" className="w-auto">
                      Volver a enviar código
                    </Button>
                  </div>
                </div>
                <div className="flex flex-row justify-around pt-3">
                  <Button
                    variant="secondary"
                    size="md"
                    className="xs:w-[140px] sm:w-[160px]"
                    onClick={() => setOpen(false)}
                  >
                    Cancelar
                  </Button>
                  <Button
                    variant="primary"
                    size="md"
                    className="xs:w-[140px] sm:w-[160px]"
                    onClick={openAlertForm}
                  >
                    Confirmar
                  </Button>
                </div>
              </>
            ) : (
              <Form {...form}>
                <form
                  onSubmit={form.handleSubmit(onSubmit)}
                  className="space-y-5 pt-4 flex flex-col items-center"
                >
                  <FormChange
                    name="currentEmail"
                    placeholder="Correo electrónico actual"
                    //inputType="email"
                    formControl={form.control}
                    schema={emailSchema}
                  />
                  <FormChange
                    name="newEmail"
                    placeholder="Correo electrónico nuevo"
                    //inputType="email"
                    formControl={form.control}
                    schema={emailSchema}
                  />
                  <FormChange
                    name="confirmNewEmail"
                    placeholder="Vuelva a escribir el correo electrónico nuevo"
                    //inputType="email"
                    formControl={form.control}
                    schema={emailSchema}
                  />
                  <div
                    className="flex flex-row justify-between xs:w-full sm:w-[85%]"
                    style={{ marginTop: '25px' }}
                  >
                    <Button
                      variant="secondary"
                      size="md"
                      type="submit"
                      className="xs:w-[140px] sm:w-[160px]"
                      onClick={() => {
                        setViewForm(false)
                        setOpen(false)
                      }}
                    >
                      Cancelar
                    </Button>
                    <Button
                      variant="primary"
                      size="md"
                      type="submit"
                      className="xs:w-[140px] sm:w-[160px]"
                    >
                      Cambiar
                    </Button>
                  </div>
                </form>
              </Form>
            )}
          </div>
        </AlertDialogContent>
      </AlertDialog>
      <AlertDialog open={alertEnd} onOpenChange={setAlertEnd}>
        <AlertDialogContent style={{ gap: '0px' }}>
          <div className="flex justify-end">
            <IconX
              stroke={1.5}
              size={20}
              color="#263658"
              className="close text-2xl cursor-pointer"
              onClick={() => setAlertEnd(false)}
            />
          </div>
          <div className="w-full flex flex-col items-center gap-4 text-secondary-500 font-inter">
            <span className="xs:text-xl sm:text-2xl font-medium text-center">
              Correo actualizado
              <br />
              correctamente
            </span>
            <span className="text-sm text-center">
              El correo ha sido actualizado de manera correcta.
            </span>
            <Button
              variant="primary"
              size="md"
              className="w-[160px]"
              onClick={() => setAlertEnd(false)}
            >
              Ok
            </Button>
          </div>
        </AlertDialogContent>
      </AlertDialog>
    </>
  )
}
