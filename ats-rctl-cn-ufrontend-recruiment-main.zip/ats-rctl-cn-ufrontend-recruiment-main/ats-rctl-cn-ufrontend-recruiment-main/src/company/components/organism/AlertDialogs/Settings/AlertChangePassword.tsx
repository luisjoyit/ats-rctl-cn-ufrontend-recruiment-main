import FormChange from '@/company/components/molecules/Settings/FormChange'
import InputOtp from '@/company/components/molecules/Settings/InputOtp'
import {
  AlertDialog,
  AlertDialogContent,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog'
import { Button } from '@/components/ui/button'
import { Form } from '@/components/ui/form'
import { zodResolver } from '@hookform/resolvers/zod'
import { IconX } from '@tabler/icons-react'
import { useEffect, useState } from 'react'
import { useForm } from 'react-hook-form'
import { z } from 'zod'

export default function AlertChangePassword() {
  const [open, setOpen] = useState(false)
  const [viewForm, setViewForm] = useState(false)

  const [alertEnd, setAlertEnd] = useState(false)

  const openAlertForm = () => {
    setViewForm(true)
  }

  const passwordSchema = z
    .object({
      currentPassword: z
        .string()
        .min(8, { message: 'Contraseña actual incorrecta' }),
      newPassword: z
        .string()
        .min(8, { message: 'Nueva contraseña debe tener mínimo 8 caracteres' })
        .regex(/[A-Z]/, {
          message: 'Nueva contraseña debe tener al menos una letra mayúscula',
        })
        .regex(/[a-z]/, {
          message: 'Nueva contraseña debe tener al menos una letra minúscula',
        })
        .regex(/[0-9]/, {
          message: 'Nueva contraseña debe tener al menos un número',
        })
        .regex(/[^A-Za-z0-9]/, {
          message: 'Nueva contraseña debe tener al menos un carácter especial',
        }),
      confirmNewPassword: z
        .string()
        .min(8, { message: 'Confirmación de nueva contraseña inválida' }),
    })
    .refine((data) => data.newPassword === data.confirmNewPassword, {
      message: 'Las nuevas contraseñas no coinciden',
      path: ['confirmNewPassword'], // path of error message
    })

  const form = useForm<z.infer<typeof passwordSchema>>({
    resolver: zodResolver(passwordSchema),
    defaultValues: {
      currentPassword: '',
      newPassword: '',
      confirmNewPassword: '',
    },
  })

  const onSubmit = (data) => {
    setTimeout(() => {
      setOpen(false)
      setAlertEnd(true)
    }, 1000)
  }

  useEffect(() => {
    if (!open) {
      form.reset()
    }
  }, [open, form])

  return (
    <>
      <AlertDialog open={open} onOpenChange={setOpen}>
        <AlertDialogTrigger asChild>
          <Button
            variant="tertiary"
            size="sm"
            className="w-auto"
            onClick={() => setOpen(true)}
          >
            Cambiar
          </Button>
        </AlertDialogTrigger>
        <AlertDialogContent style={{ gap: '0px' }}>
          <div className="flex justify-end">
            <IconX
              stroke={1.5}
              size={20}
              className="close text-2xl cursor-pointer"
              color="#263658"
              onClick={() => {
                setViewForm(false)
                setOpen(false)
              }}
            />
          </div>
          <div className="flex flex-col text-secondary-500 font-inter gap-3">
            <div className="flex justify-center">
              <span className="xs:tex-xl sm:text-2xl font-medium text-start">
                {viewForm ? 'Cambiar contraseña' : 'Ingresa el código'}
              </span>
            </div>
            {!viewForm ? (
              <>
                <div className="text-center">
                  <p className="text-sm">
                    Para cambiar la contraseña será necesario verificar su
                    identidad, escriba el código enviado al número *** *** *71
                  </p>
                </div>
                <div className="flex flex-col gap-3 items-center w-full h-auto justify-center pt-3">
                  <InputOtp />
                  <div>
                    <Button variant="tertiary" size="sm" className="w-auto">
                      Volver a enviar código
                    </Button>
                  </div>
                </div>
                <div className="flex flex-row justify-around pt-3">
                  <Button
                    variant="secondary"
                    size="md"
                    className="xs:w-[140px] sm:w-[160px]"
                    onClick={() => setOpen(false)}
                  >
                    Cancelar
                  </Button>
                  <Button
                    variant="primary"
                    size="md"
                    className="xs:w-[140px] sm:w-[160px]"
                    onClick={openAlertForm}
                  >
                    Confirmar
                  </Button>
                </div>
              </>
            ) : (
              <Form {...form}>
                <form
                  onSubmit={form.handleSubmit(onSubmit)}
                  className="space-y-5 pt-4 flex flex-col items-center"
                >
                  <FormChange
                    name="currentPassword"
                    placeholder="Contraseña actual"
                    inputType="password"
                    formControl={form.control}
                    schema={passwordSchema}
                  />
                  <FormChange
                    name="newPassword"
                    placeholder="Contraseña nueva"
                    inputType="password"
                    formControl={form.control}
                    schema={passwordSchema}
                  />
                  <FormChange
                    name="confirmNewPassword"
                    placeholder="Vuelva a escribir contraseña nueva"
                    inputType="password"
                    formControl={form.control}
                    schema={passwordSchema}
                  />
                  <div
                    style={{ marginTop: '25px' }}
                    className="flex flex-row justify-between xs:w-full sm:w-[85%]"
                  >
                    <Button
                      variant="secondary"
                      size="md"
                      type="submit"
                      className="xs:w-[140px] sm:w-[160px]"
                      onClick={() => {
                        setViewForm(false)
                        setOpen(false)
                      }}
                    >
                      Cancelar
                    </Button>
                    <Button
                      variant="primary"
                      size="md"
                      type="submit"
                      className="xs:w-[140px] sm:w-[160px]"
                    >
                      Cambiar
                    </Button>
                  </div>
                </form>
              </Form>
            )}
          </div>
        </AlertDialogContent>
      </AlertDialog>
      <AlertDialog open={alertEnd} onOpenChange={setAlertEnd}>
        <AlertDialogContent style={{ gap: '0px' }}>
          <div className="flex justify-end">
            <IconX
              stroke={1.5}
              size={20}
              className="close text-2xl cursor-pointer"
              color="#263658"
              onClick={() => setAlertEnd(false)}
            />
          </div>
          <div className="w-full flex flex-col items-center gap-4 text-secondary-500 font-inter">
            <span className="xs:text-xl sm:text-2xl font-medium text-center">
              Contraseña actualizada
              <br />
              correctamente
            </span>
            <span className="text-sm text-center">
              La contraseña ha sido actualizado de manera correcta.
            </span>
            <Button
              variant="primary"
              size="md"
              className="w-[160px]"
              onClick={() => setAlertEnd(false)}
            >
              Ok
            </Button>
          </div>
        </AlertDialogContent>
      </AlertDialog>
    </>
  )
}
