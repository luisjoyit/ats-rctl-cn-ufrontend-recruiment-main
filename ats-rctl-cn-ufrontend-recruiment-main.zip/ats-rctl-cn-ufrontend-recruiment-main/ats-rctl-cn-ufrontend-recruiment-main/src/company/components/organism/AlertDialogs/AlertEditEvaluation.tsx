import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogFooter,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog'
import { Button } from '@/components/ui/button'
import { IconX } from '@tabler/icons-react'
import { useState } from 'react'
import { useNavigate } from 'react-router-dom'

export default function AlertEditEvaluation({ openAlert, setOpenAlert }) {
  const [openAlertFinish, setOpenAlertFinish] = useState(false)

  const navigate = useNavigate()

  const handleCreateEvaluation = () => {
    setOpenAlert(false)
    setOpenAlertFinish(true)
  }

  const returnMyEvaluations = () => {
    setOpenAlertFinish(false)
    navigate(`/company/myEvaluations`)
  }

  return (
    <>
      <AlertDialog open={openAlert} onOpenChange={setOpenAlert}>
        <AlertDialogTrigger className="hidden" />
        <AlertDialogContent style={{ gap: 0 }}>
          <AlertDialogTitle className="hidden" />
          <div className="flex justify-end">
            <IconX
              stroke={1.5}
              size={20}
              color="#263658"
              className="close text-2xl cursor-pointer"
              onClick={() => setOpenAlert(false)}
            />
          </div>
          <div className="flex flex-col gap-4">
            <div className="flex flex-col gap-4 font-inter text-secondary-500 w-full items-center justify-center">
              <span className="font-medium xs:text-xl sm:text-2xl">
                ¿Estas seguro?
              </span>
              <span className="text-sm">
                Estás por finalizar la edición de esta evaluación
              </span>
            </div>
            <AlertDialogFooter>
              <div className="flex flex-row justify-around w-full">
                <AlertDialogCancel onClick={() => setOpenAlert(false)}>
                  Continuar editando
                </AlertDialogCancel>
                <AlertDialogAction onClick={handleCreateEvaluation}>
                  Finalizar edición
                </AlertDialogAction>
              </div>
            </AlertDialogFooter>
          </div>
        </AlertDialogContent>
      </AlertDialog>
      <AlertDialog open={openAlertFinish} onOpenChange={setOpenAlertFinish}>
        <AlertDialogTrigger className="hidden">
          <div />
        </AlertDialogTrigger>
        <AlertDialogContent style={{ gap: 0 }}>
          <AlertDialogTitle className="hidden" />
          <div className="flex justify-end">
            <IconX
              stroke={1.5}
              size={20}
              color="#263658"
              className="close text-2xl cursor-pointer"
              onClick={returnMyEvaluations}
            />
          </div>
          <div className="flex flex-col gap-4 font-inter text-secondary-500 w-full items-center justify-center">
            <span className="font-medium text-2xl">Evaluación editada</span>
            <span className="text-sm text-center">
              Se visualizará en el apartado de <b>Mis Evaluaciones</b>
            </span>
            <AlertDialogFooter>
              <AlertDialogAction onClick={returnMyEvaluations}>
                Volver
              </AlertDialogAction>
            </AlertDialogFooter>
          </div>
        </AlertDialogContent>
      </AlertDialog>
    </>
  )
}
