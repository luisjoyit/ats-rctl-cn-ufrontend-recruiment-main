import React, { useState } from 'react'
import {
  AlertDialog,
  AlertDialogTrigger,
  AlertDialogContent,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogCancel,
  AlertDialogAction,
} from '@/components/ui/alert-dialog'
import { Button } from '@/components/ui/button'
import AlertAccountDeleteSurvey from './AlertAccountDeleteSurvey'
import AlertAccountDeleteConfirm from './AlertAccountDeleteConfirm'
import { IconX } from '@tabler/icons-react'

//@ts-ignore
import { t, useLanguage } from '@joyit/layout'

const AlertAccountDelete = (setLoading, setAccountDeleted) => {
  const { handleChangeLanguage } = useLanguage()
  const [isFirstAlertOpen, setIsFirstAlertOpen] = useState(false)
  const [showSurvey, setShowSurvey] = useState(false)
  const [showConfirmation, setShowConfirmation] = useState(false)

  const handleFirstAlertOpen = () => {
    setIsFirstAlertOpen(true)
  }

  const handleFirstAlertClose = () => {
    setIsFirstAlertOpen(false)
  }

  const handleSurveyOpen = () => {
    setIsFirstAlertOpen(false)
    setShowSurvey(true)
  }

  const handleSurveyClose = () => {
    setShowSurvey(false)
  }

  const handleConfirmationOpen = () => {
    setShowSurvey(false)
    setShowConfirmation(true)
  }

  const handleConfirmationClose = () => {
    setShowConfirmation(false)
  }
  return (
    <>
      <AlertDialog open={isFirstAlertOpen} onOpenChange={setIsFirstAlertOpen}>
        <AlertDialogTrigger asChild>
          <Button
            variant="primary"
            size="md"
            className="w-full"
            onClick={handleFirstAlertOpen}
          >
            {t('settingsAccount.deleteAccount')}
          </Button>
        </AlertDialogTrigger>
        <AlertDialogContent style={{ gap: 0 }}>
          <div className="flex justify-end">
            <IconX
              stroke={1.5}
              size={20}
              color="#263658"
              className="text-2xl cursor-pointer"
              onClick={handleFirstAlertClose}
            />
          </div>
          <AlertDialogHeader>
            <AlertDialogTitle>
              <h1 className="text-center text-2xl font-medium font-inter text-secondary-500">
                {t('settingsAccount.areYouSure')}
              </h1>
            </AlertDialogTitle>
            <AlertDialogDescription>
              <p className="font-inter mt-[5px] text-center text-secondary-500">
                {t('settingsAccount.deleteConfirmInfo')}
              </p>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter className="mt-6">
            <div className="flex justify-around items-center w-full">
              <AlertDialogCancel
                onClick={handleSurveyOpen}
                className="text-sm xs:w-[147px] md:w-[160px]"
              >
                {t('settingsAccount.deleteAccount')}
              </AlertDialogCancel>
              <AlertDialogAction
                onClick={handleFirstAlertClose}
                className="text-sm xs:w-[147px] md:w-[160px]"
              >
                <p className="font-inter text-sm px-2">
                  {t('settingsAccount.buttonCancel')}
                </p>
              </AlertDialogAction>
            </div>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {showSurvey && (
        <AlertAccountDeleteSurvey
          onClose={handleSurveyClose}
          onConfirmationOpen={handleConfirmationOpen}
        />
      )}

      {showConfirmation && (
        <AlertAccountDeleteConfirm
          onClose={handleConfirmationClose}
          setLoading={setLoading}
          setAccountDeleted={setAccountDeleted} // Pass the prop here
        />
      )}
    </>
  )
}

export default AlertAccountDelete
