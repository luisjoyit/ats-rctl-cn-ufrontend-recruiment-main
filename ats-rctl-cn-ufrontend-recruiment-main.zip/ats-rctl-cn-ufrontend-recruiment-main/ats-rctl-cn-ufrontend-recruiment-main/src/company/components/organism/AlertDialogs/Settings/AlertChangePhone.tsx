import FormChange from '@/company/components/molecules/Settings/FormChange'
import InputOtp from '@/company/components/molecules/Settings/InputOtp'
import {
  AlertDialog,
  AlertDialogContent,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog'
import { Button } from '@/components/ui/button'
import { Form } from '@/components/ui/form'
import { zodResolver } from '@hookform/resolvers/zod'
import { IconX } from '@tabler/icons-react'
import { useEffect, useState } from 'react'
import { useForm } from 'react-hook-form'
import { z } from 'zod'

export default function AlertChangePhone() {
  const [open, setOpen] = useState(false)
  const [view, setView] = useState('initial') //views: initial, form y confirm

  const [alertEnd, setAlertEnd] = useState(false)

  const openAlertForm = () => {
    setView('form')
  }

  const phoneSchema = z
    .object({
      currentPhone: z.string().min(10, { message: 'Número actual incorrecto' }),
      newPhone: z.string().min(10, { message: 'Nuevo número inválido' }),
      confirmNewPhone: z
        .string()
        .min(10, { message: 'Confirmación de nuevo número inválido' }),
    })
    .refine((data) => data.newPhone === data.confirmNewPhone, {
      message: 'Números de contacto no coinciden',
      path: ['confirmNewPhone'], // path of error message
    })

  const form = useForm<z.infer<typeof phoneSchema>>({
    resolver: zodResolver(phoneSchema),
    defaultValues: {
      currentPhone: '',
      newPhone: '',
      confirmNewPhone: '',
    },
  })

  const onSubmit = (data) => {
    setView('confirm')
  }

  const saveChange = () => {
    setTimeout(() => {
      setOpen(false)
      setAlertEnd(true)
      setView('initial')
    }, 1000)
  }

  useEffect(() => {
    if (!open) {
      form.reset()
    }
  }, [open, form])

  return (
    <>
      <AlertDialog open={open} onOpenChange={setOpen}>
        <AlertDialogTrigger asChild>
          <Button
            variant="tertiary"
            size="sm"
            className="w-auto"
            onClick={() => setOpen(true)}
          >
            Cambiar
          </Button>
        </AlertDialogTrigger>
        <AlertDialogContent style={{ gap: '0px' }}>
          <div className="flex justify-end">
            <IconX
              stroke={1.5}
              size={20}
              className="close text-2xl cursor-pointer"
              color="#263658"
              onClick={() => {
                setView('initial')
                setOpen(false)
              }}
            />
          </div>
          <div className="flex flex-col text-secondary-500 font-inter gap-3">
            <div className="flex justify-center">
              <span className="xs:tex-xl sm:text-2xl font-medium">
                {view === 'initial'
                  ? 'Cambiar número de contacto'
                  : 'Ingresa el código'}
              </span>
            </div>
            {view === 'initial' && (
              <>
                <div className="text-center">
                  <p className="text-sm">
                    Para cambiar el número de contacto será necesario verificar
                    su identidad, escriba el código enviado al número *** ***
                    *71
                  </p>
                </div>
                <div className="flex flex-col gap-3 items-center w-full h-auto justify-center pt-3">
                  <InputOtp />
                  <div>
                    <Button variant="tertiary" size="sm" className="w-auto">
                      Volver a enviar código
                    </Button>
                  </div>
                </div>
                <div className="flex flex-row justify-around pt-3">
                  <Button
                    variant="secondary"
                    size="md"
                    className="xs:w-[140px] sm:w-[160px]"
                    onClick={() => setOpen(false)}
                  >
                    Cancelar
                  </Button>
                  <Button
                    variant="primary"
                    size="md"
                    className="xs:w-[140px] sm:w-[160px]"
                    onClick={openAlertForm}
                  >
                    Confirmar
                  </Button>
                </div>
              </>
            )}
            {view === 'form' && (
              <Form {...form}>
                <form
                  onSubmit={form.handleSubmit(onSubmit)}
                  className="space-y-5 pt-4 flex flex-col items-center"
                >
                  <FormChange
                    name="currentPhone"
                    placeholder="Número de contacto actual"
                    formControl={form.control}
                    schema={phoneSchema}
                  />
                  <FormChange
                    name="newPhone"
                    placeholder="Número de contacto nuevo"
                    formControl={form.control}
                    schema={phoneSchema}
                  />
                  <FormChange
                    name="confirmNewPhone"
                    placeholder="Vuelva a escribir número de contacto nuevo"
                    formControl={form.control}
                    schema={phoneSchema}
                  />
                  <div
                    className="flex flex-row justify-between xs:w-full sm:w-[85%]"
                    style={{ marginTop: '25px' }}
                  >
                    <Button
                      variant="secondary"
                      size="md"
                      type="submit"
                      className="xs:w-[140px] sm:w-[160px]"
                      onClick={() => {
                        setView('initial')
                        setOpen(false)
                      }}
                    >
                      Cancelar
                    </Button>
                    <Button
                      variant="primary"
                      size="md"
                      type="submit"
                      className="xs:w-[140px] sm:w-[160px]"
                    >
                      Guardar número
                    </Button>
                  </div>
                </form>
              </Form>
            )}
            {view === 'confirm' && (
              <>
                <div className="text-center">
                  <p className="text-sm">
                    Para cambiar el número de contacto será necesario
                    verificarlo. Escribir el código enviado al nuevo número ***
                    *** *26:
                  </p>
                </div>
                <div className="flex flex-col gap-3 items-center w-full h-auto justify-center pt-3">
                  <InputOtp />
                  <div>
                    <Button variant="tertiary" size="sm" className="w-auto">
                      Volver a enviar código
                    </Button>
                  </div>
                </div>
                <div className="flex flex-row justify-around pt-3">
                  <Button
                    variant="secondary"
                    size="md"
                    type="submit"
                    className="xs:w-[140px] sm:w-[160px]"
                    onClick={() => setOpen(false)}
                  >
                    Cancelar
                  </Button>
                  <Button
                    variant="primary"
                    size="md"
                    type="submit"
                    className="xs:w-[140px] sm:w-[160px]"
                    onClick={saveChange}
                  >
                    Confirmar
                  </Button>
                </div>
              </>
            )}
          </div>
        </AlertDialogContent>
      </AlertDialog>
      <AlertDialog open={alertEnd} onOpenChange={setAlertEnd}>
        <AlertDialogContent style={{ gap: '0px' }}>
          <div className="flex justify-end">
            <IconX
              stroke={1.5}
              size={20}
              className="close text-2xl cursor-pointer"
              color="#263658"
              onClick={() => setAlertEnd(false)}
            />
          </div>
          <div className="w-full flex flex-col items-center gap-4 text-secondary-500 font-inter">
            <span className="xs:text-xl sm:text-2xl font-medium text-center">
              Número de contacto actualizado
              <br />
              correctamente
            </span>
            <span className="text-sm text-center">
              El número de contacto ha sido actualizado de manera correcta.
            </span>
            <Button
              variant="primary"
              size="md"
              className="w-[160px]"
              onClick={() => setAlertEnd(false)}
            >
              Ok
            </Button>
          </div>
        </AlertDialogContent>
      </AlertDialog>
    </>
  )
}
