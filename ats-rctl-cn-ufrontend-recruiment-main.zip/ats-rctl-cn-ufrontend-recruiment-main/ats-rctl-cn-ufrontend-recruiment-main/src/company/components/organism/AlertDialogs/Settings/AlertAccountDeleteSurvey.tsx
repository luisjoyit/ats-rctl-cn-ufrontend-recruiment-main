import React, { useState } from 'react'
import {
  AlertDialog,
  AlertDialogContent,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogFooter,
  AlertDialogCancel,
  AlertDialogTrigger,
  AlertDialogAction,
} from '@/components/ui/alert-dialog'
import { IconX } from '@tabler/icons-react'
import { Checkbox } from '@/components/ui/checkbox'
//@ts-ignore
import { t, useLanguage } from '@joyit/layout'

const AlertAccountDeleteSurvey = (onClose, onConfirmationOpen) => {
  const { handleChangeLanguage } = useLanguage()
  const [selectedReason, setSelectedReason] = useState('')

  const handleReasonChange = (reason) => {
    setSelectedReason(reason)
  }
  return (
    <AlertDialog open onOpenChange={onClose}>
      <AlertDialogContent style={{ gap: 0 }}>
        <div className="flex justify-end">
          <IconX
            stroke={1.5}
            size={20}
            color="#263658"
            className="text-2xl cursor-pointer"
            onClick={onClose}
          />
        </div>
        <AlertDialogHeader>
          <AlertDialogTitle>
            <h1 className="text-center text-lg font-medium font-inter text-secondary-500">
              {t('settingsAccount.surveyTitle')}
            </h1>
          </AlertDialogTitle>
        </AlertDialogHeader>
        <div className="mt-4 text-secondary-500">
          <label className="flex items-center font-inter mt-2">
            <Checkbox
              checked={selectedReason === 'noJob'}
              id="noJob"
              onCheckedChange={() => handleReasonChange('noJob')}
              className="mr-2"
            />
            <span className="text-sm">{t('settingsAccount.noJob')}</span>
          </label>
          <label className="flex items-center font-inter mt-2">
            <Checkbox
              checked={selectedReason === 'foundJobElsewhere'}
              id="foundJobElsewhere"
              onCheckedChange={() => handleReasonChange('foundJobElsewhere')}
              className="mr-2"
            />
            <span className="text-sm">
              {t('settingsAccount.foundJobElsewhere')}
            </span>
          </label>
          <label className="flex items-center font-inter mt-2">
            <Checkbox
              checked={selectedReason === 'noInterviews'}
              id="noInterviews"
              onCheckedChange={() => handleReasonChange('noInterviews')}
              className="mr-2"
            />
            <span className="text-sm">{t('settingsAccount.noInterviews')}</span>
          </label>
          <label className="flex items-center font-inter mt-2">
            <Checkbox
              checked={selectedReason === 'noOffers'}
              id="noOffers"
              onCheckedChange={() => handleReasonChange('noOffers')}
              className="mr-2"
            />
            <span className="text-sm">{t('settingsAccount.noOffers')}</span>
          </label>
          <label className="flex items-center font-inter mt-2">
            <Checkbox
              checked={selectedReason === 'noSupport'}
              id="noSupport"
              onCheckedChange={() => handleReasonChange('noSupport')}
              className="mr-2"
            />
            <span className="text-sm">{t('settingsAccount.noSupport')}</span>
          </label>
        </div>
        <AlertDialogFooter className="mt-6">
          <div className="flex justify-around items-center w-full">
            <AlertDialogCancel onClick={onConfirmationOpen}>
              {t('settingsAccount.deleteButton')}
            </AlertDialogCancel>
            <AlertDialogAction onClick={onClose}>
              <p className="font-inter text-sm px-2">
                {t('settingsAccount.buttonCancel')}
              </p>
            </AlertDialogAction>
          </div>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  )
}

export default AlertAccountDeleteSurvey
