import { useState } from 'react'
import LoginHistory from '../../molecules/Settings/LoginHistory'
import PasswordHistory from '../../molecules/Settings/PasswordHistory'
import AlertChangeAuthentication from '../AlertDialogs/Settings/AlertChangeAuthentication'
import { Switch } from '@/components/ui/switch'
import { IconArrowLeft, IconInfoCircle } from '@tabler/icons-react'
import { Button } from '@/components/ui/button'
import SelectUi from '@/components/SelectUi'
import { useOutletContext } from 'react-router-dom'
import TooltipUi from '@/components/TooltipUi'

interface OutletContextType {
  handleViewMenu?: () => void
}

export default function Privacy() {
  const [view, setView] = useState('main') // Alterna entre vista principal y vista de historiales

  const [settingsPriv, setSettingsPriv] = useState({
    twoStepAut: 'active',
    methAut: 'phone',
    contact: 'any',
    sendRequest: true,
  })

  const [openAlertAuth, setOpenAlertAuth] = useState(false)
  const { handleViewMenu } = useOutletContext<OutletContextType>()

  const handleConfirm = () => {
    setOpenAlertAuth(false)
    setSettingsPriv((prev) => ({ ...prev, twoStepAut: 'disabled' }))
  }

  const handleCancel = () => {
    setOpenAlertAuth(false)
  }

  const changeOptions = (name: string, value: any) => {
    if (name === 'twoStepAut' && settingsPriv.twoStepAut === 'active') {
      setOpenAlertAuth(true)
    } else {
      setSettingsPriv((prev) => ({ ...prev, [name]: value }))
    }
  }

  return (
    <div>
      {view === 'main' ? (
        <div className="flex flex-col gap-6 text-secondary dark:text-white">
          <div className="flex flex-col gap-2">
            <button
              onClick={handleViewMenu}
              className="xs:flex sm:hidden bg-backgroundF-500 rounded-4xl gap-1 px-3 items-center text-xs font-medium h-[23px] max-w-max text-secondary-500 mb-2"
            >
              <IconArrowLeft stroke={1.5} size={14} />
              Volver
            </button>
            <span className="text-xl font-semibold">
              Privacidad y seguridad
            </span>
            <p className="text-sm">
              Configura opciones de privacidad y seguridad para proteger la
              cuenta de la empresa, como la autenticación en dos pasos y la
              administración de permisos.
            </p>
          </div>
          <div className="flex flex-col gap-5">
            <span className="text-xl font-semibold">
              Autentificación en dos pasos
            </span>
            <div className="flex flex-col gap-2">
              <span className="text-sm font-medium">
                Activar y desactivar autentificación en dos pasos
              </span>
              <div className="flex flex-row gap-3 items-center">
                <SelectUi
                  items={[
                    { value: 'active', label: 'Activado' },
                    { value: 'disabled', label: 'Desactivado' },
                  ]}
                  name="twoStepAut"
                  placeholder="Tipo de Autenticación"
                  value={settingsPriv.twoStepAut}
                  onChange={changeOptions}
                  className="border"
                />
                <div className="flex items-center">
                  <TooltipUi
                    Icon={IconInfoCircle}
                    label="Lorem ipsum dolor sit amet, consectetur adipiscing
                          elit."
                    sizeIcon={24}
                  />
                </div>
              </div>
            </div>
            <div className="flex flex-col gap-2">
              <span className="text-sm font-medium">
                Seleccionar método de autentificación
              </span>
              <div className="flex flex-row gap-3 items-center">
                <SelectUi
                  items={[
                    { value: 'phone', label: 'Número de contacto' },
                    { value: 'email', label: 'Correo electrónico' },
                  ]}
                  name="methAut"
                  placeholder="Número de contacto"
                  value={settingsPriv.methAut}
                  onChange={changeOptions}
                  className="border"
                />
                <div className="flex items-center">
                  <TooltipUi
                    Icon={IconInfoCircle}
                    label="Lorem ipsum dolor sit amet, consectetur adipiscing
                          elit."
                    sizeIcon={24}
                  />
                </div>
              </div>
            </div>
          </div>
          <div className="flex flex-col gap-5">
            <span className="text-xl font-semibold">
              Historial de actividades
            </span>
            <div className="flex flex-col gap-3">
              <span className="text-sm font-medium">
                Ver actividad de inicio de sesión
              </span>
              <div className="flex flex-row items-center xs:w-full sm:w-[370px] justify-between">
                <div className="flex flex-row gap-4 items-center">
                  <span className="text-sm font-medium">LIMA, PE</span>
                  <span className="text-xs">08/07/2024</span>
                  <span className="text-xs">21:17:54</span>
                </div>
                <div className="items-center">
                  <Button
                    variant="tertiary"
                    size="sm"
                    className="w-auto text-[10px] font-bold"
                    onClick={() => setView('loginHistory')}
                  >
                    Ver historial
                  </Button>
                </div>
              </div>
            </div>
            <div className="flex flex-col gap-3">
              <span className="text-sm font-medium">
                Ver cambio de contraseña
              </span>
              <div className="flex flex-row items-center xs:w-full sm:w-[370px] justify-between">
                <div className="flex flex-row gap-4 items-center">
                  <span className="text-sm font-medium">LIMA, PE</span>
                  <span className="text-xs">08/07/2024</span>
                  <span className="text-xs">21:17:54</span>
                </div>
                <div className="items-center">
                  <Button
                    variant="tertiary"
                    size="sm"
                    className="w-auto text-[10px] font-bold"
                    onClick={() => setView('passwordHistory')}
                  >
                    Ver historial
                  </Button>
                </div>
              </div>
            </div>
            <div className="flex flex-col gap-2">
              <span className="text-sm font-medium">Historial de búsqueda</span>
              <span className="text-xs">
                Sólo tú puedes visualizar el historial de búsqueda
              </span>
              <Button
                variant="tertiary"
                size="sm"
                className="w-[138px] text-[10px] font-bold"
                onClick={() => setView('loginHistory')}
              >
                Borrar historial de búsqueda
              </Button>
            </div>
          </div>
          <div className="flex flex-col gap-5">
            <span className="text-xl font-semibold">
              Quién puede contactarte
            </span>
            <div className="flex flex-col gap-2">
              <span className="text-sm font-medium">
                Quién puede enviarte solicitudes de contacto
              </span>
              <div className="flex flex-row gap-3 items-center">
                <SelectUi
                  items={[
                    { value: 'any', label: 'Cualquiera en ATS' },
                    {
                      value: 'request',
                      label: 'Personas con solicitud de mensajes aprobados',
                    },
                    { value: 'nobody', label: 'Nadie' },
                  ]}
                  value={settingsPriv.contact}
                  name="contact"
                  onChange={changeOptions}
                  placeholder="Contacto"
                  className="w-auto min-w-[181px] max-w-[340px] border"
                />
                <div className="flex items-center">
                  <TooltipUi
                    Icon={IconInfoCircle}
                    label="Lorem ipsum dolor sit amet, consectetur adipiscing
                          elit."
                    sizeIcon={24}
                  />
                </div>
              </div>
            </div>
            <div className="flex flex-col gap-4">
              <span className="text-sm font-medium">
                Permitir que te envíen solicitudes de mensajes
              </span>
              <div className="flex gap-6">
                <span className="text-sm font-medium w-[80px]">
                  {settingsPriv.sendRequest ? 'Activado' : 'Desactivado'}
                </span>
                <Switch
                  checked={settingsPriv.sendRequest}
                  onCheckedChange={(checked) =>
                    changeOptions('sendRequest', checked)
                  }
                />
              </div>
            </div>
          </div>
        </div>
      ) : view === 'loginHistory' ? (
        <LoginHistory setView={setView} />
      ) : (
        <PasswordHistory setView={setView} />
      )}
      <AlertChangeAuthentication
        open={openAlertAuth}
        setOpen={setOpenAlertAuth}
        onConfirm={handleConfirm}
        onCancel={handleCancel}
      />
    </div>
  )
}
