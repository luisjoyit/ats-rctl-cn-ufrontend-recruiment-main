import SelectUi from '@/components/SelectUi'
import TooltipUi from '@/components/TooltipUi'
import { Switch } from '@/components/ui/switch'
import { IconArrowLeft, IconInfoCircle } from '@tabler/icons-react'
import { useState } from 'react'
import { useOutletContext } from 'react-router-dom'

interface OutletContextType {
  handleViewMenu?: () => void
}

export default function Visibility() {
  const [visibility, setVisibility] = useState({
    profileType: 'public',
    switchConxExt: true,
    contactInf: 'show',
  })

  const { handleViewMenu } = useOutletContext<OutletContextType>()

  const handleChange = (name: string, value: any) => {
    setVisibility((prev) => ({ ...prev, [name]: value }))
  }

  return (
    <div className="flex flex-col gap-6 text-secondary dark:text-white">
      <div className="flex flex-col gap-2">
        <button
          onClick={handleViewMenu}
          className="xs:flex sm:hidden bg-backgroundF-500 rounded-4xl gap-1 px-3 items-center text-xs font-medium h-[23px] max-w-max text-secondary-500 mb-2"
        >
          <IconArrowLeft stroke={1.5} size={14} />
          Volver
        </button>
        <span className="text-xl font-semibold">Visibilidad del perfil</span>
        <p className="text-sm">
          Controla la visibilidad del perfil de tu empresa y ajusta la
          configuración de privacidad para mantener segura tu información.
        </p>
      </div>
      <div className="flex flex-col gap-6">
        <span className="text-xl font-semibold">
          Configuración de visibilidad
        </span>
        <div className="flex flex-col gap-2">
          <span className="text-sm font-medium">Perfil de tipo</span>
          <div className="flex flex-row gap-3 items-center">
            <SelectUi
              items={[
                { value: 'public', label: 'Público' },
                { value: 'private', label: 'Privado' },
              ]}
              value={visibility.profileType}
              name="profileType"
              onChange={handleChange}
              placeholder="Tipo de Perfil"
              className="border"
            />
            <div>
              <TooltipUi
                Icon={IconInfoCircle}
                label="Lorem ipsum dolor sit amet, consectetur adipiscing elit."
                sizeIcon={24}
              />
            </div>
          </div>
        </div>
        <div className="flex flex-col gap-2">
          <span className="text-sm font-medium">Información de contacto</span>
          <div className="flex flex-row gap-3 items-center">
            <SelectUi
              items={[
                { value: 'show', label: 'Mostrar' },
                { value: 'hide', label: 'Ocultar' },
              ]}
              value={visibility.contactInf}
              name="contactInf"
              onChange={handleChange}
              placeholder="Información de contacto"
              className="border"
            />
            <div>
              <TooltipUi
                Icon={IconInfoCircle}
                label="Lorem ipsum dolor sit amet, consectetur adipiscing elit."
                sizeIcon={24}
              />
            </div>
          </div>
        </div>
      </div>
      <div className="flex flex-col gap-6">
        <span className="text-xl font-semibold">
          Configuración de conexiones
        </span>
        <div className="flex flex-col gap-4">
          <span className="text-sm">
            Aceptar solicitudes de conexión de otras empresas de manera
            automática
          </span>
          <div className="flex gap-6">
            <span className="text-sm font-medium w-[80px]">
              {visibility.switchConxExt ? 'Activado' : 'Desactivado'}
            </span>
            <Switch
              checked={visibility.switchConxExt}
              onCheckedChange={(checked) =>
                handleChange('switchConxExt', checked)
              }
            />
          </div>
        </div>
      </div>
    </div>
  )
}
