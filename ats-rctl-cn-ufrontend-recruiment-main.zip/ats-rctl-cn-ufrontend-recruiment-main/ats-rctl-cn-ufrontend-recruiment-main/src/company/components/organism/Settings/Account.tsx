import PasswordInput from '@/aplicant/components/atoms/PasswordInput'
import AlertChangeEmail from '../AlertDialogs/Settings/AlertChangeEmail'
import AlertChangePassword from '../AlertDialogs/Settings/AlertChangePassword'
import AlertChangePhone from '../AlertDialogs/Settings/AlertChangePhone'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { useState } from 'react'
import { IconArrowLeft, IconChevronLeft } from '@tabler/icons-react'
import { useOutletContext } from 'react-router-dom'

//@ts-ignore
import { t, useLanguage } from '@joyit/layout'
import AlertAccountDesactivation from '../AlertDialogs/Settings/AlertAccountDesactivation'
import AlertAccountDelete from '../AlertDialogs/Settings/AlertAccountDelete'
import LoadingScreen from '@/aplicant/components/organism/AlertDialogs/Settings/LoadingScreen'
import AccountDeleted from '@/aplicant/components/organism/AlertDialogs/Settings/AccountDeleted'

interface OutletContextType {
  handleViewMenu?: () => void
}

export default function Account() {
  const [viewMain, setViewMain] = useState(true)
  const [loading, setLoading] = useState(false)
  const [accountDeleted, setAccountDeleted] = useState(false)
  const { handleViewMenu } = useOutletContext<OutletContextType>()

  if (loading) {
    return <LoadingScreen />
  }

  if (accountDeleted) {
    return <AccountDeleted /> // Show AccountDeleted component
  }

  return (
    <div className="flex flex-col gap-8 w-full">
      {viewMain ? (
        <>
          <div className="flex flex-col gap-2 text-secondary-500">
            <button
              onClick={handleViewMenu}
              className="xs:flex sm:hidden bg-backgroundF-500 rounded-4xl gap-1 px-3 items-center text-xs font-medium h-[23px] max-w-max mb-2"
            >
              <IconArrowLeft stroke={1.5} size={14} />
              Volver
            </button>
            <span className="text-xl font-semibold">
              Administración de la cuenta
            </span>
            <span className="text-sm">Modifica tus credenciales de sesión</span>
          </div>
          <div className="flex flex-col gap-6 w-full text-secondary-500">
            <span className="text-xl font-semibold">Tu cuenta</span>
            <div className="flex flex-col gap-1 w-full">
              <span className="font-medium text-sm">Correo Electrónico</span>
              <div className="w-full flex flex-row gap-2 items-center">
                <div className="xs:w-full sm:w-[370px]">
                  <Input
                    label="Correo Electrónico"
                    placeholder="emp*************.com"
                    id="email"
                  />
                </div>
                <AlertChangeEmail />
              </div>
            </div>
            <div className="flex flex-col gap-1">
              <span className="font-medium text-sm">Contraseña</span>
              <div className="w-full flex flex-row gap-2 items-center">
                <div className="xs:w-full sm:w-[370px]">
                  <PasswordInput
                    label="Contraseña"
                    placeholder="*********"
                    id="password"
                    //className="h-[37px]"
                  />
                </div>
                <AlertChangePassword />
              </div>
            </div>
            <div className="flex flex-col gap-1">
              <span className="font-medium text-sm">Número de contacto</span>
              <div className="w-full flex flex-row gap-2 items-center">
                <div className="xs:w-full sm:w-[370px]">
                  <Input
                    label="Número de contacto"
                    placeholder="*** *** *71"
                    id="phone"
                    onChange={(e) => {
                      const value = e.target.value
                      const numericValue = value.replace(/\D/g, '')
                      e.target.value = numericValue // Asigna solo los números al input
                    }}
                  />
                </div>
                <AlertChangePhone />
              </div>
            </div>
          </div>
          <div className="xs:max-w-[370px] sm:w-[370px]">
            <Button
              variant="primary"
              size="lg"
              className="w-full text-primary-foreground"
              onClick={() => setViewMain(false)}
            >
              Desactivar o eliminar mi cuenta
            </Button>
          </div>
        </>
      ) : (
        <div className="gap-5 flex flex-col xs:w-full sm:w-[370px]">
          <div className="mb-5 flex gap-2 cursor-pointer items-center">
            <IconChevronLeft
              stroke={1.5}
              size={16}
              onClick={() => setViewMain(true)}
            />
            <label
              className="text-sm font-medium cursor-pointer"
              onClick={() => setViewMain(true)}
            >
              Regresar a credenciales de inicio de sesión
            </label>
          </div>
          <h1 className="xs:text-lg sm:text-xl font-semibold">
            {t('settingsAccount.manageAccountTitle')}
          </h1>
          <div className="w-full flex flex-col gap-3">
            <AlertAccountDesactivation />
            <p className="text-sm">
              {t('settingsAccount.deactivateAccountInfo')}
            </p>
          </div>
          <div className="w-full mt-4 flex flex-col gap-3">
            <AlertAccountDelete
              setLoading={setLoading}
              setAccountDeleted={setAccountDeleted}
            />
            <p className="text-sm">{t('settingsAccount.deleteAccountInfo')}</p>
          </div>
        </div>
      )}
    </div>
  )
}
