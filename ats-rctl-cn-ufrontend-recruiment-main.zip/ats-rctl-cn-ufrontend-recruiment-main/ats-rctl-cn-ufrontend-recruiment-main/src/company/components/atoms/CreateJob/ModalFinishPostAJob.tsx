import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogFooter,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog'
import { IconX } from '@tabler/icons-react'
import { useState } from 'react'
import { useNavigate } from 'react-router-dom'

const ModalFinishPostAJob = ({ openModal, setOpenModal }) => {
  const navigate = useNavigate()

  return (
    <AlertDialog open={openModal} onOpenChange={setOpenModal}>
      <AlertDialogTrigger className="hidden" />
      <AlertDialogContent style={{ gap: 0 }}>
        <AlertDialogTitle className="hidden" />
        <div className="flex flex-col text-secondary-500 font-inter gap-4">
          <div className="flex justify-end">
            <IconX
              stroke={1.5}
              size={20}
              className="close text-2xl cursor-pointer"
              onClick={() => {
                setOpenModal(false)
                navigate('/company/myProcesses')
              }}
            />
          </div>
        </div>
        <div className="font-inter text-secondary-500 flex flex-col gap-3">
          <span className="font-medium text-2xl text-center">
            Su empleo ha sido publicado con éxito
          </span>
          <p className="font-medium text-sm text-center">
            Puede gestionar el empleo en el apartado de <b>Mis procesos</b>.
            Además de poder invitar colaboradores al puesto en{' '}
            <b>Buscar talento</b>.
          </p>
        </div>
        <AlertDialogFooter className="w-full">
          <div className="flex justify-center w-full mt-6">
            <AlertDialogAction
              onClick={() => {
                setOpenModal(false)
                navigate('/company/myProcesses')
              }}
              className="h-[30px]"
            >
              Ok
            </AlertDialogAction>
          </div>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  )
}

export default ModalFinishPostAJob
