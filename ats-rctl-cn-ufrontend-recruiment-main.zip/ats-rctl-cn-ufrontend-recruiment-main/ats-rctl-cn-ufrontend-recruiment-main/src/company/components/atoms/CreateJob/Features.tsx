import React, { useState } from 'react'
//@ts-ignore
import { t, useLanguage } from '@joyit/layout'
import Slider from 'rc-slider'
import EditorDemo from '@/components/editorText/editorDemo'
import Benefits from './Features/Benefits'
import { Input } from '@/components/ui/input'
import { Checkbox } from '@/components/ui/checkbox'
import SelectUi from '@/components/SelectUi'
import { JobFormSchema } from '@/company/validations/jobFormSchema'
import {
  FieldErrors,
  UseFormClearErrors,
  UseFormSetValue,
  UseFormTrigger,
  UseFormWatch,
} from 'react-hook-form'
import InputWithSuggestion from '@/components/InputWithSuggestion'
import { useCountries, useModalities } from '@/hooks/service-hooks'
import useLanguages from '@/hooks/service-hooks/useLanguages'
import useStacksTechs from '@/hooks/service-hooks/useStackTec'

interface FeaturesProps {
  errors: FieldErrors<JobFormSchema>
  setValue: UseFormSetValue<JobFormSchema>
  watch: UseFormWatch<JobFormSchema>
  trigger: UseFormTrigger<JobFormSchema>
  clearErrors: UseFormClearErrors<JobFormSchema>
}
const Features = ({
  errors,
  setValue,
  watch,
  trigger,
  clearErrors,
}: FeaturesProps) => {
  const { dataModalities: dataModality } = useModalities()
  const { dataLanguages } = useLanguages()
  const { dataStacksTechs: stackTechOptions } = useStacksTechs()
  const { dataCountries } = useCountries()

  const dataWorkSchedule = [
    {
      value: 'fulltime',
      label: 'Full time',
    },
    {
      value: 'parttime',
      label: 'Part time',
    },
    {
      value: 'freelance',
      label: 'Freelance',
    },
  ]

  const jobQuestions = [
    {
      id: 'jobDescription',
      value: `${t('features.jobDescription')} *`,
    },
    {
      id: 'jobResponsabilities',
      value: `${t('features.responsibilities')} *`,
    },
    {
      id: 'jobAdditional',
      value: t('features.additional'),
    },
  ]

  const [dataJob, setDataJob] = useState({
    modality: {
      value: '',
      label: '',
    },
    workSchedule: {
      value: '',
      label: '',
    },
    language: {
      value: '',
      label: '',
    },
    levelLanguage: {
      value: '',
      label: '',
    },
  })

  const [sliderKey, setSliderKey] = useState(Date.now())

  const handleChangeOption = (name, value) => {
    const formattedValue =
      typeof value === 'object' ? value : { value, label: '' }

    setDataJob((prevState) => ({
      ...prevState,
      [name]: formattedValue,
    }))

    setValue(name, formattedValue)

    if (name === 'language' && value.value === 'notRelevant') {
      setDataJob((prevState) => ({
        ...prevState,
        levelLanguage: { value: '', label: '' },
      }))
      setValue('levelLanguage', { value: '', label: '' })
      clearErrors('levelLanguage')
    }

    trigger(name)
  }

  const handleRangeSalary = (newRange) => {
    setValue('rangeSalarity', newRange)
  }

  const stackTech = watch('stackTech')
  const fixedSalary = watch('fixedSalary') as boolean
  const adHonorem = watch('adHonorem') as boolean

  return (
    <div className=" bg-card xs:rounded-2xl sm:rounded-[30px] shadow-cards xs:px-3 xs:py-6 sm:p-10 text-secondary-500 dark:text-white flex flex-col xs:gap-4 sm:gap-6 xs:space-y-3 sm:space-y-8">
      <div className="grid xs:grid-cols-1 sm:grid-cols-2 xs:gap-3 lg:gap-6">
        <div className="flex flex-col gap-1 xs:pr-0 sm:pr-8">
          <div className="flex xs:flex-col lg:flex-row xs:items-start lg:items-center justify-between xs:gap-2 lg:gap-0">
            <span className="font-semibold xs:text-sm sm:text-base whitespace-nowrap">
              {`${t('features.modality')} *`}
            </span>
            <SelectUi
              name="modality"
              value={dataJob.modality.value}
              items={dataModality}
              placeholder="Selecciona una opción"
              className="border h-[37px] xs:w-3/4 lg:w-[230px]"
              onChange={handleChangeOption}
              setValue={setValue}
              trigger={trigger}
            />
          </div>
          {errors?.modality?.value && (
            <span className="text-xs text-destructive-500">
              {errors.modality.value.message}
            </span>
          )}
        </div>
        <div className="flex flex-col gap-1">
          <div className="flex xs:flex-col lg:flex-row xs:items-start lg:items-center justify-between xs:gap-2 lg:gap-0">
            <span className="xs:text-sm sm:text-base font-semibold whitespace-nowrap">
              {`${t('features.timeRange')} *`}
            </span>
            <SelectUi
              name="workSchedule"
              value={dataJob.workSchedule.value}
              items={dataWorkSchedule}
              placeholder="Selecciona una opción"
              className="border h-[37px] xs:w-3/4 lg:w-[230px]"
              onChange={handleChangeOption}
              setValue={setValue}
              trigger={trigger}
            />
          </div>
          {errors?.workSchedule?.value && (
            <span className="text-xs text-destructive-500">
              {errors.workSchedule.value.message}
            </span>
          )}
        </div>
      </div>
      <div className="grid xs:grid-cols-1 sm:grid-cols-2 xs:gap-3 lg:gap-6">
        <div className="flex flex-col gap-1 xs:pr-0 sm:pr-8">
          <div className="flex xs:flex-wrap lg:flex-row items-center justify-between xs:gap-2 lg:gap-6">
            <span className="font-semibold xs:text-sm sm:text-base whitespace-nowrap">
              País/Ciudad *
            </span>
            <InputWithSuggestion
              items={dataCountries}
              placeholder="Buscar Ciudad/País"
              className="xs:w-3/4 lg:w-[230px]"
              name="countryCity"
              setValue={setValue}
              trigger={trigger}
            />
          </div>
          {errors?.countryCity?.value && (
            <span className="text-xs text-destructive-500">
              {errors.countryCity.value.message}
            </span>
          )}
        </div>
        <div className="flex justify-between">
          <div className="flex flex-col gap-1">
            <div className="flex xs:flex-wrap lg:flex-row items-center justify-between xs:gap-2 sm:gap-4">
              <span className="font-semibold xs:text-sm sm:text-base whitespace-nowrap">
                Idioma *
              </span>
              <SelectUi
                name="language"
                value={dataJob.language.value}
                items={dataLanguages}
                placeholder="Seleccionar"
                className="border h-[37px] w-[160px] text-sm placeholder:text-xs"
                onChange={handleChangeOption}
                setValue={setValue}
                trigger={trigger}
              />
            </div>
            {errors?.language?.value && (
              <span className="text-xs text-destructive-500">
                {errors.language.value.message}
              </span>
            )}
          </div>
          <div className="flex flex-col gap-1">
            <div className="flex xs:flex-wrap lg:flex-row items-center justify-between xs:gap-2 sm:gap-4">
              <span className="font-semibold xs:text-sm sm:text-base whitespace-nowrap">
                Nivel
              </span>
              <SelectUi
                name="levelLanguage"
                value={dataJob.levelLanguage.value}
                items={[
                  { value: 'basic', label: t('features.basic') },
                  {
                    value: 'intermediate',
                    label: t('features.intermediate'),
                  },
                  { value: 'advanced', label: t('features.advanced') },
                ]}
                placeholder="Seleccionar"
                className="border h-[37px] w-[160px] text-sm placeholder:text-xs"
                onChange={handleChangeOption}
                setValue={setValue}
                disabled={watch('language')?.value === 'notRelevant'}
              />
            </div>
            {errors?.levelLanguage && (
              <span className="text-xs text-destructive-500">
                {errors.levelLanguage.message}
              </span>
            )}
          </div>
        </div>
      </div>
      <div className="grid xs:grid-cols-1 sm:grid-cols-2 xs:gap-3 lg:gap-6">
        <div className="flex flex-col gap-1 xs:pr-0 sm:pr-8">
          <div className="flex flex-col xs:gap-2 sm:gap-3">
            <span className="font-semibold xs:text-sm sm:text-base whitespace-nowrap">
              {t('features.salary')}
            </span>
            <div className="flex flex-col gap-2 xs:w-full sm:w-3/4">
              <Slider
                key={sliderKey}
                min={0}
                max={20000}
                step={100}
                range
                value={watch('rangeSalarity') || [5, 1500]}
                onChange={(value) => handleRangeSalary(value)}
                disabled={fixedSalary || adHonorem}
                className="slider-salary-job w-full"
              />
              <div className="flex justify-between">
                <span>0</span>
                <span>20,000</span>
              </div>
              <div className="flex gap-2 items-center">
                <span className="xs:text-sm md:text-base">De</span>
                <Input
                  value={watch('rangeSalarity')[0] || ''}
                  onChange={(e) =>
                    handleRangeSalary([
                      Number(e.target.value),
                      watch('rangeSalarity')[1],
                    ])
                  }
                  preffix="$"
                  disabled={fixedSalary || adHonorem}
                />
                <span className="xs:text-sm md:text-base">a</span>
                <Input
                  value={watch('rangeSalarity')[1] || ''}
                  onChange={(e) =>
                    handleRangeSalary([
                      watch('rangeSalarity')[0],
                      Number(e.target.value),
                    ])
                  }
                  preffix="$"
                  disabled={fixedSalary || adHonorem}
                />
              </div>
            </div>
            <div className="flex gap-6 items-center pt-2">
              <div className="flex gap-2 items-center">
                <Checkbox
                  checked={watch('fixedSalary') as boolean}
                  onCheckedChange={(checked) => {
                    setValue('fixedSalary', checked === true)
                    if (checked) {
                      setValue('adHonorem', false)
                      setValue('rangeSalarity', [0, 0])
                      trigger('fixedSalary')
                    }
                  }}
                  className="mr-1"
                />
                <label
                  className={`xs:text-sm md:text-base text-accent-700 whitespace-nowrap ${watch('fixedSalary') && 'text-secondary-500 dark:text-white'}`}
                >
                  Salario Fijo
                </label>
                <Input
                  value={fixedSalary ? watch('fixedSalaryAmount') : ''}
                  defaultValue={0}
                  className="w-[70px]"
                  onChange={(e) => {
                    setValue('fixedSalaryAmount', Number(e.target.value))
                    trigger('fixedSalaryAmount')
                  }}
                  preffix="$"
                  disabled={!fixedSalary}
                />
              </div>
              <div className="flex gap-2 items-center">
                <Checkbox
                  checked={watch('adHonorem') as boolean}
                  onCheckedChange={(checked) => {
                    setValue('adHonorem', checked === true)
                    if (checked) {
                      setValue('fixedSalary', false)
                      setValue('rangeSalarity', [0, 0])
                      trigger('fixedSalary')
                    }
                  }}
                  className="mr-1"
                />
                <label
                  className={`xs:text-sm md:text-base text-accent-700 md:whitespace-nowrap ${watch('adHonorem') && 'text-secondary-500 dark:text-white'}`}
                >
                  Ad honorem
                </label>
              </div>
            </div>
          </div>
          {errors.rangeSalarity?.message && (
            <span className="text-xs text-destructive-500">
              {errors.rangeSalarity.message}
            </span>
          )}
          {errors.fixedSalaryAmount?.message && (
            <span className="text-xs text-destructive-500">
              {errors.fixedSalaryAmount.message}
            </span>
          )}
          {errors.fixedSalary?.message && (
            <span className="text-xs text-destructive-500">
              {errors.fixedSalary.message}
            </span>
          )}
          {errors.adHonorem?.message && (
            <span className="text-xs text-destructive-500">
              {errors.adHonorem.message}
            </span>
          )}
        </div>
      </div>
      <div className="flex flex-col xs:gap-2 sm:gap-3">
        <span className="font-semibold xs:text-sm sm:text-base whitespace-nowrap">
          Stack tech *
        </span>
        <div className="flex flex-wrap xs:gap-3 sm:gap-5">
          {stackTechOptions.map((option, index) => (
            <button
              key={index}
              type="button"
              className={`px-3 py-1 xs:text-xs sm:text-sm xs:h-[28px] md:h-[30px] flex items-center rounded-[50px] dark:text-secondary-500 ${
                stackTech.some((item) => item.value === option.value)
                  ? 'bg-primary-50'
                  : 'bg-accent-200 hover:bg-primary-50'
              }`}
              onClick={() => {
                const isSelected = stackTech.some(
                  (item) => item.value === option.value,
                )

                const updatedStackTech = isSelected
                  ? stackTech.filter((item) => item.value !== option.value)
                  : [...stackTech, { value: option.value, label: option.label }]

                setValue('stackTech', updatedStackTech)
                trigger('stackTech')
              }}
            >
              {option.label}
            </button>
          ))}
        </div>
        {errors?.stackTech && (
          <span className="text-xs text-destructive-500">
            {errors.stackTech.message}
          </span>
        )}
      </div>
      <div>
        <div className="space-y-6">
          {jobQuestions.map((question, index) => (
            <div key={index} className="space-y-2">
              <h4 className="text-sm font-semibold">{question.value}</h4>
              <div className="dark:text-secondary-500">
                <EditorDemo
                  name={question.id}
                  setValue={setValue}
                  trigger={trigger}
                />
              </div>
              {errors[question.id] && (
                <span className="text-xs text-destructive-500">
                  {errors[question.id]?.message}
                </span>
              )}
            </div>
          ))}
        </div>
      </div>
      <Benefits
        errors={errors}
        setValue={setValue}
        watch={watch}
        trigger={trigger}
      />
    </div>
  )
}

export default Features
