import React, { useState } from 'react'
//@ts-ignore
import { t, useLanguage } from '@joyit/layout'
import { IconChevronLeft, IconChevronRight } from '@tabler/icons-react'
import {
  FieldErrors,
  UseFormGetValues,
  UseFormRegister,
  UseFormSetValue,
  UseFormTrigger,
  UseFormWatch,
} from 'react-hook-form'
import { JobFormSchema } from '@/company/validations/jobFormSchema'
import SelectUi from '@/components/SelectUi'
import { useProfileTypes, useYearsEsperiences } from '@/hooks/service-hooks'

interface PostAJobProps {
  register: UseFormRegister<JobFormSchema>
  errors: FieldErrors<JobFormSchema>
  setValue: UseFormSetValue<JobFormSchema>
  getValues: UseFormGetValues<JobFormSchema>
  watch: UseFormWatch<JobFormSchema>
  trigger: UseFormTrigger<JobFormSchema>
}

const PostAJob = ({
  register,
  errors,
  setValue,
  getValues,
  watch,
  trigger,
}: PostAJobProps) => {
  const { dataYearsEsperiencess: experiencieOptions } = useYearsEsperiences()
  const { dataProfileTypes: dataProfile } = useProfileTypes()
  const availablePositions = watch('availablePositions')
  const [profile, setProfile] = useState({
    nameProfile: {
      value: '',
      label: '',
    },
    levelExperience: {
      value: '',
      label: '',
    },
  })

  const handleProfile = (name, value) => {
    setProfile((prevState) => ({
      ...prevState,
      [name]: typeof value === 'object' ? value : { value, label: '' },
    }))
    trigger(name)
  }

  return (
    <div className="flex flex-col bg-card xs:rounded-2xl sm:rounded-[30px] shadow-cards xs:px-3 xs:py-6 sm:p-10 text-secondary-500 dark:text-white xs:gap-4 sm:gap-6">
      <div className="grid xs:grid-cols-1 sm:grid-cols-2 xs:gap-3 sm:gap-6">
        <div className="flex flex-col gap-1 w-full justify-center">
          <div className="flex xs:flex-col sm:flex-row xs:items-start sm:items-end xs:gap-2 sm:gap-5 w-full">
            <label className="xs:text-sm sm:text-base font-semibold">
              {`${t('postAJob.jobTitle')} *`}
            </label>
            <input
              type="text"
              name="jobName"
              className="flex-1 xs:w-full max-w-80 block border-0 border-b-[0.5px] border-accent-700 focus:ring-0 outline-none bg-transparent"
              {...register('jobName')}
            />
          </div>
          {errors.jobName && (
            <span className="text-xs text-destructive-500">
              {errors.jobName.message}
            </span>
          )}
        </div>
        <div className="flex flex-col gap-1 w-full">
          <div className="flex xs:flex-col sm:flex-row xs:items-start sm:items-center xs:gap-2 sm:gap-5">
            <label className="xs:text-sm sm:text-base font-semibold">
              {`${t('features.experience')} *`}
            </label>
            <SelectUi
              name="levelExperience"
              items={experiencieOptions}
              value={profile.levelExperience.value}
              placeholder="Selecciona una opcion"
              className="border h-[37px] xs:w-3/4 lg:w-[230px]"
              onChange={handleProfile}
              setValue={setValue}
              trigger={trigger}
            />
          </div>
          {errors?.levelExperience?.value && (
            <span className="text-xs text-destructive-500">
              {errors.levelExperience.value.message}
            </span>
          )}
        </div>
      </div>
      <div className="grid xs:grid-cols-1 sm:grid-cols-2 xs:gap-3 sm:gap-6">
        <div className="flex flex-col gap-1">
          <div className="flex xs:flex-col sm:flex-row xs:items-start sm:items-center xs:gap-2- sm:gap-5">
            <label className="xs:text-sm sm:text-base font-semibold">
              {`${t('postAJob.profile')} *`}
            </label>
            <SelectUi
              name="nameProfile"
              items={dataProfile}
              value={profile.nameProfile.value}
              placeholder="Selecciona una opcion"
              className="border h-[37px] xs:w-3/4 lg:w-[230px]"
              onChange={handleProfile}
              setValue={setValue}
              trigger={trigger}
            />
          </div>
          {errors?.nameProfile?.value && (
            <span className="text-xs text-destructive-500">
              {errors.nameProfile.value.message}
            </span>
          )}
        </div>
        <div className="flex items-center gap-6 w-full">
          <label className="xs:text-sm sm:text-base font-semibold">
            {`${t('postAJob.available')} *`}
          </label>
          <div className="flex items-center gap-3">
            <div className="rounded-full p-1 shadow-cards dark:border dark:border-white">
              <IconChevronLeft
                stroke={2}
                size={14}
                className="text-secondary-500 dark:text-white cursor-pointer"
                onClick={() => {
                  const currentValue = getValues('availablePositions')
                  setValue('availablePositions', Math.max(currentValue - 1, 1))
                }}
              />
            </div>
            <span className="p-2 w-10 text-center">{availablePositions}</span>
            <div className="rounded-full p-1 shadow-cards dark:border dark:border-white">
              <IconChevronRight
                stroke={2}
                size={14}
                className="text-secondary-500 dark:text-white cursor-pointer"
                onClick={() => {
                  const currentValue = getValues('availablePositions')
                  setValue('availablePositions', currentValue + 1)
                }}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default PostAJob
