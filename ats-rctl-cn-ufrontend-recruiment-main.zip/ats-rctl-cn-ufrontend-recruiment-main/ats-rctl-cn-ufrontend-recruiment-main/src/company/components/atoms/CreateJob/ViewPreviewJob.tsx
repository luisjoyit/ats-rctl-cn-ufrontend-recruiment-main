import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogFooter,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog'
//@ts-ignore
import { t, useLanguage } from '@joyit/layout'
import {
  IconArrowUpRight,
  IconClockHour10,
  IconShieldLock,
  IconUserPlus,
  IconX,
} from '@tabler/icons-react'

const ViewPreviewJob = ({
  setAlertPreview,
  alertPreview,
  data,
  handleSubmit,
  handlePublish,
}) => {
  const getPositions = () => {
    if (data?.availablePositions === 1) {
      return `${data.availablePositions} Posición`
    } else {
      return `${data.availablePositions} Posiciones`
    }
  }

  const getSalary = () => {
    if (data.rangeSalarity[0] > 0 && data.rangeSalarity[1] > 0) {
      return `$${data.rangeSalarity[0]} - $${data.rangeSalarity[1]}`
    }
    if (data?.fixedSalary) {
      return `$${data.fixedSalaryAmount}`
    }
    if (data?.adHonorem) {
      return 'Ad Honorem'
    }
  }

  const postAJob = () => {
    handleSubmit((data) => {
      handlePublish(data)
    })()
  }

  return (
    <>
      <AlertDialog open={alertPreview} onOpenChange={setAlertPreview}>
        <AlertDialogTrigger className="hidden" />
        <AlertDialogContent style={{ gap: 0 }}>
          <AlertDialogTitle className="hidden" />
          <div className="flex flex-col text-secondary-500 font-inter gap-4">
            <div className="flex justify-end">
              <IconX
                stroke={1.5}
                size={20}
                className="close text-2xl cursor-pointer"
                onClick={() => {
                  setAlertPreview(false)
                }}
              />
            </div>
          </div>
          <div className="font-inter text-secondary-500 flex flex-col gap-1">
            <div className="flex gap-4 items-center">
              <div className="flex items-center gap-1">
                <span className="font-semibold text-xl">{data.jobName}</span>
                <IconArrowUpRight
                  stroke={1}
                  size={18}
                  className="text-secondary-500"
                />
              </div>
              <span className="bg-[#F0F2F4] rounded-4xl w-[112px] h-[23px] text-xs font-medium flex items-center justify-center">
                {data.modality.label}
              </span>
            </div>
            <div className="flex flex-col w-full gap-2">
              <div className="w-full flex xs:gap-2 sm:gap-6 text-secondary-500 dark:text-white font-medium xs:text-xs sm:text-sm">
                <span className="text-accent-600">
                  {data.nameProfile.label}
                </span>
                <span>{getPositions()}</span>
                <span>{data.levelExperience.label}</span>
                <span>{getSalary()}</span>
              </div>
              <div className="w-full flex xs:gap-2 sm:gap-6 font-medium xs:text-xs sm:text-sm text-secondary-500 dark:text-white">
                <div className="flex xs:gap-1 sm:gap-2 items-center">
                  <IconClockHour10
                    stroke={1}
                    size={16}
                    className="text-secondary"
                  />
                  <span>{data.workSchedule.label}</span>
                </div>
                <div className="flex xs:gap-1 sm:gap-2 items-center">
                  <IconUserPlus
                    stroke={1}
                    size={16}
                    className="text-secondary"
                  />
                  <span>{data.countryCity.label}</span>
                </div>
              </div>
            </div>
            <div className="flex flex-col w-full gap-2 pt-4">
              <div className="flex flex-col gap-2">
                <span className="font-semibold">Descripción</span>
                <div className="rounded-lg bg-card p-2 border">
                  <p className="text-sm">{data.jobDescription}</p>
                </div>
              </div>
              {data?.jobResponsabilities && (
                <div className="flex flex-col gap-2">
                  <span className="font-semibold">Funciones:</span>
                  <div className="rounded-lg bg-card p-2 border">
                    <p className="text-sm">{data.jobResponsabilities}</p>
                  </div>
                </div>
              )}
              {data?.jobAdditional && (
                <div className="flex flex-col gap-2">
                  <span className="font-semibold">Información adicional:</span>
                  <div className="rounded-lg bg-card p-2 border">
                    <p className="text-sm">{data.jobAdditional}</p>
                  </div>
                </div>
              )}
              <div className="flex flex-col gap-2">
                <span className="font-semibold">Beneficios</span>
                <div className="grid grid-cols-2 gap-2">
                  {data?.benefits.map((element, id) => (
                    <div
                      key={id}
                      className="flex border gap-2 text-sm rounded-lg p-2 w-full"
                    >
                      <div className="pt-[2px]">
                        <IconShieldLock stroke={1} size={15} />
                      </div>
                      <div className="flex flex-col gap-2">
                        {/* <span className="font-medium">{`Beneficio ${id}`}</span> */}
                        <p className="text-sm xs:hidden sm:flex">
                          {element.label}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              <div className="flex flex-col gap-2">
                <span className="font-semibold">Stack tech</span>
                <div className="rounded-lg bg-card p-2 border gap-4 flex flex-wrap">
                  {data.stackTech.map((element, id) => (
                    <span key={id} className="font-medium text-sm">
                      {element.label}
                    </span>
                  ))}
                </div>
              </div>
              <div className="flex flex-col gap-2">
                <span className="font-semibold">Idioma</span>
                <div className="rounded-lg bg-card p-2 border">
                  <span className="text-sm">
                    {data.language.label} - {data?.levelLanguage.label}
                  </span>
                </div>
              </div>
              {data?.questions?.length !== 0 && (
                <div className="flex flex-col gap-2">
                  <span className="font-semibold">Preguntas</span>
                  <div className="rounded-lg bg-card p-2 border">
                    {data.questions.map((question, id) => (
                      <div key={id}>
                        <span className="text-sm">{`${id + 1}. ${question.titleQuestion}`}</span>
                        {question.typeAnswer !== 'short' &&
                          question.answers.map((answer, id) => (
                            <div className="pl-4" key={id}>
                              <span className="text-xs">{`Opción ${id + 1}. ${answer} `}</span>
                            </div>
                          ))}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
          <AlertDialogFooter className="w-full">
            <div className="flex justify-around w-full mt-5">
              <AlertDialogCancel
                onClick={() => {
                  setAlertPreview(false)
                }}
                className="h-[30px]"
              >
                Volver
              </AlertDialogCancel>
              <AlertDialogAction onClick={postAJob} className="h-[30px]">
                Publicar
              </AlertDialogAction>
            </div>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  )
}

export default ViewPreviewJob
