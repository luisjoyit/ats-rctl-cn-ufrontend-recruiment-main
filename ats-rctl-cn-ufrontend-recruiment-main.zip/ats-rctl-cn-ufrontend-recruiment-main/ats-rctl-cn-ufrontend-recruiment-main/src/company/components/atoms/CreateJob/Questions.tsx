import QuestionItem from '@/components/editorText/questionItem'
import React, { useEffect, useState } from 'react'
//@ts-ignore
import { t, useLanguage } from '@joyit/layout'
import { Button } from '@/components/ui/button'
import { JobFormSchema } from '@/company/validations/jobFormSchema'
import {
  FieldErrors,
  UseFormGetValues,
  UseFormRegister,
  UseFormSetValue,
  UseFormTrigger,
  UseFormWatch,
} from 'react-hook-form'

interface Question {
  id?: number
  titleQuestion?: string
  typeAnswer?: 'SHORT_ANSWER' | 'LONG_ANSWER' | 'MULTIPLE_CHOICE';
  answers?: string[]
}

interface QuestionsFormProps {
  errors: FieldErrors<JobFormSchema>
  setValue: UseFormSetValue<JobFormSchema>
  getValues: UseFormGetValues<JobFormSchema>
  watch: UseFormWatch<JobFormSchema>
  trigger: UseFormTrigger<JobFormSchema>
  register: UseFormRegister<JobFormSchema>
}

const questionDataInitial: Question = {
  id: Date.now(),
  titleQuestion: '',
  typeAnswer: 'SHORT_ANSWER',
  answers: [],
}

const Questions = ({
  errors,
  setValue,
  getValues,
  watch,
  register,
  trigger,
}: QuestionsFormProps) => {
  const questions = watch('questions') || []

  const addQuestion = () => {
    const newQuestion: Question = {
      ...questionDataInitial,
      id: Date.now(),
      answers: [],
    }

    const currentQuestions = getValues('questions') || []
    const updatedQuestions = [...currentQuestions, newQuestion]

    setValue('questions', updatedQuestions)
    trigger('questions')
  }

  const removeQuestion = (id: number) => {
    const updatedQuestions = questions.filter((q) => q.id !== id)
    setValue('questions', updatedQuestions)
  }

  return (
    <div className="bg-card xs:rounded-2xl sm:rounded-[30px] shadow-cards xs:px-3 xs:py-6 sm:p-10 text-secondary-500 dark:text-white flex flex-col xs:gap-4 sm:gap-6">
      <h2 className="font-semibold xs:text-lg sm:text-xl">
        {t('question.quest')}
      </h2>
      <p className="">{t('question.form')}</p>
      {questions.map((question, index) => (
        <QuestionItem
          key={index}
          index={index}
          question={question}
          deleteQuestion={removeQuestion}
          register={register}
          errors={errors}
          setValue={setValue}
          trigger={trigger}
        />
      ))}
      <div>
        <Button
          variant="tertiary"
          size="md"
          type="button"
          onClick={addQuestion}
          className="w-auto p-0 font-semibold"
        >
          + Añadir pregunta
        </Button>
      </div>
    </div>
  )
}

export default Questions
