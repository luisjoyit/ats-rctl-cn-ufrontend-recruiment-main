import React, { useState } from 'react'
//@ts-ignore
import { t, useLanguage } from '@joyit/layout'
import { Switch } from '@/components/ui/switch'
import { UseFormSetValue, UseFormWatch } from 'react-hook-form'
import { JobFormSchema } from '@/company/validations/jobFormSchema'

interface VisibilityProps {
  setValue: UseFormSetValue<JobFormSchema>
  watch: UseFormWatch<JobFormSchema>
}

const Visibility = ({ setValue, watch }: VisibilityProps) => {
  return (
    <div className="bg-card xs:rounded-2xl sm:rounded-[30px] shadow-cards xs:px-3 xs:py-6 sm:p-10 text-secondary-500 dark:text-white flex flex-col xs:gap-4 sm:gap-6">
      <h3 className="font-semibold xs:text-lg sm:text-xl">
        {t('visibility.visi')}
      </h3>
      <div className="grid xs:grid-cols-1 sm:grid-cols-2 xs:gap-4 sm: gap-10 md:gap-20">
        <div className="flex items-center sm:gap-12 xs:justify-between sm:justify-normal xs:pr-4 sm:pr-0">
          <span className="font-semibold xs:text-sm sm:text-base whitespace-nowrap">
            {t('visibility.display')}
          </span>
          <Switch
            checked={watch('showCompanyName')}
            //onCheckedChange={(checked) => setMostrarNombreEmpresa(checked)}
            onCheckedChange={(checked) => setValue('showCompanyName', checked)}
          />
        </div>
        <div className="flex items-center sm:gap-12 xs:justify-between sm:justify-normal xs:pr-4 sm:pr-0">
          <span className="font-semibold xs:text-sm sm:text-base whitespace-nowrap">
            {t('visibility.only')}
          </span>
          <Switch
            checked={watch('onlyVerifiedProfiles')}
            onCheckedChange={(checked) =>
              setValue('onlyVerifiedProfiles', checked)
            }
          />
        </div>
      </div>
    </div>
  )
}

export default Visibility
