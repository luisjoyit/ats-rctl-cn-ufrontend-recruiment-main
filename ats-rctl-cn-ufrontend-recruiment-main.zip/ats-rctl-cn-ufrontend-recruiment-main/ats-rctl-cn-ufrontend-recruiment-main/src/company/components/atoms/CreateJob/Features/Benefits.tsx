import React, { useState } from 'react'
import {
  IconClockHour10,
  IconDeviceLaptop,
  IconShieldCheckered,
  IconMoodDollar,
  IconUserBolt,
  IconCertificate,
  IconCake,
  IconPlaneDeparture,
  IconHomeBolt,
  IconGift,
  IconDeviceImacHeart,
  IconBrain,
  IconSunglasses,
  IconBowl,
  IconWifi,
  IconTicket,
} from '@tabler/icons-react'
//@ts-ignore
import { t, useLanguage } from '@joyit/layout'
import { Button } from '@/components/ui/button'
import useMediaQuery from '@/hooks/useMediaQuery'
import {
  FieldErrors,
  UseFormSetValue,
  UseFormTrigger,
  UseFormWatch,
} from 'react-hook-form'
import { JobFormSchema } from '@/company/validations/jobFormSchema'
import { useBenefits } from '@/hooks/service-hooks'

interface BenefitsProps {
  errors: FieldErrors<JobFormSchema>
  setValue: UseFormSetValue<JobFormSchema>
  watch: UseFormWatch<JobFormSchema>
  trigger: UseFormTrigger<JobFormSchema>
}

const Benefits = ({ errors, setValue, watch, trigger }: BenefitsProps) => {
  const { language } = useLanguage()
  const isDesktop = useMediaQuery('(min-width: 768px)')
  const { dataBenefits: listBenefits, lengthBenefits } = useBenefits()

  const [showAllBenefits, setShowAllBenefits] = useState(false)

  const benefits = watch('benefits')

  const toggleBenefit = (benefit) => {
    const exists = benefits.some((item) => item.value === benefit.id)

    const updatedBenefits = exists
      ? benefits.filter((item) => item.value !== benefit.id)
      : [...benefits, { value: benefit.id, label: benefit.title }]
    setValue('benefits', updatedBenefits)
    trigger('benefits')
  }

  const displayedBenefits = showAllBenefits
    ? listBenefits
    : listBenefits.slice(0, 8)

  return (
    <div className="flex flex-col xs:gap-2 sm:gap-3">
      <h3 className="font-semibold xs:text-sm sm:text-base whitespace-nowrap">
        {`${t('features.benefit')} *`}
      </h3>
      {isDesktop ? (
        <div className="grid sm:grid-cols-3 lg:grid-cols-4 xs:gap-2 sm:gap-4">
          {displayedBenefits.map((benefit, index) => (
            <button
              key={`benefit-${index}`}
              type="button"
              className={`w-full py-2 px-4 rounded-[25px] flex items-start space-x-2 text-left transition-colors duration-200 ${
                benefits.some((item) => item.value === benefit.id)
                  ? 'bg-primary-50'
                  : 'bg-white border border-[#2636582B]'
              }`}
              onClick={() => toggleBenefit(benefit)}
            >
              <span>{benefit.icon}</span>
              <div className="dark:text-secondary-500">
                <h4 className="font-semibold">{benefit.title}</h4>
                <p className="text-xs">{benefit.description}</p>
              </div>
            </button>
          ))}
        </div>
      ) : (
        <div className="flex flex-wrap gap-2">
          {displayedBenefits.map((benefit, index) => (
            <button
              key={`benefit-${index}`}
              type="button"
              className={`px-2 py-1 h-[28px] flex items-center rounded-[25px] dark:text-secondary-500 border-[#2636582B] ${
                benefits.some((item) => item.value === benefit.id)
                  ? 'bg-primary-50'
                  : 'bg-white border border-[#2636582B]'
              }`}
              onClick={() => toggleBenefit(benefit)}
            >
              <label className="text-xs text-start">{benefit.title}</label>
            </button>
          ))}
        </div>
      )}
      <div className="items-start flex flex-col gap-1">
        {!showAllBenefits && lengthBenefits > 8 && (
          <Button
            variant="tertiary"
            size={isDesktop ? 'lg' : 'sm'}
            className="underline w-auto px-0"
            onClick={() => setShowAllBenefits(true)}
          >
            {t('features.seeMore')}
          </Button>
        )}
        {errors?.benefits && (
          <span className="text-xs text-destructive-500">
            {errors.benefits.message}
          </span>
        )}
      </div>
    </div>
  )
}
export default Benefits
