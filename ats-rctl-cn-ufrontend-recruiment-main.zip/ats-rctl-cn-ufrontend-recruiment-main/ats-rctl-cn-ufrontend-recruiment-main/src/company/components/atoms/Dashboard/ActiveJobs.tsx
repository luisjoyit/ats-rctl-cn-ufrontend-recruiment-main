import React from 'react'
import {
  IconSpeakerphone,
  IconUserPlus,
  IconCalendarEvent,
  IconBriefcase,
} from '@tabler/icons-react'
//@ts-ignore
import { t, useLanguage } from '@joyit/layout'

const jobStats = [
  {
    count: 12,
    labelKey: 'activeJobs.jobs',
    timeFrameKey: 'activeJobs.today',
    icon: (
      <IconSpeakerphone
        stroke={2}
        className="text-secondary-500 dark:text-white"
      />
    ),
    borderColor: 'border-b-4 border-[#A7F1C0]',
  },
  {
    count: 146,
    labelKey: 'activeJobs.applicants',
    timeFrameKey: 'activeJobs.today',
    icon: (
      <IconUserPlus stroke={2} className="text-secondary-500 dark:text-white" />
    ),
    borderColor: 'border-b-4 border-[#A9A7F1]',
  },
  {
    count: 3,
    labelKey: 'activeJobs.interviews',
    timeFrameKey: 'activeJobs.thisWeek',
    icon: (
      <IconCalendarEvent
        stroke={2}
        className="text-secondary-500 dark:text-white"
      />
    ),
    borderColor: 'border-b-4 border-[#F1CAA7]',
  },
  {
    count: 2,
    labelKey: 'activeJobs.positionsToFill',
    timeFrameKey: 'activeJobs.processes',
    icon: (
      <IconBriefcase
        stroke={2}
        className="text-secondary-500 dark:text-white"
      />
    ),
    borderColor: 'border-b-4 border-[#F1A7EA]',
  },
]

const ActiveJobs = () => {
  const { handleChangeLanguage } = useLanguage()
  return (
    <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-4 font-inter">
      {jobStats.map((stat, index) => (
        <div
          key={index}
          className={`xs:p-3 sm:px-6 sm:py-4 bg-card rounded-[20px] shadow-cards flex flex-col ${stat.borderColor}`}
        >
          <div className="flex items-center mb-2 text-secondary-500 dark:text-white">
            <div>{stat.icon}</div>
            <div className="ml-2 text-xl font-semibold">{stat.count}</div>
          </div>
          <div className="flex flex-col">
            <p className="">{t(stat.labelKey)}</p>
            <span className="text-sm text-muted-500">
              {t(stat.timeFrameKey)}
            </span>
          </div>
        </div>
      ))}
    </div>
  )
}

export default ActiveJobs
