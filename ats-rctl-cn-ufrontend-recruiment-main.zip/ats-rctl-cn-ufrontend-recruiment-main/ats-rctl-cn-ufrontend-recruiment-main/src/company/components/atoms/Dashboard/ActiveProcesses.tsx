import React from 'react'
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts'
//@ts-ignore
import { t, useLanguage } from '@joyit/layout'

const data = [
  { name: '0', value1: 0, value2: 0, value3: 0, value4: 0 },
  { name: '1', value1: 20, value2: 15, value3: 13, value4: 17 },
  { name: '2', value1: 40, value2: 30, value3: 24, value4: 30 },
  { name: '3', value1: 58, value2: 55, value3: 50, value4: 39 },
]

const ActiveProcesses = () => {
  const { handleChangeLanguage } = useLanguage()
  return (
    <div className="bg-card rounded-[20px] shadow-cards xs:p-3 sm:px-6 sm:py-4">
      <h2 className="font-semibold text-secondary-500 dark:text-white mb-4">
        {t('activeProcesses.processes')}
      </h2>
      <ResponsiveContainer width="100%" height={180}>
        <AreaChart
          data={data}
          margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
        >
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="name" />
          <YAxis />
          <Tooltip />
          <Area
            type="monotone"
            dataKey="value1"
            stroke="#8884d8"
            fill="#8884d8"
            fillOpacity={0.3}
          />
          <Area
            type="monotone"
            dataKey="value2"
            stroke="#82ca9d"
            fill="#82ca9d"
            fillOpacity={0.3}
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  )
}

export default ActiveProcesses
