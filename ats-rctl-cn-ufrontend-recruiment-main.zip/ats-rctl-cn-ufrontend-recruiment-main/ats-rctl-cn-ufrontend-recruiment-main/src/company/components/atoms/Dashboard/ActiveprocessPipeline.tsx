import React from 'react'
//@ts-ignore
import { t, useLanguage } from '@joyit/layout'
import { useNavigate } from 'react-router-dom'
import { Checkbox } from '@/components/ui/checkbox'

const ProcessStep = ({ label, count, color }) => (
  <span
    className={`px-5 py-2 rounded-xl text-sm font-medium ${color} text-secondary-500`}
  >
    {label}: {count}
  </span>
)

const ProcessRow = ({
  id,
  position,
  department,
  steps,
  salary,
  status,
  publicationDate,
  index,
  length,
}) => {
  const navigate = useNavigate()

  const handleProcessClick = () => {
    navigate(`/company/myProcesses/${id}/stages`)
  }

  return (
    <tr
      className={`border-gray-200 ${index !== length - 1 && 'border-b'} hover:bg-gray-50`}
    >
      <td className="p-4">
        <Checkbox className="dark:border-white" />
      </td>
      <td className="p-4">
        <div
          className="flex flex-col cursor-pointer"
          tabIndex={0}
          role="button"
          onClick={handleProcessClick}
        >
          <span className="font-medium dark:text-primary-foreground">
            {position}
          </span>
          <span className="text-sm text-[#ABBFC1]">{department}</span>
        </div>
      </td>
      <td className="p-4">
        <div className="flex flex-wrap gap-2">
          {steps.map((step, index) => (
            <ProcessStep key={index} {...step} />
          ))}
        </div>
      </td>
      <td className="p-4">{salary}</td>
      <td className="p-4">{status}</td>
      <td className="p-4">{publicationDate}</td>
    </tr>
  )
}

const ActiveProcessesPipeline = () => {
  const { handleChangeLanguage } = useLanguage()
  const processes = [
    {
      id: '001',
      position: 'Frontend Developer',
      department: 'Software Development',
      steps: [
        { label: 'Postulantes', count: 68, color: 'bg-[#D9F9E4]' },
        { label: 'Evaluaciones', count: 36, color: 'bg-[#DAD9F9]' },
        { label: 'Entrevista', count: 24, color: 'bg-[#F9E8D9]' },
        //{ label: 'Oferta', count: 2, color: 'bg-[#F9D9F6]' },
      ],
      salary: '$2,500',
      status: 'Activo',
      publicationDate: '04 Jul 2024',
    },
    {
      id: '002',
      position: 'Frontend Developer',
      department: 'Software Development',
      steps: [
        { label: 'Postulantes', count: 68, color: 'bg-[#D9F9E4]' },
        { label: 'Evaluaciones', count: 36, color: 'bg-[#DAD9F9]' },
        { label: 'Entrevista', count: 24, color: 'bg-[#F9E8D9]' },
        //{ label: 'Oferta', count: 2, color: 'bg-[#F9D9F6]' },
      ],
      salary: '$2,500',
      status: 'Activo',
      publicationDate: '04 Jul 2024',
    },
    {
      id: '003',
      position: 'Frontend Developer',
      department: 'Software Development',
      steps: [
        { label: 'Postulantes', count: 68, color: 'bg-[#D9F9E4]' },
        { label: 'Evaluaciones', count: 36, color: 'bg-[#DAD9F9]' },
        { label: 'Entrevista', count: 24, color: 'bg-[#F9E8D9]' },
        //{ label: 'Oferta', count: 2, color: 'bg-[#F9D9F6]' },
      ],
      salary: '$2,500',
      status: 'Activo',
      publicationDate: '04 Jul 2024',
    },
    {
      id: '004',
      position: 'Frontend Developer',
      department: 'Software Development',
      steps: [
        { label: 'Postulantes', count: 68, color: 'bg-[#D9F9E4]' },
        { label: 'Evaluaciones', count: 36, color: 'bg-[#DAD9F9]' },
        { label: 'Entrevista', count: 24, color: 'bg-[#F9E8D9]' },
        //{ label: 'Oferta', count: 2, color: 'bg-[#F9D9F6]' },
      ],
      salary: '$2,500',
      status: 'Activo',
      publicationDate: '04 Jul 2024',
    },
    {
      id: '005',
      position: 'Frontend Developer',
      department: 'Software Development',
      steps: [
        { label: 'Postulantes', count: 68, color: 'bg-[#D9F9E4]' },
        { label: 'Evaluaciones', count: 36, color: 'bg-[#DAD9F9]' },
        { label: 'Entrevista', count: 24, color: 'bg-[#F9E8D9]' },
        //{ label: 'Oferta', count: 2, color: 'bg-[#F9D9F6]' },
      ],
      salary: '$2,500',
      status: 'Activo',
      publicationDate: '04 Jul 2024',
    },
  ]

  return (
    <div className="bg-card rounded-[20px] shadow-cards xs:p-3 sm:px-6 sm:py-4 flex flex-col gap-4">
      <table className="w-full">
        <thead>
          <tr className="text-left text-[#5D7B7E] text-sm">
            <th className="p-4 text-left">
              <Checkbox className="dark:border-white" />
            </th>
            <th className="p-4 text-left">Perfil</th>
            <th className="p-4 text-left">Proceso</th>
            <th className="p-4 text-left">Salario</th>
            <th className="p-4 text-left">Status</th>
            <th className="p-4 text-left">Fecha de publicación</th>
          </tr>
        </thead>
        <tbody>
          {processes.map((process, index) => (
            <ProcessRow
              key={process.id}
              index={index}
              length={processes.length}
              {...process}
            />
          ))}
        </tbody>
      </table>
    </div>
  )
}

export default ActiveProcessesPipeline
