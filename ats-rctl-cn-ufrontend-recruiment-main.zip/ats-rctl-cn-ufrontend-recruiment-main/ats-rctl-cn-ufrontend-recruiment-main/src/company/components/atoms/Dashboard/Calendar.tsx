import React, { useState } from 'react'
//@ts-ignore
import { t, useLanguage } from '@joyit/layout'
import { IconChevronLeft, IconChevronRight } from '@tabler/icons-react'

const Calendar = () => {
  const weekDays = ['LUN', 'MAR', 'MIE', 'JUE', 'VIER', 'SAB', 'DOM']
  const currentDate = new Date()
  const daysInMonth = new Date(
    currentDate.getFullYear(),
    currentDate.getMonth() + 1,
    0,
  ).getDate()

  const initialWeek = Array.from({ length: 7 }, (_, index) =>
    (index + 1).toString(),
  )
  const [currentWeek, setCurrentWeek] = useState(initialWeek)

  const nextWeek = () => {
    const nextWeekDates = currentWeek.map((date) => {
      let nextDate = parseInt(date) + 1
      if (nextDate > daysInMonth) {
        nextDate = 1
      }
      return nextDate.toString()
    })
    setCurrentWeek(nextWeekDates)
  }

  const prevWeek = () => {
    const prevWeekDates = currentWeek.map((date) => {
      let prevDate = parseInt(date) - 1
      if (prevDate < 1) {
        prevDate = daysInMonth
      }
      return prevDate.toString()
    })
    setCurrentWeek(prevWeekDates)
  }

  const events = [
    {
      date: '25',
      month: 'MAR',
      title: 'Frontend Developer',
      description: 'Etapa 2 entrevista - grupal',
      time: '11am - 12pm',
    },
    {
      date: '25',
      month: 'MAR',
      title: 'Frontend Developer',
      description: 'Etapa 2 entrevista - grupal',
      time: '11am - 12pm',
    },
    {
      date: '25',
      month: 'MAR',
      title: 'Frontend Developer',
      description: 'Etapa 2 entrevista - grupal',
      time: '11am - 12pm',
    },
  ]

  return (
    <div className="bg-card rounded-[20px] shadow-cards xs:p-3 sm:px-6 sm:py-4 text-secondary-500 dark:text-white">
      <div className="flex justify-between items-center mb-4">
        <h2 className="font-semibold">{t('calendar.calendario')}</h2>
        <button className="text-sm">{t('calendar.viewAll')}</button>
      </div>

      <div className="flex justify-between items-center mb-4">
        <IconChevronLeft
          stroke={2}
          className="text-secondary-500 dark:text-white cursor-pointer"
          onClick={prevWeek}
        />
        <span className="font-semibold text-sm">{`${
          currentWeek[0]
        } de ${currentDate.toLocaleString('default', { month: 'long' })} - ${
          currentWeek[currentWeek.length - 1]
        } de ${currentDate.toLocaleString('default', {
          month: 'long',
        })}`}</span>
        <IconChevronRight
          stroke={2}
          className="text-secondary-500 dark:text-white cursor-pointer"
          onClick={nextWeek}
        />
      </div>

      <div className="grid grid-cols-7 gap-2 mb-4">
        {weekDays.map((day, index) => (
          <div
            key={index}
            className={`text-center text-sm ${
              index === 0
                ? 'font-semibold text-secondary-500 dark:text-white'
                : 'text-muted-500'
            }`}
          >
            {day}
          </div>
        ))}
        {currentWeek.map((date, index) => (
          <div
            key={index}
            className={`text-center ${
              index === 0
                ? 'font-semibold text-secondary-500 dark:text-white'
                : 'text-muted-500'
            }`}
          >
            {date}
          </div>
        ))}
      </div>

      <hr className="mb-4" />

      <div className="space-y-4">
        {events.map((event, index) => (
          <div key={index} className="flex items-start gap-4">
            <div className="bg-secondary-50 rounded-[10px] w-[56px] h-[56px] flex flex-col items-center justify-center">
              <div className="font-semibold text-seconday-500 dark:text-white">
                {event.date}
              </div>
              <div className="text-xs text-gray-500">{event.month}</div>
            </div>
            <div className="text-seconday-500 dark:text-white">
              <h3 className="font-semibold">{event.title}</h3>
              <p className="text-xs">
                {event.description}{' '}
                <span className="font-semibold">- grupal</span>
              </p>
              <p className="text-xs text-gray-500">{event.time}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

export default Calendar
