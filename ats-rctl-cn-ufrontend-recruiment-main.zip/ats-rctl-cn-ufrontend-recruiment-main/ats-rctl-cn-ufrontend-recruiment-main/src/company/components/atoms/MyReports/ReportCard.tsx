import React from 'react'
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts'
//@ts-ignore
import { t, useLanguage } from '@joyit/layout'

const data = {
  daily: [
    { name: '0', uv: 0 },
    { name: '1', uv: 35 },
    { name: '2', uv: 70 },
    { name: '3', uv: 105 },
    { name: '4', uv: 140 },
  ],
  biweekly: [
    { name: '0', uv: 10 },
    { name: '1', uv: 45 },
    { name: '2', uv: 80 },
    { name: '3', uv: 115 },
    { name: '4', uv: 150 },
  ],
  monthly: [
    { name: '0', uv: 20 },
    { name: '1', uv: 55 },
    { name: '2', uv: 90 },
    { name: '3', uv: 125 },
    { name: '4', uv: 160 },
  ],
  annual: [
    { name: '0', uv: 30 },
    { name: '1', uv: 65 },
    { name: '2', uv: 100 },
    { name: '3', uv: 135 },
    { name: '4', uv: 170 },
  ],
}

export default function ReportCard({
  title,
  count,
  percentage,
  time,
  interval,
}) {
  const { handleChangeLanguage } = useLanguage()
  return (
    <div className="bg-card rounded-[30px] shadow-md p-6 xs:w-full md:w-80 flex-shrink-0 flex flex-col gap-1">
      <div className="text-sm text-secondary-500 dark:text-white">
        {t('myReports.requests')}
      </div>
      <div className="flex justify-between items-start">
        <div className="flex flex-col gap-1 font-bold">
          <div className="text-xl text-secondary-500 dark:text-white">
            {title}
          </div>
          <div className="text-2xl text-[#007A91] ">{count}</div>
        </div>
        <div className="text-right">
          <div className="text-[#00C851] font-medium text-sm">{percentage}</div>
          <div className="text-2xl font-bold text-[#9A9A9A]">26</div>
          <div className="text-secondary-500 dark:text-white text-xs">
            {time}
          </div>
        </div>
      </div>
      <div className="h-24 pt-3">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data[interval]}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="name" hide />
            <YAxis hide />
            <Tooltip />
            <Line
              type="monotone"
              dataKey="uv"
              stroke="#4A90E2"
              strokeWidth={2}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  )
}
