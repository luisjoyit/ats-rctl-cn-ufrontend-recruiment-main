import React, { useState } from 'react'
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts'
import { IconCalendarClock } from '@tabler/icons-react'
//@ts-ignore
import { t, useLanguage } from '@joyit/layout'
import {
  Select,
  SelectTrigger,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectValue,
} from '@/components/ui/select'
import useMediaQuery from '@/hooks/useMediaQuery'
import SelectUi from '@/components/SelectUi'

const data = [
  { name: '0', value: 200 },
  { name: '1', value: 200 },
  { name: '2', value: 800 },
  { name: '3', value: 500 },
  { name: '4', value: 400 },
  { name: '5', value: 900 },
  { name: '6', value: 900 },
  { name: '7', value: 400 },
  { name: '8', value: 300 },
  { name: '9', value: 600 },
]

const GraphicalReport = () => {
  const [selectedType, setSelectedType] = useState('new')
  const [selectedInterval, setSelectedInterval] = useState('daily')

  const isMobile = useMediaQuery('(max-width: 768px)')
  const { handleChangeLanguage } = useLanguage()

  const changeSelectInterval = (name, value) => {
    setSelectedInterval(value)
  }

  const reportTypes = [
    {
      id: 'new',
      name: t('myReports.newRequests'),
      shortName: t('myReports.new'),
    },
    {
      id: 'processed',
      name: t('myReports.processedRequests'),
      shortName: t('myReports.inProgress'),
    },
    {
      id: 'rejected',
      name: t('myReports.rejectedRequests'),
      shortName: t('myReports.rejected'),
    },
    {
      id: 'interview',
      name: t('myReports.interviewsHeld'),
      shortName: t('myReports.interviews'),
    },
  ]

  //const intervalTypes = ['daily', 'biweekly', 'monthly', 'annual']
  const intervalTypes = [
    {
      value: 'daily',
      label: t('myReports.daily'),
    },
    {
      value: 'biweekly',
      label: t('myReports.biweekly'),
    },
    {
      value: 'monthly',
      label: t('myReports.monthly'),
    },
    {
      value: 'annual',
      label: t('myReports.annual'),
    },
  ]

  return (
    <div className="bg-card xs:px-2 xs:py-4 md:px-6 md:py-8 rounded-[30px] shadow-cards gap-8 flex flex-col">
      <div className="flex xs:flex-col md:flex-row xs:px-4 md:pl-4 justify-between gap-3">
        <div className="flex flex-col gap-2">
          <span className="xs:flex md:hidden text-md font-semibold text-secondary dark:text-white">
            {t('myReports.requests')}
          </span>
          <div className="w-auto shadow-cards rounded-md flex justify-between">
            {reportTypes.map((type, index) => (
              <button
                key={index}
                className={`xs:p-2 md:px-4 md:py-2 xs:text-xs md:text-sm rounded-md focus:outline-none transition-colors duration-200 ${
                  selectedType === type.id
                    ? 'bg-secondary text-white'
                    : 'text-secondary hover:bg-gray-100 truncate'
                }`}
                onClick={() => setSelectedType(type.id)}
              >
                {isMobile ? type.shortName : type.name}
              </button>
            ))}
          </div>
        </div>
        <div className="flex justify-end">
          <SelectUi
            name="category"
            value={selectedInterval}
            items={intervalTypes}
            onChange={changeSelectInterval}
            placeholder="Periodo"
            icon={<IconCalendarClock stroke={2} size={16} />}
            className={`xs:w-[120px] md:w-[140px] justify-between shadow-cards ${isMobile && 'text-xs'}`}
          />
        </div>
      </div>
      <div className="h-80">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={data}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            <Area
              type="monotone"
              dataKey="value"
              stroke="#8884d8"
              fill="#8884d8"
              fillOpacity={0.3}
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  )
}

export default GraphicalReport
