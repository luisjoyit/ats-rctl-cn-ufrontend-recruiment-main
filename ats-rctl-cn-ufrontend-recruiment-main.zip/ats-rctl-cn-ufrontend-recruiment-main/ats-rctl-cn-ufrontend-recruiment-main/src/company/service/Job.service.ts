import { graphql } from '@/gql'

class JobServiceCompany {
  createJob() {
    const createJobApplications = graphql(`
      mutation CreateJob($job: JobInput) {
        CreateJob(job: $job)
      }
    `)
    return createJobApplications
  }
}
export default new JobServiceCompany()
