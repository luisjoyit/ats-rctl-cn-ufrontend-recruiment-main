import { z } from 'zod'

const questionSchema = z
  .object({
    id: z.number(),
    titleQuestion: z.string().min(8, 'La pregunta es obligatoria'),
    typeAnswer: z.enum(['MULTIPLE_CHOICE', 'SHORT_ANSWER']),
    answers: z
      .array(z.string().min(4, 'La opción debe tener al menos 4 caracteres'))
      .optional(),
  })
  .refine(
    (data) => {
      if (data.typeAnswer === 'SHORT_ANSWER') {
        return !data.answers || data.answers.length === 0
      } else if (data.typeAnswer === 'MULTIPLE_CHOICE') {
        return data.answers && data.answers.length > 1
      }
      return true
    },
    {
      message: 'Para preguntas de este tipo debe haber más de una opción',
    },
  )

export const jobFormSchema = z
  .object({
    jobName: z.string().min(5, 'El nombre de empleo es requerido'),
    levelExperience: z.object({
      value: z.string().min(1, 'El nivel de experiencia es requerido'),
      label: z.string().optional(),
    }),
    nameProfile: z.object({
      value: z.string().min(1, 'Perfil del empleo es requerido'),
      label: z.string().optional(),
    }),
    availablePositions: z
      .number()
      .min(1, 'Debe tener al menos un puesto disponible'),
    modality: z.object({
      value: z.string().min(1, 'La modalidad de trabajo es requerida'),
      label: z.string().optional(),
    }),
    workSchedule: z.object({
      value: z.string().min(1, 'El horario de trabajo es requerido'),
      label: z.string().optional(),
    }),
    countryCity: z.object({
      value: z.string().min(1, 'Ingrese Ciudad/País'),
      label: z.string().optional(),
    }),
    language: z.object({
      value: z.string().min(1, 'Seleccione un idioma'),
      label: z.string().optional(),
    }),
    levelLanguage: z.object({
      value: z.string().optional(),
      label: z.string().optional(),
    }),
    rangeSalarity: z
      .array(z.number().min(0, 'El salario debe ser mayor a 0'))
      .length(2)
      .optional(),
    fixedSalary: z.boolean().optional(),
    fixedSalaryAmount: z
      .number()
      .nullable()
      .refine((value) => value !== null && value > 0, {
        message: 'Debe ingresar el monto del salario fijo mayor a 0',
      })
      .optional(),
    adHonorem: z.boolean().optional(),
    stackTech: z
      .array(
        z.object({
          value: z
            .string()
            .min(1, 'El campo value debe tener al menos 1 carácter'),
          label: z.string().optional(),
        }),
      )
      .min(1, 'Debe tener al menos un objeto en el array'),
    jobDescription: z
      .string()
      .min(15, 'La descripción del trabajo es requerida y detallada'),
    jobResponsabilities: z
      .string()
      .min(15, 'Las funciones del trabajo son requeridas.'),
    jobAdditional: z
      .string()
      .nullable()
      .optional()
      .refine((value) => !value || value.length >= 10, {
        message: 'Detallar requisitos adicionales',
      }),
    benefits: z
      .array(
        z.object({
          value: z
            .string()
            .min(1, 'El campo value debe tener al menos 1 carácter'),
          label: z.string().optional(),
        }),
      )
      .min(1, 'Debe tener al menos un objeto en el array'),
    showCompanyName: z.boolean(),
    onlyVerifiedProfiles: z.boolean(),
    questions: z.array(questionSchema).optional(),
  })
  .refine(
    (data) => {
      if (data.fixedSalary) {
        return data.fixedSalaryAmount !== null && data.fixedSalaryAmount > 0
      }
      if (!data.fixedSalary && !data.adHonorem) {
        return (
          data.rangeSalarity !== undefined &&
          data.rangeSalarity.length === 2 &&
          data.rangeSalarity[0] < data.rangeSalarity[1]
        )
      }
      return true
    },
    {
      message: 'Ingrese las condiciones salariales',
      path: ['rangeSalarity'],
    },
  )
  .refine(
    (data) => {
      if (data.language.value !== 'notRelevant') {
        return data.levelLanguage.value.length > 1
      }
      return true
    },
    {
      message: 'Seleccione el nivel del idioma',
      path: ['levelLanguage'],
    },
  )

export type JobFormSchema = z.infer<typeof jobFormSchema>
