import { z } from 'zod'

const questionSchema = z
  .object({
    id: z.number(),
    titleQuestion: z.string().min(8, 'La pregunta es obligatoria'),
    typeAnswer: z.enum(['short', 'several']),
    answers: z
      .array(z.string().min(4, 'La opción debe tener al menos 4 caracteres'))
      .optional(),
  })
  .refine(
    (data) => {
      if (data.typeAnswer === 'short') {
        return !data.answers || data.answers.length === 0
      } else if (data.typeAnswer === 'several') {
        return data.answers && data.answers.length > 1
      }
      return true
    },
    {
      message: 'Para preguntas de este tipo debe haber más de una opción',
    },
  )

export const evaluationFormSchema = z.object({
  evaluationName: z.string().min(5, 'El nombre de la evaluación es requerida'),
  unitTime: z.string().min(1, 'Seleccione la unidad de tiempo'),
  valueTime: z.number().min(1, 'Indique la duración de la evaluación'),
  description: z.string().min(10, 'La descripción es requerida'),
  questions: z
    .array(questionSchema)
    .min(1, 'Se requiere como mínimo 1 preguntas'),
})

export type EvaluationFormSchema = z.infer<typeof evaluationFormSchema>
