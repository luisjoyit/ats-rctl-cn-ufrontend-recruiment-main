import type { WorkMode } from '@/gql/graphql'
import { useGraphQLMutation } from '@/hooks/userMutation'
import JobServiceCompany from '@/company/service/Job.service'
import { useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'

export function useJobsCompany() {
  const queryClient = useQueryClient()

  const {
    mutate: createJob,
    isPending,
    data,
    error,
    isError,
    isSuccess,
  } = useGraphQLMutation(JobServiceCompany.createJob(), {
    onSuccess: (data) => {
      // queryClient.invalidateQueries({
      //   queryKey: ['GetJobsFavoritesByUser', { userId: 1 }],
      // })
      toast.success('Se creo la oferta correctamente')
    },
    onError: (error) => {
      toast.error('Hubo un error al crear la oferta')
    },
  })

  return { createJob, isPending, data, error, isError, isSuccess }
}
