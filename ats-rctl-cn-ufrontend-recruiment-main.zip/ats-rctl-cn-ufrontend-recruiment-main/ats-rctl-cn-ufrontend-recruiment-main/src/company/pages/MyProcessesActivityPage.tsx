import MyProcessesActivity from '../components/templates/MyProcessesActivity'

export default function MyProcessesActivityPage() {
  return <MyProcessesActivity />
}
