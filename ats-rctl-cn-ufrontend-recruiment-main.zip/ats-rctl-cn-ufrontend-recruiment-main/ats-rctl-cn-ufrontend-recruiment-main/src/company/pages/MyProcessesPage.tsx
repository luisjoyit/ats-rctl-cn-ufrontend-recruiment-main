import React from 'react'
import MyProcesses from '../components/templates/MyProcesses'
export default function MyProcessesPage() {
  return <MyProcesses />
}
