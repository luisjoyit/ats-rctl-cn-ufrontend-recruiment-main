import HomeDemo from '../components/templates/HomeDemo'

export default function HomeDemoPage() {
  return <HomeDemo />
}
