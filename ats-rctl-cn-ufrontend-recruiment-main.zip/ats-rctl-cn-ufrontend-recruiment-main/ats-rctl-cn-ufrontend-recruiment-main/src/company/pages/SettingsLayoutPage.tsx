import React from 'react'
import SettingsLayout from '../components/templates/SettingsLayout'

export default function SettingsLayoutPage() {
  return <SettingsLayout />
}
