import MyProcessesInfo from '../components/templates/MyProcessesInfo'

export default function MyProcessesInfoPage() {
  return <MyProcessesInfo />
}
