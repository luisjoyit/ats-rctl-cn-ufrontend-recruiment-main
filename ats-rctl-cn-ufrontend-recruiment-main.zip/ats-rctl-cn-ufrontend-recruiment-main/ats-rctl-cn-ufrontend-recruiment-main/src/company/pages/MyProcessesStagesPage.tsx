import MyProcessesStages from '../components/templates/MyProcessesStages'

export default function MyProcessesStagesPage() {
  return <MyProcessesStages />
}
