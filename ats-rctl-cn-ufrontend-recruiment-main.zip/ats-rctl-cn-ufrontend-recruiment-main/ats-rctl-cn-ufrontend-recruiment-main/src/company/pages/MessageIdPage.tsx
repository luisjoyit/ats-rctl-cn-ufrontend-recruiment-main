import React from 'react'

export default function MessageIdPage() {
  return <div>MessageIdPage</div>
}
