import CreateJob from '../components/templates/CreateJob'

export default function CreateJobPage() {
  return <CreateJob />
}
