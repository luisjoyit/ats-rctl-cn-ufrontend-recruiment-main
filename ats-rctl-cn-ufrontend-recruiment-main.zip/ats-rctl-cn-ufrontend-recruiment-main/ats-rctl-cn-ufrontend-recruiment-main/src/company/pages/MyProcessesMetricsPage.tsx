import MyProcessesMetrics from '../components/templates/MyProcessesMetrics'

export default function MyProcessesMetricsPage() {
  return <MyProcessesMetrics />
}
