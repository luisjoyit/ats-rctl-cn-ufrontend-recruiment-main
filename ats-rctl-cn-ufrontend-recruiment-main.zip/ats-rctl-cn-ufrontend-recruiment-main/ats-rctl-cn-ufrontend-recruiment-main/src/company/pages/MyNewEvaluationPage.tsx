import MyNewEvaluation from '../components/templates/MyNewEvaluation'

export default function MyNewEvaluationPage() {
  return <MyNewEvaluation />
}
