import FaqSeeTicket from '../components/templates/FaqSeeTicket'

export default function FaqSeeTicketPage() {
  return <FaqSeeTicket />
}
