import React from 'react'
import MyEvaluations from '../components/templates/MyEvaluations'

export default function MyEvaluationsPage() {
  return <MyEvaluations />
}
