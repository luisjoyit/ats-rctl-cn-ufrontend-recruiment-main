import MyReports from '../components/templates/MyReports'

export default function MyReportsPage() {
  return <MyReports />
}
