import MyCompany from '../components/templates/MyCompany'

export default function MyCompanyPage() {
  return <MyCompany />
}
