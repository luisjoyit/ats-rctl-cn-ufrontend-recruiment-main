import Dashboard from '../components/templates/CompanyDashboard'

export default function CompanyDashboardPage() {
  return <Dashboard />
}
