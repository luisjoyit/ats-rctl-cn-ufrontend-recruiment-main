import React from 'react'

export default function MessageDetailPage() {
  return <div>MessageDetailPage</div>
}
