import Messages from '../components/templates/Messages'

export default function MessagesPage() {
  return <Messages />
}
