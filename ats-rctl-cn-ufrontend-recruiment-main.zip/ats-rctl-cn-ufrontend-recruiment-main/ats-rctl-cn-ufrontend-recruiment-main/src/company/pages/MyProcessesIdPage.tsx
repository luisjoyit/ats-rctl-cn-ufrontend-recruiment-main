import MyProcessesId from '../components/templates/MyProcessesId'

export default function MyProcessesIdPage() {
  return <MyProcessesId />
}
