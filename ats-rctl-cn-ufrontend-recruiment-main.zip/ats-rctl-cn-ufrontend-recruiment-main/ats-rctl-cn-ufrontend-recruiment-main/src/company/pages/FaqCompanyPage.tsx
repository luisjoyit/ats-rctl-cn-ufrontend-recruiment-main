import FaqCompany from '../components/templates/FaqCompany'

export default function FaqCompanyPage() {
  return <FaqCompany />
}
