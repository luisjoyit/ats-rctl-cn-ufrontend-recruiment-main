export type Id = string | number

export type Stage = {
  id: Id
  name: string
  color: string
}

export type Card = {
  id: Id
  stageId: Id
  name: string
  position: string
  salary: number
  imgProfile: string
  countryImg: string
  recent: boolean
}
