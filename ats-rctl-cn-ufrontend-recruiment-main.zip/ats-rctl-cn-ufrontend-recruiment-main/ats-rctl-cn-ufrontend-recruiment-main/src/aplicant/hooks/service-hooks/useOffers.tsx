import { jobsService } from '@/aplicant/service'
import type { WorkMode } from '@/gql/graphql'
import { useGraphQL } from '@/hooks/useGraphQery'

interface IUseOffers {
  page?: number
  size?: number
  countryId?: number
  levelOfExperienceId?: number
  minSalary?: number
  maxSalary?: number
  profileTypeId?: number
  technologyStack?: string[]
  workmode?: WorkMode
}

export function useJobs({
  page,
  size = 10,
  countryId,
  levelOfExperienceId,
  minSalary,
  maxSalary,
  profileTypeId,
  technologyStack,
  workmode,
}: IUseOffers) {
  const { data, isLoading, error } = useGraphQL(jobsService.getAllJobs(), {
    page,
    size,
    countryId,
    levelOfExperienceId,
    minSalary,
    maxSalary,
    profileTypeId,
    technologyStack,
    workmode,
  })

  if (!data?.GetAllJobsFilter)
    return {
      currentPage: 0,
      elementPerPage: 0,
      totalItems: 0,
      totalPage: 0,
      jobs: [],
      isLoading,
      error,
    }

  const dataJobs = data.GetAllJobsFilter
  const jobs = dataJobs?.jobs || []

  const { currentPage, elementPerPage, totalItems, totalPage } = dataJobs

  return {
    jobs,
    currentPage,
    elementPerPage,
    totalItems,
    totalPage,
    isLoading,
    error,
  }
}

export function useJobsById(id: number) {
  const { data, isLoading, error } = useGraphQL(jobsService.getJobById(), {
    id,
  })
  const dataJob = data?.GetJobById || null

  return { dataJob, isLoading, error }
}
