import { Route, Routes } from 'react-router-dom'
import DashboardPage from './pages/DashboradPage'
import OfferIdPage from './pages/OfferIdPage'
import OffersPage from './pages/OffersPage'
import OfferDetailPage from './pages/OfferDetailPage'
import MyApplicationsPage from './pages/MyApplicationsPage'
import FavoritesPage from './pages/MyFavoritesPage'
import FaqPage from './pages/FaqPage'
import MyProfilePage from './pages/MyProfilePage'
import SettingsLayoutPage from './pages/SettingsLayoutPage'
import SettingOptionPage from './pages/SettingOptionPage'
import AccountOption from './components/organism/SectionsSettings/Account'
import VisibilityOption from './components/organism/SectionsSettings/Visibility'
import NotificationsOption from './components/organism/SectionsSettings/Notifications'
import FaqNamePage from './pages/FaqNamePage'
import MyEvaluations from './components/templates/MyEvaluations'
import NotificationsPage from './pages/NotificationsPage'
import MyFavoritesDetailPage from './pages/MyFavoritesDetailPage'
import MyFavoritePage from './pages/MyFavoritePage'
import MyEvaluationIdPage from './pages/MyEvaluationIdPage'
import MyEvaluationsFaqIdPage from './pages/MyEvaluationsFaqIdPage'
import MyEvaluationsEndPage from './pages/MyEvaluationsEndPage'
import NewFaqPage from './pages/NewFaqPage'
import ProccesDetailsPage from './pages/ProccesDetailsPage'
import MyPortfolioPage from './pages/MyPortfolioPage'
import InterviewCalendar from './components/templates/InterviewCalendar'
import MyCurriculumPage from './pages/MyCurriculumPage'
import MyEmploymentPage from './pages/MyEmploymentPage'
import FaqTicketPage from './pages/FaqTicketPage'
import FaqUpdatePage from './pages/FaqUpdatePage'
import FaqAffairsPage from './pages/FaqAffairsPage'
import { ProtectedLayout } from '@/protected-route'

//@ts-ignore
import { protectedRouteLoader } from '@joyit/user-management'

export default function ApplicantPage(props) {
  return (
    <Routes>
      {/* <Route path="/recruitment" element={<AllIssues />} /> */}
      <Route path="offers" element={<OffersPage />} />
      <Route path="offers/:offerId" element={<OfferIdPage />}>
        <Route index element={<OfferDetailPage />} />
      </Route>

      <Route element={<ProtectedLayout roles={['applicant']} />}>
        <Route path="dashboard" element={<DashboardPage />} />
        <Route path="candidate/applications" element={<MyApplicationsPage />} />
        <Route
          path="candidate/applications/details"
          element={<ProccesDetailsPage />}
        />
        <Route
          path="candidate/applications/calendarInterviews"
          element={<InterviewCalendar />}
        />
        <Route path="candidate/favorites" element={<MyFavoritePage />} />
        <Route path="candidate/favorites/:offerId" element={<FavoritesPage />}>
          <Route index element={<MyFavoritesDetailPage />} />
        </Route>

        <Route
          path="offers/:offerId/detail"
          element={<MyEmploymentPage />}
        ></Route>

        <Route path="candidate/myProfile" element={<MyProfilePage />} />
        <Route
          path="candidate/myProfile/myPortfolio"
          element={<MyPortfolioPage />}
        />
        <Route path="candidate/myProfile/cv" element={<MyCurriculumPage />} />
        <Route path="settings" element={<SettingsLayoutPage />}>
          <Route index element={<SettingOptionPage />} />
          <Route path="cuenta" element={<AccountOption />} />
          <Route path="notificaciones" element={<NotificationsOption />} />
          <Route path="visibilidad" element={<VisibilityOption />} />
        </Route>
        <Route path="candidate/myEvaluations" element={<MyEvaluations />} />
        <Route
          path="candidate/myEvaluations/:evaluationId"
          element={<MyEvaluationIdPage />}
        />
        <Route
          path="candidate/myEvaluations/:evaluationId/:faqId"
          element={<MyEvaluationsFaqIdPage />}
        />
        <Route
          path="candidate/myEvaluations/:evaluationId/:faqId/end"
          element={<MyEvaluationsEndPage />}
        />
        <Route path="faq" element={<FaqPage />} />
        <Route path="faq/ticket" element={<FaqTicketPage />} />
        <Route path="faq/ticket/affairs" element={<FaqAffairsPage />} />
        <Route path="faq/ticket/update" element={<FaqUpdatePage />} />
        <Route path="faq/:categoryName" element={<FaqNamePage />} />
        <Route path="notifications" element={<NotificationsPage />} />
        <Route path="faq/newfaq" element={<NewFaqPage />} />
      </Route>
      <Route path="*" element={<div>Not Found</div>} />
    </Routes>
  )
}
