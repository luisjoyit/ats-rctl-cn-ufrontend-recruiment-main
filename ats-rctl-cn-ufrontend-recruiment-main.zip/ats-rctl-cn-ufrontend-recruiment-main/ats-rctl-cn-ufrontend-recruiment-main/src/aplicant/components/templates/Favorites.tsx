import {
  Outlet,
  useNavigate,
  useParams,
  useSearchParams,
} from 'react-router-dom'
import { useGraphQL } from '@/hooks/useGraphQery'
import {
  Card,
  CardContent,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { Pagination } from '@/components/ui/pagination'
import { useEffect, useState } from 'react'
import { Button } from '@/components/ui/button'
import svgPeru from '../../../static/svg/peru.svg'
// import {
//   getJobs,
//   getJobsFavorites,
//   toggleJobFavorite,
// } from '@/aplicant/service/jobs.service'
import { IconBolt, IconHeart } from '@tabler/icons-react'
//@ts-ignore
import { t, useLanguage } from '@joyit/layout'
import { cn } from '@/lib/utils'
import useFavoriteJobStore from '@/store/favoriteJobStore'
import { useGraphQLMutation } from '@/hooks/userMutation'
import { toast } from 'sonner'
import { useQueryClient } from '@tanstack/react-query'
import FiltersJobs from '../molecules/FiltersJobs'
import OfferIdLoading from '../atoms/Skeleton-Loading/Offers/offerId-loading'
// import { favoritesService } from '@/aplicant/service'
import InputWithIcon from '@/components/inputWithIcon'

function capitalizeAndJoin(input: string, separator: string): string {
  return input
    .split(separator)
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
    .join(' ')
}

const initialValuesFilters = {
  category: '',
  location: '',
  years_exp: '',
  modality: '',
  benefits: [],
  salary: [500, 2500],
  order: '',
}

export function Favorites(props) {
  const [dataFilters, setDataFilters] = useState(initialValuesFilters) //guarda todos los filtros
  const { handleChangeLanguage } = useLanguage()
  const navigate = useNavigate()
  const queryClient = useQueryClient()
  const { toggleHearth, toggleHearthHandler } = useFavoriteJobStore()
  const [searchParams, setSearchParams] = useSearchParams()
  // const createFavorite = favoritesService.createJobFavorite()
  // const deleteFavorite = favoritesService.deleteJobFavorite()

  // Manejo del estado para el uso del Drawer (Modal) en vista de celular
  const [open, setOpen] = useState(false)
  const currentPage = parseInt(searchParams.get('page') || '1', 10)
  // const allFavoritesOffers = favoritesService.getJobsFavorites()

  // const { data, isLoading } = useGraphQL(allFavoritesOffers, keycloak.token, {
  //   currentPage,
  //   elementPerPage: 6,
  //   userId: 1,
  //   level_exp_id: 0,
  //   modality_id: 0,
  //   newer: true,
  //   oldest: false,
  //   more_relevant: false,
  // })

  // const { mutate: deleteFavoriteJob } = useGraphQLMutation(
  //   deleteFavorite,
  //   keycloak.token,
  //   {
  //     onSuccess: (data) => {
  //       queryClient.invalidateQueries({
  //         queryKey: ['GetJobsFavoritesByUser', { userId: 1 }],
  //       })
  //       toast.success('Se Elimino de favoritos correctamente')
  //     },
  //     onError: (error) => {
  //       toast.error('Hubo un error al eliminar de favoritos')
  //     },
  //   },
  // )

  useEffect(() => {
    const data = localStorage.getItem('favorite-repos')
    if (data) {
      const parseData = JSON.parse(data)?.state
      toggleHearthHandler(parseData.toggleHearth)
    }
  }, [])

  const handleCardClick = (id) => {
    if (id !== null) {
      setOpen((prevDrawerOpen) => !prevDrawerOpen)
      const page = searchParams.get('page') || '1'
      navigate(`/applicants/candidate/favorites/${id}?page=${page}`)
    }
  }

  const handlePageChange = (page) => {
    setSearchParams({ page: page.toString() })
  }
  const handleCloseDrawer = () => {
    setOpen(false) // Establecer open como false cuando se cierra el drawer
  }

  function handleClick(id) {
    // deleteFavoriteJob({ job_id: id, user_id: 1 })
    alert('Se elimino de favoritos')
    toggleHearthHandler(id)
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="flex justify-end gap-4">
        <InputWithIcon
          placeholder="Buscar en mis favoritos"
          className="lg:w-[221px]"
        />
        <FiltersJobs
          itemsCategory={[]}
          itemsLocation={[]}
          itemsYearsExp={[]}
          itemsModality={[]}
          //itemsBenefits={[]}
          dataFilters={dataFilters}
          setDataFilters={setDataFilters}
          initialValuesFilters={initialValuesFilters}
        />
      </div>
      <div className="grid grid-cols-3">
        <div className="font-inter col-span-3 md:col-span-1 ">
          pagina de favoritos
        </div>
        <div className="col-span-3 md:col-span-2 md:ml-28">
          <Outlet context={{ open, handleCardClick, handleCloseDrawer }} />
        </div>
      </div>
    </div>
  )
}
