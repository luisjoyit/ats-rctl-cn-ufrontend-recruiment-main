import { Route, Routes } from 'react-router-dom'
import AccountOption from '../organism/SectionsSettings/Account'
import NotificationsOption from '../organism/SectionsSettings/Notifications'
import VisibilityOption from '../organism/SectionsSettings/Visibility'

export default function SettingsOption() {
  return (
    <div>
      <Routes>
        <Route path="/cuenta" element={<AccountOption />} />
        <Route path="/visibilidad" element={<VisibilityOption />} />
        <Route path="/notificaciones" element={<NotificationsOption />} />
      </Routes>
    </div>
  )
}
