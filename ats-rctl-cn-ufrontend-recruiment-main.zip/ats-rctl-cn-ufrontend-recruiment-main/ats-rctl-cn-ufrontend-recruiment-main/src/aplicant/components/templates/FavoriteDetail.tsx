import { useOutletContext, useParams } from 'react-router-dom'
import { useGraphQL } from '@/hooks/useGraphQery'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import {
  Drawer,
  DrawerClose,
  DrawerContent,
  DrawerDescription,
  DrawerFooter,
  DrawerHeader,
  DrawerTitle,
} from '@/components/ui/drawer'
import { Button } from '@/components/ui/button'
import svgPerson from '../../../static/svg/icons/icon_person.svg'
import svgPerson2 from '../../../static/svg/icons/icon_person2.svg'
import {
  IconArrowUpRight,
  IconCake,
  IconClockHour2,
  IconPlug,
  IconSchool,
} from '@tabler/icons-react'
import { jobsService } from '@/aplicant/service'

import { formatRelativeDate } from '@/helpers/formatDate'
import CardCulqi from '../molecules/CardCulqi'

//@ts-ignore
import { t, useLanguage } from '@joyit/layout'
import OfferDetailLoading from '../atoms/Skeleton-Loading/Offers/offerDetail-loading'
import { useJobsById } from '@/aplicant/hooks/service-hooks/useOffers'

interface OutletContextType {
  open: boolean
  handleCardClick: (id: string | null) => void
  handleCloseDrawer: () => void
}

function useMediaQuery(query: string): boolean {
  return window.matchMedia(query).matches
}

export function FavoriteDetail(props) {
  const { offerId } = useParams()
  const offerById = jobsService.getJobById()
  const { open, handleCardClick, handleCloseDrawer } =
    useOutletContext<OutletContextType>()
  const { dataJob, isLoading } = useJobsById(parseInt(offerId))
  // const { data, isLoading } = useGraphQL(offerById, {
  //   id: parseInt(offerId),
  // })

  const isDesktop = useMediaQuery('(min-width: 768px)')

  if (isLoading) {
    return (
      <div className="flex justify-center items-center">
        <OfferDetailLoading />
      </div>
    )
  }

  if (!dataJob) {
    return (
      <div className="flex justify-center items-center">
        <Card
          className="font-inter px-12 xs:mt-0 md:mt-8 flex min-w-full max-w-[706px] xs:h-full md:h-[820px] md:max-h-[889px] rounded-[11px]"
          style={!isDesktop ? { display: 'none' } : {}}
        >
          <div className="text-[#D2D2D2] text-[36px] flex items-center justify-center text-center">
            Haz clic en un empleo para obtener más información y continuar.
          </div>
        </Card>
      </div>
    )
  }

  return (
    <>
      {isDesktop ? (
        <Card className="py-4 mt-8 font-inter md:w-[706px] h-[889px] rounded-2xl">
          <div className="py-0 px-9 mb-6 text-[#263658]">
            <h1 className="font-bold text-base text-secondary-500">
              {dataJob.name}
            </h1>
            <div className="flex mb-2">
              <p className="text-xs font-">{dataJob.company.name} - </p>
              <p className="text-xs text-gray-500">
                {formatRelativeDate(dataJob.createdAt)}
              </p>
            </div>
            <p className="text-xs font-medium text-slate-600 mb-2">
              {/* //todo: falta implementar esta función */}
              {/* {capitalizeAndJoin(offer.workModality.name, '_')} */}
              remoto
            </p>
            <p className="text-xs mb-2">
              {t('offerDetail.Sueldo', { salary: dataJob.salary })}
            </p>
            <div>
              <button className="bg-joyitBluePrimary text-joyitBluePrimary-foreground rounded-4xl px-5 py-[0.10rem] shadow-none">
                {t('offerDetail.PostularAhora')}
              </button>
              <Button variant="link" className="rounded-full py-2 px-3">
                {t('offerDetail.PaginaDeEmpleo')}
                <IconArrowUpRight className="pl-2" stroke={1.5} />
              </Button>
            </div>
          </div>
          <hr />
          <CardContent className="py-0 px-9 mt-5 text-[#263658]">
            <h2 className="text-base font-semibold">
              {t('offerDetail.Descripcion')}
            </h2>
            <p className="text-xs mt-2 mb-5">{dataJob.description}</p>
            <h2 className="text-base font-semibold">
              {t('offerDetail.Requisitos')}
            </h2>
            <p className="text-xs mt-2 mb-5">
              {dataJob.levelOfExperience.name.toUpperCase()}
            </p>
            <h2 className="text-base font-semibold">Funciones</h2>
            <p className="text-xs mt-2 mb-5">
              <ul>
                <li>
                  . Analizar y programar las soluciones de software que cumplan
                  con las definiciones dadas.
                </li>
                <li>
                  . Mantener un código fuente eficiente y adaptable para ser
                  unido a código de otros programadores.
                </li>
                <li>
                  . Cumplir con las metodologías y arquitecturas definidas para
                  el desarrollo de software.
                </li>
                <li>
                  . Participar activamente en las células ágiles de trabajo{' '}
                </li>
              </ul>
            </p>
            <h2 className="text-base font-semibold">
              {t('offerDetail.StacksTecnologicos')}
            </h2>
            <div className="grid grid-cols-4 w-2/4 gap-3 mt-2 mb-5">
              {/* //todo: falta implementar esta función */}
              {/* {offer.technologyStacks.map((tec) => (
                <button
                  key={tec.id}
                  className="text-xs font-medium rounded-lg py-1 bg-[#EDF4FF]"
                >
                  {tec.name}
                </button>
              ))} */}
              <button className="text-xs font-medium rounded-lg py-1 bg-[#EDF4FF]">
                React
              </button>
            </div>
            <h2 className="text-base font-semibold">
              {t('offerDetail.Beneficios')}
            </h2>
            <div className="flex justify-between w-48 mt-2 mb-5">
              <IconCake stroke={1} color="#C73866" size={26} />
              <IconClockHour2 stroke={1} color="#C73866" size={26} />
              <img src={svgPerson} alt="" />
              <img src={svgPerson2} alt="" />
              <IconPlug stroke={1} color="#C73866" size={26} />
              <IconSchool stroke={1} color="#C73866" size={26} />
            </div>
            <CardCulqi />
          </CardContent>
        </Card>
      ) : (
        <Drawer
          open={open}
          onOpenChange={() => handleCardClick(null)}
          onClose={handleCloseDrawer}
        >
          <DrawerContent>
            <DrawerHeader className="font-inter">
              <DrawerTitle>
                <div className="mb-3">
                  <h1 className="font-bold text-base text-start">
                    {dataJob.name}
                  </h1>
                  <div className="flex justify-stretch mb-2">
                    <p className="text-xs font-normal">
                      {dataJob.company.name} -{' '}
                    </p>
                    <p className="text-xs text-gray-500">
                      {formatRelativeDate(dataJob.createdAt)}
                    </p>
                  </div>
                  <p className="text-xs text-start font-medium text-slate-600 mb-6">
                    {/* //todo: falta implementar esta función */}
                    {/* {capitalizeAndJoin(offer.workModality.name, '_')} */}
                    remoto
                  </p>
                  <p className="text-xs mb-4">
                    {t('offerDetail.Sueldo', { salary: dataJob.salary })}
                  </p>
                  <div className="flex">
                    <Button className="bg-joyitBluePrimary text-joyitBluePrimary-foreground rounded-full py-2 px-6">
                      {t('offerDetail.PostularAhora')}
                    </Button>
                    <Button variant="link" className="rounded-full py-2 px-3">
                      {t('offerDetail.PaginaDeEmpleo')}
                      <IconArrowUpRight className="pl-2" stroke={1.5} />
                    </Button>
                  </div>
                </div>
              </DrawerTitle>
              <hr />
              <DrawerDescription>
                <div className="flex flex-col items-start mt-3">
                  <h2 className="text-sm font-medium">
                    {t('offerDetail.Descripcion')}
                  </h2>
                  <p className="text-xs text-start mt-2 mb-5">
                    {dataJob.description}
                  </p>
                  <h2 className="text-sm font-medium">
                    {t('offerDetail.Requisitos')}
                  </h2>
                  <p className="text-xs mt-2 mb-5">
                    {dataJob.levelOfExperience.name.toUpperCase()}
                  </p>
                  <h2>{t('offerDetail.StacksTecnologicos')}</h2>
                  <div className="grid grid-cols-4 w-full gap-2 mt-2 mb-5">
                    {/* //todo: falta implementar esta función */}
                    {/* {offer.technologyStacks.map((tec) => (
                      <Button
                        key={tec.id}
                        variant="secondary"
                        className="text-xs font-medium rounded-3xl"
                      >
                        {tec.name}
                      </Button>
                    ))} */}
                    <Button
                      variant="secondary"
                      className="text-xs font-medium rounded-3xl"
                    >
                      React
                    </Button>
                  </div>
                  <h2>{t('offerDetail.Beneficios')}</h2>
                  <div className="flex justify-between w-48 mt-2 mb-5">
                    <IconCake stroke={1} color="#C73866" size={26} />
                    <IconClockHour2 stroke={1} color="#C73866" size={26} />
                    <img src={svgPerson} alt="" />
                    <img src={svgPerson2} alt="" />
                    <IconPlug stroke={1} color="#C73866" size={26} />
                    <IconSchool stroke={1} color="#C73866" size={26} />
                  </div>
                  <CardCulqi />
                </div>
              </DrawerDescription>
            </DrawerHeader>
            <DrawerFooter className="font-inter">
              <DrawerClose asChild onClick={handleCloseDrawer}>
                <Button variant="outline">
                  {t('offerDetail.CerrarModal')}
                </Button>
              </DrawerClose>
            </DrawerFooter>
          </DrawerContent>
        </Drawer>
      )}
      {/* Card para desktop */}

      {/* Drawer para mobile */}
    </>
  )
}
