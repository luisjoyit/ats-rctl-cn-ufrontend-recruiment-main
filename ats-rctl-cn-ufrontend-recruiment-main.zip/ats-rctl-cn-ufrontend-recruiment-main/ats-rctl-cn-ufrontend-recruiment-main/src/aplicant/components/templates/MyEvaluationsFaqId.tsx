import React from 'react'
import { useParams, Link, useNavigate } from 'react-router-dom'
//@ts-ignore
import { t, useLanguage } from '@joyit/layout'
import { Progress } from '@/components/ui/progress'

export default function MyEvaluationsFaqId() {
  const { evaluationId } = useParams()
  const { handleChangeLanguage } = useLanguage()
  const [progress, setProgress] = React.useState(0)
  const [currentQuestion, setCurrentQuestion] = React.useState(0)
  const [checkboxes, setCheckboxes] = React.useState([
    { label: '', checked: false },
    { label: '', checked: false },
    { label: '', checked: false },
    { label: '', checked: false },
  ])

  const navigate = useNavigate()

  const questions = [
    {
      question: '¿Cuál es el propósito principal de una API REST?',
      answers: [
        'Proporcionar una interfaz uniforme para la comunicación entre sistemas',
        'Crear bases de datos relacionales',
        'Diseñar interfaces de usuario',
        'Optimizar el rendimiento del servidor',
      ],
    },
    {
      question:
        '¿Qué significa CRUD en el contexto de operaciones de base de datos?',
      answers: [
        'Create, Read, Update, Delete',
        'Compile, Run, Update, Debug',
        'Connect, Retrieve, Update, Disconnect',
        'Copy, Replicate, Upload, Download',
      ],
    },
    {
      question: '¿Cuál es la diferencia principal entre GET y POST en HTTP?',
      answers: [
        'GET recupera datos, POST envía datos para ser procesados',
        'GET es más seguro que POST',
        'POST es más rápido que GET',
        'GET puede enviar más datos que POST',
      ],
    },
    {
      question: '¿Qué es la autenticación JWT?',
      answers: [
        'Un método de autenticación basado en tokens',
        'Un protocolo de encriptación',
        'Un tipo de base de datos',
        'Un lenguaje de programación',
      ],
    },
    {
      question: '¿Cuál es la función principal de un ORM?',
      answers: [
        'Mapear objetos de programación a tablas de bases de datos',
        'Optimizar consultas SQL',
        'Crear interfaces de usuario',
        'Gestionar servidores web',
      ],
    },
    {
      question: '¿Qué es el patrón de diseño MVC?',
      answers: [
        'Modelo-Vista-Controlador, un patrón de arquitectura de software',
        'Método de Validación Continua',
        'Manejo de Versiones Concurrentes',
        'Módulo de Verificación de Código',
      ],
    },
    {
      question: '¿Qué es un ataque de inyección SQL?',
      answers: [
        'Insertar código SQL malicioso en las entradas de la aplicación',
        'Sobrecarga del servidor de base de datos',
        'Robo de contraseñas de administrador de base de datos',
        'Modificación no autorizada de esquemas de base de datos',
      ],
    },
    {
      question: '¿Cuál es la diferencia entre una base de datos SQL y NoSQL?',
      answers: [
        'SQL usa un esquema predefinido, NoSQL es más flexible',
        'SQL es más rápida que NoSQL',
        'NoSQL solo se usa para big data',
        'SQL no puede escalar horizontalmente',
      ],
    },
    {
      question: '¿Qué es el control de versiones y por qué es importante?',
      answers: [
        'Sistema para rastrear y gestionar cambios en el código, facilita la colaboración',
        'Método para optimizar el rendimiento del código',
        'Herramienta para depurar errores en el código',
        'Técnica para comprimir archivos de código',
      ],
    },
    {
      question: '¿Qué es la programación asíncrona?',
      answers: [
        'Permite que ciertas operaciones se ejecuten en segundo plano sin bloquear la ejecución principal',
        'Un paradigma de programación que no utiliza funciones',
        'Programación que solo se ejecuta durante la noche',
        'Un método para sincronizar todos los procesos en un programa',
      ],
    },
    {
      question: '¿Qué son los microservicios?',
      answers: [
        'Arquitectura que estructura una aplicación como un conjunto de servicios pequeños y autónomos',
        'Servicios web que solo manejan peticiones muy pequeñas',
        'APIs que se ejecutan en servidores de baja potencia',
        'Funciones de utilidad que ocupan menos de 100 líneas de código',
      ],
    },
    {
      question: '¿Qué es la escalabilidad en el desarrollo de software?',
      answers: [
        'La capacidad de un sistema para manejar un crecimiento en la carga de trabajo',
        'La habilidad de escribir código más rápido',
        'El proceso de hacer que el software sea compatible con múltiples sistemas operativos',
        'La práctica de dividir un programa en módulos más pequeños',
      ],
    },
  ]

  React.useEffect(() => {
    setCheckboxes(
      questions[currentQuestion].answers.map((answer) => ({
        label: answer,
        checked: false,
      })),
    )
  }, [currentQuestion])

  const handleCheckboxChange = (index: number) => {
    const newCheckboxes = checkboxes.map((checkbox, i) => ({
      ...checkbox,
      checked: i === index,
    }))
    setCheckboxes(newCheckboxes)
  }

  const handleNext = () => {
    if (currentQuestion < questions.length - 1) {
      const newQuestion = currentQuestion + 1
      setCurrentQuestion(newQuestion)
      setProgress(((newQuestion + 1) / questions.length) * 100)
    } else {
      setProgress(100)
    }
  }

  const handleBack = () => {
    if (currentQuestion > 0) {
      const newQuestion = currentQuestion - 1
      setCurrentQuestion(newQuestion)
      setProgress((newQuestion / questions.length) * 100)
    }
  }

  const translateWithParams = (key, params) => {
    let translation = t(key)
    for (const param in params) {
      translation = translation.replace(`{${param}}`, params[param])
    }
    return translation
  }

  const isAnswerSelected = checkboxes.some((checkbox) => checkbox.checked)
  const isLastQuestion = currentQuestion === questions.length - 1

  return (
    <div className="flex flex-col w-full font-inter text-secondary-500 gap-8">
      <Link to={`/applicants/candidate/myEvaluations/codingChallenge1`}>
        <button className="w-[101px] h-[23px] bg-backgroundF-500 rounded-[30px] text-sm">
          {t('myEvaluationid.volver')}
        </button>
      </Link>
      <div className="flex flex-col gap-2 dark:text-white">
        <h1 className="font-bold">{t('myEvaluationid.subtitulo')}</h1>
        <h2 className="text-sm">{t('myEvaluationid.texto')}</h2>
      </div>
      <div className="relative w-full flex flex-col gap-6 rounded-[11px] bg-white p-10 pt-5 shadow-[0px_0px_1px_0px_#00000040]">
        <div className="flex flex-col gap-3">
          <div className="flex justify-between items-center">
            <h1 className="text-xs">{t('myEvaluationid.progreso')}</h1>
            <span className="text-xs font-semibold">
              {Math.round(progress)}%
            </span>
          </div>
          <Progress value={progress} className="w-full" />
        </div>
        <h2 className="font-semibold">
          {translateWithParams('myEvaluationsFaqId.pregunta', {
            current: currentQuestion + 1,
            total: questions.length,
          })}
        </h2>
        <h3 className="text-sm">{questions[currentQuestion].question}</h3>
        <div className="">
          {checkboxes.map((checkbox, index) => (
            <div key={index} className="flex items-center mb-2">
              <input
                type="checkbox"
                id={`checkbox-${index}`}
                checked={checkbox.checked}
                onChange={() => handleCheckboxChange(index)}
                className="opacity-0 absolute h-8 w-8"
              />
              <label
                htmlFor={`checkbox-${index}`}
                className={`w-3 h-3 rounded-full cursor-pointer flex items-center justify-center border border-muted-100`}
              >
                <span
                  className={`w-2 h-2 rounded-full ${
                    checkbox.checked ? 'bg-[#263658]' : ''
                  }`}
                ></span>
              </label>
              <span className="ml-2 text-sm">{checkbox.label}</span>
            </div>
          ))}
        </div>

        <div
          className={`flex ${isLastQuestion ? 'justify-center' : 'flex-col-reverse items-center gap-3 sm:flex-row sm:justify-evenly'}`}
        >
          {!isLastQuestion && currentQuestion > 0 && (
            <button
              className="w-[156px] h-[31px] rounded-[30px] bg-[#E9EAF5] text-secondary-500"
              onClick={handleBack}
            >
              {t('myEvaluationsFaqId.atras')}
            </button>
          )}
          {!isLastQuestion ? (
            <button
              className="w-[156px] h-[31px] rounded-[30px] bg-primary text-white"
              onClick={handleNext}
              disabled={!isAnswerSelected}
            >
              {t('myEvaluationsFaqId.siguiente')}
            </button>
          ) : (
            <Link
              to={`/applicants/candidate/myEvaluations/${evaluationId}/${evaluationId}/end`}
              className={`w-[169px] h-[31px] rounded-[30px] ${isAnswerSelected ? 'bg-primary' : 'bg-gray-300'} text-white flex items-center justify-center`}
              onClick={(e) => {
                if (!isAnswerSelected) {
                  e.preventDefault()
                }
              }}
            >
              {t('myEvaluationsFaqId.terminar')}
            </Link>
          )}
        </div>
      </div>
    </div>
  )
}
