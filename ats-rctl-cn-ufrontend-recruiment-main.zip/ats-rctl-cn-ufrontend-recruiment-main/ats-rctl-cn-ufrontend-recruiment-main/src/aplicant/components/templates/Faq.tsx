import React, { useState } from 'react'
import {
  IconUser,
  IconSettings,
  IconSearch,
  IconHelp,
  IconPlus,
  IconMinus,
  IconX,
  IconChevronLeft,
} from '@tabler/icons-react'
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger as AccordionTriggerOriginal,
} from '@/components/ui/accordion'
import { Textarea } from '@/components/ui/textarea'
import { Input } from '@/components/ui/input'
import { categoryFaq } from '@/DataFaq/FaqData'
//@ts-ignore
import { t, useLanguage } from '@joyit/layout'
import useMediaQuery from '@/hooks/useMediaQuery'
import { Drawer, DrawerContent, DrawerClose } from '@/components/ui/drawer'
import { Link, useOutletContext } from 'react-router-dom'
import { cn } from '@/lib/utils'
import { Button } from '@/components/ui/button'
import EditorDemo from '@/components/editorText/editorDemo'
import InputWithIcon from '@/components/inputWithIcon'

const datosBotones = [
  {
    titulo: categoryFaq[0].title,
    descripcion: categoryFaq[0].subTitles,
    icon: IconHelp,
  },
  {
    titulo: categoryFaq[1].title,
    descripcion: categoryFaq[1].subTitles,
    icon: IconUser,
  },
  {
    titulo: categoryFaq[2].title,
    descripcion: categoryFaq[2].subTitles,
    icon: IconSearch,
  },
  {
    titulo: categoryFaq[3].title,
    descripcion: categoryFaq[3].subTitles,
    icon: IconSettings,
  },
]

function BotonFaq({ titulo, descripcion, icon: Icon, onClick }) {
  const [isHovered, setIsHovered] = useState(false)

  const handleMouseEnter = () => {
    setIsHovered(true)
  }

  const handleMouseLeave = () => {
    setIsHovered(false)
  }

  const buttonClass =
    'bg-white text-[#263658] hover:bg-[#263658] hover:text-white'
  const iconColor = isHovered ? 'white' : '#263658'

  return (
    <button
      className={`sm:w-[291px] h-[112px] rounded-[11px] mt-0 flex flex-col justify-center items-start p-2 ${buttonClass}`}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      onClick={onClick}
    >
      <div className="flex items-center mb-2">
        <Icon stroke={2} className={`text-[${iconColor}]`} />
        <h1 className="font-semibold text-sm ml-2">{titulo}</h1>
      </div>
      <div className="w-full pl-8 h-auto">
        <p className="text-xs text-left break-words whitespace-normal w-full">
          {descripcion}
        </p>
      </div>
    </button>
  )
}

function generarPreguntas(selectedCategory) {
  const index = datosBotones.findIndex((bot) => bot.titulo === selectedCategory)
  const category = categoryFaq[index]
  const preguntas = category ? category.subcategory : []
  return preguntas
}

function AccordionTrigger({ children, ...props }) {
  const [isExpanded, setIsExpanded] = useState(false)

  const handleToggle = () => {
    setIsExpanded(!isExpanded)
  }

  return (
    <AccordionTriggerOriginal
      {...props}
      onClick={handleToggle}
      className="flex items-center justify-between w-full gap-2"
      icon={
        <div className="bg-[#EAEFF0] rounded-full p-1 flex justify-center items-center w-6 h-6">
          {isExpanded ? (
            <IconMinus stroke={2} size={16} className="text-[#263658]" />
          ) : (
            <IconPlus stroke={2} size={16} className="text-[#263658]" />
          )}
        </div>
      }
    >
      <span className="text-start">{children}</span>
    </AccordionTriggerOriginal>
  )
}

function AccordionFaq({
  selectedCategory,
  preguntas,
  selectedIcon: SelectedIcon,
}) {
  return (
    <>
      <div className="w-full h-full overflow-y-auto">
        <div className="flex items-center mb-4">
          <h1 className="font-bold ml-2 text-secondary-500">
            {selectedCategory}
          </h1>
        </div>
        <Accordion type="multiple" className="w-full text-secondary-500">
          {preguntas.map((pregunta, index) => (
            <AccordionItem
              key={index}
              value={`item-${index + 1}`}
              className="border-t-0 border-b-[1px] border-secondary-500 md:max-w-3xl ml-0 md:ml-10 pr-2 md:pr-0"
            >
              <AccordionTrigger>{pregunta.title}</AccordionTrigger>
              <AccordionContent className="ml-2">
                {pregunta.subTitles}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </>
  )
}

export default function FaqCompany() {
  const { handleChangeLanguage } = useLanguage()
  const [selectedCategory, setSelectedCategory] = useState(categoryFaq[0].title)
  const [open, setOpen] = useState(false)
  const preguntas = generarPreguntas(selectedCategory)
  const isDesktop = useMediaQuery('(min-width: 768px)')
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [ticketId, setTicketId] = useState('')

  const selectedIcon = datosBotones.find(
    (boton) => boton.titulo === selectedCategory,
  )?.icon

  const handleButtonClick = (titulo) => {
    setSelectedCategory(titulo)
    setOpen(true)
  }

  const getCategoryIcon = (categoryTitle) => {
    const category = datosBotones.find((cat) => cat.titulo === categoryTitle)
    if (category) {
      const IconComponent = category.icon
      return <IconComponent stroke={2} size={36} className="text-[#263658]" />
    }
    return <IconHelp stroke={2} size={36} className="text-[#263658]" />
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const newTicketId =
      'N' +
      Math.floor(Math.random() * 1000000000)
        .toString()
        .padStart(9, '0')
    setTicketId(newTicketId)
    setIsModalOpen(true)
  }

  const closeModal = () => {
    setIsModalOpen(false)
  }

  const getContent = () => (
    <>
      {selectedCategory !== 'Generar ticket de soporte' ? (
        <>
          <div className="flex items-center mb-4 xs:mt-4 md:mt-0">
            {getCategoryIcon(selectedCategory)}
            <h1 className="font-bold ml-2 text-secondary-500">
              {selectedCategory}
            </h1>
          </div>
          <Accordion type="multiple" className="w-full text-secondary-500">
            {preguntas.map((pregunta, index) => (
              <AccordionItem
                key={index}
                value={`item-${index + 1}`}
                className="border-t-0 border-b-[1px] border-secondary-500 md:max-w-3xl ml-10 xs:pr-2 md:pr-0"
              >
                <AccordionTrigger>{pregunta.title}</AccordionTrigger>
                <AccordionContent className="ml-2">
                  {pregunta.subTitles}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </>
      ) : (
        <form
          onSubmit={handleSubmit}
          className="flex flex-col gap-5 p-4 text-secondary-500"
        >
          <div className="font-medium">
            <h1 className="font-semibold text-lg">
              {t('FormFaq.perzonalizada')}
            </h1>
            <h2>{t('FormFaq.texto')}</h2>
          </div>
          <div className="grid sm:grid-cols-3 gap-5">
            <Input placeholder={t('FormFaq.nombre')} />
            <Input placeholder={t('FormFaq.correo')} />
            <Input placeholder={t('FormFaq.consulta')} />
          </div>
          <EditorDemo
            name="description"
            placeholder="Describe tu consulta"
            isHeaderEnd
          />
          <div className="flex mt-5 w-full justify-end">
            <Button type="submit" variant="primary" size="sm">
              {t('FormFaq.enviar')}
            </Button>
          </div>
        </form>
      )}
    </>
  )

  return (
    <>
      <NabvarFaq handleButtonClick={handleButtonClick} />
      <h2 className="text-sm font-inter ml-4 font-medium text-[#263658]">
        Categorías
      </h2>
      <div className="font-inter flex xs:flex-col md:flex-row md:justify-between text-secondary dark:text-white gap-4 lg:gap-10 p-4">
        <div className="flex flex-col gap-2 mb-6 sm:mb-0">
          {datosBotones.map((boton, index) => (
            <BotonFaq
              key={index}
              titulo={boton.titulo}
              descripcion={boton.descripcion}
              icon={boton.icon}
              onClick={() => handleButtonClick(boton.titulo)}
            />
          ))}
        </div>

        {isDesktop ? (
          <div
            className={`w-full sm:w-[865px] rounded-[11px] bg-white p-4 flex flex-col overflow-y-auto ${selectedCategory === 'Generar ticket de soporte' ? 'h-[399px]' : ''}`}
          >
            {getContent()}
          </div>
        ) : (
          <Drawer open={open} onOpenChange={setOpen}>
            <DrawerContent className="p-4 h-[calc(100vh-4rem)] flex flex-col font-inter">
              <div className="flex-grow overflow-y-auto">{getContent()}</div>
              <DrawerClose />
            </DrawerContent>
          </Drawer>
        )}
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-[11px] w-full max-w-[486px] h-auto md:h-[239px] p-6 relative">
            <button
              onClick={closeModal}
              className="absolute top-2 right-2 text-gray-500 hover:text-gray-700"
            >
              <IconX size={20} />
            </button>
            <h2 className="text-xl font-bold mb-4 text-center text-secondary-500 mt-4">
              ¡Ticket enviado con éxito!
            </h2>
            <p className="text-center mb-2">Ticket ID: {ticketId}</p>
            <p className="text-center text-sm text-secondary-500 mb-6">
              Puedes realizar el seguimiento y ver las actualizaciones del
              estado de tu ticket en la sección "Ver mis tickets".
            </p>
            <div className="flex justify-center">
              <Button
                onClick={closeModal}
                className="bg-secondary-500 text-white hover:bg-secondary-600 w-full md:w-[160px] h-[37px] rounded-[8px]"
              >
                Ok
              </Button>
            </div>
          </div>
        </div>
      )}
    </>
  )
}

interface NabvarFaqProps {
  handleButtonClick: (string) => void
}

function NabvarFaq({ handleButtonClick }: NabvarFaqProps) {
  return (
    <div className="p-4 flex items-center md:gap-48 xs:flex-col md:flex-row xs:gap-3">
      <h1 className="text-secondary-500 font-inter font-semibold">
        Centro de Ayuda
      </h1>
      <div className="flex items-center flex-1 justify-between md:flex-row xs:flex-col xs:gap-3 md:gap-0">
        <InputWithIcon placeholder="Buscar Pregunta" className="w-full" />
        <Button
          size="default"
          className="px-5"
          onClick={() => handleButtonClick('Generar ticket de soporte')}
        >
          Generar Ticket de Soporte
        </Button>
        <Link
          to={'http://localhost:9000/recruitment/applicants/faq/ticket'}
          className="px-5 text-secondary-500"
        >
          Ver mis tickets
        </Link>
      </div>
    </div>
  )
}
