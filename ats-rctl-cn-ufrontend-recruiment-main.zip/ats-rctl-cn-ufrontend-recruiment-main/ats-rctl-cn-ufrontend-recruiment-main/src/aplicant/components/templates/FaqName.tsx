import { useParams } from 'react-router-dom'
import FormFaq from '../molecules/FormFaq'
import AccordionUi from '@/components/AccordionUi'
//@ts-ignore
import { t, useLanguage } from '@joyit/layout'

export default function FaqName() {
  const { categoryName } = useParams()
  const { handleChangeLanguage } = useLanguage()
  const dataAcordeon = [
    {
      accordionTrigger: t('acordeon.acordeonuno'),
      accordionContent:
        'Si tienes preguntas específicas o deseas consejos sobre cómo hacer que tu currículum vitae sea más efectivo, por favor pregúntame, y haré lo mejor para proporcionarte información útil. Puedes describir secciones clave o preguntas específicas que tengas, y podemos trabajar en ellas juntos.',
      value: 'item1',
    },
    {
      accordionTrigger: t('acordeon.acordeondos'),
      accordionContent:
        'Si tienes preguntas específicas o deseas consejos sobre cómo hacer que tu currículum vitae sea más efectivo, por favor pregúntame, y haré lo mejor para proporcionarte información útil. Puedes describir secciones clave o preguntas específicas que tengas, y podemos trabajar en ellas juntos.',
      value: 'item2',
    },
  ]
  return (
    <>
      <div>
        <h1 className="font-inter font-bold">{t('categorias.frecuentes')}</h1>
        <h2 className="font-inter text-sm">
          {t('categorias.categoria')}
          {categoryName}
        </h2>
        <AccordionUi
          accordionItems={dataAcordeon}
          className="bg-[#E7F0FF] mt-3"
        />
      </div>
      <div className="mt-20">
        <FormFaq />
      </div>
    </>
  )
}
