import React, { useEffect, useState } from 'react'
import { Calendar, momentLocalizer } from 'react-big-calendar'
import moment from 'moment'
import 'react-big-calendar/lib/css/react-big-calendar.css'
import ModalCalendar from '../molecules/ModalCalendar'
import { Combobox } from '../atoms/ComboBox'
import useMediaQuery from '@/hooks/useMediaQuery'
import { IconChevronLeft, IconChevronRight } from '@tabler/icons-react'
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover'

// @ts-ignore
import { t, useLanguage } from '@joyit/layout'

const events = [
  {
    id: 1,
    company: 'Yape Company',
    interviewer: 'Interview with Jaimes French',
    position: 'Designer UI',
    start: new Date(2024, 5, 9, 10, 0), // Jun 29, 2024, 10:00 AM
    end: new Date(2024, 5, 9, 11, 0), // Jun 29, 2024, 11:00 AM
  },
  {
    id: 2,
    company: 'JoyIt',
    interviewer: 'Interview with Tanies Giovich',
    position: 'FullStack Developer',
    start: new Date(2024, 5, 15, 10, 0), // Jun 29, 2024, 10:00 AM
    end: new Date(2024, 5, 15, 11, 0), // Jun 29, 2024, 11:00 AM
  },
  {
    id: 3,
    company: 'Services Culqui',
    interviewer: 'Interview with John Doe',
    position: 'Backend Developer',
    start: new Date(2024, 5, 20, 10, 0), // Jun 29, 2024, 10:00 AM
    end: new Date(2024, 5, 20, 11, 0), // Jun 29, 2024, 11:00 AM
  },
  {
    id: 4,
    company: 'Yape',
    interviewer: 'Interview with Jane Smith',
    position: 'Fronted Developer',
    start: new Date(2024, 4, 30, 14, 0), // May 30, 2024, 2:00 PM
    end: new Date(2024, 4, 30, 15, 0), // May 30, 2024, 3:00 PM
  },
  {
    id: 5,
    company: 'Empresa del Norte SAC',
    interviewer: 'Interview with Jane Smith',
    position: 'Fronted Developer',
    start: new Date(2024, 5, 24, 14, 0), // Jun 30, 2024, 2:00 PM
    end: new Date(2024, 5, 24, 15, 0), // Jun 30, 2024, 3:00 PM
  },
]

const localizer = momentLocalizer(moment)

moment.updateLocale('en', {
  week: {
    dow: 1, // Monday is the first day of the week
  },
})

const CustomMonthHeader = ({ label }) => {
  const isDesktop = useMediaQuery('(min-width: 768px)')
  const { language } = useLanguage()

  const fullDaysNameEs = {
    'lun.': 'Lunes',
    'mar.': 'Martes',
    'mié.': 'Miércoles',
    'jue.': 'Jueves',
    'vie.': 'Viernes',
    'sáb.': 'Sábado',
    'dom.': 'Domingo',
  }
  const fullDaysNameEn = {
    Mon: 'Monday',
    Tue: 'Tuesday',
    Wed: 'Wednesday',
    Thu: 'Thursday',
    Fri: 'Friday',
    Sat: 'Saturday',
    Sun: 'Sunday',
  }

  const getDayNames = () => {
    if (language === 'es') {
      return fullDaysNameEs
    } else {
      return fullDaysNameEn
    }
  }

  const dayNames = getDayNames()
  return <span>{isDesktop ? dayNames[label] : dayNames?.[label]?.[0]}</span>
}

const capitalizeFirstLetter = (string) => {
  return string.charAt(0).toUpperCase() + string.slice(1)
}

export default function InterviewCalendar() {
  const [view, setView] = useState('month')
  const [labelView, setLabelView] = useState(
    t('postulationsCalendar.views.month'),
  )

  const { language } = useLanguage()

  const [selectedEvent, setSelectedEvent] = useState(null)
  const [openPop, setOpenPop] = useState(false)

  const [selectedMonth, setSelectedMonth] = useState(moment().month())
  const [selectedYear, setSelectedYear] = useState(moment().year())
  const [selectedDate, setSelectedDate] = useState(moment().toDate())
  const [weekRange, setWeekRange] = useState('')
  const [listMonths, setListMonths] = useState([])

  const isDesktop = useMediaQuery('(min-width: 640px)')
  const isTablet = useMediaQuery('(min-width: 768px)')

  useEffect(() => {
    const newDate = moment()
      .year(selectedYear)
      .month(selectedMonth)
      .date(1)
      .toDate()
    setSelectedDate(newDate)
  }, [selectedMonth, selectedYear])

  useEffect(() => {
    moment.locale(language)
    if (view === 'week') {
      const startOfWeek = moment(selectedDate).startOf('week').format('MMM D')
      const endOfWeek = moment(selectedDate).endOf('week').format('MMM D, YYYY')
      setWeekRange(
        `${capitalizeFirstLetter(startOfWeek)} - ${capitalizeFirstLetter(
          endOfWeek,
        )}`,
      )
    } else {
      setWeekRange('')
    }
  }, [selectedDate, view, language])

  useEffect(() => {
    setSelectedMonth(moment(selectedDate).month())
    setSelectedYear(moment(selectedDate).year())
  }, [selectedDate])

  useEffect(() => {
    moment.locale(language)
    setLabelView(t('postulationsCalendar.views.month'))

    const localizedMonths = moment.months().map((month, index) => ({
      value: index,
      label: capitalizeFirstLetter(month),
    }))
    setListMonths(localizedMonths)
  }, [language])

  const months: any[] = moment.months().map((month, index) => ({
    value: index,
    label: month,
  }))

  const years = Array.from({ length: 5 }, (_, i) => {
    const year = moment().year() - 2 + i
    return { value: year, label: year }
  })

  const dataViews = [
    { value: 'month', label: t('postulationsCalendar.views.month') },
    { value: 'week', label: t('postulationsCalendar.views.week') },
  ]

  const handleViewChange = (view) => {
    setView(view)
    const valueLabel = dataViews.find((element) => element.value === view)
    setLabelView(valueLabel.label)
  }

  const handleEventClick = (event) => {
    if (!openPop && selectedEvent === null) {
      setSelectedEvent(event)
    } else {
      setSelectedEvent((prevEvent) =>
        prevEvent?.id === event?.id ? event : null,
      )
    }
  }

  const handleOpenChange = (open, event) => {
    if (!open) {
      setSelectedEvent(null)
    }
  }

  const handleMonthChange = (month) => {
    setSelectedMonth(month)
  }

  const handleYearChange = (year) => {
    setSelectedYear(year)
  }

  const handleNext = () => {
    if (view === 'month') {
      const nextMonth = moment(selectedDate).add(1, 'months').toDate()
      setSelectedDate(nextMonth)
      setSelectedMonth(moment(nextMonth).month())
      setSelectedYear(moment(nextMonth).year())
    } else if (view === 'week') {
      const nextWeek = moment(selectedDate).add(1, 'weeks').toDate()
      setSelectedDate(nextWeek)
    }
  }

  const handlePrev = () => {
    if (view === 'month') {
      const prevMonth = moment(selectedDate).subtract(1, 'months').toDate()
      setSelectedDate(prevMonth)
      setSelectedMonth(moment(prevMonth).month())
      setSelectedYear(moment(prevMonth).year())
    } else if (view === 'week') {
      const prevWeek = moment(selectedDate).subtract(1, 'weeks').toDate()
      setSelectedDate(prevWeek)
    }
  }

  const handleToday = () => {
    const today = new Date()
    setSelectedDate(today)
    setSelectedMonth(moment(today).month())
    setSelectedYear(moment(today).year())
  }

  const getTilteCalendar = () => {
    return (
      <div className="flex w-full justify-center text[#263658] text-lg font-semibold">
        {view === 'week' ? (
          <span className="text-center font-bold">{weekRange}</span>
        ) : (
          <span>
            {capitalizeFirstLetter(months[selectedMonth]?.label)},{' '}
            {selectedYear}
          </span>
        )}
      </div>
    )
  }

  return (
    <div className="px-0 font-inter w-full">
      <h1 className="text-l sm:text-xl font-bold">
        {t('postulationsCalendar.title')}
      </h1>
      <div className="flex flex-col xs:gap-3 sm:gap-7 my-4 w-full">
        <div className="flex xs:flex-col sm:flex-row items-center justify-between w-full gap-3 sm:gap-0">
          <div className="flex flex-row xs:justify-between sm:justify-around xs:gap-1 sm:gap-3 xs:w-full sm:w-auto">
            <div className="flex xs:gap-1 sm:gap-3">
              <Combobox
                name="months"
                items={listMonths}
                defaultValue={listMonths[selectedMonth]?.label || ''}
                onChange={handleMonthChange}
                small={false}
              />
              <Combobox
                name="years"
                items={years}
                defaultValue={selectedYear}
                onChange={handleYearChange}
                small={true}
              />
            </div>
            <div>
              <Combobox
                name="view"
                items={dataViews}
                defaultValue={labelView}
                onChange={handleViewChange}
                small={false}
              />
            </div>
          </div>
          {isTablet && getTilteCalendar()}
          <div className="flex w-auto pl-8 xs:justify-center sm:justify-end gap-1 my-2  text-secondary-500">
            <div className="bg-backgroundF-500 rounded-full w-[29px] flex items-center justify-center">
              <IconChevronLeft
                stroke={1}
                onClick={handlePrev}
                className="cursor-pointer"
                size={24}
              />
            </div>
            <button
              onClick={handleToday}
              className="rounded-[30px] h-[29px] font-inter text-sm w-24 bg-backgroundF-500"
            >
              {t('postulationsCalendar.today')}
            </button>
            <div className="bg-backgroundF-500 rounded-full w-[29px] flex items-center justify-center">
              <IconChevronRight
                stroke={1}
                onClick={handleNext}
                className="cursor-pointer"
                size={24}
              />
            </div>
          </div>
        </div>
        {!isTablet && getTilteCalendar()}
        <div className="h-[80vh] xs:-mx-3 sm:mx-0">
          <Calendar
            className="calendarInterviews"
            localizer={localizer}
            events={events}
            defaultView={view}
            //views={['month']}
            view={view}
            onView={handleViewChange}
            components={{
              toolbar: () => null,
              //event: CustomEvent,
              event: ({ event, ...props }) => (
                <Popover
                  open={selectedEvent?.id === event.id}
                  onOpenChange={(open) => handleOpenChange(open, event)}
                  key={event.id}
                >
                  <PopoverTrigger asChild>
                    <div
                      id={event.id}
                      role="button"
                      tabIndex={0}
                      className="w-full flex xs:flex-col sm:flex-row xs:justify-center lg:justify-between h-full items-center xs:text-[9px] md:text-sm"
                      onClick={() => handleEventClick(event)}
                    >
                      <span className="text-company flex xs:text-center lg:text-start">
                        {event.company}
                      </span>
                      <span className="xs:hidden lg:flex">
                        {moment(event.start).format('HH:mm')}
                      </span>
                    </div>
                  </PopoverTrigger>
                  <PopoverContent
                    className="bg-white rounded-[11px] shadow-modal p-6 max-w-[316px] xs:w-[300px] sm:w-[316px]"
                    side={isTablet ? 'left' : 'top'}
                    style={{ boxShadow: '0px 0px 15px 2px #00000040' }}
                  >
                    <ModalCalendar
                      dataInterview={selectedEvent}
                      setSelectedEvent={handleEventClick}
                      openPopover={setOpenPop}
                    />
                  </PopoverContent>
                </Popover>
              ),
              month: {
                header: CustomMonthHeader,
              },
            }}
            onSelectEvent={handleEventClick}
            style={{ height: '100%' }}
            date={selectedDate}
            onNavigate={(date) => setSelectedDate(date)}
          />
        </div>
      </div>
    </div>
  )
}
