import React from 'react'
import { Link, useParams } from 'react-router-dom'
//@ts-ignore
import { t, useLanguage } from '@joyit/layout'
import { Progress } from '@/components/ui/progress'
import { Button } from '@/components/ui/button'

export default function MyEvaluationId() {
  const { evaluationId } = useParams()
  const { handleChangeLanguage } = useLanguage()
  const [progress, setProgress] = React.useState(0)

  return (
    <div className="flex flex-col gap-8 justify-center font-inter text-secondary-500">
      <div>
        <Link to={`/applicants/candidate/myEvaluations/`}>
          <button className="w-[101px] h-[23px] bg-backgroundF-500 rounded-[30px] text-sm">
            {t('myEvaluationid.volver')}
          </button>
        </Link>
      </div>
      <div className="flex flex-col gap-2 dark:text-white">
        <h1 className="font-bold">{t('myEvaluationid.subtitulo')}</h1>
        <h2 className="text-sm">{t('myEvaluationid.texto')}</h2>
      </div>
      <div className="w-full flex flex-col gap-6 rounded-[11px] bg-white p-10 pt-5 shadow-[0px_0px_1px_0px_#00000040]">
        <div className="flex flex-col gap-3">
          <h1 className="text-xs">{t('myEvaluationid.progreso')}</h1>
          <Progress value={progress} className="w-full" />
        </div>
        <h2 className="font-semibold">{t('myEvaluationid.test')}</h2>
        <div>
          <ol className="list-decimal ml-5 space-y-4 font-normal text-sm">
            <li>Lee cada pregunta antes de marcar tu respuesta.</li>
            <li>Solo puedes retroceder una pregunta.</li>
            <li>Puedes volver a “Mis evaluaciones” sin perder tu progreso.</li>
            <li>Haz clic en “Completar" al finalizar.</li>
            <li>Puedes tomar el mismo test cada 3 meses.</li>
          </ol>
        </div>
        <div className="flex justify-center mt-10">
          <Link to={`/applicants/candidate/myEvaluations/${evaluationId}/1`}>
            <Button className="sm:w-[314px] h-[31px] rounded-[30px] bg-primary text-white">
              {t('myEvaluationid.botton')}
            </Button>
          </Link>
        </div>
      </div>
    </div>
  )
}
