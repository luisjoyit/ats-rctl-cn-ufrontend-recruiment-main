import { useJobs } from '@/aplicant/hooks/service-hooks/useOffers'
import { useEffect, useState } from 'react'
import { Navigate } from 'react-router-dom'

export default function Offers() {
  const { jobs, isLoading, error } = useJobs({
    page: 1,
    size: 1,
  })

  const [navigateTo, setNavigateTo] = useState('')

  useEffect(() => {
    if (!isLoading && !error && jobs && jobs.length > 0) {
      // Establecer la ruta a la que se debe navegar
      setNavigateTo(`/recruitment/offers/${jobs[0].id}`)
    }
  }, [jobs, isLoading, error])

  if (isLoading) return <p>Cargando...</p>
  if (error) return <p>Error cargando la oferta.</p>
  if (navigateTo) {
    // Si navigateTo está establecido, redireccionar a esa ruta
    return <Navigate to={navigateTo} replace />
  }

  return null
}
