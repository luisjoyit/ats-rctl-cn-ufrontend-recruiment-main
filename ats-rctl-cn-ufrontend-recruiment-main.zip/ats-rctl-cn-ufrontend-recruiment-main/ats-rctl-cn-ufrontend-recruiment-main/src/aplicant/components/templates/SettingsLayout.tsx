import { useEffect, useState } from 'react'
import { Link, Outlet, useLocation, useNavigate } from 'react-router-dom'
import LinkNavigationSettings from '../atoms/LinkNavigationSettings'
import {
  IconBellRinging,
  IconEyeCheck,
  IconSettings,
} from '@tabler/icons-react'

//@ts-ignore
import { t, useLanguage } from '@joyit/layout'
import useMediaQuery from '@/hooks/useMediaQuery'

export default function SettingsLayout() {
  const { handleChangeLanguage } = useLanguage()
  const location = useLocation()
  const navigate = useNavigate()
  const redirectTo = '/recruitment/settings/cuenta'
  useEffect(() => {
    if (location.pathname === '/recruitment/settings') {
      navigate(redirectTo)
    }
  }, [location.pathname, navigate, redirectTo])

  const links = [
    {
      title: t('settingsLayout.AdministracionCuenta'),
      shortTitle: 'Cuenta',
      url: '/applicants/settings/cuenta',
      icon: (
        <IconSettings
          stroke={1.5}
          className="text-secondary-500 dark:text-white"
        />
      ),
    },
    {
      title: t('settingsLayout.VisibilidadPerfil'),
      shortTitle: 'Visibilidad',
      url: '/applicants/settings/visibilidad',
      icon: (
        <IconEyeCheck
          stroke={1.5}
          className="text-secondary-500 dark:text-white"
        />
      ),
    },
    {
      title: t('settingsLayout.Notificaciones'),
      shortTitle: 'Notificaciones',
      url: '/applicants/settings/notificaciones',
      icon: (
        <IconBellRinging
          stroke={1.5}
          className="text-secondary-500 dark:text-white"
        />
      ),
    },
  ]

  const isDesktop = useMediaQuery('(min-width:640px)')
  const [viewMenu, setViewMenu] = useState(true)

  const handleViewMenu = () => {
    setViewMenu(true)
  }

  return (
    <>
      {isDesktop ? (
        <div className="flex pt-12 p-6 bg-card rounded-[13px] shadow-cards min-h-[87vh]">
          <div className="xs:w-full md:w-[30%]">
            <div className="xs:w-full md:w-[175px] text-secondary dark:text-foreground flex xs:flex-row md:flex-col justify-around">
              {links.map((link) => (
                <LinkNavigationSettings
                  key={link.title}
                  title={link.title}
                  url={link.url}
                  shortTitle={link.shortTitle}
                  textColor="text-[#263658]"
                  textSize="text-base"
                  textWeight="font-medium"
                  underlineThickness="2px"
                  isSelected={location.pathname === link.url}
                  icon={link.icon}
                />
              ))}
            </div>
          </div>
          <div className="xs:w-full md:w-[420px]">
            <Outlet context={{ handleViewMenu }} />
          </div>
        </div>
      ) : (
        <div className="bg-card p-6 rounded-[13px] shadow-cards min-h-screen">
          {viewMenu ? (
            <div className="flex flex-col">
              <span className="font-semibold text-lg mb-8 text-secondary dark:text-white">
                Configuración
              </span>
              <div className="grid grid-cols-1 gap-3">
                {links.map((link, id) => (
                  <div
                    key={id}
                    className="h-24 w-full rounded-lg flex items-center justify-center text-secondary dark:text-white font-medium flex-col gap-3 border p-3"
                  >
                    <Link
                      to={link.url}
                      onClick={() => setViewMenu(false)}
                      className="flex flex-col gap-3 items-center"
                    >
                      <div>{link.icon}</div>
                      <span className="text-center">{link.title}</span>
                    </Link>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="flex">
              <Outlet context={{ handleViewMenu }} />
            </div>
          )}
        </div>
      )}
    </>
  )
}
