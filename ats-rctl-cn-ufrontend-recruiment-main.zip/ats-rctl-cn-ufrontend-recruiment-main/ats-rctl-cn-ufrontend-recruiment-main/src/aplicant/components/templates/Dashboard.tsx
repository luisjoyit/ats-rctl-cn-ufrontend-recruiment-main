import React, { useEffect, useState } from 'react'
import { Toaster, toast } from 'sonner'
import LastApplicationsSection from '../organism/LastApplicationsSection'
import DiscordLink from '../molecules/DiscordLink'
import EnglishCommunityLink from '../molecules/EnglishCommunityLink'
import GraficPostulationsMain from '../molecules/grafic_postulationMain'
import GraficInterviews from '../molecules/grafic_interviews'
import GraficProfileViews from '../molecules/grafic_profileViews'
import { Alert, AlertTitle } from '@/components/ui/alert'
import { DecodedAccessToken } from '@/types'
//@ts-ignore
import { t, useLanguage } from '@joyit/layout'
//@ts-ignore
import { useKeycloakHook, useUserRole } from '@joyit/user-management'

import { IconDownload, IconX } from '@tabler/icons-react'
import SelectUi from '@/components/SelectUi'

const Dashboard: React.FC = () => {
  const { handleChangeLanguage } = useLanguage()
  const { userInfo } = useUserRole() as { userInfo: DecodedAccessToken | null }

  const [showAlert, setShowAlert] = useState(true)
  const [selectMonth, setSelectMonth] = useState(String(new Date().getMonth()))

  const getMonths = [
    { value: '0', label: 'Enero' },
    { value: '1', label: 'Febrero' },
    { value: '2', label: 'Marzo' },
    { value: '3', label: 'Abril' },
    { value: '4', label: 'Mayo' },
    { value: '5', label: 'Junio' },
    { value: '6', label: 'Julio' },
    { value: '7', label: 'Agosto' },
    { value: '8', label: 'Septiembre' },
    { value: '9', label: 'Octubre' },
    { value: '10', label: 'Noviembre' },
    { value: '11', label: 'Diciembre' },
  ]

  useEffect(() => {
    const selectedForInterview = true

    if (selectedForInterview) {
      toast.success(t('dashboard.interviewSelectedMessage'))
    }
  }, [])

  return (
    <div className="flex flex-col gap-10">
      {showAlert && (
        <Alert
          className={`bg-[#FCD34D] h-[92px] rounded-2xl flex justify-between xs:items-start sm:items-center p-6 mb-3`}
        >
          <AlertTitle className="w-full flex flex-col justify-center gap-1 items-start mb-0">
            <span className="text-center font-bold">
              ¡Tu perfil esta al 80%
            </span>
            <span className="text-sm">
              Completa tu CV para mejorar tus oportunidades laborales.
            </span>
          </AlertTitle>
          <div className="flex gap-4 items-center">
            <button className="w-[163px] h-[32px] rounded-full text-[#020617] font-medium text-sm xs:hidden sm:block border border-[#020617]">
              Completar mis datos
            </button>
          </div>
        </Alert>
      )}
      <div className="transition-all duration-300 flex xs:flex-col sm:flex-row justify-between xs:gap-3 sm:gap-0">
        <div className="flex flex-col gap-2">
          <h1 className="font-bold text-3xl relative z-0 dark:text-foreground text-[#020617]">
            {t('dashboard.goodmorning')}, {userInfo?.given_name}
          </h1>
          <span className="text-[#64748B]">
            Aquí podrás ver el resumen general de tus postulaciones
          </span>
        </div>
        <div className="flex gap-3 xs:justify-between sm:items-end">
          <SelectUi
            items={getMonths}
            value={selectMonth}
            name="month"
            placeholder="Selecciona el mes"
            className="h-[40px] xs:w-[256px] xl:w-[200px] rounded-md border border-[#E2E8F0]"
          />
          <button className="flex items-center gap-2 h-[40px] bg-[#2563EB] text-sm font-medium text-[#EFF6FF] rounded-full py-2 px-3">
            <IconDownload stroke={2} className="size-4 text-[#EFF6FF]" />
            <span className="xs:hidden xl:flex">Descargar</span>
          </button>
        </div>
      </div>
      <div className="grid gap-14">
        <div className="grid xs:grid-cols-2 xl:grid-cols-[repeat(3,minmax(0,360px))] xl:h-[208px] justify-between gap-7 overflow-x-auto">
          <GraficInterviews />
          <GraficProfileViews />
          <GraficPostulationsMain />
        </div>
        <div className="grid xl:grid-cols-[repeat(4,minmax(0,270px))] justify-between gap-7">
          <div className="col-span-2 ">
            <LastApplicationsSection />
          </div>
          <div className="grid gap-10 col-span-2">
            <DiscordLink />
            <EnglishCommunityLink />
          </div>
        </div>
      </div>
      <Toaster />
    </div>
  )
}

export default Dashboard
