import React from 'react'
import { Textarea } from '@/components/ui/textarea'
import { Input } from '@/components/ui/input'
import {
  IconUser,
  IconSettings,
  IconSearch,
  IconHelp,
} from '@tabler/icons-react'
//@ts-ignore
import { t, useLanguage } from '@joyit/layout'

const datosBotones = [
  {
    titulo: 'Preguntas Generales',
    descripcion: 'Se introduce la descripción de preguntas generales',
  },
  {
    titulo: 'Busqueda de empleo',
    descripcion: 'Se introduce la descripción de preguntas de producto',
  },
  {
    titulo: 'Proceso de seleccion',
    descripcion: 'Se introduce la descripción de preguntas de envío',
  },
  {
    titulo: 'Soporte Tecnico',
    descripcion: 'Se introduce la descripción de preguntas de pago',
  },
  {
    titulo: 'Generar ticket de soporte',
    descripcion: 'Se introduce la descripción de preguntas de pago',
  },
]

function BotonFaq({ titulo, descripcion }) {
  const iconColor = '#00B7DA' // Color para los iconos
  const [isHovered, setIsHovered] = React.useState(false) // Estado para controlar el hover

  const handleMouseEnter = () => {
    setIsHovered(true)
  }

  const handleMouseLeave = () => {
    setIsHovered(false)
  }

  return (
    <button
      className="w-full h-[93px] rounded-[11px] bg-white mt-0 text-sm flex flex-col justify-center items-start p-3 hover:bg-primary hover:text-white"
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
    >
      {titulo === 'Preguntas Generales' && (
        <div className="flex items-center mb-2">
          <IconHelp
            stroke={2}
            className="icon"
            style={{ color: isHovered ? 'white' : iconColor }}
          />
          <h1 className="font-bold ml-2">{titulo}</h1>
        </div>
      )}
      {titulo === 'Busqueda de empleo' && (
        <div className="flex items-center mb-2">
          <IconUser
            stroke={2}
            className="icon"
            style={{ color: isHovered ? 'white' : iconColor }}
          />
          <h1 className="font-bold ml-2">{titulo}</h1>
        </div>
      )}
      {titulo === 'Soporte Tecnico' && (
        <div className="flex items-center mb-2">
          <IconSettings
            stroke={2}
            className="icon"
            style={{ color: isHovered ? 'white' : iconColor }}
          />
          <h1 className="font-bold ml-2">{titulo}</h1>
        </div>
      )}
      {titulo === 'Generar ticket de soporte' && (
        <div className="flex items-center mb-2">
          <IconSettings
            stroke={2}
            className="icon"
            style={{ color: isHovered ? 'white' : iconColor }}
          />
          <h1 className="font-bold ml-2">{titulo}</h1>
        </div>
      )}
      {titulo !== 'Preguntas Generales' &&
        titulo !== 'Busqueda de empleo' &&
        titulo !== 'Soporte Tecnico' &&
        titulo !== 'Generar ticket de soporte' && (
          <div className="flex items-center mb-2">
            <IconSearch
              stroke={2}
              className="icon"
              style={{ color: isHovered ? 'white' : iconColor }}
            />
            <h1 className="font-bold ml-2">{titulo}</h1>
          </div>
        )}
      <h2 className="text-xs">{descripcion}</h2>
    </button>
  )
}

export default function NewFaq() {
  const { handleChangeLanguage } = useLanguage()
  return (
    <div className="font-inter p-5 flex flex-col justify-between items-center text-[#263658] rounded-[11px]">
      <div className="flex flex-col gap-2 items-start">
        <h1 className="font-bold">Preguntas Frecuentes</h1>
        <h2>Categorías</h2>
        {datosBotones.map((boton, index) => (
          <BotonFaq
            key={index}
            titulo={boton.titulo}
            descripcion={boton.descripcion}
          />
        ))}
      </div>

      <div
        className="mt-16 font-inter font-bold"
        style={{ marginLeft: '20px' }}
      >
        <div className="rounded-[11px] bg-white p-8 text-[#263658] ">
          <div className="font-medium mb-4">
            <h1 className="font-bold">{t('FormFaq.perzonalizada')}</h1>
            <h2>{t('FormFaq.texto')}</h2>
          </div>
          <div className="grid sm:grid-cols-3 items-center gap-5 focus:outline-none focus:shadow-none">
            <div className="hover:outline-none">
              <Input
                className="rounded-[11px] h-[27px] font-medium focus:outline-none focus:shadow-none"
                placeholder={t('FormFaq.nombre')}
              />
            </div>
            <div className="hover:outline-none">
              <Input
                className="rounded-[11px] h-[27px] font-medium focus:outline-none focus:shadow-none"
                placeholder={t('FormFaq.correo')}
              />
            </div>
            <div className="hover:outline-none">
              <Input
                className="rounded-[11px] h-[27px] font-medium focus:outline-none focus:shadow-none"
                placeholder={t('FormFaq.consulta')}
              />
            </div>
          </div>
          <Textarea className="mt-4 font-medium w-full max-h-full sm:w-72 focus:outline-none focus:shadow-none" />

          <div className="flex mt-2 w-full justify-end">
            <button className="rounded-[11px] w-[90px] bg-[#263658] items-center text-white font-medium mr-2">
              {t('FormFaq.enviar')}
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
