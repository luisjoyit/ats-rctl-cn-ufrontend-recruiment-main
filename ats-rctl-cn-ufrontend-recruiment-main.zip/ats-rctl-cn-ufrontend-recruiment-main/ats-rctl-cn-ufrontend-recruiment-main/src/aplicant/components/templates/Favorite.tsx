import { useEffect, useState } from 'react'
import { Navigate } from 'react-router-dom'
import { useGraphQL } from '@/hooks/useGraphQery'

// import { jobsService, favoritesService } from '@/aplicant/service'
import OfferIdLoading from '../atoms/Skeleton-Loading/Offers/offerId-loading'

export default function Favorite() {
  // const allOffers = favoritesService.getJobsFavorites()
  // const { data, isLoading, error } = useGraphQL(allOffers, keycloak.token, {
  //   currentPage: 1,
  //   elementPerPage: 1,
  //   level_exp_id: 0,
  //   modality_id: 0,
  //   categorie_id: 0,
  //   country_id: 0,
  //   newer: true,
  //   oldest: false,
  //   more_relevant: false,
  //   userId: 1,
  // })
  const [navigateTo, setNavigateTo] = useState('')

  // useEffect(() => {
  //   if (
  //     !isLoading &&
  //     !error &&
  //     data &&
  //     data.GetJobsFavoritesByUserFilter.favoriteEntityList &&
  //     data.GetJobsFavoritesByUserFilter.favoriteEntityList.length > 0
  //   ) {
  //     // Establecer la ruta a la que se debe navegar
  //     setNavigateTo(
  //       `/recruitment/candidate/favorites/${data.GetJobsFavoritesByUserFilter.favoriteEntityList[0].id}`,
  //     )
  //   }
  // }, [data, isLoading, error])

  // if (isLoading) return <OfferIdLoading />
  // if (error) return <p>Error cargando la oferta.</p>
  if (navigateTo) {
    // Si navigateTo está establecido, redireccionar a esa ruta
    return <Navigate to={navigateTo} replace />
  }

  return null
}
