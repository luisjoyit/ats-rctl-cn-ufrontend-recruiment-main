import React, { useState } from 'react'
import {
  IconArrowLeft,
  IconBolt,
  IconBowl,
  IconBrain,
  IconBuilding,
  IconClockHour10,
  IconDeviceLaptop,
  IconHeart,
  IconHeartFilled,
  IconHomeBolt,
  IconSettings,
  IconShieldLock,
  IconUserBolt,
} from '@tabler/icons-react'
import svgPeru from '../../../static/svg/peru.svg'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardFooter, CardHeader } from '@/components/ui/card'
import { useNavigate, useSearchParams } from 'react-router-dom'
import TooltipUi from '@/components/TooltipUi'

const infoJob = {
  company: 'Accenture',
  modality: 'Remoto',
  salary: 6500,
  city: 'Lima',
  country: 'Perú',
  description:
    'Estamos en la búsqueda de un Backend Developer para crear y mantener servicios backend escalables y eficientes. El candidato ideal dominará lenguajes como Python, Java o Node.js, y será capaz de manejar tanto bases de datos relacionales como no relacionales. Será responsable de implementar APIs RESTful, optimizar el rendimiento del sistema y colaborar con equipos multidisciplinarios. La experiencia en microservicios, Docker, Kubernetes y la integración de servicios en la nube es altamente valorada.',
  tasks: [
    'Desarrollo de endpoints de API RESTful utilizando Node.js y Express.js.',
    'Integración de bases de datos relacionales y no relacionales, como MySQL, MongoDB, etc.',
    'Optimización del rendimiento del backend mediante técnicas como la optimización de consultas y la implementación de cachés.',
    'Implementación de medidas de seguridad en la API, como autenticación y autorización de usuarios.',
    'Trabajo en colaboración con otros desarrolladores, tanto del equipo de backend como del frontend.',
    'Creación y mantenimiento de documentación técnica detallada.',
    'Identificación y resolución de problemas técnicos y de rendimiento en el backend de la aplicación.',
  ],
  requirements: [
    'Experiencia demostrada en desarrollo backend utilizando Node.js.',
    'Conocimiento sólido de JavaScript y frameworks de desarrollo backend como Express.js.',
    'Experiencia en el desarrollo de APIs RESTful.',
    'Familiaridad con bases de datos relacionales y no relacionales como MySQL, MongoDB, etc.',
    'Capacidad para trabajar de forma independiente y en equipo.',
    'Excelentes habilidades de comunicación y resolución de problemas.',
  ],
  benefits: [
    {
      title: 'Seguro Médico',
      name: 'medical',
      description:
        'Seguro médico empresarial que protege a empleados y familias con atención integral.',
    },
    {
      title: 'Desarrollo Profesional',
      name: 'development',
      description:
        'Oportunidades de desarrollo profesional para crecer y avanzar en tu carrera con nosotros.',
    },
    {
      title: 'Acceso a eventos',
      name: 'events',
      description:
        'Acceso exclusivo a eventos para fomentar el networking y el desarrollo profesional.',
    },
    {
      title: 'Horario Flexible',
      name: 'flexible',
      description:
        'Horarios flexibles para equilibrar tu vida personal y profesional con comodidad.',
    },
    {
      title: 'Seguro Médico',
      name: 'medical',
      description:
        'Seguro médico empresarial que protege a empleados y familias con atención integral.',
    },
  ],
  stackTech: [
    'AWS',
    'Docker',
    'Inglés',
    'Javascript',
    'Micorservicios',
    'Typescript',
    'Vue JS',
  ],
  languages: ['Ingles'],
}

const MyEmployment = () => {
  const [favoriteJobs, setFavoriteJobs] = useState([])
  const [searchParams, setSearchParams] = useSearchParams()
  const navigate = useNavigate()

  const cardsArray = Array.from({ length: 2 }) // reemplazar por las ofertas similares disponibles

  const toggleFavorite = (id) => {
    if (favoriteJobs.includes(id)) {
      setFavoriteJobs(favoriteJobs.filter((jobId) => jobId !== id))
    } else {
      setFavoriteJobs([...favoriteJobs, id])
    }
  }

  const isFavorite = (id) => favoriteJobs.includes(id)

  const renderIcon = (name) => {
    switch (name) {
      case 'medical':
        return <IconShieldLock stroke={1} size={15} />
      case 'development':
        return <IconUserBolt stroke={1} size={15} />
      case 'events':
        return <IconDeviceLaptop stroke={1} size={15} />
      case 'flexible':
        return <IconClockHour10 stroke={1} size={15} />
      default:
        return <IconShieldLock stroke={1} size={15} />
    }
  }

  return (
    <div className="relative">
      <button
        onClick={() => navigate(-1)}
        className="flex bg-backgroundF-500 rounded-4xl gap-1 px-3 items-center text-xs font-medium h-[23px] max-w-max mb-4"
      >
        <IconArrowLeft stroke={1.5} size={14} />
        Volver
      </button>
      <div className="flex flex-col text-secondary-500 dark:text-white gap-1">
        <div className="flex justify-between items-center">
          <h1 className="font-semibold text-2xl">Desarrollador Backend</h1>
          <Button variant="primary" size="lg" className="text-white">
            Postular ahora
          </Button>
        </div>
        <div className="flex flex-col gap-2">
          <div className="flex">
            <span className="text-medium">{infoJob.company}</span>
            <span className="text-muted-500 ml-2 text-sm">Publicado Hoy</span>
          </div>
          <div className="flex items-center gap-6">
            <div className="flex flex-row gap-2">
              <div>
                <IconDeviceLaptop
                  stroke={2}
                  className="text-grafic-heart"
                  size={16}
                />
              </div>
              <span className="text-xs text-grafic-heart">
                {infoJob.modality}
              </span>
            </div>
            <h3 className="text-sm">Sueldo: ${infoJob.salary}</h3>
          </div>
          <div className="flex items-center gap-2">
            <img src={svgPeru} alt="Peru" className="size-4" />
            <h1 className="text-sm">{`${infoJob.city}, ${infoJob.country}`}</h1>
          </div>
        </div>
      </div>
      <hr className="my-6 border-gray-300 border-t-2" />

      <ScrollArea className="max-h-[65vh] overflow-y-auto scrollbar-hide scrollColor custom-scroll">
        <div className="pr-3 text-secondary-500 dark:text-white font-inter flex flex-col gap-6">
          <div className="flex flex-col gap-2">
            <div className="flex gap-2 items-center">
              <IconSettings stroke={1.5} size={18} />
              <h2 className="font-semibold">Descripción</h2>
            </div>
            <div className="rounded-lg bg-card px-6 py-4 gap-3 flex flex-col">
              <p className="text-sm">{infoJob.description}</p>
            </div>
          </div>
          <div className="flex flex-col gap-2">
            <div className="flex gap-2 items-center">
              <IconSettings stroke={1.5} size={18} />
              <h2 className="font-semibold">Funciones</h2>
            </div>
            <div className="rounded-lg bg-card px-6 py-4 gap-3 flex flex-col">
              <ul className="list-disc xs:pl-2 sm:pl-4">
                {infoJob.tasks.map((items, id) => (
                  <li key={id} className="text-sm">
                    {items}
                  </li>
                ))}
              </ul>
            </div>
          </div>
          <div className="flex flex-col gap-2">
            <div className="flex gap-2 items-center">
              <IconSettings stroke={1.5} size={18} />
              <h2 className="font-semibold">Requisitos</h2>
            </div>
            <div className="rounded-lg bg-card px-6 py-4 gap-3 flex flex-col">
              <ul className="list-disc xs:pl-2 sm:pl-4">
                {infoJob.requirements.map((items, id) => (
                  <li key={id} className="text-sm">
                    {items}
                  </li>
                ))}
              </ul>
            </div>
          </div>
          <div className="flex flex-col gap-4">
            <div className="flex gap-2 items-center">
              <IconSettings stroke={1.5} size={18} />
              <h2 className="font-semibold">Stack Tecnológico</h2>
            </div>
            <div className="flex flex-wrap gap-4">
              {infoJob.stackTech.map((element, id) => (
                <span
                  key={id}
                  className="h-[31px] text-xs flex items-center bg-accent-200 rounded-[50px] px-4"
                >
                  {element}
                </span>
              ))}
            </div>
          </div>
          <div className="flex flex-col gap-4">
            <div className="flex gap-2 items-center">
              <IconSettings stroke={1.5} size={18} />
              <h2 className="font-semibold">Idiomas</h2>
            </div>
            <div className="flex flex-wrap gap-4">
              {infoJob.languages.map((element, id) => (
                <span
                  key={id}
                  className="h-[31px] text-xs flex items-center bg-accent-200 rounded-[50px] px-4"
                >
                  {element}
                </span>
              ))}
            </div>
          </div>
          <div className="flex flex-col gap-4">
            <div className="flex gap-2 items-center">
              <IconSettings stroke={1.5} size={18} />
              <h2 className="font-semibold">Beneficios</h2>
            </div>
            <div className="rounded-lg bg-card xs:p-3 sm:px-6 sm:py-5 flex flex-wrap xs:gap-3 sm:gap-x-6 sm:gap-y-4">
              {infoJob.benefits.map((element, id) => (
                <div
                  key={id}
                  className="flex gap-2 text-sm border rounded-lg xs:p-2 sm:p-3 xs:w-auto sm:w-[260px]"
                >
                  <div className="pt-[2px]">{renderIcon(element.name)}</div>
                  <div className="flex flex-col gap-2">
                    <span className="font-medium xs:text-sm sm:text-base">
                      {element.title}
                    </span>
                    <p className="text-sm xs:hidden sm:flex">
                      {element.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div className="w-full min-h-[208px] bg-secondary-500 rounded-lg mt-4 flex flex-col p-8 justify-between">
            <h2 className="text-white text-xl ">Hola, Somos Accenture</h2>
            <div className="flex items-center">
              <div className="xs:w-[91px] sm:w-[101px] xs:h-[73px] sm:h-[93px] bg-white rounded-[15px]"></div>
              <p className="text-white text-left ml-4 xs:w-full sm:w-[40%] xs:text-sm sm:text-base">
                Lorem ipsum es el texto que se usa habitualmente en diseño
                gráfico en demostraciones. Lorem ipsum es el texto que se usa
                habitualmente en diseño gráfico en demostraciones.
              </p>
            </div>
          </div>
          <h3 className="font-semibold text-lg">Empleos Similares</h3>
          <div className=" flex flex-col gap-3">
            {cardsArray.map((_, index) => (
              <Card
                key={index}
                className="py-4 px-6 cursor-pointer rounded-2xl min-w-[310px] max-w-[480px] 2xl:min-w-[480px]"
                //onClick={() => handleCardClick(offer.id)}
              >
                <CardHeader className="p-0">
                  <div className="flex justify-between items-center">
                    <h1 className="text-sm text-secondary-500 dark:text-white font-semibold tracking-normal">
                      Desarrollador Backend
                    </h1>
                    <div className="flex items-center">
                      <IconBolt
                        className="mx-1"
                        color="#FC8862"
                        fill="#FC8862"
                      />
                      <button
                      /*onClick={(e) => {
                                e.stopPropagation()
                                handleToggleFavorite(offer.id)
                              }}*/
                      >
                        <IconHeart
                          stroke={1.5}
                          color="#C73866"
                          style={{
                            fill: isFavorite(index) ? '#C73866' : 'none',
                          }}
                          onClick={() => toggleFavorite(index)}
                          /*className={cn({
                                  'text-[#C73866]': !toggleHearth[offer.id],
                                  'stroke-[#C73866]': toggleHearth[offer.id],
                                })}
                                fill={
                                  toggleHearth[offer.id] ? '#C73866' : 'white'
                                }*/
                        />
                      </button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="p-0 pt-0.5">
                  <div className="flex pb-2">
                    <p className="text-xs">Culqui</p>
                    <p className="text-xs text-gray-500 ml-2">
                      {`Publicado hace 3 horas`}
                    </p>
                  </div>
                  <div className="flex pb-2 justify-between">
                    <div>
                      <p className="text-xs text-grafic-heart flex gap-1 items-center">
                        <IconBuilding
                          stroke={2}
                          size={20}
                          className="text-grafic-heart"
                        />
                        {/* {capitalizeAndJoin(offer.workModality.name, '_')} */}
                        {/* //todo: falta propiedad del backend */}
                        Remoto
                      </p>
                    </div>
                    <div className="flex gap-1">
                      <TooltipUi
                        Icon={IconClockHour10}
                        label="Horario Flexible"
                      />
                      <TooltipUi Icon={IconHomeBolt} label="Subsidio de luz" />
                      <TooltipUi Icon={IconShieldLock} label="Seguro médico" />
                      <TooltipUi Icon={IconBowl} label="Bono alimenticio" />
                      <TooltipUi
                        Icon={IconBrain}
                        label="Asistencia psicológica"
                      />
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="p-0">
                  <div className="flex justify-between items-center w-full">
                    <div className="flex justify-between items-center">
                      <img src={svgPeru} alt="country"></img>
                      <p className="text-xs mx-2">Lima, Perú</p>
                    </div>
                    <Button
                      variant="primary"
                      size="sm"
                      className="w-20"
                      //onClick={() => handleClickPostular(+offer.id, 1)}
                    >
                      Postular
                    </Button>
                  </div>
                </CardFooter>
              </Card>
            ))}
          </div>
        </div>
      </ScrollArea>
    </div>
  )
}

export default MyEmployment
