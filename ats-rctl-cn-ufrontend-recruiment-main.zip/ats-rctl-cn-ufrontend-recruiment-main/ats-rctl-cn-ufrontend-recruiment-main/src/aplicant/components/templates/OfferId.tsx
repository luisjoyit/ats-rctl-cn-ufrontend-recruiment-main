import { Outlet, useNavigate, useSearchParams } from 'react-router-dom'
import { Card, CardContent, CardFooter, CardHeader } from '@/components/ui/card'
import { Pagination } from '@/components/ui/pagination'
import { useEffect, useState } from 'react'
import svgPeru from '../../../static/svg/peru.svg'

import {
  IconBolt,
  IconBowl,
  IconBrain,
  IconBuilding,
  IconClockHour10,
  IconHeart,
  IconHomeBolt,
  IconShieldLock,
} from '@tabler/icons-react'

import { formatRelativeDate } from '@/helpers/formatDate'
//@ts-ignore
import { t, useLanguage } from '@joyit/layout'
import { cn } from '@/lib/utils'
import useFavoriteJobStore from '@/store/favoriteJobStore'
import { useGraphQLMutation } from '@/hooks/userMutation'
import { toast } from 'sonner'
import OfferIdLoading from '../atoms/Skeleton-Loading/Offers/offerId-loading'
import FiltersJobs from '../molecules/FiltersJobs'

import { Button } from '@/components/ui/button'
import InputWithIcon from '@/components/inputWithIcon'
import TooltipUi from '@/components/TooltipUi'
import {
  useCategories,
  useCountries,
  useModalities,
  useYearsEsperiences,
} from '@/hooks/service-hooks'
import { useJobs } from '@/aplicant/hooks/service-hooks/useOffers'

const initialValuesFilters = {
  category: '',
  location: null,
  years_exp: '', //se retiro de filtros
  modality: '',
  benefits: [], //se retiro de filtros
  salary: [500, 20000],
  order: '',
  levelExperience: null, //se agrego,
  stackTech: [], //se agrego,
  adHonorem: false, //se agrego,
}

export function OfferId(props) {
  const navigate = useNavigate()
  const [searchParams, setSearchParams] = useSearchParams()
  const { handleChangeLanguage } = useLanguage()
  const { dataCategories } = useCategories()
  const { dataModalities } = useModalities()
  const { dataYearsEsperiencess } = useYearsEsperiences()
  const { dataCountries } = useCountries()

  const { toggleHearth, toggleHearthHandler } = useFavoriteJobStore()

  const [dataFilters, setDataFilters] = useState(initialValuesFilters) //guarda todos los filtros
  // Manejo del estado para el uso del Drawer (Modal) en vista de celular
  const [open, setOpen] = useState(false)

  const currentPage = parseInt(searchParams.get('page') || '1', 10)

  const {
    totalItems,
    currentPage: paginaActual,
    elementPerPage,
    jobs,
    isLoading,
  } = useJobs({
    page: currentPage - 1,
    levelOfExperienceId:
      dataFilters.levelExperience && Number(dataFilters.levelExperience),
    countryId: dataFilters.location && Number(dataFilters.location),
    minSalary: dataFilters.salary[0],
    maxSalary: dataFilters.salary[1],
    technologyStack: dataFilters.stackTech,
  })

  useEffect(() => {
    //@ts-ignore
    setSearchParams((prevSearchParams) => ({
      ...prevSearchParams,
      page: currentPage.toString(),
    }))
  }, [currentPage, setSearchParams])

  //recuperar si el boton de favorito esta activo o no de localstorage
  useEffect(() => {
    const data = localStorage.getItem('favorite-repos')
    if (data) {
      const parseData = JSON.parse(data)?.state
      toggleHearthHandler(parseData.toggleHearth)
    }
  }, [])

  const handlePageChange = (page) => {
    setSearchParams({ page: page.toString() })
  }

  const handleCardClick = (id) => {
    if (id !== null) {
      setOpen((prevDrawerOpen) => !prevDrawerOpen)
      const page = searchParams.get('page') || '1'
      navigate(`/applicants/offers/${id}?page=${page}`)
    }
  }

  const handleClickPostular = (jobId: number, userId: number) => {
    // mutateCreateJobApp({ jobId: jobId, userId: userId })
    alert('Postulación realizada con éxito')
  }

  const handleCloseDrawer = () => {
    setOpen(false) // Establecer open como false cuando se cierra el drawer
  }

  const handleToggleFavorite = (id: string) => {
    // mutate({ isFavorite: !toggleHearth[id], jobId: +id, userId: 1 })
    if (toggleHearth[id]) {
      // deleteFavoriteJob({ job_id: id, user_id: 1 })
      alert('Eliminado de favoritos')
    } else {
      // createFavoriteJob({ job_id: id, user_id: 1 })
      alert('Agregado a favoritos')
    }
    toggleHearthHandler(id)
  }

  return (
    <div className="flex flex-col gap-4">
      <div className="flex justify-end gap-4">
        <InputWithIcon placeholder="Buscar ofertas" className="lg:w-[221px]" />
        <FiltersJobs
          itemsCategory={dataCategories}
          itemsLocation={dataCountries}
          itemsYearsExp={dataYearsEsperiencess}
          itemsModality={dataModalities}
          dataFilters={dataFilters}
          setDataFilters={setDataFilters}
          initialValuesFilters={initialValuesFilters}
        />
        <Button
          variant="primary"
          size="md"
          className="bg-secondary-700 dark:bg-secondary w-[133px]"
        >
          {/*t('filterJobs.searchIA')*/}
          Buscar con IA
        </Button>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-[minmax(300px,_480px)_minmax(350px,_706px)] gap-4 font-inter">
        <div className="">
          {isLoading ? (
            <OfferIdLoading />
          ) : (
            <>
              <h1 className="font-semibold text-secondary-500 dark:text-white">
                {t('offersPage.OfertasDisponibles', {
                  count: totalItems,
                })}
              </h1>
              <div>
                {jobs.length > 0 ? (
                  jobs.map((offer) => (
                    <Card
                      key={offer.id}
                      className="py-4 px-6 mt-2.5 cursor-pointer rounded-2xl min-w-[310px] max-w[480px] 2xl:min-w-[480px]"
                      onClick={() => handleCardClick(offer.id)}
                    >
                      <CardHeader className="p-0">
                        <div className="flex justify-between items-center">
                          <h1 className="text-sm text-secondary-500 dark:text-white font-semibold tracking-normal">
                            {offer.name}
                          </h1>
                          <div className="flex items-center">
                            <IconBolt
                              className="mx-1"
                              color="#FC8862"
                              fill="#FC8862"
                            />
                            <button
                              onClick={(e) => {
                                e.stopPropagation()
                                handleToggleFavorite(offer.id)
                              }}
                            >
                              <IconHeart
                                stroke={1.5}
                                className={cn({
                                  'text-[#C73866]': !toggleHearth[offer.id],
                                  'stroke-[#C73866]': toggleHearth[offer.id],
                                })}
                                fill={
                                  toggleHearth[offer.id] ? '#C73866' : 'white'
                                }
                              />
                            </button>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent className="p-0 pt-0.5">
                        <div className="flex pb-2">
                          <p className="text-xs">{offer.company?.name}</p>
                          <p className="text-xs text-gray-500 ml-2">
                            {`Publicado ${formatRelativeDate(offer.createdAt)}`}
                          </p>
                        </div>
                        <div className="flex pb-2 justify-between">
                          <div>
                            <p className="text-xs text-grafic-heart flex gap-1 items-center">
                              <IconBuilding
                                stroke={2}
                                size={20}
                                className="text-grafic-heart"
                              />
                              {/* {capitalizeAndJoin(offer.workModality.name, '_')} */}
                              {/* //todo: falta propiedad del backend */}
                              Remoto
                            </p>
                          </div>
                          <div className="flex gap-1">
                            <TooltipUi
                              Icon={IconClockHour10}
                              label="Horario Flexible"
                            />
                            <TooltipUi
                              Icon={IconHomeBolt}
                              label="Subsidio de luz"
                            />
                            <TooltipUi
                              Icon={IconShieldLock}
                              label="Seguro médico"
                            />
                            <TooltipUi
                              Icon={IconBowl}
                              label="Bono alimenticio"
                            />
                            <TooltipUi
                              Icon={IconBrain}
                              label="Asistencia psicológica"
                            />
                          </div>
                        </div>
                      </CardContent>
                      <CardFooter className="p-0">
                        <div className="flex justify-between items-center w-full">
                          <div className="flex justify-between items-center">
                            <img src={svgPeru} alt="country"></img>
                            <p className="text-xs mx-2">{offer.country.name}</p>
                          </div>
                          <Button
                            variant="primary"
                            size="sm"
                            className="w-20"
                            onClick={() => handleClickPostular(+offer.id, 1)}
                          >
                            {t('offerCard.Postular')}
                          </Button>
                        </div>
                      </CardFooter>
                    </Card>
                  ))
                ) : (
                  <p>No hay ofertas disponibles...</p>
                )}
              </div>
              <Pagination
                currentPage={paginaActual + 1}
                totalItems={totalItems}
                itemsPerPage={elementPerPage}
                onPageChange={handlePageChange}
                className="py-7"
              />
              <h1 className="font-bold text-base text-secondary-500">
                {t('offersPage.EmpleosSimilares')}
              </h1>
            </>
          )}
        </div>
        <div className="">
          <Outlet context={{ open, handleCardClick, handleCloseDrawer }} />
        </div>
      </div>
    </div>
  )
}
