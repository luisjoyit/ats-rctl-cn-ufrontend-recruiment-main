import React, { useEffect, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import CodingChallenge from '../molecules/Coding_Challenge'
//@ts-ignore
import { t, useLanguage } from '@joyit/layout'
import Confetti from 'react-confetti'
import { toast } from 'sonner'

const MyEvaluations: React.FC = () => {
  const { handleChangeLanguage } = useLanguage()
  const location = useLocation()
  const navigate = useNavigate()
  const [showConfetti, setShowConfetti] = useState(false)
  const [activeTab, setActiveTab] = useState('todos')

  useEffect(() => {
    if (location.state?.showConfetti) {
      setShowConfetti(true)
      setTimeout(() => {
        setShowConfetti(false)
        if (location.state?.showSonner) {
          toast.success(
            'Haz obtenido un puntaje de 85% en el Coding Challenge Test',
          )
        }
        navigate('.', { replace: true })
      }, 8000) // Mostrar confeti por 3 segundos
    }
  }, [location.state, navigate])

  const allChallenges = [
    {
      name: t('dashboard.discord.MyEvaluations.evaluations.englishTest'),
      takenBy: 450,
      percentage: '93',
      id: 'englishTest',
    },
    {
      name: t('dashboard.discord.MyEvaluations.evaluations.codingChallenge'),
      takenBy: 6850,
      percentage: '100',
      id: 'codingChallenge',
    },
    {
      name: t('dashboard.discord.MyEvaluations.evaluations.psychometricTest'),
      takenBy: 846,
      percentage: '60',
      id: 'psychometricTest',
    },
    {
      name: t('dashboard.discord.MyEvaluations.evaluations.softSkills'),
      takenBy: 450,
      percentage: '30',
      id: 'softSkills',
    },
    {
      name: t('dashboard.discord.MyEvaluations.evaluations.testIngles'),
      takenBy: 450,
      percentage: '0',
      id: 'testIngles',
    },
    {
      name: t('dashboard.discord.MyEvaluations.evaluations.joyitTest'),
      takenBy: 450,
      percentage: '0',
      id: 'joyitTest',
    },
  ]

  const renderTabContent = () => {
    const filteredChallenges = allChallenges.filter((challenge) => {
      switch (activeTab) {
        case 'pendientes':
          return challenge.percentage === '0'
        case 'asignadas':
          return (
            challenge.name ===
              t('dashboard.discord.MyEvaluations.evaluations.englishTest') &&
            challenge.percentage === '0'
          )
        case 'realizadas':
          return challenge.percentage !== '0'
        default:
          return true
      }
    })

    return (
      <div className="">
        <div className="grid xs:grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-8 justify-center">
          {filteredChallenges.map((challenge) => (
            <CodingChallenge
              key={challenge.id}
              name={challenge.name}
              takenBy={challenge.takenBy}
              percentage={challenge.percentage}
              id={challenge.id}
            />
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="flex flex-col gap-6">
      {showConfetti && <Confetti />}
      <h1 className="font-semibold text-secondary-500 dark:text-white text-xl">
        {t('dashboard.discord.MyEvaluations.evaluaciones')}
      </h1>
      <div className="">
        <div className="inline-flex rounded-[20px] bg-white dark:bg-slate-600 p-1 mb-4">
          {['todos', 'pendientes', 'asignadas', 'realizadas'].map((tab) => (
            <button
              key={tab}
              className={`xs:px-3 md:px-4 py-1 rounded-[20px] focus:outline-none text-sm ${
                activeTab === tab
                  ? 'bg-secondary-500 text-secondary-foreground'
                  : ''
              }`}
              onClick={() => setActiveTab(tab)}
            >
              {t(`dashboard.discord.MyEvaluations.evaluations.${tab}`)}
            </button>
          ))}
        </div>
        {renderTabContent()}
      </div>
    </div>
  )
}

export default MyEvaluations
