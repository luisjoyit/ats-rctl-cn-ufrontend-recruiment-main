import { Link, useOutletContext, useParams } from 'react-router-dom'
import { Card, CardContent } from '@/components/ui/card'
import { Drawer, DrawerContent } from '@/components/ui/drawer'
import { Button } from '@/components/ui/button'

import {
  IconArrowUpRight,
  IconBolt,
  IconBowl,
  IconBrain,
  IconClockHour10,
  IconDeviceLaptop,
  IconHeart,
  IconHomeBolt,
  IconShieldLock,
  IconX,
} from '@tabler/icons-react'

import { formatRelativeDate } from '@/helpers/formatDate'
import CardCulqi from '../molecules/CardCulqi'
import VuelveMasEmpleable from '../molecules/VuelveMasEmpleable'
import CardPotenciaIA from '../molecules/CardPotenciaIA'
//@ts-ignore
import { t, useLanguage } from '@joyit/layout'

import OfferDetailLoading from '../atoms/Skeleton-Loading/Offers/offerDetail-loading'
import TooltipUi from '@/components/TooltipUi'
import { useJobsById } from '@/aplicant/hooks/service-hooks/useOffers'

interface OutletContextType {
  open: boolean
  handleCardClick: (id: string | null) => void
  handleCloseDrawer: () => void
}

function useMediaQuery(query: string): boolean {
  return window.matchMedia(query).matches
}

export function OfferDetail(props) {
  const { offerId } = useParams()
  const { open, handleCardClick, handleCloseDrawer } =
    useOutletContext<OutletContextType>()

  const { dataJob, isLoading } = useJobsById(parseInt(offerId))

  // const { mutate: mutateCreateJobApp, data: createJobAppData } =
  //   useGraphQLMutation(createJobApplication(), keycloak.token, {
  //     onSuccess: (data) => {
  //       toast.success('Postulación realizada con éxito')
  //     },
  //     onError: (error) => {
  //       toast.error('Error al postular')
  //     },
  //   })

  const isDesktop = useMediaQuery('(min-width: 768px)')

  const handleClickPostular = (jobId: number, userId: number) => {
    // mutateCreateJobApp({ jobId: jobId, userId: userId })
  }

  if (isLoading) {
    return (
      <div className="flex justify-center items-center">
        <OfferDetailLoading />
      </div>
    )
  }

  if (!dataJob) {
    return (
      <div className="flex flex-col gap-6">
        <Card
          className="font-inter px-12 xs:mt-0 md:mt-8 flex min-w-full max-w-[706px] xs:h-full md:h-[820px] md:max-h-[889px] rounded-[11px]"
          style={!isDesktop ? { display: 'none' } : {}}
        >
          <div className="text-[#D2D2D2] text-[36px] flex items-center justify-center text-center">
            Haz clic en un empleo para obtener más información y continuar.
          </div>
        </Card>
        <div className="flex flex-col gap-6">
          <VuelveMasEmpleable />
          <CardPotenciaIA />
        </div>
      </div>
    )
  }

  const dataFunctions = [
    'Analizar y programar las soluciones de software que cumplan con las definiciones dadas.',
    'Mantener un código fuente eficiente y adaptable para ser unido a código de otros programadores.',
    'Cumplir con las metodologías y arquitecturas definidas para el desarrollo de software.',
    'Participar activamente en las células ágiles de trabajo.',
  ]

  const getContent = () => (
    <Card
      className="xs:p-3 md:p-6 xs:py-2 md:py-6 xs:mt-0 md:mt-8 font-inter flex flex-col min-w-full max-w-[706px] xs:h-full md:h-[820px] md:max-h-[889px] rounded-[11px]"
      style={!isDesktop ? { boxShadow: 'none', border: 0 } : {}}
    >
      <div className="flex flex-col gap-1 text-secondary-500 dark:text-secondary-foreground">
        <div className="flex flex-row w-full justify-between">
          <h1 className="font-semibold text-base">{dataJob.name}</h1>
          <div className="flex flex-row gap-1">
            <IconBolt
              color="#FC8862"
              fill="#FC8862"
              className="cursor-pointer"
            />
            <IconHeart
              stroke={1.5}
              className="text-grafic-heart cursor-pointer"
            />
          </div>
        </div>
        <div className="flex">
          <p className="text-sm">
            {dataJob.company?.name}
            <span className="text-muted-500 ml-2">{`Publicado ${formatRelativeDate(dataJob.createdAt)}`}</span>
          </p>
        </div>
        <div className="flex flex-row gap-2">
          <div>
            <IconDeviceLaptop
              stroke={2}
              className="text-grafic-heart"
              size={16}
            />
          </div>
          <span className="text-xs text-grafic-heart">
            {/* {capitalizeAndJoin(offer.workModality.name, '_')} */}
            {/* //todo: falta propiedad del backend para modalidad de trabajo */}
            Remoto
          </span>
        </div>
        <p className="text-sm">
          {t('offerDetail.Sueldo', { salary: dataJob.salary })}
        </p>
        <div className="mt-3 mb-5 flex flex-row gap-2">
          <Button
            size="sm"
            className="w-28"
            onClick={() => handleClickPostular(+dataJob.id, 1)}
          >
            {/* //todo: falt implementar */}
            {/* {createJobAppData?.createJobApplication?.jobApplication
              ?.createdAt
              ? convertDate(
                  createJobAppData?.createJobApplication?.jobApplication
                    ?.createdAt,
                )
              : t('offerDetail.PostularAhora')} */}
            {t('offerDetail.PostularAhora')}
          </Button>
          <Link to={'/applicants/offers/1/detail'}>
            <Button variant="tertiary" size="sm" className="w-auto">
              {t('offerDetail.PaginaDeEmpleo')}
              <IconArrowUpRight className="pl-2" stroke={1.5} />
            </Button>
          </Link>
        </div>
      </div>
      <hr />
      <CardContent className="p-0 mt-5 flex flex-col flex-1 gap-4 text-secondary-500 dark:text-secondary-foreground overflow-y-auto">
        <div className="flex flex-col gap-2">
          <h2 className="text-sm font-semibold">
            {t('offerDetail.Descripcion')}
          </h2>
          <p className="text-xs">{dataJob.description}</p>
        </div>
        <div className="flex flex-col gap-2">
          <h2 className="text-sm font-semibold">Funciones</h2>
          <ul className="list-disc pl-4">
            {dataFunctions.map((element, id) => (
              <li key={id} className="text-xs">
                {element}
              </li>
            ))}
          </ul>
        </div>
        <div className="flex flex-col gap-2">
          <h2 className="text-sm font-semibold">
            {t('offerDetail.Requisitos')}
          </h2>
          {/* Falta campo de requisitos en back
          <ul className="list-disc pl-4">
            {data.map((element, id) => (
              <li key={id} className="text-xs">
                {element}
              </li>
            ))}
          </ul>*/}
          <ul className="list-disc pl-4">
            <li className="text-xs">{dataJob.levelOfExperience.name}</li>
          </ul>
        </div>
        <div className="flex flex-col gap-2">
          <h2 className="text-sm font-semibold">
            {t('offerDetail.StacksTecnologicos')}
          </h2>
          <div className="w-full flex flex-wrap gap-3">
            {/* //todo: falta propiedad del backend para tecnologias */}
            {/* {offer.technologyStacks.map((tec) => (
            <button
              key={tec.id}
              className="text-xs font-medium rounded-lg py-1 xs:px-3 md:px-5 bg-accent-100"
            >
              {tec.name}
            </button>
          ))} */}
            <button className="text-xs font-medium rounded-lg py-1 xs:px-3 md:px-5 bg-accent-100">
              React
            </button>
          </div>
        </div>
        <div className="flex flex-col gap-2">
          <h2 className="text-sm font-semibold">
            {t('offerDetail.Beneficios')}
          </h2>
          <div className="flex gap-3">
            <TooltipUi
              Icon={IconClockHour10}
              label="Horario Flexible"
              sizeIcon={24}
            />
            <TooltipUi
              Icon={IconHomeBolt}
              label="Subsidio de luz"
              sizeIcon={24}
            />
            <TooltipUi
              Icon={IconShieldLock}
              label="Seguro médico"
              sizeIcon={24}
            />
            <TooltipUi Icon={IconBowl} label="Bono alimenticio" sizeIcon={24} />
            <TooltipUi
              Icon={IconBrain}
              label="Asistencia psicológica"
              sizeIcon={24}
            />
          </div>
        </div>
        <CardCulqi />
      </CardContent>
    </Card>
  )

  return (
    <div className="flex flex-col gap-6">
      {isDesktop ? (
        getContent()
      ) : (
        <Drawer
          open={open}
          onOpenChange={() => handleCardClick(null)}
          onClose={handleCloseDrawer}
        >
          <DrawerContent className="xs:p-2 sm:p-6 h-[100vh] overflow-y-auto">
            <div className="flex justify-end">
              <IconX size={18} stroke={1} onClick={handleCloseDrawer} />
            </div>
            {getContent()}
          </DrawerContent>
        </Drawer>
      )}
      <div className="flex flex-col gap-6">
        <VuelveMasEmpleable />
        <CardPotenciaIA />
      </div>
    </div>
  )
}
