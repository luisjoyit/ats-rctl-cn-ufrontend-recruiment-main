import {
  IconAwardFilled,
  IconBrandLinkedin,
  IconLink,
  IconChevronLeft,
  IconChevronRight,
  IconMailFilled,
  IconPhoneFilled,
} from '@tabler/icons-react'
import { MyCurriculum } from '@/constants/DataCv'
import Joyit from '../../../../public/Joyit.png'
import { Button } from '@/components/ui/button'
import { useEffect, useRef, useState } from 'react'
import ReactToPrint from 'react-to-print'
import useMediaQuery from '@/hooks/useMediaQuery'
import html2pdf from 'html2pdf.js'
import { Link } from 'react-router-dom'

function MyCurriculumComponent() {
  const printRef = useRef<HTMLDivElement>(null)
  const [currentPage, setCurrentPage] = useState(0)
  const [totalPages, setTotalPages] = useState(1)

  const isMobile = useMediaQuery('(max-width: 640px)')
  const isTablet = useMediaQuery('(max-width: 1024px)')

  // Lógica para dividir el contenido en páginas
  useEffect(() => {
    const calculatePages = () => {
      const pageHeight = 1122 // Altura en píxeles de una página A4 a 96 DPI
      const contentDiv = printRef.current

      if (contentDiv) {
        const children = Array.from(contentDiv.children)
        let currentHeight = 0
        let pageCount = 0

        children.forEach((child) => {
          const childHeight = (child as HTMLElement).offsetHeight
          if (currentHeight + childHeight > pageHeight) {
            pageCount++
            currentHeight = childHeight
          } else {
            currentHeight += childHeight
          }
        })
        //if (currentHeight > 0) pageCount++ // Para la última página si queda algo de contenido
        setTotalPages(pageCount)
      }
    }

    calculatePages()
  }, [printRef.current])

  // Función para generar y descargar el PDF en mobile
  const handleDownloadPDF = () => {
    const options = {
      //margin: [0, 0, 0, 0], // Margen [superior, izquierda, inferior, derecha] en mm
      filename: 'CV.pdf',
      image: { type: 'jpeg', quality: 0.98 }, // Tipo de imagen y calidad
      html2canvas: { scale: 2, useCORS: true }, // Opciones para html2canvas
      jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }, // Configuración del PDF
    }

    // Selecciona el contenido que quieres convertir a PDF
    const element = document.getElementById('content-to-print')

    // Genera el PDF
    html2pdf().from(element).set(options).save()
  }

  const nextPage = () => {
    if (currentPage < totalPages - 1) {
      setCurrentPage((prevPage) => prevPage + 1)
    }
  }

  const prevPage = () => {
    if (currentPage > 0) {
      setCurrentPage((prevPage) => prevPage - 1)
    }
  }

  const ContentRight = () => (
    <div
      className="w-[650px] bg-[#EDF4FF] bg-print flex flex-col justify-start font-inter text-secondary-500 gap-12 pb-4"
      style={{ pageBreakInside: 'avoid' }}
      id="content-right"
    >
      <div className="flex flex-col gap-2 pt-20 px-10">
        <h1 className="text-4xl font-semibold">
          {MyCurriculum.profile.fullName.split(' ').slice(0, 3).join(' ')}
        </h1>
        <h2 className="text-4xl font-semibold">
          {MyCurriculum.profile.fullName.split(' ').slice(3).join(' ')}
        </h2>
        <p className="text-xl">{MyCurriculum.profile.profile}</p>
        <p className="text-base text-justify pt-3">
          {MyCurriculum.profile.summary}
        </p>
      </div>
      <div className="flex flex-col gap-2">
        <div className="px-10">
          <h3 className="text-2xl font-semibold">EXPERIENCIA LABORAL</h3>
        </div>
        <div className=" pl-10">
          <hr className="border-t-2 border-secondary-500 w-full" />
        </div>
        <div className="relative flex flex-col px-10 pt-6">
          {MyCurriculum.experience.map((exp, index) => (
            <div key={index} className="relative flex pb-5">
              <div className="absolute inset-0 flex items-center">
                {index !== MyCurriculum?.experience?.length - 1 && (
                  <div className="w-0.5 h-full bg-secondary-500 ml-[6.5px] mt-2 z-0"></div>
                )}
              </div>
              <div className="flex-shrink-0 z-10 w-3.5 h-3.5 rounded-full bg-white border-2 border-secondary-500 mt-1" />
              <div className="pl-5">
                <h4 className="text-base font-medium">
                  {exp.position} en {exp.company}
                </h4>
                <p className="text-[#5A5A5A]">{exp.period}</p>
                <ul className="list-disc pl-5 mt-2">
                  {exp.responsibilities.map((resp, idx) => (
                    <li key={idx}>{resp}</li>
                  ))}
                </ul>
              </div>
            </div>
          ))}
        </div>
      </div>
      <div className="flex flex-col gap-2">
        <div className="px-10">
          <h3 className="text-2xl font-semibold">PORTAFOLIO</h3>
        </div>
        <div className=" pl-10">
          <hr className="border-t-2 border-secondary-500 w-full" />
        </div>
        <div className="flex flex-col px-10 pt-6">
          {MyCurriculum.portfolio.map((project, index) => (
            <div key={index} className="flex mt-11 gap-5">
              <img
                src={project.image}
                alt=""
                className="w-64 h-40 rounded-2xl object-cover"
              />
              <div className="flex flex-col gap-1">
                <h4 className="font-medium">{project.title}</h4>
                <p className="text-sm font-medium">{project.year}</p>
                <p className="text-xs text-justify">{project.description}</p>
                <div className="flex flex-row gap-4 justify-start pt-3">
                  <Button
                    variant="primary"
                    size="sm"
                    className="w-auto h-auto gap-2 py-1"
                  >
                    Ver
                    <IconLink size={14} className="rotate-45" />
                  </Button>
                  <Button
                    variant="primary"
                    size="sm"
                    className="w-auto h-auto gap-2 py-1"
                  >
                    Github
                    <IconLink size={14} className="rotate-45" />
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
      <div className="flex flex-col gap-2">
        <div className="px-10">
          <h3 className="text-2xl font-semibold">EVALUACIONES</h3>
        </div>
        <div className=" pl-10">
          <hr className="border-t-2 border-secondary-500 w-full" />
        </div>
        <div className="flex flex-wrap px-10 pt-6 justify-between gap-3.5">
          {MyCurriculum.evaluations?.map((evaluation, id) => (
            <div
              key={id}
              className="bg-white w-[170px] h-[62] rounded-[15px] flex flex-row p-3 gap-3 justify-between"
            >
              <div className="flex items-center">
                <p className="text-sm font-medium">{evaluation.name}</p>
              </div>
              <div className="rounded-full bg-secondary-500 flex items-center justify-center h-[42px] w-[42px]">
                <span className="text-white text-xs font-medium">
                  {evaluation.percent}%
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )

  const ContentLeft = () => (
    <div
      className="w-[350px] bg-secondary-500 bg-print flex flex-col items-start p-8 text-white font-inter pb-4"
      style={{ pageBreakInside: 'avoid' }}
      id="content-left"
    >
      <div className="text-sm flex items-center justify-center w-full mb-8">
        <span className="mr-2 text-lg">Powered by</span>
        <img src={Joyit} alt="Joyit Logo" className="object-cover" />
      </div>
      <div className="flex justify-center w-full">
        <div className="relative">
          <img
            src={MyCurriculum.profile.profileImage}
            alt=""
            className="w-48 h-48 aspect-square rounded-full object-cover border-white border-4"
          />
          <img
            src={MyCurriculum.profile.countryFlag}
            alt=""
            className="w-10 h-10 object-cover rounded-full absolute right-0 bottom-5"
          />
        </div>
      </div>
      <div className="mt-20 grid gap-12">
        <div className="w-full mb-8">
          <h3 className="text-xl font-semibold mb-1">CONTACTO</h3>
          <hr className="border-t-2 border-white w-full mb-4" />
          <div className="flex items-center mb-2">
            <IconMailFilled className="mr-2" size={20} />
            <p className="text-sm font-medium">{MyCurriculum.contact.email}</p>
          </div>
          <div className="flex items-center mb-2">
            <IconPhoneFilled className="mr-2" size={20} />
            <p className="text-sm font-medium">{MyCurriculum.contact.phone}</p>
          </div>
          <div className="flex items-center">
            <IconBrandLinkedin stroke={2} className="mr-2" />
            <p className="text-sm">{MyCurriculum.contact.linkedin}</p>
          </div>
        </div>

        <div className="w-full mb-8">
          <h3 className="text-xl font-semibold mb-1">EDUCACIÓN</h3>
          <hr className="border-t-2 border-white w-full mb-4" />
          {MyCurriculum.education.map((edu, index) => (
            <div key={index}>
              <p className="text-sm font-semibold mb-1">
                {edu.degree} en {edu.institution}
              </p>
              <p className="text-sm mb-4">{edu.period}</p>
            </div>
          ))}
        </div>

        <div className="w-full mb-8">
          <h3 className="text-xl font-semibold mb-1">CERTIFICADOS</h3>
          <hr className="border-t-2 border-white w-full mb-4" />
          {MyCurriculum.certificates.map((cert, index) => (
            <div key={index} className="flex items-center mb-2">
              <div>
                <IconAwardFilled className="mr-2" size={16} />
              </div>
              <div>
                <p className="text-xs font-medium">{cert}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="w-full">
          <h3 className="text-xl font-semibold mb-1">STACK TECH</h3>
          <hr className="border-t-2 border-white w-full mb-4" />
          {MyCurriculum.skills.map((skill, index) => (
            <div key={index} className="flex items-center justify-between mb-2">
              <span className="text-sm mr-2 font-semibold">{skill.name}</span>
              <div className="flex">
                {[...Array(4)].map((_, i) => (
                  <div
                    key={i}
                    className={`w-[12px] h-[12px] rounded-full bg-white mr-2 ${
                      i < skill.level ? '' : 'opacity-30'
                    }`}
                  ></div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )

  return (
    <div className="flex flex-col items-center justify-center font-inter gap-4">
      <div className="flex flex-col justify-between items-center xs:w-full lg:w-[1000px] gap-4">
        <div className="flex flex-row justify-between items-center w-full">
          <Link to="/applicants/candidate/myProfile">
            <button className="w-[101px] h-[23px] rounded-[30px] bg-backgroundF-500 text-secondary-500 font-medium text-sm">
              Volver
            </button>
          </Link>
          {isMobile ? (
            <Button
              variant="primary"
              size="sm"
              className="w-auto"
              onClick={handleDownloadPDF}
            >
              Descargar como PDF
            </Button>
          ) : (
            <ReactToPrint
              trigger={() => (
                <Button variant="primary" size="sm" className="w-auto">
                  Descargar como PDF
                </Button>
              )}
              content={() => printRef.current}
              pageStyle="@page { size: A4; margin: 20mm; }"
            />
          )}
        </div>
        <div className="flex flex-row w-full justify-end gap-2">
          <button
            className="w-[40px] h-[26px] bg-backgroundF-500 rounded-[30px] flex items-center justify-center hover:bg-[#00B7DA] hover:text-white transition-colors duration-300"
            onClick={prevPage}
            disabled={currentPage === 0}
          >
            <IconChevronLeft stroke={2} size={18} />
          </button>
          <button
            className="w-[40px] h-[26px] bg-backgroundF-500 rounded-[30px] flex items-center justify-center hover:bg-[#00B7DA] hover:text-white transition-colors duration-300"
            onClick={nextPage}
            disabled={currentPage === totalPages - 1}
          >
            <IconChevronRight stroke={2} size={18} />
          </button>
        </div>
      </div>
      <div
        className={`relative transform ${
          isMobile
            ? 'scale-x-[38%] scale-y-[45%] translate-y-[-27%]'
            : isTablet
              ? 'scale-x-75 scale-y-[90%] translate-y-[-5%]'
              : 'scale-100 translate-y-0'
        }`}
      >
        <div
          className="w-[1000px] h-[1122px] overflow-hidden bg-print"
          style={{
            background:
              'linear-gradient(to right, #263658 0%, #263658 35%, #EDF4FF 35%, #EDF4FF 100%)',
          }}
        >
          <div
            style={{
              transform: `translateY(-${currentPage * 1100}px)`, //1122
              transition: 'transform 0.3s ease',
              minHeight: '1122px',
              paddingBottom: '20px',
            }}
            className="w-[1000px] h-[1122px]"
          >
            <div id="content-to-print" className="flex flex-row" ref={printRef}>
              <ContentLeft />
              <ContentRight />
            </div>
          </div>
          <span className="absolute bottom-4 right-4 font-semibold">
            {currentPage + 1}/{totalPages}
          </span>
        </div>
      </div>
    </div>
  )
}

export default MyCurriculumComponent
