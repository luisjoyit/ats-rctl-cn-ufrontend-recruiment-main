import { Link } from 'react-router-dom'
import AvatarUploadDescription from '../molecules/AvatarUploadDescription'
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs'
import { Button } from '@/components/ui/button'
import SectionContact from '../organism/SectionsMyProfile/SectionContact'
import SectionEducation from '../organism/SectionsMyProfile/SectionEducation'
import SectionProffesionalResume from '../organism/SectionsMyProfile/SectionProffesionalResume'
import SectionWorkExperience from '../organism/SectionsMyProfile/SectionWorkExperience'

export default function MyProfile() {
  const itemsTabs = [
    {
      value: 'contact',
      name: 'Datos de contacto',
    },
    {
      value: 'profile',
      name: 'Perfil profesional',
    },
    {
      value: 'experience',
      name: 'Experiencia',
    },
    {
      value: 'education',
      name: 'Educación',
    },
  ]

  return (
    <div className="flex flex-col gap-8">
      <header>
        <section className="flex flex-col-reverse sm:flex-row-reverse justify-between items-center z-10 ">
          <div className="flex gap-4 xs:pt-8 sm:pt-4 xs:w-full sm:w-auto justify-between">
            <Button
              variant="secondary"
              size="md"
              className="xs:w-auto sm:w-[175px]"
            >
              Importar cv con IA
            </Button>
            <Button
              variant="primary"
              size="md"
              className="xs:w-auto sm:w-[152px] gap-4"
            >
              Descargar CV
            </Button>
          </div>
          <AvatarUploadDescription />
        </section>
      </header>
      <div className="flex flex-col xs:gap-8 lg:gap-20">
        <Tabs defaultValue="contact">
          <TabsList className="w-full grid grid-cols-4 h-[45px] p-0 bg-white">
            {itemsTabs.map((tab, index) => (
              <TabsTrigger
                key={index}
                value={tab.value}
                className="border-t border-x border-b-0 bg-white data-[state=active]:bg-[#263658] data-[state=active]:text-white rounded-t-[11px] rounded-b-none h-[45px]"
              >
                <span className="truncate xs:text-xs sm:text-base">
                  {tab.name}
                </span>
              </TabsTrigger>
            ))}
          </TabsList>
          <TabsContent value="contact" className="mt-0">
            <SectionContact />
          </TabsContent>
          <TabsContent value="profile" className="mt-0">
            <SectionProffesionalResume />
          </TabsContent>
          <TabsContent value="experience" className="mt-0">
            <SectionWorkExperience />
          </TabsContent>
          <TabsContent value="education" className="mt-0">
            <SectionEducation />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
