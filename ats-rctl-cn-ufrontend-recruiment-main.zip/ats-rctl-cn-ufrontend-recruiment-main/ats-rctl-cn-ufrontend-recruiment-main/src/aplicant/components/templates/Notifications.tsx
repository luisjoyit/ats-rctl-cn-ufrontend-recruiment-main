import React from 'react'
import Platform_Notifications from '../molecules/Platform_Notifications'
//@ts-ignore
import { t, useLanguage } from '@joyit/layout'

const Notifications: React.FC = () => {
  const { handleChangeLanguage } = useLanguage()

  const notificationsByDate = [
    {
      date: '05/05/2024',
      notifications: [
        {
          time: '16:01',
          message: t('dashboard.discord.notifications.postulo'),
        },
        {
          time: '16:01',
          message: t('dashboard.discord.notifications.completo'),
        },
        { time: '16:01', message: t('dashboard.discord.notifications.subio') },
      ],
    },
    {
      date: '04/05/2024',
      notifications: [
        { time: '16:01', message: t('dashboard.discord.notifications.unio') },
      ],
    },
  ]

  return (
    <div className="mt-3">
      <h1 className="font-extrabold text-x">
        {t('dashboard.discord.notifications.Platform')}
      </h1>
      <div className="mt-3">
        <Platform_Notifications notificationsByDate={notificationsByDate} />
      </div>
    </div>
  )
}

export default Notifications
