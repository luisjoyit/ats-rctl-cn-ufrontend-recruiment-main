import React from 'react'
import { useParams, useNavigate, useLocation } from 'react-router-dom'
//@ts-ignore
import { t, useLanguage } from '@joyit/layout'
import { Progress } from '@/components/ui/progress'

export default function MyEvaluationsEnd() {
  const { evaluationId } = useParams()
  const { handleChangeLanguage } = useLanguage()
  const location = useLocation()
  const navigate = useNavigate()

  // Obtener el progreso del estado de la ubicación, o usar 100 como valor predeterminado
  const progress = location.state?.progress || 100
  const [score, setScore] = React.useState(progress)

  const handleBackClick = () => {
    navigate(`/applicants/candidate/myEvaluations/`, {
      state: { showConfetti: true, showSonner: true },
    })
  }

  return (
    <div className="flex flex-col w-full font-inter text-secondary-500 gap-8">
      <button
        className="w-[101px] h-[23px] bg-backgroundF-500 rounded-[30px] text-sm"
        onClick={handleBackClick}
      >
        {t('myEvaluationid.volver')}
      </button>
      <div className="flex flex-col gap-2 dark:text-white">
        <h1 className="font-bold">{t('myEvaluationid.subtitulo')}</h1>
        <h2 className="text-sm">{t('myEvaluationid.texto')}</h2>
      </div>
      <div className="w-full flex flex-col gap-16 rounded-[11px] bg-white p-10 pt-5 shadow-[0px_0px_1px_0px_#00000040] min-h-[408px]">
        <div className="flex flex-col gap-3">
          <div className="flex justify-between items-center">
            <h1 className="text-xs">{t('myEvaluationid.progreso')}</h1>
            <span className="text-xs font-semibold">{score}%</span>
          </div>
          <Progress value={score} className="w-full" />
        </div>
        <div className="flex flex-col items-center gap-1">
          <h2 className="text-xl font-semibold text-center">
            {t('myEvaluationsEnd.texto')}
          </h2>
          <p className="text-lg font-medium text-center">
            Puntaje: {score}%/100%
          </p>
          <button
            className="w-[101px] h-[23px] bg-[#E9EAF5] rounded-[30px] mt-4"
            onClick={handleBackClick}
          >
            {t('myEvaluationid.volver')}
          </button>
        </div>
      </div>
    </div>
  )
}
