import React, { useCallback, useMemo, useState } from 'react'
import { IconDownload } from '@tabler/icons-react'
import { Pagination } from '@/components/ui/pagination'
import { useNavigate, useSearchParams } from 'react-router-dom'

import {
  AlertDialog,
  AlertDialogTrigger,
  AlertDialogContent,
} from '@/components/ui/alert-dialog'
import {
  ChevronLeft,
  ChevronRight,
  ChevronsLeft,
  ChevronsRight,
  ListFilter,
  MoveDown,
  MoveUp,
  Trash,
  Trash2,
  X,
} from 'lucide-react'
import logoInter from '../../../../public/logos/interbank.webp'
import { Input } from '@/components/ui/input'

const initialValuesFilters = {
  category: '',
  location: '',
  modality: '',
  salary: [500, 2500],
  order: '',
  levelExperience: '',
  stackTech: [],
  adHonorem: false,
}

type Jobs = {
  id: string
  perfil: string
  empresa: string
  status: string
  salario: number
  tipo: string
  fecha: string
  city: string
}

function MyApplications() {
  const navigate = useNavigate()
  const [searchParams, setSearchParams] = useSearchParams()
  const currentLatest = searchParams.get('latest')
  // const alljobsApplications = applicationsService.GetAllJobApplicationByUser()
  const [dataFilters, setDataFilters] = useState(initialValuesFilters) //guarda todos los filtros

  const [showModal, setShowModal] = useState(false)

  const jobs: Jobs[] = [
    {
      id: '001',
      perfil: 'UX/UI Designer',
      empresa: 'Joyit',
      status: 'Postulado',
      salario: 2500,
      tipo: 'Remoto',
      fecha: '04 Jul 2024',
      city: 'Mexico',
    },
    {
      id: '002',
      perfil: 'Frontend Developer',
      empresa: 'Encora',
      status: 'En proceso',
      salario: 3500,
      tipo: 'Remoto',
      fecha: '04 Jul 2024',
      city: 'Mexico',
    },
    {
      id: '003',
      perfil: 'Backend Developer',
      empresa: 'Apple',
      status: 'Finalizado',
      salario: 4500,
      tipo: 'Híbrido',
      fecha: '04 Jul 2024',
      city: 'Mexico',
    },
    {
      id: '004',
      perfil: 'Devops',
      empresa: 'Yape',
      status: 'En proceso',
      salario: 0,
      tipo: 'Remoto',
      fecha: '04 Jul 2024',
      city: 'Mexico',
    },
    {
      id: '005',
      perfil: 'Arquitecto de Infraestructura Cloud',
      empresa: 'Culqi',
      status: 'Postulado',
      salario: 1500,
      tipo: 'Presencial',
      fecha: '04 Jul 2024',
      city: 'Mexico',
    },
    {
      id: '006',
      perfil: 'UX Designer',
      empresa: 'Google',
      status: 'Finalizado',
      salario: 10000,
      tipo: 'Remoto',
      fecha: '04 Jul 2024',
      city: 'Mexico',
    },
    {
      id: '007',
      perfil: 'UI Designer',
      empresa: 'Amazon',
      status: 'Postulado',
      salario: 8500,
      tipo: 'Freelance',
      fecha: '04 Jul 2024',
      city: 'Perú',
    },
    {
      id: '008',
      perfil: 'Frontend Developer',
      empresa: 'Culqi',
      status: 'Postulado',
      salario: 13000,
      tipo: 'Remoto',
      fecha: '04 Jul 2024',
      city: 'Mexico',
    },
    {
      id: '009',
      perfil: 'Backend Developer',
      empresa: 'Google',
      status: 'Finalizado',
      salario: 0,
      tipo: 'Remoto',
      fecha: '04 Jul 2024',
      city: 'Mexico',
    },
    {
      id: '010',
      perfil: 'DevSecOps',
      empresa: 'Amazon',
      status: 'En proceso',
      salario: 8500,
      tipo: 'Remoto',
      fecha: '04 Jul 2024',
      city: 'Perú',
    },
  ]

  const [jobList, setJobList] = useState(jobs)
  const [selectedJobs, setSelectedJobs] = useState<Set<string>>(new Set())
  const [selectedJobCount, setSelectedJobCount] = useState(0)
  const [selectedJobIds, setSelectedJobIds] = useState([])
  const [itemToDelete, setItemToDelete] = useState(null)

  const [searchTerm, setSearchTerm] = useState('')
  const [sortConfig, setSortConfig] = useState<{
    key: keyof Jobs
    direction: 'asc' | 'desc'
  } | null>(null)
  //desktop
  const [currentPage, setCurrentPage] = useState(1)
  const [jobsPerPage, setJobsPerPage] = useState(9)

  const handleSelectAll = (isChecked: boolean) => {
    if (isChecked) {
      const allJobIds = jobList.map((job) => job.id)
      setSelectedJobs(new Set(allJobIds))
      setSelectedJobCount(allJobIds.length)
      setSelectedJobIds(allJobIds)
    } else {
      setSelectedJobs(new Set())
      setSelectedJobCount(0)
      setSelectedJobIds([])
    }
  }

  const handleSelectJob = (id: string) => {
    setSelectedJobs((prevSelected) => {
      const newSelected = new Set(prevSelected)
      if (newSelected.has(id)) {
        newSelected.delete(id)
      } else {
        newSelected.add(id)
      }
      const selectedIdsArray = Array.from(newSelected)
      setSelectedJobCount(selectedIdsArray.length)
      setSelectedJobIds(selectedIdsArray)

      return newSelected
    })
  }

  const handleSort = (key: keyof Jobs) => {
    setSortConfig((prevSort) => {
      if (prevSort && prevSort.key === key) {
        return { key, direction: prevSort.direction === 'asc' ? 'desc' : 'asc' }
      }
      return { key, direction: 'asc' }
    })
  }

  const sortedJobs = useMemo(() => {
    if (!sortConfig) return jobList
    return [...jobList].sort((a, b) => {
      if (a[sortConfig.key] < b[sortConfig.key])
        return sortConfig.direction === 'asc' ? -1 : 1
      if (a[sortConfig.key] > b[sortConfig.key])
        return sortConfig.direction === 'asc' ? 1 : -1
      return 0
    })
  }, [jobList, sortConfig])

  const filteredJobs = useMemo(() => {
    return sortedJobs.filter((job) =>
      job.perfil.toLowerCase().includes(searchTerm.toLowerCase()),
    )
  }, [sortedJobs, searchTerm])

  const paginatedJobs = useMemo(() => {
    const startIdx = (currentPage - 1) * jobsPerPage
    return filteredJobs.slice(startIdx, startIdx + jobsPerPage)
  }, [filteredJobs, currentPage, jobsPerPage])

  const totalPages = Math.ceil(filteredJobs.length / jobsPerPage)

  const handleDeleteJob = (idOrIds) => {
    const idsToDelete = Array.isArray(idOrIds) ? idOrIds : [idOrIds]

    const updatedJobs = jobList.filter((job) => !idsToDelete.includes(job.id))
    setJobList(updatedJobs)

    const newSelectedJobs = new Set(selectedJobs)
    idsToDelete.forEach((id) => newSelectedJobs.delete(id))
    setSelectedJobs(newSelectedJobs)
    setSelectedJobCount(newSelectedJobs.size)
    setSelectedJobIds(Array.from(newSelectedJobs))
  }

  const openDeleteModal = (idOrIds) => {
    setItemToDelete(idOrIds)
    setShowModal(true)
  }

  const confirmDelete = () => {
    if (itemToDelete) {
      handleDeleteJob(itemToDelete)
    }
    setShowModal(false)
    setItemToDelete(null)
  }

  const handleDeleteSelected = () => {
    openDeleteModal(selectedJobIds)
  }

  const getArrowColor = (key: keyof Jobs, direction: 'asc' | 'desc') => {
    return sortConfig?.key === key && sortConfig?.direction === direction
      ? 'text-blue-500'
      : 'text-gray-400'
  }

  const getStatusColor = (status) => {
    switch (status) {
      case 'Postulado':
        return 'bg-[#16A34A] text-[#EFF6FF]'
      case 'En proceso':
        return 'bg-[#F59E0B] text-[#EFF6FF]'
      case 'Finalizado':
        return 'bg-[#EF4444] text-[#EFF6FF]'
      case 'Entrevista':
        return 'bg-yellow-100 text-yellow-800'
      case 'Oferta':
        return 'bg-pink-100 text-pink-800'
      default:
        return 'bg-gray-100 text-gray-800'
    }
  }
  // For mobile

  const itemsPerPageMobil = 5
  const currentPageMobil = parseInt(searchParams.get('page') || '1', 10)

  const currentData = jobList.slice(
    (currentPageMobil - 1) * itemsPerPageMobil,
    currentPageMobil * itemsPerPageMobil,
  )
  const handlePageChange = (page) => {
    setSearchParams({ page: page.toString() })
  }

  return (
    <div className="">
      {/* Vista de escritorio */}
      <div className="flex xs:flex-col sm:flex-row justify-between items-start xs:mb-2 sm:mb-10 xs:gap-5 sm:gap-0">
        <h2 className="text-3xl font-semibold text-[#020617]">
          Mis postulaciones
        </h2>
        <div className="flex items-center gap-3 justify-between xs:w-full sm:w-fit">
          <div className="relative">
            <input
              type="text"
              placeholder="Buscar"
              className="border w-[264px] h-[40px] rounded-lg focus:outline-none py-2.5 px-3"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <button className="text-[#020617] py-2 px-3 text-sm font-medium rounded-full border border-[#E2E8F0] flex items-center gap-2">
            <ListFilter className="text-[#2563EB] size-4" />
            Filtros
          </button>
          <button className="xs:hidden sm:flex items-center gap-2 h-[40px] bg-[#2563EB] text-sm font-medium text-[#EFF6FF] rounded-full py-2 px-3">
            <IconDownload stroke={2} className="size-4 text-[#EFF6FF]" />
            Descargar
          </button>
        </div>
      </div>
      <div className="xs:mt-6 sm:mt-3 xs:mb-3 sm:mb-6 flex justify-between items-center">
        <span>Empleos postulados: {jobList.length}</span>
        {selectedJobIds.length > 0 && (
          <button
            className="flex items-center justify-center border border-[#E2E8F0] py-1.5 px-3 text-[#020617] font-medium text-sm rounded-full"
            // onClick={() => handleDeleteJob(selectedJobIds)}
            onClick={handleDeleteSelected}
          >
            Eliminar postulación
          </button>
        )}
      </div>
      <div className="hidden md:block">
        <div className="w-full border border-[#E2E8F0] rounded-2xl p-2">
          <table className="bg-white min-w-full ">
            <thead className="h-12 w-full">
              <tr>
                <th className="p-2">
                  <input
                    type="checkbox"
                    checked={selectedJobs.size === jobList.length}
                    onChange={(e) => handleSelectAll(e.target.checked)}
                  />
                </th>
                <th className="p-2 text-start text-sm font-medium text-[#64748B]"></th>
                <th
                  className="p-2 cursor-pointer text-start text-sm font-medium text-[#64748B]"
                  onClick={() => handleSort('perfil')}
                >
                  Perfil
                </th>
                <th className="p-2">
                  <div className="flex items-center gap-1">
                    <span className="text-sm font-medium text-[#64748B]">
                      Empresa
                    </span>
                    <button
                      onClick={() => handleSort('empresa')}
                      className="flex relative"
                    >
                      <MoveUp
                        className={`${getArrowColor('empresa', 'asc')} absolute left-2`}
                        size={14}
                        strokeWidth={1.5}
                      />
                      <MoveDown
                        className={getArrowColor('empresa', 'desc')}
                        size={14}
                        strokeWidth={1.5}
                      />
                    </button>
                  </div>
                </th>
                <th className="p-2">
                  <div className="flex items-center gap-1">
                    <span className="text-sm font-medium text-[#64748B]">
                      Estatus
                    </span>
                    <button
                      onClick={() => handleSort('status')}
                      className="flex relative"
                    >
                      <MoveUp
                        className={`${getArrowColor('status', 'asc')} absolute left-2`}
                        size={14}
                        strokeWidth={1.5}
                      />
                      <MoveDown
                        className={getArrowColor('status', 'desc')}
                        size={14}
                        strokeWidth={1.5}
                      />
                    </button>
                  </div>
                </th>
                <th className="p-2 text-start text-sm font-medium text-[#64748B]">
                  Salario
                </th>
                <th className="p-2 text-start text-sm font-medium text-[#64748B]">
                  Tipo
                </th>
                <th className="p-2 text-start text-sm font-medium text-[#64748B]">
                  Fecha
                </th>
                <th className="p-2 text-start text-sm font-medium text-[#64748B]"></th>
              </tr>
            </thead>
            <tbody>
              {paginatedJobs.map((job) => (
                <tr
                  key={job.id}
                  className="border-t border-[#E2E8F0] h-14 text-sm font-normal hover:bg-[#DBEAFE80]"
                >
                  <td className="p-2 text-center">
                    <input
                      type="checkbox"
                      checked={selectedJobs.has(job.id)}
                      onChange={() => handleSelectJob(job.id)}
                    />
                  </td>
                  <td className="p-2">
                    <img src={logoInter} className="size-10" alt="logo" />
                  </td>
                  <td className="p-2">
                    <button
                      onClick={() =>
                        navigate('/applicants/offers/:offerId/detail')
                      }
                    >
                      {job.perfil}
                    </button>
                  </td>
                  <td className="p-2">{job.empresa}</td>
                  <td className="p-2">
                    <span
                      className={`h-6 w-fit rounded-full py-1 px-2.5 text-xs font-semibold ${getStatusColor(job.status)}`}
                    >
                      {job.status}
                    </span>
                  </td>
                  <td className="p-2">
                    {job.salario === 0 ? '-' : job.salario.toLocaleString()}
                  </td>
                  <td className="p-2">{job.tipo}</td>
                  <td className="p-2">{job.fecha}</td>
                  <td className="p-2">
                    <Trash
                      size={16}
                      className="text-[#DC2626] cursor-pointer"
                      strokeWidth={1.5}
                      // onClick={() => handleDeleteJob(job.id)}
                      onClick={() => openDeleteModal(job.id)}
                    />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="flex justify-between items-center mt-6">
          <div>
            <span className="text-xsm text-[#64748B]">{`${selectedJobCount} de ${jobList.length} fila(s) seleccionada(s)`}</span>
          </div>
          <div className="flex gap-7">
            <div className="flex text-sm text-[#020617] font-medium items-center gap-2">
              <span>Filas por página</span>
              <div className="w-[72px] h-[36px]">
                <Input
                  type="number"
                  value={jobsPerPage}
                  onChange={(e) => setJobsPerPage(Number(e.target.value))}
                  min={8}
                  max={jobList.length}
                />
              </div>
            </div>
            <div className="flex items-center">
              <span className="text-sm text-[#020617] font-medium">{`Página ${currentPage} de ${totalPages}`}</span>
            </div>
            <div className="flex gap-2 items-center">
              <button
                onClick={() => setCurrentPage(1)}
                className="border border-[#E2E8F0] rounded-full size-8 flex items-center justify-center"
                disabled={currentPage === 1}
              >
                <ChevronsLeft
                  size={16}
                  className="text-[#2563EB]"
                  strokeWidth={1.5}
                />
              </button>
              <button
                onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
                disabled={currentPage === 1}
                className="border border-[#E2E8F0] rounded-full size-8 flex items-center justify-center"
              >
                <ChevronLeft
                  size={16}
                  className="text-[#2563EB]"
                  strokeWidth={1.5}
                />
              </button>
              <button
                onClick={() =>
                  setCurrentPage((prev) => Math.min(prev + 1, totalPages))
                }
                disabled={currentPage === totalPages}
                className="border border-[#E2E8F0] rounded-full size-8 flex items-center justify-center"
              >
                <ChevronRight
                  size={16}
                  className="text-[#2563EB]"
                  strokeWidth={1.5}
                />
              </button>
              <button
                onClick={() => setCurrentPage(totalPages)}
                disabled={currentPage === totalPages}
                className="border border-[#E2E8F0] rounded-full size-8 flex items-center justify-center"
              >
                <ChevronsRight
                  size={16}
                  className="text-[#2563EB]"
                  strokeWidth={1.5}
                />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Vista móvil */}
      <div className="md:hidden">
        <div className="grid grid-cols-1 gap-4 md:hidden">
          {currentData.map((job, index) => (
            <div
              key={index}
              className="bg-white rounded-2xl border border-[#E2E8F0] p-4 flex flex-col gap-3"
            >
              <div className="relative flex gap-4">
                <div>
                  <img src={logoInter} className="size-10" alt="logo" />
                </div>
                <div className="text-[#020617] flex flex-col">
                  <span className="text-lg font-semibold">{job.perfil}</span>
                  <span>{job.empresa}</span>
                  <div
                    className={`mt-2 h-6 w-fit rounded-full py-1 px-2.5 text-xs font-semibold ${getStatusColor(job.status)}`}
                  >
                    {job.status}
                  </div>
                </div>
                <div className="absolute top-0 right-0">
                  <Trash
                    size={16}
                    className="text-[#DC2626]"
                    strokeWidth={1.5}
                    onClick={() => openDeleteModal(job.id)}
                  />
                </div>
              </div>
              <div>
                <span className="text-sm font-medium text-[#020617]">
                  {`${job.tipo} (${job.city})`}
                </span>
              </div>
            </div>
          ))}
        </div>
        <Pagination
          currentPage={currentPageMobil}
          totalItems={jobList ? jobList.length : 2}
          itemsPerPage={itemsPerPageMobil}
          onPageChange={handlePageChange}
          className="py-7"
        />
      </div>
      <AlertDialog open={showModal} onOpenChange={setShowModal}>
        <AlertDialogTrigger className="hidden" />
        <AlertDialogContent className="xs:max-w-[320px] sm:max-w-[430px]">
          <div className="flex flex-col gap-3 relative">
            <div className="absolute -top-2 -right-2">
              <button className="bg-[#DBEAFE] rounded-full size-7 p-1.5">
                <X
                  size={16}
                  strokeWidth={1.5}
                  className="text-[#2563EB]"
                  onClick={() => setShowModal(false)}
                />
              </button>
            </div>
            <h1 className="text-2xl text-[#020617] font-semibold">
              Eliminar postulación
            </h1>
            <p className="text-sm text-[#64748B]">
              Ten en cuenta que si eliminas tu postulación, tendrás que postular
              nuevamente.
            </p>
            <div className="flex xs:flex-col sm:flex-row xs:gap-2 sm:gap-0 justify-between mt-6 w-full">
              <button
                className="border border-[#E2E8F0] flex items-center justify-center py-2 px-3 rounded-full text-[#020617] text-xsm font-medium h-10 xs:w-full sm:w-auto"
                onClick={() => {
                  setShowModal(false)
                }}
              >
                Cancelar
              </button>
              <button
                className="bg-[#2563EB] flex items-center justify-center py-2 px-3 rounded-full text-[#EFF6FF] text-xsm font-medium h-10 xs:w-full sm:w-[86px]"
                onClick={confirmDelete}
              >
                Eliminar
              </button>
            </div>
          </div>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}

export default MyApplications
