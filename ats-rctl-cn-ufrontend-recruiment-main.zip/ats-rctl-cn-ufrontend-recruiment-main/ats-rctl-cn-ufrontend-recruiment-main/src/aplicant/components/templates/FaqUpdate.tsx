import { useState } from 'react'
import { Link } from 'react-router-dom'
import { IconChevronLeft, IconX } from '@tabler/icons-react'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'

export default function FaqUpdate() {
  const [subject, setSubject] = useState('')
  const [inquiryType, setInquiryType] = useState('')
  const [inquiry, setInquiry] = useState('')
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [ticketId, setTicketId] = useState('')

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Eliminar el console.log para evitar el error de ESLint
    // console.log({ subject, inquiryType, inquiry })

    // Generar un ID de ticket aleatorio
    const newTicketId =
      'N' +
      Math.floor(Math.random() * 1000000000)
        .toString()
        .padStart(9, '0')
    setTicketId(newTicketId)
    setIsModalOpen(true)
  }

  const closeModal = () => {
    setIsModalOpen(false)
    // Resetear los campos del formulario
    setSubject('')
    setInquiryType('')
    setInquiry('')
  }

  return (
    <div className="max-w-[1180px] mx-auto p-4 md:p-6 font-inter">
      <div className="mb-6">
        <Link
          to="http://localhost:9000/recruitment/applicants/faq/ticket"
          className="flex items-center text-sm text-gray-600"
        >
          <IconChevronLeft className="w-4 h-4 mr-1" />
          <span>Regresar a mis tickets</span>
        </Link>
      </div>

      <h1 className="text-xl md:text-2xl font-bold mb-4">Crear nuevo ticket</h1>

      <div className="bg-white rounded-lg shadow-sm p-4 md:p-6 w-full max-w-[1180px]">
        <h2 className="text-lg font-semibold mb-2">
          ¿Necesitas ayuda personalizada?
        </h2>
        <p className="text-gray-600 mb-6">
          Genera un Ticket con tu consulta, y nosotros te responderemos en el
          menor tiempo posible
        </p>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="flex xs:flex-col md:flex-row gap-4">
            <Input
              type="text"
              placeholder="Asunto"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              className="w-full md:w-[901px] h-[37px]"
            />
            <Select value={inquiryType} onValueChange={setInquiryType}>
              <SelectTrigger className="md:w-[189px] h-[37px]">
                <SelectValue placeholder="Elige el tipo de consulta" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="general">Consulta General</SelectItem>
                <SelectItem value="technical">Problema Técnico</SelectItem>
                <SelectItem value="billing">Facturación</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Textarea
              placeholder="Escriba aquí su consulta"
              value={inquiry}
              onChange={(e) => setInquiry(e.target.value)}
              className="w-full h-[146px]"
            />
          </div>

          <div className="flex justify-end">
            <Button
              type="submit"
              className="bg-[#263658] text-white hover:bg-[#1e2a45] w-[85px] h-[35px]"
            >
              Enviar
            </Button>
          </div>
        </form>
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-[11px] w-full max-w-[486px] h-auto md:h-[239px] p-6 relative">
            <button
              onClick={closeModal}
              className="absolute top-2 right-2 text-gray-500 hover:text-gray-700"
            >
              <IconX size={20} />
            </button>
            <h2 className="text-xl font-bold mb-4 text-center text-secondary-500 mt-4">
              ¡Ticket enviado con éxito!
            </h2>
            <p className="text-center mb-2">Ticket ID: {ticketId}</p>
            <p className="text-center text-sm text-secondary-500 mb-6">
              Puedes realizar el seguimiento y ver las actualizaciones del
              estado de tu ticket en la sección "Ver mis tickets".
            </p>
            <div className="flex justify-center">
              <Button
                onClick={closeModal}
                className="bg-secondary-500 text-white hover:bg-secondary-600 w-full md:w-[160px] h-[37px] rounded-[8px]"
              >
                Ok
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
