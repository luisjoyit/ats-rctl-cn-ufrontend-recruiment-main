import CardAnimatedBorderGradient from '@/components/ui/CardPulseBorder'
import { Button } from '@/components/ui/button'
import { useEffect, useState } from 'react'
import { IconLink } from '@tabler/icons-react'
import { Link } from 'react-router-dom'
import AddFormMyPortfolio from '../organism/SectionsMyProfile/Forms/AddFormMyPortfolio'

export interface IProjects {
  id: number
  name: string
  year: string
  description: string
  img: string
  linkProject: string
  linkRepo: string
}

const dataProjects: IProjects[] = [
  {
    id: 1,
    name: 'ATS UX/UI Project 1',
    year: '2023',
    description:
      'Enfoque centrado en el usuario para optimizar la navegación, simplificar el proceso de solicitud y mejorar la interacción general del usuario con la plataforma.',
    img: 'https://mariosc21.github.io/myPortfolio/assets/cochera2.png',
    linkProject:
      'http://localhost:9000/recruitment/applicants/candidate/myProfile',
    linkRepo:
      'http://localhost:9000/recruitment/applicants/candidate/myProfile',
  },
]

const dataInitial: IProjects = {
  id: -1,
  name: '',
  year: '',
  description: '',
  img: '',
  linkProject: '',
  linkRepo: '',
}

export default function MyPortfolio() {
  const [projects, setProjects] = useState<IProjects[]>(dataProjects)
  const [extendCard, setExtendCard] = useState<{ [key: number]: boolean }>({})

  useEffect(() => {
    if (projects.length === 0) {
      setProjects([dataInitial])
      setExtendCard({ [dataInitial.id]: false })
    }
  }, [projects])

  const toogleExtendCard = (id: number) => {
    setExtendCard((prevState) => ({
      ...prevState,
      [id]: !prevState[id],
    }))
  }

  const addProject = () => {
    const idGenerator = Date.now() + Math.floor(Math.random() * 1000)
    const newProject = { ...dataInitial, id: idGenerator }
    setProjects((prevProjects) => [
      ...prevProjects,
      { ...newProject }, // Añade un nuevo projecto con los valores por defecto
    ])
    setExtendCard((prevState) => ({
      ...prevState,
      [newProject.id]: true,
    }))
  }

  const deleteProject = (id: number) => {
    setProjects((prevProjects) =>
      prevProjects.filter((project) => project.id !== id),
    )
  }

  const saveProject = (updateProject: IProjects) => {
    setProjects((prevProjects) => {
      const projectExists = prevProjects.some(
        (proj) => proj.id === updateProject.id,
      )
      if (projectExists) {
        return prevProjects.map((proj) =>
          proj.id === updateProject.id ? updateProject : proj,
        )
      } else {
        return [...prevProjects, updateProject]
      }
    })
  }

  return (
    <main className="grid xs:grid-cols-1 sm:grid-cols-2 lg:grid-cols-[497px_1fr] gap-12 justify-between min-h-screen">
      <section className="flex flex-col gap-4 text-secondary-500 font-inter">
        <header className="flex flex-col gap-3">
          <button className="bg-[#E9EAF5] h-[23px] w-[101px] rounded-[30px] text-xs cursor-pointer">
            <Link to="/applicants/candidate/myProfile">Volver</Link>
          </button>
          <h1 className="font-medium mt-3 dark:text-white">Mi Portafolio</h1>
          <p className="text-xs dark:text-white">
            Personaliza tu portafolio con descripciones, imágenes y enlaces para
            destacar tu trabajo de manera impactante. Recuerda que tu portafolio
            se integrará en tu CV descargable.
          </p>
        </header>
        {projects?.map((proj, id) => (
          <AddFormMyPortfolio
            key={id}
            dataProject={proj}
            extendCard={!!extendCard[proj.id]}
            setExtendCard={toogleExtendCard}
            deleteProject={deleteProject}
            saveProject={saveProject}
          />
        ))}
        <Button
          variant="link"
          className="text-primary px-2 py-0 justify-start"
          onClick={addProject}
        >
          + Añade un proyecto
        </Button>
      </section>

      <section className="flex flex-col gap-4 text-secondary-500 font-inter">
        <h1 className="font-medium">Vista Previa</h1>
        <CardAnimatedBorderGradient className="h-[90%]">
          {dataProjects.length > 0 ? (
            dataProjects.map((project, id) => (
              <div
                key={id}
                className="bg-backgroundF dark:bg-[#F7FAFF] rounded-2xl grid xs:grid-cols-1 lg:grid-cols-[274px_1fr] p-4 gap-7"
              >
                <div className="h-[157px] w-full rounded-2xl bg-backgroundF-500">
                  <img
                    src={project.img}
                    alt=""
                    className="object-cover h-full w-full rounded-xl"
                  />
                </div>
                <div className="grid gap-3">
                  <div className="flex flex-col font-medium">
                    <span>{project.name}</span>
                    <span>{project.year}</span>
                  </div>
                  <p className="text-xs">{project.description}</p>
                  <div className="flex gap-4">
                    <Button
                      variant="primary"
                      size="sm"
                      icon={<IconLink className="rotate-45" />}
                      iconPosition="right"
                      className="w-auto"
                    >
                      Ver
                    </Button>
                    <Button
                      variant="primary"
                      size="sm"
                      icon={<IconLink className="rotate-45" />}
                      iconPosition="right"
                      className="w-auto"
                    >
                      Github
                    </Button>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="bg-backgroundF dark:bg-[#F7FAFF] rounded-2xl grid xs:grid-cols-1 sm:grid-cols-[274px_1fr] p-4 gap-7">
              <div className="h-[157px] w-full rounded-2xl bg-backgroundF-500"></div>
              <div>
                <span className="text-[15px]">(No Especificado)</span>
              </div>
            </div>
          )}
        </CardAnimatedBorderGradient>
      </section>
    </main>
  )
}
