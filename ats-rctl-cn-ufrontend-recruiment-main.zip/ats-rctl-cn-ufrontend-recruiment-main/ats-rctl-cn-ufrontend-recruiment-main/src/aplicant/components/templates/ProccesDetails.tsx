import { IconUserFilled, IconArrowUpRight } from '@tabler/icons-react'

export default function ProccesDetails() {
  return (
    <div>
      <div className="flex items-center font-inter">
        <h1 className="font-bold text-2xl text-[#263658]">Backend Developer</h1>
        <button className="ml-8 w-[107px] h-[22px] rounded-[30px] bg-[#F1F5F8] text-sm text-[#263658] flex items-center">
          Ver Empleo
          <IconArrowUpRight className="ml-1" stroke={1} />
        </button>
      </div>
      <h2 className="text-xs">Accenture - Postulado Feb 02, 14:50 pm</h2>
      <div className="flex mt-14 space-x-28 items-center">
        <div className="flex flex-col items-center justify-center w-[250px] h-[212px] rounded-[10px] bg-white">
          <div className="w-[55.68px] h-[55.68px] rounded-full bg-[#FC8862] mb-1"></div>
          <h3 className="text-xs">Postulado</h3>
        </div>
        <div className="flex flex-col items-center">
          <div className="w-[55.68px] h-[55.68px] rounded-full bg-gray-300 mb-1"></div>
          <h3 className="text-xs">Visto</h3>
        </div>
        <div className="flex flex-col items-center">
          <div className="w-[55.68px] h-[55.68px] rounded-full bg-gray-300 mb-1"></div>
          <h3 className="text-xs">Contactado</h3>
        </div>
        <div className="flex flex-col items-center">
          <div className="w-[55.68px] h-[55.68px] rounded-full bg-gray-300 mb-1"></div>
          <h3 className="text-xs">Oferta</h3>
        </div>
        {/* Ajuste del margen superior para subir la nueva card */}
        <div className="w-[268px] h-[198px] rounded-[30px] bg-white flex flex-col justify-center items-center relative mt-[-50px] transform translate-x-[-40px]">
          <IconUserFilled
            className=" text-[#263658] absolute top-0 mt-8"
            stroke={2}
            size={28}
          />
          <p className="text-6xl text-[#263658] font-medium mt-9">48</p>
          <p className="text-lg text-[#263658]">Postulados</p>
        </div>
      </div>
      {/* Nueva card debajo de los círculos */}
      <div className="w-[719px] h-[440px] rounded-[10px] bg-white mt-[-50px]"></div>
    </div>
  )
}
