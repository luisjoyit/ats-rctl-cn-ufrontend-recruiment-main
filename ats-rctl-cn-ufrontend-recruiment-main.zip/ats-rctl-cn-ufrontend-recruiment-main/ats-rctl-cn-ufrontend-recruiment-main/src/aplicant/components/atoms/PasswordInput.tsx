import { Button } from '@/components/ui/button'
import { Input, InputProps } from '@/components/ui/input'
import { IconEye, IconEyeClosed } from '@tabler/icons-react'
import { useState } from 'react'

export default function PasswordInput(props: InputProps) {
  const [showPassword, setShowPassword] = useState(false)

  const togglePasswordVisibility = () => {
    setShowPassword((prevShowPassword) => !prevShowPassword)
  }

  const passwordSuffix = (
    <Button
      className="rounded-full bg-accent-100 m-0 px-[5px] size-6 mx-2 w-auto hover:bg-accent-100"
      onClick={togglePasswordVisibility}
    >
      {showPassword ? (
        <IconEyeClosed stroke={1.5} size={16} className="text-secondary-500" />
      ) : (
        <IconEye stroke={1.5} size={16} className="text-secondary-500" />
      )}
    </Button>
  )

  return (
    <Input
      type={showPassword ? 'text' : 'password'}
      placeholder="Contraseña"
      suffix={passwordSuffix}
      {...props}
    />
  )
}
