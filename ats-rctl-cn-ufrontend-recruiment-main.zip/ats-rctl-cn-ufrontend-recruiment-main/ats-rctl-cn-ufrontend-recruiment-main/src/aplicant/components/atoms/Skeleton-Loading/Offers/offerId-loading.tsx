import { Skeleton } from '@/components/ui/skeleton'

export default function OfferIdLoading() {
  return (
    <div className="flex flex-col space-y-3">
      <Skeleton className="h-[125px] min-w-full max-w[480px] 2xl:min-w-[480px] rounded-xl bg-slate-200" />
      <Skeleton className="h-[125px] min-w-full max-w[480px] 2xl:min-w-[480px] rounded-xl bg-slate-200" />
      <Skeleton className="h-[125px] min-w-full max-w[480px] 2xl:min-w-[480px] rounded-xl bg-slate-200" />
      <Skeleton className="h-[125px] min-w-full max-w[480px] 2xl:min-w-[480px] rounded-xl bg-slate-200" />
      <Skeleton className="h-[125px] min-w-full max-w[480px] 2xl:min-w-[480px] rounded-xl bg-slate-200" />
      <Skeleton className="h-[125px] min-w-full max-w[480px] 2xl:min-w-[480px] rounded-xl bg-slate-200" />
    </div>
  )
}
