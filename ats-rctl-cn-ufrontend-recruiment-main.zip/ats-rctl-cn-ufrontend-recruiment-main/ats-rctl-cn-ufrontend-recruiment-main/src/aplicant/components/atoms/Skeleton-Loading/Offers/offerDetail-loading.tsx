import { Skeleton } from '@/components/ui/skeleton'

export default function OfferDetailLoading() {
  return (
    <Skeleton className="min-w-full max-w-[706px] 2xl:min-w-[706px] min-h-[820px] max-h-[889px] 2xl:h-[889px] rounded-xl bg-slate-200" />
  )
}
