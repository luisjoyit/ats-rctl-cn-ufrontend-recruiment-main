import React, { useEffect, useState } from 'react'

import { Button } from '@/components/ui/button'
import {
  Command,
  CommandGroup,
  CommandItem,
  CommandList,
} from '@/components/ui/command'
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover'
import {
  IconChevronDown,
  IconSquare,
  IconSquareCheckFilled,
} from '@tabler/icons-react'

// @ts-ignore
import { t, useLanguage } from '@joyit/layout'

interface ComboBoxProps {
  items: Array<{ [key: string]: any }>
  defaultValue: string | number
  onChange:
    | ((value: string) => void)
    | ((value1: string, value2: string) => void)
  uncheck?: boolean
  placeholder?: string
  style?: string
  small?: boolean
  width?: string
  name?: string
}

export function Combobox({
  items,
  defaultValue,
  onChange,
  uncheck,
  placeholder,
  style,
  small,
  width,
  name,
}: ComboBoxProps) {
  const [open, setOpen] = useState(false)
  const [value, setValue] = useState(defaultValue)

  const { language } = useLanguage()

  useEffect(() => {
    setValue(defaultValue)
  }, [defaultValue, language])

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          role="combobox"
          aria-expanded={open}
          className={`bg-[#E9EAF5] text-[#263658] 
                        xs:text-xs sm:text-sm rounded-[30px]
                        border-1 border-[#E9EAF5] outline-none justify-around
                        h-[29px] font-inter 
                        ${style ? style : 'p-1.5'} 
                        ${small && 'w-20'}
                        ${width ? width : 'xs:w-24 sm:w-36'}
                    `}
        >
          {value ? value : placeholder}
          <IconChevronDown stroke={1.5} width={18} height={18} />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="min-w-[200px] max-w-auto p-0">
        <Command>
          <CommandList>
            <CommandGroup>
              {items.map((element) => (
                <CommandItem
                  key={element.value}
                  value={element.label}
                  onSelect={(currentValue) => {
                    const newValue = currentValue === value ? '' : currentValue
                    setValue(newValue)
                    onChange(newValue === '' ? '0' : element.value, name)
                    setOpen(false)
                  }}
                >
                  {value == element.label ? (
                    <IconSquareCheckFilled
                      stroke={1.5}
                      width={13}
                      height={13}
                      color="#263658"
                    />
                  ) : (
                    <IconSquare stroke={1.5} width={13} height={13} />
                  )}
                  <span className="pl-1 text-[#263658] text-sm font-inter">
                    {element.label}
                  </span>
                </CommandItem>
              ))}
            </CommandGroup>
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  )
}
