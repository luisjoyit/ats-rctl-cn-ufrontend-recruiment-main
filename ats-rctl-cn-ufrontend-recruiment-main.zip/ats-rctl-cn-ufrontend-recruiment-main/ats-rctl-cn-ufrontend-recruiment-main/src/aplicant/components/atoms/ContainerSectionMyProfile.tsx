import { cn } from '@/lib/utils'

interface ContainerSectionMyProfileProps
  extends React.HTMLAttributes<HTMLElement> {}

export default function ContainerSectionMyProfile({
  children,
  className,
  ...props
}: ContainerSectionMyProfileProps) {
  return (
    <article className={cn('grid gap-3', className)} {...props}>
      {children}
    </article>
  )
}
