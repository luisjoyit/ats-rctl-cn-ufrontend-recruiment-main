interface AccordionTittleContentProps {
  title: string
  subtitle: string
}

export default function AccordionTittleContent({
  title,
  subtitle,
}: AccordionTittleContentProps) {
  return (
    <p className="flex flex-col text-start">
      <span className="font-normal">{title}</span>
      <span className="opacity-55 text-sm">{subtitle}</span>
    </p>
  )
}
