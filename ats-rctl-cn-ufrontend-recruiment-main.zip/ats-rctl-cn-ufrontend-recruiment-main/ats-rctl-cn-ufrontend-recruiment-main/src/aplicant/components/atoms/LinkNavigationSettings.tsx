import useMediaQuery from '@/hooks/useMediaQuery'
import { cn } from '@/lib/utils'
import { Link } from 'react-router-dom'

interface LinkNavigationSettingsProps {
  title: string
  url: string
  shortTitle: string
  description?: string
  textColor: string
  textSize: string
  textWeight: string
  underlineThickness: string
  isSelected: boolean
  icon: React.ReactNode
}

export default function LinkNavigationSettings({
  title,
  url,
  shortTitle,
  description,
  textColor,
  textSize,
  textWeight,
  underlineThickness,
  isSelected,
  icon,
}: LinkNavigationSettingsProps) {
  // Estilos para el contenedor que incluye el potencial subrayado
  const containerStyles = cn('inline-block pb-4', {
    textColor,
    textSize,
    textWeight,
  })

  const isDesktop = useMediaQuery('(min-width: 768px)')

  return (
    <div className="flex xs:text-center md:text-start pb-5">
      <Link
        to={url}
        className={`${containerStyles} xs:h-[50px] md:h-auto`}
        style={{
          borderBottom: isSelected ? `${underlineThickness} solid` : 'none',
          paddingBottom: isSelected ? (isDesktop ? '15px' : '0px') : '16px',
        }}
      >
        {isDesktop ? (
          <>
            <h1 className="font-semibold">{title}</h1>
            <p className="text-sm">{description}</p>
          </>
        ) : (
          <div className="flex flex-col items-center gap-1">
            <div>{icon}</div>
            <span className="text-xs">{shortTitle}</span>
          </div>
        )}
      </Link>
    </div>
  )
}
