import React from 'react'
// @ts-ignore
import { t, useLanguage } from '@joyit/layout'
import { IconUserCheck } from '@tabler/icons-react'

const GraficInterviews: React.FC = () => {
  const { language } = useLanguage()

  return (
    <div className="bg-[#EFF6FF] rounded-2xl xs:px-4 xs:py-2 sm:p-4 font-inter flex flex-col justify-between w-full h-full">
      <div className="size-12 bg-[#BFDBFE] rounded-full p-3">
        <IconUserCheck stroke={1.5} className="text-[#2563EB]" />
      </div>
      <div className="flex flex-col text-[#020617]">
        <span>Número de postulaciones</span>
        <span className="text-[32px] font-bold">32</span>
      </div>
    </div>
  )
}

export default GraficInterviews
