import { Button } from '@/components/ui/button'
import imgPotenciaIA from '../../../../public/ImgPotenciaIA.png'
function CardPotenciaIA() {
  return (
    <div className="w-full flex flex-wrap gap-10 bg-primary-foreground rounded-[11px] xs:px-6 xl:px-12 py-8 drop-shadow-md shadow-[0px_0px_3px_0px_#00000040] font-inter">
      <div className="flex items-center">
        <img src={imgPotenciaIA} alt="" className="object-cover" />
      </div>
      <div className="flex flex-col flex-1 gap-2 justify-between text-secondary-500">
        <div>
          <h1 className="font-medium text-base-">¡Nuevo!</h1>
          <h2 className="font-bold text-xl">Potencia tu perfil con IA</h2>
        </div>
        <p className="font-normal text-xs">
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Quibusdam,
          in? Libero omnis a animi! Doloremque repellendus illo sunt culpa
          optio. Veniam id totam, incidunt libero culpa quam in eum enim.
        </p>
        <Button variant="primary" size="sm" className="w-[102px]">
          Importar CV
        </Button>
      </div>
    </div>
  )
}
export default CardPotenciaIA
