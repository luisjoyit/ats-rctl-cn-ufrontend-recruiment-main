import React from 'react'

interface NotificationProps {
  time: string
  message: string
}

const Notification: React.FC<NotificationProps> = ({ time, message }) => {
  return (
    <div className="bg-[#E7F0FF] p-4 rounded-lg mb-4">
      <div className="flex items-center">
        <div className="text-sm text-[#263658]">{time}</div>
        <div className="ml-4 text-[#263658]">{message}</div>
      </div>
    </div>
  )
}

interface NotificationsByDateProps {
  date: string
  notifications: NotificationProps[]
}

const Platform_Notifications: React.FC<{
  notificationsByDate: NotificationsByDateProps[]
}> = ({ notificationsByDate }) => {
  return (
    <div className="mt-4 space-y-8 text-[#263658]">
      {notificationsByDate.map(({ date, notifications }, index) => (
        <div key={index} className="mb-8">
          <div className="text-[#263658] mb-2">{date}</div>
          {notifications.map((notification, index) => (
            <Notification
              key={index}
              time={notification.time}
              message={notification.message}
            />
          ))}
        </div>
      ))}
    </div>
  )
}

export default Platform_Notifications
