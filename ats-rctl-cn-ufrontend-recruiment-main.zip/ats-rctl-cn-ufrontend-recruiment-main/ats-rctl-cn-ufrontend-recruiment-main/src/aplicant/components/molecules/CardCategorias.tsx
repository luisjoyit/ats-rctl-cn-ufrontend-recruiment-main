import { Link } from 'react-router-dom'

interface ICardCategorias {
  name: string
  subname: string
  image: string
}
function CardCategorias({ name, subname, image }: ICardCategorias) {
  return (
    <Link
      to={`/recruitment/faq/${name} ${subname}`}
      className="relative grid rounded-[12px] w-full sm:w-36 h-[140.78px] bg-[#E7F0FF] text-left p-10 mt-3 hover:bg-primary"
    >
      <span className="text-2xl">{name}</span>
      <span className="text-2xl ">{subname}</span>
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="rounded-[10px] w-[83px] h-[103.39px] bg-white ml-48 flex items-center justify-center">
          <img src={image} alt="" />
        </div>
      </div>
    </Link>
  )
}

export default CardCategorias
