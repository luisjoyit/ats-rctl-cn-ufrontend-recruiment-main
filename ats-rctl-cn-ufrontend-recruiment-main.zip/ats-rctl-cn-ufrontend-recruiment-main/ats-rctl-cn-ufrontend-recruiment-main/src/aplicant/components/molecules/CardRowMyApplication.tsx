interface ICardRowMyApplication {
  title: string
  companyName: string
  companyImage: string
  workModality: string
  salary: number
  createdAt: string
}

export default function CardRowMyApplication({
  title,
  companyImage,
  companyName,
  createdAt,
  salary,
  workModality,
}: ICardRowMyApplication) {
  return (
    <div className="flex justify-between items-center">
      <div className="flex gap-3  items-center w-72">
        <img
          src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQHvgjyIam1OM06KWMuB0RSeVKV7F8kR95NLbJo19wHjw&s"
          alt=""
          className="h-14 w-14 rounded-full"
        />
        <div className="flex flex-col justify-center font-inter">
          <h1>{title}</h1>
          <span className="text-slate-700/70">{companyName}</span>
        </div>
      </div>

      <div className="flex gap-4 ">
        <span className="p-3 bg-amber-500 text-white rounded-2xl h-4 flex justify-center items-center lowercase">
          Postulado
        </span>
        <span className="p-3 text-black rounded-2xl h-4 flex justify-center items-center lowercase">
          Visto
        </span>
        <span className="p-3 text-black rounded-2xl h-4 flex justify-center items-center lowercase">
          Contactado
        </span>
        <span className="p-3 text-black rounded-2xl h-4 flex justify-center items-center lowercase">
          Oferta
        </span>
      </div>

      <span className="p-3 bg-primary text-white rounded-2xl h-4 flex justify-center items-center lowercase">
        {workModality}
      </span>

      <span className="font-inter text-green-800">${salary}</span>

      {/* formatear fecha  de create at a este formato Feb 02, 14:50 pm*/}
      <span className="font-inter">
        {new Date(createdAt).toLocaleDateString('es-ES', {
          month: 'short',
          day: '2-digit',
          hour: '2-digit',
          minute: '2-digit',
        })}
      </span>
    </div>
  )
}
