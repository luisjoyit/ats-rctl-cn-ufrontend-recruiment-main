import React from 'react'
import discord from '../../../../public/img_testIngles/discord.webp'
import frame from '../../../../public/img_testIngles/discordFrame.webp'
import { toast } from 'sonner'
//@ts-ignore
import { t, useLanguage } from '@joyit/layout'

const DiscordLink: React.FC = () => {
  const handleRedirect = () => {
    toast.info('Serás redirigido a una página externa a la aplicación', {
      duration: 1500,
      position: 'top-center',
    })

    setTimeout(() => {
      window.open('https://discord.com', '_blank')
    }, 1500)
  }

  return (
    <div className="bg-[#5765F2] font-inter rounded-2xl relative overflow-hidden xs:h-[200px] xl:h-full w-full">
      <img
        className="object-cover h-auto xs:w-[200px] sm:w-[290px] absolute right-0 -bottom-8"
        src={frame}
        alt=""
      />
      <div className="absolute xs:p-3 sm:p-8 flex flex-col justify-end h-full gap-5">
        <img src={discord} className="object-cover w-[40px]" alt="" />
        <p className="grid font-semibold text-xl text-[#F8FAFA] gap-1">
          <span>¡Únete a nuestra</span>
          <span>comunidad en Discord!</span>
        </p>
        <button
          onClick={handleRedirect}
          className="rounded-full bg-[#E2E8F0] w-[71px] h-[36px] text-sm font-semibold text-[#020617]"
        >
          {t('dashboard.discord.Vamos')}
        </button>
      </div>
    </div>
  )
}

export default DiscordLink
