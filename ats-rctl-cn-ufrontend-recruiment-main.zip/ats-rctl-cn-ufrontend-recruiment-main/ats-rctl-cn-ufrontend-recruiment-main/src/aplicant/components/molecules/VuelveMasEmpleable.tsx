import { Button } from '@/components/ui/button'

function VuelveMasEmpleable() {
  return (
    <div className="w-full flex xs:flex-col sm:flex-row gap-10 rounded-[11px] md:h-[162px] xs:px-6 xl:px-12 py-8 bg-secondary font-inter justify-between">
      <div className="flex flex-col gap-2 justify-center items-center">
        <h1 className="text-primary-foreground text-2xl">
          Vuelvete más Empleable
        </h1>
        <h2 className=" flex flex-col text-primary-foreground text-left">
          Prueba nuestras evaluaciones
        </h2>
      </div>
      <div className="flex flex-col gap-3 items-center md:items-end justify-center">
        <Button
          variant="primary"
          size="sm"
          className="w-[132px] border border-primary-foreground"
        >
          Coding Challenge
        </Button>
        <Button
          variant="primary"
          size="sm"
          className="w-[132px] border border-primary-foreground"
        >
          Test de ingles
        </Button>
      </div>
    </div>
  )
}

export default VuelveMasEmpleable
