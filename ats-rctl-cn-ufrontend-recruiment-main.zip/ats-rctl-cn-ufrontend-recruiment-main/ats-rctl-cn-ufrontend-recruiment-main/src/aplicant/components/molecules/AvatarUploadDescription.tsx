import AvatarUpload from '@/components/AvatarUpload'

export default function AvatarUploadDescription() {
  const dataGeneral = {
    name: 'Liset del Pilar Cárdenas Charcape',
    profile: 'UX/UI DESIGNER',
  }
  return (
    <div className="flex items-end gap-4">
      <AvatarUpload />
      <div className="flex flex-col pb-3 gap-2 font-inter text-secondary dark:text-white">
        <span className="text-2xl leading-none">{dataGeneral.name}</span>
        <span className="text-sm -mt-1">{dataGeneral.profile}</span>
      </div>
    </div>
  )
}
