interface ICardPreguntasFrecuentes {
  titulo: string
}
function CardPreguntasFrecuentas({ titulo }: ICardPreguntasFrecuentes) {
  return (
    <div className="rounded-[10px] w-[979px] h-[10px] bg-[#E7F0FF] mt-4 p-8 flex items-center font-inter text-black justify-between">
      <h1>{titulo}</h1>

      <svg
        xmlns="http://www.w3.org/2000/svg"
        className="h-6 w-6 transform transition-transform duration-300 text-black rotate-0"
        viewBox="0 0 20 20"
        fill="currentColor"
      >
        <path
          fill-rule="evenodd"
          d="M6.293 7.293a1 1 0 011.414 0L10 9.586l2.293-2.293a1 1 0 111.414 1.414l-3 3a1 1 0 01-1.414 0l-3-3a1 1 0 010-1.414z"
          clip-rule="evenodd"
        />
      </svg>
    </div>
  )
}

export default CardPreguntasFrecuentas
