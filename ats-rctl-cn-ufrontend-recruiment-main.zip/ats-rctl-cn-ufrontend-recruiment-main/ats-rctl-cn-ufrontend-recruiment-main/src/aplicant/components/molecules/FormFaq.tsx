import { Textarea } from '@/components/ui/textarea'
import { Input } from '@/components/ui/input'
//@ts-ignore
import { t, useLanguage } from '@joyit/layout'

function FormFaq() {
  const { handleChangeLanguage } = useLanguage()
  return (
    <div className="mt-10 font-inter font-bold text-black">
      {t('FormFaq.perzonalizada')}
      <div className="font-medium">
        <h1>{t('FormFaq.texto')}</h1>
      </div>
      <div className="rounded-[30px] w-full h-full bg-[#E7F0FF] mt-4 p-8 font-inter text-black ">
        <div className="grid sm:grid-cols-3 items-center gap-5 ">
          <Input
            className=" rounded-[11px]  h-[27px] font-medium hover:outline-none"
            placeholder={t('FormFaq.nombre')}
          />

          <Input
            className=" rounded-[11px]  h-[27px] font-medium hover:outline-none"
            placeholder={t('FormFaq.correo')}
          />

          <Input
            className="rounded-[11px]  h-[27px] font-medium hover:outline-none"
            placeholder={t('FormFaq.consulta')}
          />
        </div>
        <Textarea className="mt-4 font-medium w-full max-h-full sm:w-72" />

        <div className=" flex mt-2 w-full justify-end">
          <button className="rounded-[11px] w-[90px] bg-[#263658] items-center text-white font-medium mr-2">
            {t('FormFaq.enviar')}
          </button>
        </div>
      </div>
    </div>
  )
}
export default FormFaq
