import React from 'react'
import woman from '../../../../public/img_testIngles/woman.webp'
//@ts-ignore
import { t, useLanguage } from '@joyit/layout'
import { Link } from 'react-router-dom'

const EnglishCommunityLink: React.FC = () => {
  return (
    <div className="bg-black font-inter rounded-2xl relative overflow-hidden xs:h-[200px] xl:h-full w-full">
      <img className="object-cover h-full w-full absolute" src={woman} alt="" />
      <div className="absolute xs:p-3 sm:p-8 flex flex-col justify-end h-full gap-5">
        <p className="grid font-semibold text-xl text-[#F8FAFA]">
          <span>{t('dashboard.discord.english.Demuestra')}</span>
          <span>conocimientos en</span>
          <span>Inglés</span>
        </p>
        <Link to="/applicants/candidate/myEvaluations">
          <button className="rounded-full bg-[#FFFFFF] w-[79px] h-[36px] text-[#020617] px-2 py-1.5 text-sm font-semibold border border-[#E2E8F0]">
            {t('dashboard.discord.english.Test')}
          </button>
        </Link>
      </div>
    </div>
  )
}

export default EnglishCommunityLink
