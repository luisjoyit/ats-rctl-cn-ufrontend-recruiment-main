import { Button } from '@/components/ui/button'
import {
  IconAlignLeft,
  IconCalendarEvent,
  IconCopy,
  IconLink,
  IconX,
} from '@tabler/icons-react'
import AcceptInterview from '../organism/AlertDialogs/Calendar/AcceptInterview'
import DeclineInterview from '../organism/AlertDialogs/Calendar/DeclineInterview'
import RescheduleInterview from '../organism/AlertDialogs/Calendar/RescheduleInterview'

// @ts-ignore
import { t, useLanguage } from '@joyit/layout'

function ModalCalendar({ dataInterview, setSelectedEvent, openPopover }) {
  const { handleChangeLanguage } = useLanguage()

  const closePopover = () => {
    setSelectedEvent(null)
    openPopover(false)
  }

  return (
    <div className="flex flex-col font-inter">
      <div className="flex justify-end">
        <IconX
          stroke={1.5}
          className="close cursor-pointer text-secondary-500"
          onClick={closePopover}
        />
      </div>
      <div className="flex flex-col w-full text-secondary-500">
        <div className="flex flex-r w-full mb-4">
          <div className="w-[8%] mr-3">
            <IconCalendarEvent stroke={1.5} width={26} height={26} />
          </div>
          <div className="flex flex-col">
            <h2 className="m-0 text-xl font-bold">
              {t('postulationsCalendar.modalMain.title')}{' '}
              {dataInterview.company}
            </h2>
            <div className="flex flex-col text-xs font-normal">
              <span>Jueves, 09 de mayo</span>
              <span className="pt-1">12:30PM - 1:30PM</span>
            </div>
          </div>
        </div>
        <div className="flex flex-r w-full items-center mb-4">
          <div className="w-[8%] mr-3 cursor-pointer">
            <IconLink stroke={2} width={20} height={20} />
          </div>
          <div className="mr-3">
            <Button className="bg-[#263658] rounded-[30px] text-xs font-medium h-6">
              {t('postulationsCalendar.modalMain.meeting')}
            </Button>
          </div>
          <div className="cursor-pointer">
            <IconCopy stroke={2} width={18} height={18} />
          </div>
        </div>
        <div className="flex flex-r w-full mb-4">
          <div className="w-[8%] mr-3">
            <IconAlignLeft stroke={2} width={20} height={20} />
          </div>
          <div className="w-[92%]">
            <p className="text-xs">
              {dataInterview?.company}{' '}
              {t('postulationsCalendar.modalMain.body')}{' '}
              {dataInterview?.position}
            </p>
          </div>
        </div>
      </div>
      <div className="flex flex-r border-t border-[#D9D9D9] pt-4 pb-2 text-secondary-500 items-center gap-4">
        <span className="font-medium text-sm">
          {t('postulationsCalendar.modalMain.question')}
        </span>
        <AcceptInterview
          eventModalClose={closePopover}
          dataInterview={dataInterview}
        />
        <DeclineInterview
          eventModalClose={closePopover}
          dataInterview={dataInterview}
        />
        <RescheduleInterview
          eventModalClose={closePopover}
          dataInterview={dataInterview}
        />
      </div>
    </div>
  )
}

export default ModalCalendar
