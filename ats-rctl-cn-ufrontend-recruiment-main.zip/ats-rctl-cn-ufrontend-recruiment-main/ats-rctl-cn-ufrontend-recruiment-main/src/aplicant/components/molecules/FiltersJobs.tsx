import { useEffect, useState } from 'react'

// @ts-ignore
import { t, useLanguage } from '@joyit/layout'
import { Button } from '@/components/ui/button'
import InputWithIcon from '@/components/inputWithIcon'
import {
  AlertDialog,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog'
import { Checkbox } from '@/components/ui/checkbox'
import SelectUi from '@/components/SelectUi'
import { Input } from '@/components/ui/input'
import { IconAdjustmentsHorizontal, IconX } from '@tabler/icons-react'
import Slider from 'rc-slider'
import 'rc-slider/assets/index.css'
import FiltersStacks from './FiltersStacks'

type Items = {
  value: string
  label: string
}

interface FiltersJobsProps {
  itemsCategory: Items[]
  itemsLocation: Items[]
  itemsYearsExp: Items[]
  itemsModality: Items[]
  //itemsBenefits: ItemsBenefit[]
  dataFilters: any
  setDataFilters: any
  initialValuesFilters: any
}

export default function FiltersJobs({
  itemsCategory,
  itemsLocation,
  itemsModality,
  itemsYearsExp,
  dataFilters,
  setDataFilters,
  initialValuesFilters,
}: FiltersJobsProps) {
  const { handleChangeLanguage } = useLanguage()

  const [openAlert, setOpenAlert] = useState(false)
  const [sliderKey, setSliderKey] = useState(Date.now())
  const [rangeSalary, setRangeSalary] = useState(dataFilters.salary)

  const handleFiltersChange = (name: string, value: any) => {
    setDataFilters({ ...dataFilters, [name]: value })
    //setFilters({ ...dataFilters, [name]: value })
  }

  const handleRangeSalary = (newRange) => {
    setRangeSalary(newRange)
    setDataFilters((prevState) => ({ ...prevState, salary: newRange }))
  }

  const handleSubmit = () => {
    setOpenAlert(false)
  }

  const cleanFilters = () => {
    setDataFilters(initialValuesFilters)
    setRangeSalary([500, 2500])
    setOpenAlert(false)
  }

  const itemsOrder = [
    {
      value: 'mostRecent',
      label: 'Mas reciente',
    },
    {
      value: 'forMe',
      label: 'Para mí',
    },
    {
      value: 'betterPaid',
      label: 'Mejor remunerado',
    },
    {
      value: 'manyApplications',
      label: 'Mayor número de postulantes',
    },
    {
      value: 'lessApplications',
      label: 'Menor número de postulantes',
    },
  ]

  useEffect(() => {
    //setFilters(dataFilters)
  }, [dataFilters])

  const stackSuggestions = [
    { value: 'html', label: 'HTML' },
    { value: 'javascript', label: 'JavaScript' },
    { value: 'css', label: 'CSS' },
    { value: 'angular', label: 'Angular' },
    { value: 'nodejs', label: 'Node.JS' },
  ]

  return (
    <AlertDialog open={openAlert} onOpenChange={setOpenAlert}>
      <AlertDialogTrigger asChild>
        <Button variant="primary" size="md" className="w-[108px] gap-3">
          <IconAdjustmentsHorizontal stroke={2} size={18} />
          Filtros
        </Button>
      </AlertDialogTrigger>
      <AlertDialogContent style={{ gap: 0 }} className="max-w-[605px]">
        <AlertDialogHeader>
          <div className="flex justify-end">
            <IconX
              stroke={1.5}
              size={20}
              color="#263658"
              className="close text-2xl cursor-pointer"
              onClick={cleanFilters}
            />
          </div>
          <AlertDialogTitle
            className="text-start font-semibold text-secondary-500"
            style={{ marginTop: 0 }}
          >
            {/*t('filterJobs.moreFilters.moreFilters')*/}
            Filtros
          </AlertDialogTitle>
          <AlertDialogDescription className="text-secondary-500 flex flex-col gap-6">
            <div className="flex flex-col gap-3 pt-2">
              <span className="text-start font-medium text-sm">
                Ordenar por
              </span>
              <div className="flex flex-wrap gap-y-3 gap-x-2">
                {itemsOrder.map((item, id) => (
                  <button
                    key={id}
                    className={`h-[31px] w-auto px-3 rounded-[50px] ${dataFilters.order === item.value ? 'bg-secondary-500 text-white' : 'bg-accent-200'}`}
                    onClick={() => handleFiltersChange('order', item.value)}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>
            <div className="flex xs:gap-3 md:gap-6 w-full">
              <div className="flex flex-col gap-3 w-full">
                <span className="text-start font-medium text-sm">
                  Categoría
                </span>
                <SelectUi
                  placeholder="Seleccionar"
                  value={dataFilters.category}
                  onChange={handleFiltersChange}
                  items={itemsCategory}
                  name="category"
                  className="border border-muted-100 xs:w-full md:w-[229px] placeholder:muted-300"
                />
              </div>
              <div className="flex flex-col gap-3 w-full">
                <span className="text-start font-medium text-sm">
                  Ubicación
                </span>
                <InputWithIcon
                  placeholder="Buscar"
                  name="location"
                  value={dataFilters.location}
                  onChange={(name, value) => handleFiltersChange(name, value)}
                  className="xs:w-full lg:w-[229px]"
                  heightInput="h-[31px]"
                />
              </div>
            </div>
            <div className="flex xs:gap-3 md:gap-6 w-full">
              <div className="flex flex-col gap-3 w-full">
                <span className="text-start font-medium text-sm">
                  Nivel de Experiencia
                </span>
                <SelectUi
                  placeholder="Seleccionar"
                  items={[
                    { value: 'trainee', label: 'Trainee' },
                    { value: 'junior', label: 'Junior' },
                    { value: 'semiSenior', label: 'Semi Senior' },
                    { value: 'senior', label: 'Senior' },
                  ]}
                  name="levelExperience"
                  value={dataFilters.levelExperience}
                  onChange={handleFiltersChange}
                  className="border border-muted-100 xs:w-full md:w-[229px]"
                />
              </div>
              <div className="flex flex-col gap-3 w-full">
                <span className="text-start font-medium text-sm">
                  Modalidad
                </span>
                <SelectUi
                  placeholder="Seleccionar"
                  items={itemsModality}
                  name="modality"
                  value={dataFilters.modality}
                  onChange={handleFiltersChange}
                  className="border border-muted-100 xs:w-full md:w-[229px]"
                />
              </div>
            </div>
            <div className="flex flex-col gap-3">
              <span className="text-start font-medium text-sm">Stack Tech</span>
              <FiltersStacks
                name="stackTech"
                value={dataFilters.stackTech}
                onChange={handleFiltersChange}
                suggestions={stackSuggestions}
              />
            </div>
            <div className="flex flex-col gap-3">
              <span className="text-start font-medium text-sm">
                Expectativa Salarial
              </span>
              <div className="flex flex-col gap-4 w-full">
                <Slider
                  key={sliderKey}
                  min={0}
                  max={20000}
                  step={100}
                  range
                  value={rangeSalary}
                  onChange={(newRange) => handleRangeSalary(newRange)}
                  className="slider-salary-job slider-range-filters w-full"
                />
                <div className="flex items-center w-full justify-between">
                  <div className="flex xs:gap-2 md:gap-4 items-center">
                    <span className="text-sm">de</span>
                    <div className="w-[85px]">
                      <Input
                        value={dataFilters.salary[0]}
                        preffix="$"
                        onChange={(e) =>
                          handleRangeSalary([
                            Number(e.target.value),
                            dataFilters.salary[1],
                          ])
                        }
                        className="h-[31px] w-full rounded-[50px]"
                      />
                    </div>
                    <span className="text-sm">a</span>
                    <div className="w-[85px]">
                      <Input
                        value={dataFilters.salary[1]}
                        preffix="$"
                        onChange={(e) =>
                          handleRangeSalary([
                            dataFilters.salary[0],
                            Number(e.target.value),
                          ])
                        }
                        className="h-[31px] w-full rounded-[50px]"
                      />
                    </div>
                  </div>
                  <div className="flex gap-2 items-center">
                    <Checkbox
                      checked={dataFilters.adHonorem}
                      onCheckedChange={(checked) =>
                        handleFiltersChange('adHonorem', checked)
                      }
                      className="mr-1"
                    />
                    <label
                      className={`xs:text-sm md:text-base text-muted-300 md:whitespace-nowrap ${dataFilters.adHonorem && 'text-secondary-500 dark:text-white'}`}
                    >
                      Ad honorem
                    </label>
                  </div>
                </div>
              </div>
            </div>
          </AlertDialogDescription>
        </AlertDialogHeader>
        <div className="flex flex-row justify-around mt-8">
          <Button
            variant="secondary"
            size="sm"
            className="xs:w-24 sm:w-36"
            onClick={cleanFilters}
          >
            {/*t('filterJobs.clean')*/}
            Cancelar
          </Button>
          <Button
            variant="primary"
            size="sm"
            className="xs:w-24 sm:w-36"
            onClick={handleSubmit}
          >
            {t('filterJobs.apply')}
          </Button>
        </div>
      </AlertDialogContent>
    </AlertDialog>
  )
}
