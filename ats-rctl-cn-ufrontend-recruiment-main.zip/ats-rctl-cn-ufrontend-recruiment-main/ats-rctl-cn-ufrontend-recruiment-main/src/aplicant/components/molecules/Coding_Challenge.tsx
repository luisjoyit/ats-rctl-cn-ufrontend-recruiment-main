import React from 'react'
import { Link } from 'react-router-dom'
import { IconUserCheck } from '@tabler/icons-react'
import * as Progress from '@radix-ui/react-progress'
//@ts-ignore
import { t, useLanguage } from '@joyit/layout'
import { Checkbox } from '@/components/ui/checkbox'

interface Props {
  name: string
  percentage: string
  takenBy: number
  id: string
}

const CodingChallenge: React.FC<Props> = ({
  name,
  percentage,
  takenBy,
  id,
}) => {
  const getColorClass = (percentage: number) => {
    if (percentage >= 90) return 'bg-[#00C851]'
    if (percentage >= 60) return 'bg-[#FFBB33]'
    if (percentage > 0) return 'bg-[#FF4444]'
    return 'bg-gray-300'
  }

  return (
    <div className="bg-[#E7F0FF] rounded-[11px] p-3 xs:max-w-full sm:max-w-[360px] min-h-[114.5px] flex flex-col text-secondary-500 justify-between font-inter">
      <div className="flex justify-between items-start">
        <h2 className="font-semibold text-base">{name}</h2>
      </div>
      <div className="flex justify-between items-center">
        <div className="flex items-center">
          <IconUserCheck
            stroke={2}
            className="mr-2 text-secondary-500"
            size={16}
          />
          <span className="text-sm font-semibold">{takenBy}</span>
        </div>
        <div className="w-24 relative">
          <Progress.Root
            className="overflow-hidden bg-white rounded-full w-full h-6"
            style={{
              transform: 'translateZ(0)',
            }}
            value={Number(percentage)}
          >
            <Progress.Indicator
              className={`w-full h-full transition-transform duration-[660ms] ease-[cubic-bezier(0.65, 0, 0.35, 1)] ${getColorClass(Number(percentage))}`}
              style={{ transform: `translateX(-${100 - Number(percentage)}%)` }}
            />
          </Progress.Root>
          <div
            className={`absolute inset-0 flex items-center justify-center font-medium text-sm ${Number(percentage) < 50 ? 'text-secondary-500' : 'text-white'}`}
          >
            {percentage}%
          </div>
        </div>
      </div>
      <div className="flex justify-between items-center">
        {percentage === '0' ? (
          <Link to={`/applicants/candidate/myEvaluations/${id}`}>
            <button className="rounded-[30px] bg-primary text-white py-auto px-5 font-inter h-[20px] text-xs">
              {t('dashboard.discord.MyEvaluations.evaluations.takeTestButton')}
            </button>
          </Link>
        ) : (
          <>
            <span className="inline-block rounded-[30px] bg-backgroundF-50 dark:bg-[#F7FAFF] xs:px-6 sm:px-2 xl:px-6 py-1 cursor-pointer text-xs">
              02/05/2024
            </span>
            <div className="inline-flex items-center">
              <Checkbox className="h-4 w-4 bg-backgroundF-50" />
              <span className="ml-2 text-xs text-secondary-500">
                {t('dashboard.discord.MyEvaluations.evaluations.showIn')}
              </span>
            </div>
          </>
        )}
      </div>
    </div>
  )
}

export default CodingChallenge
