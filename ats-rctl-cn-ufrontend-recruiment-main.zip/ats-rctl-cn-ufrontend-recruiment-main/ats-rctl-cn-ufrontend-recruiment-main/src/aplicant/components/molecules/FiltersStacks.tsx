import { useState } from 'react'
import { IconSearch, IconX } from '@tabler/icons-react'
import { Input } from '@/components/ui/input'

interface Stack {
  value: string
  label: string
}

interface TagInputProps {
  suggestions: Stack[]
  value: Stack[]
  onChange: (name: string, value: Stack[]) => void
  name: string
}

export default function FiltersStacks({
  suggestions,
  value,
  onChange,
  name,
}: TagInputProps) {
  const [inputValue, setInputValue] = useState('')
  const [filteredSuggestions, setFilteredSuggestions] = useState<Stack[]>([])

  const handleInputChange = (e) => {
    const newValue = e.target.value
    setInputValue(newValue)

    // Filtrar las sugerencias según lo que el usuario escriba
    if (newValue) {
      const filtered = suggestions.filter((stack) =>
        stack.label.toLowerCase().includes(newValue.toLowerCase()),
      )
      setFilteredSuggestions(filtered)
    } else {
      setFilteredSuggestions([])
    }
  }

  const handleSuggestionClick = (suggestion: Stack) => {
    // Si la sugerencia no está ya seleccionada, la añadimos
    if (!value.some((stack) => stack.value === suggestion.value)) {
      onChange(name, [...value, suggestion])
    }
    setInputValue('')
    setFilteredSuggestions([])
  }

  const handleTagRemove = (stackToRemove: Stack) => {
    // Eliminar el tag seleccionado
    const updatedTags = value.filter(
      (stack) => stack.value !== stackToRemove.value,
    )
    onChange(name, updatedTags)
  }

  return (
    <div className="flex flex-wrap gap-2">
      <div className="relative">
        <div className="relative xs:w-[165px] lg:w-[166px]">
          <span className="absolute top-0 bottom-0 w-4 h-4 my-auto left-4 antialiased text-secondary-500 z-20">
            <IconSearch stroke={1.5} className="w-full h-full" />
          </span>
          <Input
            type="text"
            name={name}
            className={`py-2 !pl-10 !pr-4 rounded-lg focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-transparent sm:block border border-muted-100 w-full h-[31px]`}
            placeholder="Buscar stack"
            value={inputValue}
            onChange={handleInputChange}
          />
        </div>

        {filteredSuggestions.length > 0 && (
          <ul className="absolute z-10 bg-white border border-gray-300 w-full mt-1 rounded-lg shadow-lg">
            {filteredSuggestions.map((suggestion) => (
              <li
                key={suggestion.value}
                className="p-2 hover:bg-gray-200 cursor-pointer"
                onClick={() => handleSuggestionClick(suggestion)}
              >
                {suggestion.label}
              </li>
            ))}
          </ul>
        )}
      </div>

      {value?.map((tag) => (
        <div
          key={tag.value}
          className="flex items-center bg-accent-200 rounded-[50px] px-3 py-1 h-[31px]"
        >
          <span className="text-xs text-secondary-500">{tag.label}</span>
          <IconX
            size={14}
            className="ml-2 cursor-pointer text-secondary-500"
            onClick={() => handleTagRemove(tag)}
          />
        </div>
      ))}
    </div>
  )
}
