import { IconPoint, IconPointFilled } from '@tabler/icons-react'
import { useNavigate } from 'react-router-dom'

interface ListLasAplicationDashboardProps {
  job: {
    job: string
    company: string
    state: string
    salary: number
    date: String
    modality: string
    city: string
    time: string
    logo: any
  }
}

export default function ListLasAplicationDashboard({
  job,
}: ListLasAplicationDashboardProps) {
  const navigate = useNavigate()
  return (
    <button
      className="flex xs:flex-col sm:flex-row gap-3 justify-between hover:bg-[#EFF6FF] rounded-2xl xs:items-start sm:items-center xs:h-auto sm:h-[96px] px-4 xs:py-4 sm:py-0 xs:border xl:border-none border-[#E2E8F0]"
      onClick={() => navigate('/applicants/offers/:offerId/detail')}
    >
      <div className="flex gap-4">
        <div className="flex items-center justify-center w-[48px] shrink-0">
          <img
            src={job.logo}
            className="w-auto max-w-full h-auto object-contain"
            alt=""
          />
        </div>
        <div className="flex flex-col gap-1 items-start placeholder:w-full">
          <span className="font-semibold text-lg text-[#18181B] text-start">
            {job.job.length > 30 ? job.job.substring(0, 25) + '...' : job.job}
          </span>
          <div className="flex text-[#0F172A] items-center gap-2">
            <span className="text-sm">{job.date}</span>
            <IconPointFilled stroke={2} size={12} />
            <span className="truncate sm:max-w-[64px] xl:max-w-max text-sm">
              {job.company}
            </span>
          </div>
        </div>
      </div>
      <div className="flex xs:gap-4 sm:gap-2">
        <span className="rounded-[99px] bg-[#CEF7FF] py-1.5 px-3 text-xs font-semibold text-[#003D49]">
          {job.modality}
        </span>
        <span className="rounded-[99px] bg-[#CBFFE0] py-1.5 px-3 text-xs font-semibold text-[#006428]">
          {job.city}
        </span>
        <span className="rounded-[99px] bg-[#FFF4DD] py-1.5 px-3 text-xs font-semibold text-[#CC8800]">
          {job.time}
        </span>
      </div>
    </button>
  )
}
