import imgCulqi from '../../../../public/ImgCulqi.png'
function CardCulqi() {
  return (
    <div className="rounded-[11px] w-full bg-accent-100 p-6 flex flex-col gap-3 justify-center font-inter">
      <h1 className="font-medium text-base">Hola,somos Culqi</h1>
      <div className="flex gap-5 items-center">
        <img className="md:w-[55px] md:h-[55px]" src={imgCulqi} alt="" />
        <h2 className="text-sm">
          Somos una empresa peruana de soluciones de pagos que forma parte del
          grupo Credicorp, y tenemos como principal objetivo ayudar a las
          empresas a evolucionar y atreverse a más.
        </h2>
      </div>
    </div>
  )
}
export default CardCulqi
