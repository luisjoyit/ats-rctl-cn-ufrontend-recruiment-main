import { Switch } from '@/components/ui/switch'

//@ts-ignore
import { t, useLanguage } from '@joyit/layout'
import { IconArrowLeft } from '@tabler/icons-react'
import { useState } from 'react'
import { useOutletContext } from 'react-router-dom'

interface OutletContextType {
  handleViewMenu?: () => void
}

export default function NotificationsOption() {
  const { handleChangeLanguage } = useLanguage()
  const [option, setOptions] = useState({
    postulations: true,
    updateProfile: true,
    newOpportunities: true,
    updatePost: true,
    invitationInt: true,
  })
  const changeOptions = (name: string, value: boolean) => {
    setOptions((prev) => ({ ...prev, [name]: value }))
  }
  const { handleViewMenu } = useOutletContext<OutletContextType>()

  const ContainerSwitch = ({ label, checked, onChange }) => {
    return (
      <div className="flex items-center justify-between bg-primary-foreground xs:px-5 sm:px-8 py-2.5 rounded-[11px] my-[12px] border">
        <p className="text-[15px] font-medium inline-block text-secondary-500">
          {label}
        </p>
        <Switch checked={checked} onCheckedChange={onChange} />
      </div>
    )
  }

  return (
    <div className="text-secondary dark:text-foreground">
      <div>
        <button
          onClick={handleViewMenu}
          className="xs:flex sm:hidden bg-backgroundF-500 rounded-4xl gap-1 px-3 items-center text-xs font-medium h-[23px] max-w-max mb-4"
        >
          <IconArrowLeft stroke={1.5} size={14} />
          Volver
        </button>
        <h1 className="text-[20px] font-semibold">
          {t('settingsNotifications.title')}
        </h1>
        <p className="text-sm my-[14px]">{t('settingsNotifications.detail')}</p>
      </div>
      <div className="mt-[27px] ">
        <h2 className="text-[20px] font-semibold">
          {t('settingsNotifications.titlePlataforma')}
        </h2>
        <ContainerSwitch
          label={t('settingsNotifications.optionPostularTrabajo')}
          checked={option.postulations}
          onChange={(checked) => changeOptions('postulations', checked)}
        />
        <ContainerSwitch
          label={t('settingsNotifications.optionActualizarPerfil')}
          checked={option.updateProfile}
          onChange={(checked) => changeOptions('updateProfile', checked)}
        />
      </div>
      <div className="mt-[46px] ">
        <h2 className="text-[20px] font-semibold">
          {t('settingsNotifications.titleCorreo')}
        </h2>
        <ContainerSwitch
          label={t('settingsNotifications.optionOportunidadLaboral')}
          checked={option.newOpportunities}
          onChange={(checked) => changeOptions('newOpportunities', checked)}
        />
        <ContainerSwitch
          label={t('settingsNotifications.optionEstadoPostulación')}
          checked={option.updatePost}
          onChange={(checked) => changeOptions('updatePost', checked)}
        />
        <ContainerSwitch
          label={t('settingsNotifications.optionInvitacionEntrevista')}
          checked={option.invitationInt}
          onChange={(checked) => changeOptions('invitationInt', checked)}
        />
      </div>
    </div>
  )
}
