import { Switch } from '@/components/ui/switch'

//@ts-ignore
import { t, useLanguage } from '@joyit/layout'
import { IconArrowLeft } from '@tabler/icons-react'
import { useState } from 'react'
import { useOutletContext } from 'react-router-dom'

interface OutletContextType {
  handleViewMenu?: () => void
}

export default function VisibilityOption() {
  const { handleChangeLanguage } = useLanguage()
  const [optionView, setOptionView] = useState(true)
  const { handleViewMenu } = useOutletContext<OutletContextType>()

  return (
    <div className="text-secondary dark:text-foreground">
      <div>
        <button
          onClick={handleViewMenu}
          className="xs:flex sm:hidden bg-backgroundF-500 rounded-4xl gap-1 px-3 items-center text-xs font-medium h-[23px] max-w-max mb-4"
        >
          <IconArrowLeft stroke={1.5} size={14} />
          Volver
        </button>
        <h1 className="text-[20px] font-semibold">
          {t('settingsVisibility.title')}
        </h1>
        <p className="text-sm my-[14px]">{t('settingsVisibility.detail')}</p>
      </div>
      <div className="mt-[23px] max-w-[370px]">
        <div className="flex items-center justify-between bg-primary-foreground dark:text-secondary-500 px-[31px] py-[10px] rounded-[11px] border">
          <p className="text-[15px] font-medium inline-block">
            {t('settingsVisibility.optionVisible')}
          </p>
          <Switch
            checked={optionView}
            onCheckedChange={(checked) => setOptionView(checked)}
          />
        </div>
      </div>
    </div>
  )
}
