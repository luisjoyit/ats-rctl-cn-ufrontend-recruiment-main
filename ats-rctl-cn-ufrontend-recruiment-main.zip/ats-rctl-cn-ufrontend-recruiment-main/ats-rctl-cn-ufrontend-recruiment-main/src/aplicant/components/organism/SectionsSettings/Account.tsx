import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import PasswordInput from '../../atoms/PasswordInput'
import { useState } from 'react'
import AccountDesactivationAlert from '../AlertDialogs/Settings/AccountDesactivation'
import AccountDeletionAlert from '../AlertDialogs/Settings/AccountDeletion'

//@ts-ignore
import { t, useLanguage } from '@joyit/layout'
import LoadingScreen from '../AlertDialogs/Settings/LoadingScreen'
import AccountDeleted from '../AlertDialogs/Settings/AccountDeleted'
import { IconArrowLeft, IconChevronLeft } from '@tabler/icons-react'
import { useOutletContext } from 'react-router-dom'

interface OutletContextType {
  handleViewMenu?: () => void
}

export default function AccountOption() {
  const { handleChangeLanguage } = useLanguage()
  const [userInfoVisible, setUserInfoVisible] = useState(true)
  const [email, setEmail] = useState('')
  const [loading, setLoading] = useState(false)
  const [accountDeleted, setAccountDeleted] = useState(false)
  const { handleViewMenu } = useOutletContext<OutletContextType>()

  const toggleInfoVisibility = () => {
    setUserInfoVisible((prevInputsVisible) => !prevInputsVisible)
  }

  if (loading) {
    return <LoadingScreen />
  }

  if (accountDeleted) {
    return <AccountDeleted /> // Show AccountDeleted component
  }

  return (
    <div className="text-secondary dark:text-foreground w-full">
      {userInfoVisible && (
        <>
          <button
            onClick={handleViewMenu}
            className="xs:flex sm:hidden bg-backgroundF-500 rounded-4xl gap-1 px-3 items-center text-xs font-medium h-[23px] max-w-max mb-4"
          >
            <IconArrowLeft stroke={1.5} size={14} />
            Volver
          </button>
          <h1 className="text-xl font-semibold">
            {t('settingsAccount.title')}
          </h1>
          <p className="font-medium my-[14px] text-sm">
            {t('settingsAccount.detail')}
          </p>
          <div className="mt-[23px]">
            <h3 className="text-xl font-semibold">
              {t('settingsAccount.subtitle')}
            </h3>
            <div className="mt-4">
              <Label
                htmlFor="email"
                className="font-semibold mb-[5px] text-secondary-500 text-base"
              >
                {t('settingsAccount.emailLabel')}
              </Label>
              <div className="flex justify-between items-center gap-2">
                <div className="flex-grow">
                  <Input
                    type="email"
                    placeholder="correo*********.com"
                    value={email}
                    id="email"
                    className="h-[37px]"
                    onChange={(e) => setEmail(e.target.value)}
                  />
                </div>
                <Button variant="tertiary" size="sm" className="w-auto">
                  {t('settingsAccount.changeButton')}
                </Button>
              </div>
            </div>
            <div className="mt-[22px]">
              <Label
                htmlFor="email"
                className="font-semibold mb-[5px] text-secondary-500 text-base"
              >
                {t('settingsAccount.passwordLabel')}
              </Label>
              <div className="flex justify-between items-center gap-2">
                <div className="flex-grow">
                  <PasswordInput
                    id="email"
                    placeholder="********************"
                    className="h-[37px]"
                  />
                </div>
                <Button variant="tertiary" size="sm" className="w-auto">
                  {t('settingsAccount.changeButton')}
                </Button>
              </div>
            </div>
            <div className="mt-[30px] w-full">
              <Button
                variant="primary"
                size="md"
                className="w-full"
                onClick={toggleInfoVisibility}
              >
                {t('settingsAccount.manageAccountButton')}
              </Button>
            </div>
          </div>
        </>
      )}
      {!userInfoVisible && (
        <div className="gap-5 flex flex-col xs:full sm:w-[370px]">
          <div className="mb-5 flex gap-2 cursor-pointer items-center">
            <IconChevronLeft
              stroke={1.5}
              size={16}
              onClick={() => setUserInfoVisible(true)}
            />
            <label
              className="text-sm font-medium cursor-pointer"
              onClick={() => setUserInfoVisible(true)}
            >
              Regresar a credenciales de inicio de sesión
            </label>
          </div>
          <h1 className="xs:text-lg sm:text-xl font-semibold">
            {t('settingsAccount.manageAccountTitle')}
          </h1>
          <div className="w-full flex flex-col gap-3">
            <AccountDesactivationAlert />
            <p className="text-sm">
              {t('settingsAccount.deactivateAccountInfo')}
            </p>
          </div>
          <div className="w-full mt-4 flex flex-col gap-3">
            <AccountDeletionAlert
              setLoading={setLoading}
              setAccountDeleted={setAccountDeleted}
            />
            <p className="text-sm">{t('settingsAccount.deleteAccountInfo')}</p>
          </div>
        </div>
      )}
    </div>
  )
}
