import ButtonCalendar from '@/components/ButtonCaledar'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog'
import { IconX } from '@tabler/icons-react'
import { useState } from 'react'

// @ts-ignore
import { t, useLanguage } from '@joyit/layout'

export default function AcceptInterview({ eventModalClose, dataInterview }) {
  const { handleChangeLanguage } = useLanguage()
  const [open, setOpen] = useState(false)

  const submitConfirm = () => {
    setOpen(false)
    eventModalClose()
  }

  return (
    <AlertDialog open={open} onOpenChange={setOpen}>
      <AlertDialogTrigger asChild>
        <ButtonCalendar label={t('postulationsCalendar.modalMain.yes')} />
      </AlertDialogTrigger>
      <AlertDialogContent className="xs:w-full sm:w-[452px] w-[452px]">
        <AlertDialogHeader>
          <div className="flex justify-end">
            <IconX
              stroke={1.5}
              size={20}
              className="close text-secondary-500 cursor-pointer"
              onClick={() => setOpen(false)}
            />
          </div>
          <AlertDialogTitle
            className="xs:text-lg sm:text-xl font-medium text-secondary-500"
            style={{ marginTop: 0 }}
          >
            {t('postulationsCalendar.modalAcceptInterview.title')}{' '}
            {dataInterview.company}
          </AlertDialogTitle>
          <AlertDialogDescription className="text-sm text-secondary-500">
            Jueves, 09 de mayo de 12:30pm a 1:30pm
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter style={{ justifyContent: 'center' }}>
          <div className="flex flex-row justify-center gap-8 w-full">
            <AlertDialogCancel
              onClick={() => setOpen(false)}
              className="w-[100px] h-[30px]"
            >
              {t('postulationsCalendar.modalAcceptInterview.return')}
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={submitConfirm}
              className="w-[100px] h-[30px]"
            >
              {t('postulationsCalendar.modalAcceptInterview.submit')}
            </AlertDialogAction>
          </div>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  )
}
