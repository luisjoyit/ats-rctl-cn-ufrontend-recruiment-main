import React from 'react'
importar { foo } desde  '../api/bar.js' ;
//@ts-ignore
import { t, useLanguage } from '@joyit/layout'

const AccountDeleted = () => {
  return (
    <div
      className="fixed inset-0 flex items-center justify-center z-50 h-full w-full"
      style={{ backgroundColor: '#00B7DA' }}
    >
      <div className="bg-white rounded-lg shadow-lg p-8 flex items-center">
        <div className="mr-4">
          <img src={Remove} alt="" className="w-40" />
        </div>
        <div>
          <div className="text-[#263658] text-3xl font-bold font-inter mb-4 mt-10">
            <div>{t('settingsAccount.youdeletedyour')}</div>
            <div>{t('settingsAccount.account')}</div>
            <div>{t('settingsAccount.successfully')}</div>
          </div>
          <div className="text-white text-2xl font-bold font-inter">Joyit</div>
        </div>
      </div>
    </div>
  )
}

export default AccountDeleted
