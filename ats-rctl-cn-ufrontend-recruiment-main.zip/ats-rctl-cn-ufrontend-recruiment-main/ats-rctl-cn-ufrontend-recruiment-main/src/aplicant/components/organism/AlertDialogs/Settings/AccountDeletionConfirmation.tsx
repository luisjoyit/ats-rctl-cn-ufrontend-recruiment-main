import React from 'react'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import { Button } from '@/components/ui/button'

//@ts-ignore
import { t, useLanguage } from '@joyit/layout'
import { IconX } from '@tabler/icons-react'

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms))

export default function AccountDeletionConfirmationAlert({
  onClose,
  setLoading,
  setAccountDeleted,
}) {
  const { handleChangeLanguage } = useLanguage()

  const onloading = async () => {
    setLoading(true)
    await delay(5000)
    setLoading(false)
    setAccountDeleted(true)
    await delay(6000)
    setAccountDeleted(false)
  }

  return (
    <AlertDialog open onOpenChange={onClose}>
      <AlertDialogContent style={{ gap: 0 }}>
        <div className="flex justify-end">
          <IconX
            stroke={1.5}
            size={20}
            color="#263658"
            className="text-2xl cursor-pointer"
            onClick={onClose}
          />
        </div>
        <AlertDialogHeader>
          <AlertDialogTitle>
            <h1 className="text-center text-xl font-medium font-inter text-secondary-500">
              {t('settingsAccount.emailModalConfirmTitle')}
            </h1>
          </AlertDialogTitle>
          <AlertDialogDescription>
            <p className="font-inter mt-[5px] text-center text-secondary-500">
              {t('settingsAccount.emailModalConfirmDetail')}
            </p>
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter className=" mt-[19px]">
          <div className="flex justify-center items-center w-full">
            <AlertDialogAction onClick={onloading}>
              <p className="font-inter text-sm px-2">Ok</p>
            </AlertDialogAction>
          </div>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  )
}
