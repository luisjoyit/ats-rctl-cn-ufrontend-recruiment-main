import React, { useEffect, useState } from 'react'

const LoadingScreen = () => {
  const [currentColorIndex, setCurrentColorIndex] = useState(0)
  const colors = ['#000000', '#cccccc']

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentColorIndex((prevIndex) => (prevIndex + 1) % colors.length)
    }, 500)

    return () => clearInterval(interval)
  }, [])

  return (
    <div className="fixed inset-0 flex flex-col items-center justify-center bg-white z-50">
      <h1 className="text-center text-5xl text-[#263658] font-bold font-inter">
        Joyit
      </h1>
      <div className="flex justify-center mt-2">
        <div className="flex">
          {[0, 1, 2].map((index) => (
            <div
              key={index}
              className="h-2.5 w-2.5 rounded-full mx-1"
              style={{
                backgroundColor:
                  colors[(currentColorIndex + index) % colors.length],
              }}
            ></div>
          ))}
        </div>
      </div>
    </div>
  )
}

export default LoadingScreen
