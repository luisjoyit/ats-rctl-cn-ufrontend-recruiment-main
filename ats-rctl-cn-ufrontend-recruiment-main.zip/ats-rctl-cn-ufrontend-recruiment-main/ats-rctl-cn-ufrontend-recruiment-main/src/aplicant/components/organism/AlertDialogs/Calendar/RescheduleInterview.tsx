import ButtonCalendar from '@/components/ButtonCaledar'
import {
  AlertDialog,
  AlertDialogCancel,
  AlertDialogAction,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog'
import { Button } from '@/components/ui/button'
import { Calendar } from '@/components/ui/calendar'
import {
  IconCalendarEvent,
  IconDots,
  IconMailForward,
  IconX,
} from '@tabler/icons-react'
import { useState } from 'react'

// @ts-ignore
import { t, useLanguage } from '@joyit/layout'
import { AlertDialogOverlay } from '@radix-ui/react-alert-dialog'

export default function RescheduleInterview({
  eventModalClose,
  dataInterview,
}) {
  const { handleChangeLanguage } = useLanguage()

  const [openReschedule, setOpenReschedule] = useState(false)
  const [showMessage, setShowMessage] = useState(false)
  const [visibleReschedule, setVisibleReschedule] = useState(true)
  const [openConfirm, setOpenConfirm] = useState(false)

  const dataHour = [
    '2:30 - 3:00pm',
    '3:30 - 4:00pm',
    '4:00 - 4:30pm',
    '4:30 - 5:00pm',
  ]

  const [selectedHour, setSelectedHour] = useState(null)
  const [selectedDate, setSelectedDate] = useState(null)

  const handleDateChange = (date) => {
    setSelectedDate(date)
  }

  const formatDate = (dateString) => {
    const options = {
      weekday: 'long' as const,
      year: 'numeric' as const,
      month: 'long' as const,
      day: 'numeric' as const,
    }

    const date = new Date(dateString)

    return date.toLocaleDateString('es-ES', options)
  }

  const submitReschedule = () => {
    setOpenConfirm(true)
    setVisibleReschedule(false)
  }

  const finishReschedule = () => {
    setOpenConfirm(false)
    setOpenReschedule(false)
    eventModalClose()
  }

  return (
    <div className="relative inline-block h-7">
      <AlertDialog open={openReschedule} onOpenChange={setOpenReschedule}>
        <AlertDialogTrigger asChild>
          <Button
            className={`bg-[#E9EAF5] hover:bg-primary rounded-[30px] text-xs text-[#263658] hover:text-white font-medium h-7 font-inter w-10`}
            onMouseEnter={() => setShowMessage(true)}
            onMouseLeave={() => setShowMessage(false)}
          >
            <IconDots
              stroke={2}
              size={16}
              className="xs:w-[14px] sm:w-[20px]"
            />
          </Button>
        </AlertDialogTrigger>
        {showMessage && (
          <div className="absolute -bottom-8 mb-2 w-48 bg-white text-xs text-secondary-500 text-center font-inter py-1 px-2 rounded-[3px] shadow-lg">
            {t('postulationsCalendar.modalMain.reschedule')}
          </div>
        )}
        <AlertDialogContent
          className={`${!visibleReschedule && 'hidden'} xs:w-full sm:w-[521px]`}
        >
          <AlertDialogHeader className="w-auto">
            <div className="flex justify-end">
              <IconX
                stroke={1.5}
                size={20}
                className="close text-secondary-500 cursor-pointer"
                onClick={() => setOpenReschedule(false)}
              />
            </div>
            <div className="flex xs:flex-col sm:flex-row gap-6 text-secondary-500">
              <div className="flex flex-col items-start w-full">
                <span className="text-sm font-semibold pb-3">
                  {dataInterview.company}
                </span>
                <div className="flex flex-col border-t border-[#D9D9D9] pt-3 items-start w-full">
                  <span className="flex text-base font-semibold w-full items-start">
                    {dataInterview.position}
                  </span>
                  <span className="text-xs">
                    {t('postulationsCalendar.modalReschedule.subtitle')}
                  </span>
                  <div className="flex xs:flex-wrap sm:flex-col gap-2 pt-2">
                    {dataHour.map((element, index) => (
                      <button
                        key={index}
                        className={` h-7 rounded-[30px] font-medium font-inter 
                                      text-xs text-[#263658] hover:bg-[#263658] hover:text-white 
                                      flex items-center w-24 justify-center cursor-pointer
                                      ${
                                        element === selectedHour
                                          ? 'bg-[#263658] text-white'
                                          : 'bg-[#E9EAF5] text-[#263658]'
                                      }
                                  `}
                        onClick={() => setSelectedHour(element)}
                      >
                        {element}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
              <div>
                <Calendar
                  mode="single"
                  selected={selectedDate}
                  onSelect={handleDateChange}
                  className="calendarReschedule"
                  //disabled={date => !isDateAvailable(date)}
                />
              </div>
            </div>
          </AlertDialogHeader>
          <AlertDialogFooter style={{ justifyContent: 'center' }}>
            <div className="flex flex-row justify-center gap-8 w-full">
              <AlertDialogCancel
                onClick={() => setOpenReschedule(false)}
                className="w-[100px] h-[30px]"
              >
                {t('postulationsCalendar.modalReschedule.return')}
              </AlertDialogCancel>
              <AlertDialog open={openConfirm} onOpenChange={submitReschedule}>
                <AlertDialogOverlay className="bg-none" />
                <AlertDialogTrigger asChild>
                  <AlertDialogAction className="h-[30px] w-auto">
                    {t('postulationsCalendar.modalReschedule.submit')}
                  </AlertDialogAction>
                </AlertDialogTrigger>
                <AlertDialogContent className="xs:w-full sm:w-[452px] w-[452px]">
                  <AlertDialogHeader>
                    <div className="flex justify-end">
                      <IconX
                        stroke={1.5}
                        size={20}
                        className="close text-secondary-500 cursor-pointer"
                        onClick={finishReschedule}
                      />
                    </div>
                    <AlertDialogTitle
                      className="text-xl font-medium text-secondary-500"
                      style={{ marginTop: 0 }}
                    >
                      {t('postulationsCalendar.modalReschedule.titleConfirm')}
                    </AlertDialogTitle>
                    <AlertDialogDescription className="text-sm text-secondary-500">
                      <div className="flex flex-row gap-2 justify-start items-start w-full mt-4">
                        <div className="w-auto">
                          <IconCalendarEvent stroke={1.5} />
                        </div>
                        <div className="flex flex-col text-start items-start ml-2">
                          <span className="font-bold">
                            {t(
                              'postulationsCalendar.modalReschedule.subTitleConfirm',
                            )}
                          </span>
                          <span>{`${formatDate(
                            selectedDate,
                          )} de ${selectedHour}`}</span>
                        </div>
                      </div>
                      <div className="flex flex-row gap-2 justify-start items-start mt-3">
                        <div className="w-auto">
                          <IconMailForward stroke={1.5} />
                        </div>
                        <div className="text-start ml-2">
                          <p>
                            {t(
                              'postulationsCalendar.modalReschedule.textBodyConfirm',
                            )}
                          </p>
                        </div>
                      </div>
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter className="flex items-center justify-center">
                    <AlertDialogAction
                      onClick={finishReschedule}
                      className="h-[30px] w-[42px]"
                    >
                      Ok
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            </div>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
