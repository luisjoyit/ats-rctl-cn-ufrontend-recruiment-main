import { Button } from '@/components/ui/button'
import ContainerSectionMyProfile from '../../../atoms/ContainerSectionMyProfile'
import { useState } from 'react'
import { useQueryClient } from '@tanstack/react-query'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogFooter,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog'
import {
  IconEdit,
  IconGripVertical,
  IconTrash,
  IconX,
} from '@tabler/icons-react'
import InputWithIcon from '@/components/inputWithIcon'
import { Checkbox } from '@/components/ui/checkbox'
import { ScrollArea } from '@/components/ui/scroll-area'
import CardAnimatedBorderGradient from '@/components/ui/CardPulseBorder'
import { useForm } from 'react-hook-form'
import {
  stackTechFormSchema,
  StackTechFormSchema,
} from '@/aplicant/validations/ProfileProffesionalSchema'
import { zodResolver } from '@hookform/resolvers/zod'
import { Drawer, DrawerContent, DrawerTitle } from '@/components/ui/drawer'
import useMediaQuery from '@/hooks/useMediaQuery'

const dataStackTech = [
  {
    id: 1,
    name: 'Design Tools',
    stackList: [
      {
        value: 'figma',
        label: 'Figma',
      },
      {
        value: 'sketch',
        label: 'Sketch',
      },
      {
        value: 'adobeXd',
        label: 'Adobe XD',
      },
      {
        value: 'inVision',
        label: 'InVision',
      },
      {
        value: 'axureRp',
        label: 'Axure RP',
      },
    ],
  },
  {
    id: 2,
    name: 'Prototyping',
    stackList: [
      {
        value: 'framer',
        label: 'Framer',
      },
      {
        value: 'principe',
        label: 'Principe',
      },
      {
        value: 'marvel',
        label: 'Marvel',
      },
    ],
  },
  {
    id: 3,
    name: 'Design Systems',
    stackList: [
      {
        value: 'material',
        label: 'Material',
      },
      {
        value: 'carbon',
        label: 'Carbon',
      },
      {
        value: 'fluent',
        label: 'Fluent',
      },
      {
        value: 'bootstrap',
        label: 'Bootstrap',
      },
    ],
  },
  {
    id: 4,
    name: 'Collaboration Tools',
    stackList: [
      {
        value: 'zeplin',
        label: 'Zeplin',
      },
      {
        value: 'miro',
        label: 'Miro',
      },
      {
        value: 'slack',
        label: 'Slack',
      },
      {
        value: 'jira',
        label: 'Jira',
      },
      {
        value: 'confluence',
        label: 'Confluence',
      },
    ],
  },
  {
    id: 5,
    name: 'Wireframing',
    stackList: [
      {
        value: 'balsamiq',
        label: 'Balsamiq',
      },
      {
        value: 'moqups',
        label: 'Moqups',
      },
    ],
  },
  {
    id: 6,
    name: 'Versión Control',
    stackList: [
      {
        value: 'github',
        label: 'Github',
      },
      {
        value: 'bitbucket',
        label: 'Bitbucket',
      },
    ],
  },
]

export interface IFormStackTech {
  stackTech: string[]
}

export function FormTechnologyStack({
  dataProfessionalStack,
  setDataProfessionalStack,
}) {
  const {
    register,
    handleSubmit,
    getValues,
    setValue,
    trigger,
    watch,
    formState: { errors },
  } = useForm<StackTechFormSchema>({
    resolver: zodResolver(stackTechFormSchema),
    defaultValues: {
      stackTech: dataProfessionalStack.stackTech || [],
    },
    mode: 'onChange',
  })
  const isLoading = false
  const [openModal, setOpenModal] = useState(false)
  const [openDrawer, setOpenDrawer] = useState(false)
  const [searchTerm, setSearchTerm] = useState('')
  const isMobile = useMediaQuery('(max-width: 640px)')

  const changeInput = (name, value) => {
    setSearchTerm(value)
  }

  const handleCheckboxChange = (value: string) => {
    const currentValues = getValues('stackTech') || []
    const newValues = currentValues.includes(value)
      ? currentValues.filter((tech) => tech !== value)
      : [...currentValues, value]

    setValue('stackTech', newValues)
    trigger('stackTech')
  }

  const watchedStackTech = watch('stackTech', [])

  const findLabelByValue = (value: string): string | undefined => {
    for (const category of dataStackTech) {
      const foundItem = category.stackList.find((item) => item.value === value)
      if (foundItem) {
        return foundItem.label
      }
    }
    return undefined
  }

  const onSubmit = (data: StackTechFormSchema) => {
    setDataProfessionalStack(data as IFormStackTech)
    setOpenModal(false)
    setOpenDrawer(false)
  }

  const deleteSkill = (value: string) => {
    const updatedStack = dataProfessionalStack.stackTech.filter(
      (stack) => stack !== value,
    )
    setDataProfessionalStack({ stackTech: updatedStack })
    setValue('stackTech', updatedStack)
    trigger('stackTech')
  }

  // Filtrar las opciones basado en el término de búsqueda
  const filteredStackTech = dataStackTech
    .map((category) => {
      const filteredStackList = category.stackList.filter((stack) =>
        stack.label.toLowerCase().includes(searchTerm.toLowerCase()),
      )
      if (filteredStackList.length > 0) {
        return {
          ...category,
          stackList: filteredStackList,
        }
      }
      return null
    })
    .filter(Boolean)

  const getContent = () => (
    <div className="flex flex-col gap-4">
      <InputWithIcon
        className="lg:w-full"
        placeholder="Buscar Habilidad Técnica"
        onChange={(name, value) => changeInput(name, value)} // Actualiza el término de búsqueda
      />
      <ScrollArea className="max-h-[254px] overflow-y-auto scrollbar-hide scrollColor custom-scroll">
        <div className="columns-3 space-y-3">
          {filteredStackTech.map((element, index) => (
            <div key={index} className="flex flex-col gap-2">
              <span className="font-medium text-sm">{element.name}</span>
              {element.stackList.map((stack, id) => (
                <div key={id} className="flex gap-2 items-center">
                  <Checkbox
                    {...register('stackTech')}
                    value={stack.value}
                    checked={watchedStackTech.includes(stack.value)}
                    const handleCheckedChange = (value) => handleCheckboxChange(value);

                    return (
                      <input type="checkbox" onChange={e => handleCheckedChange(stack.value)} />
                    );
                  <span className="text-xs">{stack.label}</span>
                </div>
              ))}
            </div>
          ))}
        </div>
      </ScrollArea>
    </div>
  )

  return (
    <ContainerSectionMyProfile>
      {isLoading ? (
        <div>Cargando...</div>
      ) : (
        <>
          {dataProfessionalStack?.stackTech?.map((skill, id) => (
            <CardAnimatedBorderGradient className="rounded-lg p-3" key={id}>
              <div className="flex gap-4">
                <div>
                  <IconGripVertical stroke={1.5} />
                </div>
                <div className="flex justify-between w-full">
                  <span>{findLabelByValue(skill)}</span>
                  <div className="flex gap-4">
                    <IconTrash
                      stroke={1.5}
                      onClick={() => deleteSkill(skill)}
                      className="text-secondary-500 cursor-pointer"
                      size={22}
                    />
                    <IconEdit
                      stroke={1.5}
                      className="text-secondary-500 cursor-pointer"
                      onClick={() => {
                        isMobile ? setOpenDrawer(true) : setOpenModal(true)
                      }}
                    />
                  </div>
                </div>
              </div>
            </CardAnimatedBorderGradient>
          ))}
          <button
            className="flex text-primary hover:text-primary-700 font-medium w-auto text-start text-sm"
            type="button"
            onClick={() => {
              isMobile ? setOpenDrawer(true) : setOpenModal(true)
            }}
          >
            + Añade una habilidad tecnológica
          </button>
        </>
      )}
      <AlertDialog open={openModal} onOpenChange={setOpenModal}>
        <AlertDialogTrigger className="hidden" />
        <AlertDialogContent style={{ gap: 0 }}>
          <AlertDialogTitle className="hidden" />
          <div className="flex justify-end">
            <IconX
              stroke={1.5}
              size={20}
              className="cursor-pointer text-secondary-500"
              onClick={() => setOpenModal(false)}
            />
          </div>
          <div className="flex flex-col gap-8">
            <div className="flex flex-col gap-4 font-inter text-secondary-500 text-center">
              <span className="text-xl font-semibold">
                Selecciona tu Stack tech
              </span>
              <span>UX/UI Designer</span>
            </div>
            {getContent()}
            <AlertDialogFooter className="flex xs:flex-row xs:justify-between sm:justify-around w-full">
              <AlertDialogCancel>Cancelar</AlertDialogCancel>
              <AlertDialogAction onClick={handleSubmit(onSubmit)}>
                Guardar
              </AlertDialogAction>
            </AlertDialogFooter>
          </div>
        </AlertDialogContent>
      </AlertDialog>
      <Drawer open={openDrawer} onOpenChange={setOpenDrawer}>
        <DrawerContent className="p-4 h-[90vh] overflow-y-auto">
          <DrawerTitle className="hideen" />
          <div className="flex justify-end">
            <IconX
              size={18}
              stroke={1}
              onClick={() => setOpenDrawer(!openDrawer)}
            />
          </div>
          <div className="flex flex-col gap-8 mt-3">
            <div className="flex flex-col gap-4 font-inter text-secondary-500 text-center">
              <span className="text-xl font-semibold">
                Selecciona tu Stack tech
              </span>
              <span>UX/UI Designer</span>
            </div>
            {getContent()}
            <div className="flex justify-between">
              <Button variant="secondary" size="md">
                Cancelar
              </Button>
              <Button
                variant="primary"
                size="md"
                onClick={handleSubmit(onSubmit)}
              >
                Guardar
              </Button>
            </div>
          </div>
        </DrawerContent>
      </Drawer>
    </ContainerSectionMyProfile>
  )
}
