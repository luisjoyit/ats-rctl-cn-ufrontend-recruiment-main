import SelectUi from '@/components/SelectUi'
import CardAnimatedBorderGradient from '@/components/ui/CardPulseBorder'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { IconChevronDown, IconLink, IconTrash } from '@tabler/icons-react'
import { Button } from '@/components/ui/button'
import { useEffect, useRef, useState } from 'react'
import { IProjects } from '@/aplicant/components/templates/MyPortfolio'
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import EditorDemo from '@/components/editorText/editorDemo'
import FloatingSelect from '@/components/FloatingSelect'

interface ISectionMyPortfolio {
  dataProject: IProjects
  extendCard: boolean
  setExtendCard: (id: number) => void
  deleteProject: (id: number) => void
  saveProject: (newProject: IProjects) => void
}

const years = [
  { value: '2024', label: '2024' },
  { value: '2023', label: '2023' },
  { value: '2022', label: '2022' },
  { value: '2021', label: '2021' },
  { value: '2020', label: '2020' },
  { value: '2019', label: '2019' },
]

export default function AddFormMyPortfolio({
  dataProject,
  extendCard,
  setExtendCard,
  deleteProject,
  saveProject,
}: ISectionMyPortfolio) {
  const [project, setProject] = useState<IProjects>(dataProject)
  const [fileName, setFileName] = useState<string | null>(null)
  const inputRef = useRef(null)

  useEffect(() => {
    setProject(dataProject)
  }, [dataProject])

  const handleChangeFile = (event) => {
    const { files } = event.target
    const file = files?.[0]
    if (file) {
      setFileName(file.name)
      setProject((prevState) => ({ ...prevState, img: file }))
    }
  }

  const handleChangeData = (name, value) => {
    setProject((prevState) => ({ ...prevState, [name]: value }))
  }

  const handleButtonClick = () => {
    inputRef.current.click()
  }

  const getTitleProject = () => {
    const fieldsToCheck = ['name', 'year']
    const isEmpty = fieldsToCheck.every((field) => project[field] === '')
    if (isEmpty) {
      return '(No Especificado)'
    } else {
      return (
        <div className="flex flex-col">
          <span className="text-secondary-500 text-[15px]">{project.name}</span>
          <span className="text-[#5A5A5A] text-[13px]">{project.year}</span>
        </div>
      )
    }
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    saveProject(project)
  }

  return (
    <CardAnimatedBorderGradient>
      <form onSubmit={handleSubmit} className="font-inter flex flex-col gap-4">
        <div className="flex flex-row w-full justify-between">
          <h1 className="text-[15px]">{getTitleProject()}</h1>
          <div className="flex gap-3 items-center">
            <IconTrash
              stroke={1.5}
              onClick={() => deleteProject(project.id)}
              className={`text-secondary-500 cursor-pointer ${!extendCard && 'hidden'}`}
              size={22}
            />

            <button onClick={() => setExtendCard(project.id)}>
              <IconChevronDown
                stroke={1.5}
                size={20}
                className={`${extendCard && 'rotate-180'} text-secondary-500`}
              />
            </button>
          </div>
        </div>
        <div className={`${!extendCard && 'hidden'} flex flex-col gap-4`}>
          <div className="grid grid-cols-[1fr_124px] gap-3">
            <Input
              type="text"
              name="name"
              variant="floatingLabel"
              label="Titulo del proyecto *"
              value={project.name}
              onChange={(e) => handleChangeData(e.target.name, e.target.value)}
            />
            <FloatingSelect
              name="year"
              onChange={handleChangeData}
              value={project.year}
              options={years}
              label="País"
              className="border w-full"
              background="bg-white"
            />
          </div>
          <EditorDemo
            name="description"
            placeholder="Describe brevemente lo mas relevante de tu participación en el proyecto."
            value={project.description}
            onChange={(value) =>
              setProject((prev) => ({ ...prev, description: value }))
            }
            isHeaderEnd
          />
          <div className="flex flex-col gap-2">
            {fileName && (
              <div className="text-xs text-secondary-500">{fileName}</div>
            )}
            <input
              type="file"
              ref={inputRef}
              className="hidden"
              accept="image/*"
              onChange={handleChangeFile}
            />
            <Button
              variant="primary"
              size="sm"
              className="bg-primary text-white w-full"
              onClick={handleButtonClick}
            >
              Añadir imagen
            </Button>
          </div>
          <div className="flex gap-2 items-center">
            <IconLink stroke={2} className="rotate-45" />
            <div className="flex-1">
              <Input
                type="text"
                name="linkProject"
                variant="floatingLabel"
                label="Link al proyecto *"
                value={project.linkProject}
                onChange={(e) =>
                  handleChangeData(e.target.name, e.target.value)
                }
              />
            </div>
          </div>
          <div className="flex items-center gap-2">
            <IconLink stroke={2} className="rotate-45" />
            <div className="flex-1">
              <Input
                type="text"
                name="linkRepo"
                variant="floatingLabel"
                label="Link del repositorio Github *"
                value={project.linkRepo}
                onChange={(e) =>
                  handleChangeData(e.target.name, e.target.value)
                }
              />
            </div>
          </div>
        </div>
      </form>
    </CardAnimatedBorderGradient>
  )
}
