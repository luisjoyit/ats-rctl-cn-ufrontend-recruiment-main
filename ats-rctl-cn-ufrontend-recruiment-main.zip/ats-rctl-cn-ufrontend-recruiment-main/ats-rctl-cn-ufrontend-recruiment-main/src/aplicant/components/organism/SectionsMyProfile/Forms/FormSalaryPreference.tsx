import {
  salarityFormSchema,
  SalarityFormSchema,
} from '@/aplicant/validations/ProfileProffesionalSchema'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogFooter,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog'
import { Button } from '@/components/ui/button'
import { Checkbox } from '@/components/ui/checkbox'
import { Drawer, DrawerContent, DrawerTitle } from '@/components/ui/drawer'
import { Input } from '@/components/ui/input'
import { Separator } from '@/components/ui/separator'
import useMediaQuery from '@/hooks/useMediaQuery'
import { zodResolver } from '@hookform/resolvers/zod'
import { IconEdit, IconX } from '@tabler/icons-react'
import Slider from 'rc-slider'
import { useState } from 'react'
import { useForm } from 'react-hook-form'

export interface IFormSalarity {
  rangeSalarity: number[]
  adHonoren: boolean
}

const FormSalaryPreference = ({
  dataSalarity,
  setDataSalarity,
  openDrawer,
  setOpenDrawer,
}) => {
  const {
    handleSubmit,
    setValue,
    watch,
    formState: { errors },
  } = useForm<SalarityFormSchema>({
    resolver: zodResolver(salarityFormSchema),
    defaultValues: {
      rangeSalarity: dataSalarity.rangeSalarity || [500, 1500],
      adHonorem: dataSalarity.adHonorem || false,
    },
    mode: 'onChange',
  })
  const [openModal, setOpenModal] = useState(false)
  const isMobile = useMediaQuery('(max-width: 640px)')
  const [sliderKey, setSliderKey] = useState(Date.now())
  const adHonorem = watch('adHonorem') as boolean

  const handleRangeSalary = (newRange) => {
    setValue('rangeSalarity', newRange)
  }

  const onSubmit = (data: SalarityFormSchema) => {
    if (data.adHonorem) {
      setDataSalarity((prev) => ({
        ...prev,
        rangeSalarity: [],
        adHonorem,
      }))
    } else {
      setDataSalarity(data)
    }
    setOpenModal(false)
    setOpenDrawer(false)
  }

  const getContent = () => (
    <div className="flex flex-col gap-10 font-inter text-secondary-500 text-center">
      <span className="text-xl font-semibold">Preferencia Salarial</span>
      <div className="flex flex-col gap-8 px-4">
        <div className="flex flex-col gap-2 xs:px-4 sm:px-10">
          <Slider
            key={sliderKey}
            min={0}
            max={20000}
            step={100}
            range
            defaultValue={[500, 1500]}
            value={watch('rangeSalarity') || [500, 1500]}
            onChange={(value) => handleRangeSalary(value)}
            disabled={adHonorem}
            className="slider-salary-job w-full"
          />
          <div className="flex justify-between">
            <span>0</span>
            <span>20,000</span>
          </div>
          <div className="flex gap-2 items-center">
            <span className="xs:text-sm md:text-base">De</span>
            <Input
              value={watch('rangeSalarity')[0] || ''}
              onChange={(e) =>
                handleRangeSalary([
                  Number(e.target.value),
                  watch('rangeSalarity')[1],
                ])
              }
              preffix="$"
              disabled={adHonorem}
            />
            <span className="xs:text-sm md:text-base">a</span>
            <Input
              value={watch('rangeSalarity')[1] || ''}
              onChange={(e) =>
                handleRangeSalary([
                  watch('rangeSalarity')[0],
                  Number(e.target.value),
                ])
              }
              preffix="$"
              disabled={adHonorem}
            />
          </div>
        </div>
        <Separator />
        <div className="flex gap-2 items-center justify-center">
          <Checkbox
            checked={watch('adHonorem') as boolean}
            onCheckedChange={(checked) => {
              setValue('adHonorem', checked === true)
              if (checked) {
                setValue('rangeSalarity', [500, 1500])
              }
            }}
            className="mr-1"
          />
          <label
            className={`xs:text-sm md:text-base text-accent-700 md:whitespace-nowrap ${watch('adHonorem') && 'text-secondary-500 dark:text-white'}`}
          >
            Ad honorem
          </label>
        </div>
      </div>
    </div>
  )

  return (
    <div>
      <div className="flex justify-between">
        {dataSalarity.rangeSalarity.length !== 0 ? (
          <span className="text-secondary-500 font-medium">{`$ ${dataSalarity.rangeSalarity[0]} - $ ${dataSalarity.rangeSalarity[1]}`}</span>
        ) : (
          <span className="text-secondary-500 font-medium">Ad Honorem</span>
        )}
        <IconEdit
          stroke={1.5}
          className="text-secondary-500 cursor-pointer xs:hidden sm:flex"
          onClick={
            isMobile ? () => setOpenDrawer(true) : () => setOpenModal(true)
          }
        />
      </div>

      {/* Si no existe rango y adHonorem es falso */}
      {dataSalarity.rangeSalarity.length !== 0 && dataSalarity.adHonorem && (
        <button
          className="text-primary hover:text-primary-700 font-medium w-auto text-start text-sm"
          type="button"
          onClick={
            isMobile ? () => setOpenDrawer(true) : () => setOpenModal(true)
          }
        >
          + Indica tu preferencia salarial
        </button>
      )}

      {isMobile ? (
        <Drawer open={openDrawer} onOpenChange={setOpenDrawer}>
          <DrawerContent className="p-4 h-[80vh] overflow-y-auto">
            <DrawerTitle className="hideen" />
            <div className="flex justify-end">
              <IconX
                size={18}
                stroke={1}
                onClick={() => setOpenDrawer(!openDrawer)}
              />
            </div>
            <div className="flex flex-col gap-8 mt-3">
              {getContent()}
              <div className="flex justify-between">
                <Button variant="secondary" size="md">
                  Cancelar
                </Button>
                <Button
                  variant="primary"
                  size="md"
                  onClick={handleSubmit(onSubmit)}
                >
                  Guardar
                </Button>
              </div>
            </div>
          </DrawerContent>
        </Drawer>
      ) : (
        <AlertDialog open={openModal} onOpenChange={setOpenModal}>
          <AlertDialogTrigger className="hidden" />
          <AlertDialogContent style={{ gap: 0 }}>
            <AlertDialogTitle className="hidden" />
            <div className="flex justify-end">
              <IconX
                stroke={1.5}
                size={20}
                className="cursor-pointer text-secondary-500"
                onClick={() => setOpenModal(false)}
              />
            </div>
            <div className="flex flex-col gap-8">
              {getContent()}
              <AlertDialogFooter className="flex xs:flex-row xs:justify-between sm:justify-around w-full">
                <AlertDialogCancel>Cancelar</AlertDialogCancel>
                <AlertDialogAction onClick={handleSubmit(onSubmit)}>
                  Guardar
                </AlertDialogAction>
              </AlertDialogFooter>
            </div>
          </AlertDialogContent>
        </AlertDialog>
      )}
    </div>
  )
}

export default FormSalaryPreference
