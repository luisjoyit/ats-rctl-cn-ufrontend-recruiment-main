import { useState } from 'react'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogFooter,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog'
import { IconEdit, IconX } from '@tabler/icons-react'
import { Input } from '@/components/ui/input'
import {
  personalInfoFormSchema,
  PersonalInfoFormSchema,
} from '@/aplicant/validations/ProfileContactSchema'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import useMediaQuery from '@/hooks/useMediaQuery'
import { Drawer, DrawerContent, DrawerTitle } from '@/components/ui/drawer'
import { Button } from '@/components/ui/button'

export interface IFormPersonalInfo {
  name: string
  lastName: string
  country: string
  location: string
}

interface IPersonalInfo {
  dataInfo: IFormPersonalInfo
  setDataInfo: (newData: IFormPersonalInfo) => void
}

const FormPersonalInfo = ({ dataInfo, setDataInfo }: IPersonalInfo) => {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<PersonalInfoFormSchema>({
    resolver: zodResolver(personalInfoFormSchema),
    defaultValues: {
      name: dataInfo.name,
      lastName: dataInfo.lastName,
      country: dataInfo.country,
      location: dataInfo.location,
    },
    mode: 'onChange',
  })
  const [openModal, setOpenModal] = useState(false)
  const [openDrawer, setOpenDrawer] = useState(false)
  const isMobile = useMediaQuery('(max-width: 640px)')

  const onSubmit = (data: PersonalInfoFormSchema) => {
    setDataInfo(data as IFormPersonalInfo)
    setOpenModal(false)
    setOpenDrawer(false)
  }

  const getContent = () => (
    <div className="flex flex-col gap-6">
      <div className="flex flex-col gap-1">
        <Input
          name="name"
          placeholder="Nombres"
          variant="floatingLabel"
          label="Nombre *"
          type="text"
          className="text-sm w-full"
          {...register('name')}
        />
        {errors.name && (
          <span className="text-xs text-destructive-500 ml-2">
            {errors.name.message}
          </span>
        )}
      </div>
      <div className="flex flex-col gap-1">
        <Input
          name="lastName"
          placeholder="Apellidos"
          variant="floatingLabel"
          label="Apellido *"
          type="text"
          className="text-sm w-full"
          {...register('lastName')}
        />
        {errors.lastName && (
          <span className="text-xs text-destructive-500 ml-2">
            {errors.lastName.message}
          </span>
        )}
      </div>
      <div className="flex flex-col gap-1">
        <Input
          name="country"
          placeholder="País"
          variant="floatingLabel"
          label="País *"
          type="text"
          {...register('country')}
          className="text-sm w-full"
        />
        {errors.country && (
          <span className="text-xs text-destructive-500 ml-2">
            {errors.country.message}
          </span>
        )}
      </div>
      <div className="flex flex-col gap-1">
        <Input
          name="location"
          placeholder="País"
          variant="floatingLabel"
          label="Ubicación *"
          type="text"
          {...register('location')}
          className="text-sm w-full"
        />
        {errors.location && (
          <span className="text-xs text-destructive-500 ml-2">
            {errors.location.message}
          </span>
        )}
      </div>
    </div>
  )

  return (
    <>
      {isMobile ? (
        <>
          <IconEdit
            stroke={1.5}
            className="text-secondary-500 cursor-pointer"
            onClick={() => setOpenDrawer(true)}
          />
          <Drawer
            open={openDrawer}
            onOpenChange={setOpenDrawer}
            //onClose={}
          >
            <DrawerContent className="p-4 h-[80vh] overflow-y-auto">
              <DrawerTitle className="hideen" />
              <div className="flex justify-end">
                <IconX
                  size={18}
                  stroke={1}
                  onClick={() => setOpenDrawer(!openDrawer)}
                />
              </div>
              <div className="flex flex-col gap-8 mt-3">
                <span className="font-inter text-secondary-500 text-xl font-semibold text-center">
                  Información personal
                </span>
                {getContent()}
                <div className="flex justify-between">
                  <Button variant="secondary" size="md">
                    Cancelar
                  </Button>
                  <Button
                    variant="primary"
                    size="md"
                    onClick={handleSubmit(onSubmit)}
                  >
                    Guardar
                  </Button>
                </div>
              </div>
            </DrawerContent>
          </Drawer>
        </>
      ) : (
        <AlertDialog open={openModal} onOpenChange={setOpenModal}>
          <AlertDialogTrigger>
            <IconEdit
              stroke={1.5}
              className="text-secondary-500 cursor-pointer"
              onClick={() => setOpenModal(true)}
            />
          </AlertDialogTrigger>
          <form>
            <AlertDialogContent
              style={{ gap: 0 }}
              className="xs:hidden sm:flex"
            >
              <AlertDialogTitle className="hidden" />
              <div className="flex justify-end">
                <IconX
                  stroke={1.5}
                  size={20}
                  className="cursor-pointer text-secondary-500"
                  onClick={() => setOpenModal(false)}
                />
              </div>
              <div className="flex flex-col gap-8">
                <span className="font-inter text-secondary-500 text-xl font-semibold text-center">
                  Información personal
                </span>
                {getContent()}
                <AlertDialogFooter className="flex xs:flex-row xs:justify-between sm:justify-around w-full">
                  <AlertDialogCancel>Cancelar</AlertDialogCancel>
                  <AlertDialogAction onClick={handleSubmit(onSubmit)}>
                    Guardar
                  </AlertDialogAction>
                </AlertDialogFooter>
              </div>
            </AlertDialogContent>
          </form>
        </AlertDialog>
      )}
    </>
  )
}

export default FormPersonalInfo
