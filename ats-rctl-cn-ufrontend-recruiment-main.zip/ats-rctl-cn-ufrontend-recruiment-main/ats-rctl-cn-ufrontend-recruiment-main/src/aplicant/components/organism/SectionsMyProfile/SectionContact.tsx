import { Button } from '@/components/ui/button'
import CardAnimatedBorderGradient from '@/components/ui/CardPulseBorder'
import { Input } from '@/components/ui/input'
import { Separator } from '@/components/ui/separator'
import {
  IconBrandGithub,
  IconBrandLinkedin,
  IconBrandWhatsapp,
} from '@tabler/icons-react'
import { useState } from 'react'
import FormPersonalInfo, { IFormPersonalInfo } from './Forms/FormPersonalInfo'
import FormContactInfo, { IFormContactInfo } from './Forms/FormContactInfo'
import FormNetworks, { IFormNetworks } from './Forms/FormNetworks'

const dataInfoProfile = {
  name: 'Liset del Pilar',
  lastName: 'Cárdenas Charcape',
  country: 'Peru',
  location: 'Lima, Lima',
  email: 'lisetcardenas007@gmail.com',
  phone: '943132859',
  linkLinkedin: 'https://linkedin.com/in/lisetcardenas/',
  linkGithub: '',
  linkWhatsapp: '',
}

export default function SectionContact() {
  const [dataPersonalInfo, setDataPersonalInfo] = useState<IFormPersonalInfo>({
    name: dataInfoProfile?.name || '',
    lastName: dataInfoProfile?.lastName || '',
    country: dataInfoProfile?.country || '',
    location: dataInfoProfile?.location || '',
  })

  const [dataContactInfo, setDataContactInfo] = useState<IFormContactInfo>({
    email: dataInfoProfile?.email || '',
    phone: dataInfoProfile?.phone || '',
  })

  const [dataNetworks, setDataNetworks] = useState<IFormNetworks>({
    linkLinkedin: dataInfoProfile?.linkLinkedin || '',
    linkGithub: dataInfoProfile?.linkGithub || '',
    linkWhatsapp: dataInfoProfile?.linkGithub || '',
  })

  return (
    <div className="flex flex-col gap-6">
      <CardAnimatedBorderGradient className=" shadow-none border-x border-b border-t-0">
        <div className="flex flex-col xs:gap-3 sm:gap-6">
          <div className="flex justify-between">
            <h1 className="font-inter font-semibold text-secondary-500">
              Informacion personal
            </h1>
            <div className="xs:block sm:hidden">
              <FormPersonalInfo
                dataInfo={dataPersonalInfo}
                setDataInfo={setDataPersonalInfo}
              />
            </div>
          </div>
          <div className="flex">
            <div className="flex xs:flex-col sm:flex-row xs:w-full sm:w-[90%] h-auto xs:gap-3 sm:gap-8">
              <div className="flex flex-col xs:w-full sm:w-[436px] xs:gap-3 sm:gap-6">
                <Input
                  name="name"
                  placeholder="Nombres"
                  variant="floatingLabel"
                  label="Nombre *"
                  type="text"
                  value={dataPersonalInfo.name}
                  className="text-sm w-full"
                  readOnly
                />
                <Input
                  name="lastName"
                  placeholder="Apellidos"
                  variant="floatingLabel"
                  label="Apellido *"
                  type="text"
                  value={dataPersonalInfo.lastName}
                  className="text-sm w-full"
                  readOnly
                />
              </div>
              <Separator
                orientation="vertical"
                className="h-[98px] xs:hidden sm:block"
              />
              <div className="flex flex-col xs:w-full sm:w-[436px] xs:gap-3 sm:gap-6">
                <Input
                  name="country"
                  placeholder="País"
                  variant="floatingLabel"
                  label="País *"
                  type="text"
                  value={dataPersonalInfo.country}
                  className="text-sm w-full"
                  readOnly
                />
                <Input
                  name="city"
                  placeholder="País"
                  variant="floatingLabel"
                  label="Ubicación *"
                  type="text"
                  value={dataPersonalInfo.location}
                  className="text-sm w-full"
                  readOnly
                />
              </div>
            </div>
            <div className="w-auto xs:hidden sm:flex justify-center items-center flex-1">
              <FormPersonalInfo
                dataInfo={dataPersonalInfo}
                setDataInfo={setDataPersonalInfo}
              />
            </div>
          </div>
        </div>
      </CardAnimatedBorderGradient>
      <CardAnimatedBorderGradient>
        <div className="flex flex-col xs:gap-3 sm:gap-6">
          <div className="flex justify-between">
            <h1 className="font-inter font-semibold text-secondary-500">
              Informacion de contacto
            </h1>
            <div className="xs:block sm:hidden">
              <FormContactInfo
                dataContact={dataContactInfo}
                setDataContact={setDataContactInfo}
              />
            </div>
          </div>
          <div className="flex">
            <div className="flex xs:flex-col sm:flex-row xs:w-full sm:w-[90%] h-auto xs:gap-3 sm:gap-8">
              <div className="xs:w-full sm:w-[436px]">
                <Input
                  name="email"
                  placeholder="Email"
                  variant="floatingLabel"
                  label="Correo electrónico *"
                  type="text"
                  value={dataContactInfo.email}
                  className="text-sm w-full"
                  readOnly
                />
              </div>
              <Separator
                orientation="vertical"
                className="h-[40px] xs:hidden sm:block"
              />
              <div className="xs:w-full sm:w-[436px]">
                <Input
                  name="phone"
                  placeholder="Teléfono"
                  variant="floatingLabel"
                  label="Teléfono *"
                  type="text"
                  value={dataContactInfo.phone}
                  className="text-sm w-full"
                  readOnly
                />
              </div>
            </div>
            <div className="w-auto xs:hidden sm:flex justify-center items-center flex-1">
              <FormContactInfo
                dataContact={dataContactInfo}
                setDataContact={setDataContactInfo}
              />
            </div>
          </div>
        </div>
      </CardAnimatedBorderGradient>
      <CardAnimatedBorderGradient className="xs:px-4 xs:py-4 sm:px-8 sm:py-8">
        <div className="flex flex-col xs:gap-3 sm:gap-6 font-inter">
          <div className="flex justify-between">
            <h1 className="font-semibold text-secondary-500">
              Redes profesionales
            </h1>
            <div className="xs:block sm:hidden">
              {(dataNetworks.linkGithub !== '' ||
                dataNetworks.linkLinkedin !== '' ||
                dataNetworks.linkWhatsapp !== '') && (
                <FormNetworks
                  dataNetworks={dataNetworks}
                  setDataNetworks={setDataNetworks}
                />
              )}
            </div>
          </div>
          <div className="flex">
            <div className="flex xs:flex-col sm:flex-row gap-4 xs:w-full sm:w-[90%]">
              {dataNetworks.linkLinkedin && (
                <button
                  className="flex px-4 items-center justify-center gap-3 w-[207px] h-[37px] border rounded-lg"
                  onClick={() =>
                    window.open(dataNetworks.linkLinkedin, '_blank')
                  }
                >
                  <IconBrandLinkedin
                    stroke={1.5}
                    size={18}
                    className="text-secondary-500 cursor-pointer"
                  />
                  <span className="truncate">
                    {dataNetworks.linkLinkedin.split('linkedin.com/in/')[1]}
                  </span>
                </button>
              )}
              {dataNetworks.linkGithub && (
                <button
                  className="flex px-4 items-center justify-center gap-3 w-[207px] h-[37px] border rounded-lg"
                  type="button"
                  onClick={() => window.open(dataNetworks.linkGithub, '_blank')}
                >
                  <IconBrandGithub
                    stroke={1.5}
                    size={18}
                    className="text-secondary-500 cursor-pointer"
                  />
                  <span className="truncate">
                    {dataNetworks.linkGithub.split('github.com/')[1]}
                  </span>
                </button>
              )}
              {dataNetworks.linkWhatsapp && (
                <button
                  className="flex px-4 items-center justify-center gap-3 w-[207px] h-[37px] border rounded-lg"
                  onClick={() =>
                    window.open(dataNetworks.linkWhatsapp, '_blank')
                  }
                >
                  <IconBrandWhatsapp
                    stroke={1.5}
                    size={18}
                    className="text-secondary-500 cursor-pointer"
                  />
                  <span>Whatsapp</span>
                </button>
              )}
              {dataNetworks.linkGithub === '' &&
                dataNetworks.linkLinkedin === '' &&
                dataNetworks.linkWhatsapp === '' && (
                  <Button
                    variant="tertiary"
                    size="md"
                    className="text-primary hover:text-primary-700 font-medium w-auto justify-start"
                  >
                    + Añade redes profesionales
                  </Button>
                )}
            </div>
            <div className="min-w-[24px] max-w-[149px] xs:hidden sm:flex justify-center items-center flex-1">
              {(dataNetworks.linkGithub !== '' ||
                dataNetworks.linkLinkedin !== '' ||
                dataNetworks.linkWhatsapp !== '') && (
                <FormNetworks
                  dataNetworks={dataNetworks}
                  setDataNetworks={setDataNetworks}
                />
              )}
            </div>
          </div>
        </div>
      </CardAnimatedBorderGradient>
    </div>
  )
}
