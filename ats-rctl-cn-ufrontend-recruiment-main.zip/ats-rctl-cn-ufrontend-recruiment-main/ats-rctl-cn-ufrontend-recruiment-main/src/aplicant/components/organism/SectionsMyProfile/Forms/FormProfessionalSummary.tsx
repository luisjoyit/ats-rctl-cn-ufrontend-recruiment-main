import { useState } from 'react'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogFooter,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog'
import { IconEdit, IconX } from '@tabler/icons-react'
import { Textarea } from '@/components/ui/textarea'
import {
  summaryFormSchema,
  SummaryFormSchema,
} from '@/aplicant/validations/ProfileProffesionalSchema'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import useMediaQuery from '@/hooks/useMediaQuery'
import { Drawer, DrawerContent, DrawerTitle } from '@/components/ui/drawer'
import { Button } from '@/components/ui/button'

export interface IFormSummary {
  professionalSummary: string
}

const FormProfessionalSummary = ({ trigger, dataSummary, setDataSummary }) => {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<SummaryFormSchema>({
    resolver: zodResolver(summaryFormSchema),
    defaultValues: {
      professionalSummary: dataSummary.professionalSummary,
    },
    mode: 'onChange',
  })
  const [openModal, setOpenModal] = useState(false)
  const [openDrawer, setOpenDrawer] = useState(false)
  const isMobile = useMediaQuery('(max-width: 640px)')

  const onSubmit = (data: SummaryFormSchema) => {
    setDataSummary((prev) => ({
      ...prev,
      professionalSummary: data.professionalSummary, // Actualizar el resumen
    }))
    setOpenModal(false)
    setOpenDrawer(false)
  }

  const getContent = () => (
    <div className="flex flex-col gap-1">
      <Textarea
        placeholder="¡Escribe de 2 a 4 oraciones cortas y enérgicas para interesar al lector! Menciona tu rol, experiencia y, lo más importante, tus mayores logros, mejores cualidades y habilidades."
        name="professionalSummary"
        className="font-inter text-xs text-secondary-500 dark:bg-white border bottom-0 resize-none xs:p-3 min-h-28"
        {...register('professionalSummary')}
      />
      {errors.professionalSummary && (
        <span className="text-xs text-destructive-500 ml-2">
          {errors.professionalSummary.message}
        </span>
      )}
    </div>
  )

  return (
    <>
      {isMobile ? (
        <>
          {trigger === 'button' ? (
            <button
              className="flex text-primary hover:text-primary-700 font-medium w-auto text-start text-sm"
              type="button"
              onClick={() => setOpenDrawer(true)}
            >
              + Agrega tu resumen profesional
            </button>
          ) : (
            <IconEdit
              stroke={1.5}
              className="text-secondary-500 cursor-pointer"
              onClick={() => setOpenDrawer(true)}
            />
          )}
          <Drawer open={openDrawer} onOpenChange={setOpenDrawer}>
            <DrawerContent className="p-4 h-[80vh] overflow-y-auto">
              <DrawerTitle className="hideen" />
              <div className="flex justify-end">
                <IconX
                  size={18}
                  stroke={1}
                  onClick={() => setOpenDrawer(!openDrawer)}
                />
              </div>
              <div className="flex flex-col gap-8 mt-3">
                <span className="font-inter text-secondary-500 text-xl font-semibold text-center">
                  Resumen profesional
                </span>
                {getContent()}
                <div className="flex justify-between">
                  <Button variant="secondary" size="md">
                    Cancelar
                  </Button>
                  <Button
                    variant="primary"
                    size="md"
                    onClick={handleSubmit(onSubmit)}
                  >
                    Guardar
                  </Button>
                </div>
              </div>
            </DrawerContent>
          </Drawer>
        </>
      ) : (
        <>
          <AlertDialog open={openModal} onOpenChange={setOpenModal}>
            <AlertDialogTrigger>
              {trigger === 'button' ? (
                <button
                  className="flex text-primary hover:text-primary-700 font-medium w-auto text-start text-sm"
                  type="button"
                  onClick={() => setOpenModal(true)}
                >
                  + Agrega tu resumen profesional
                </button>
              ) : (
                <IconEdit
                  stroke={1.5}
                  className="text-secondary-500 cursor-pointer"
                  onClick={() => setOpenModal(true)}
                />
              )}
            </AlertDialogTrigger>
            <AlertDialogContent style={{ gap: 0 }}>
              <AlertDialogTitle className="hidden" />
              <div className="flex justify-end">
                <IconX
                  stroke={1.5}
                  size={20}
                  className="cursor-pointer text-secondary-500"
                  onClick={() => setOpenModal(false)}
                />
              </div>
              <div className="flex flex-col gap-8">
                <span className="font-inter text-secondary-500 text-xl font-semibold text-center">
                  Resumen profesional
                </span>
                {getContent()}
                <AlertDialogFooter className="flex xs:flex-row xs:justify-between sm:justify-around w-full">
                  <AlertDialogCancel>Cancelar</AlertDialogCancel>
                  <AlertDialogAction onClick={handleSubmit(onSubmit)}>
                    Guardar
                  </AlertDialogAction>
                </AlertDialogFooter>
              </div>
            </AlertDialogContent>
          </AlertDialog>
        </>
      )}
    </>
  )
}

export default FormProfessionalSummary
