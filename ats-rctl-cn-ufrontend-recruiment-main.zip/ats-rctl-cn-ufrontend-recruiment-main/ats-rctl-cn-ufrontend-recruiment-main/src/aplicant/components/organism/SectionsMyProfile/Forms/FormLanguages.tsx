import { Button } from '@/components/ui/button'
import ContainerSectionMyProfile from '../../../atoms/ContainerSectionMyProfile'
import { useState } from 'react'
import { useQueryClient } from '@tanstack/react-query'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogFooter,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog'
import {
  IconEdit,
  IconGripVertical,
  IconTrash,
  IconX,
} from '@tabler/icons-react'
import LevelSelector, { levels } from '@/components/levelSelector/LevelSelector'
import FloatingSelect from '@/components/FloatingSelect'
import CardAnimatedBorderGradient from '@/components/ui/CardPulseBorder'
import { useForm } from 'react-hook-form'
import {
  languagesFormSchema,
  LanguagesFormSchema,
} from '@/aplicant/validations/ProfileProffesionalSchema'
import { zodResolver } from '@hookform/resolvers/zod'
import useMediaQuery from '@/hooks/useMediaQuery'
import { Drawer, DrawerContent, DrawerTitle } from '@/components/ui/drawer'

interface ILanguage {
  language: string
  levelLanguage: string
}
export interface IFormLanguages {
  languages: ILanguage[]
}

const arrayLanguages = [
  {
    value: 'english',
    label: 'Inglés',
  },
  {
    value: 'spanish',
    label: 'Español',
  },
  {
    value: 'portuguese',
    label: 'Portuguese',
  },
  {
    value: 'japonese',
    label: 'Japones',
  },
  {
    value: 'aleman',
    label: 'Alemán',
  },
  {
    value: 'chino',
    label: 'Chino',
  },
]

export function FormLanguages({ proffLanguages, setProffLanguages }) {
  const {
    setValue,
    watch,
    handleSubmit,
    reset,
    clearErrors,
    formState: { errors },
  } = useForm<LanguagesFormSchema>({
    resolver: zodResolver(languagesFormSchema),
    defaultValues: {
      languages: proffLanguages.languages || [
        { language: '', levelLanguage: 'basic' },
      ],
    },
    mode: 'onChange',
  })
  const isLoading = false

  const [openModal, setOpenModal] = useState(false)
  const [openDrawer, setOpenDrawer] = useState(false)
  const isMobile = useMediaQuery('(max-width: 640px)')

  const [editingLanguageIndex, setEditingLanguageIndex] = useState<
    number | null
  >(null)
  const itemsLevels = levels

  const handleChangeData = (name: 'language', value: string) => {
    setValue(`languages.${editingLanguageIndex}.${name}`, value as any)
    clearErrors(`languages.${editingLanguageIndex}.language`)
  }

  const handleLevelChange = (value: string) => {
    setValue(`languages.${editingLanguageIndex}.levelLanguage`, value)
  }

  const addLanguage = () => {
    setEditingLanguageIndex(proffLanguages.languages.length)
    reset({
      languages: [
        ...proffLanguages.languages,
        { language: '', levelLanguage: 'basic' },
      ],
    })
    setOpenModal(true)
    setOpenDrawer(true)
  }

  const editLanguage = (index: number) => {
    setEditingLanguageIndex(index)
    reset({ languages: proffLanguages.languages })
    setOpenModal(true)
    setOpenDrawer(true)
  }

  const deleteLanguage = (index: number) => {
    const newLanguages = [...proffLanguages.languages]
    newLanguages.splice(index, 1)
    setProffLanguages({ languages: newLanguages })
  }

  const findLabelByValueLanguages = (value: string): string | undefined => {
    const foundItem = arrayLanguages.find((item) => item.value === value)
    return foundItem ? foundItem.label : undefined
  }

  const findLabelByValueLevels = (value: string): string | undefined => {
    const foundItem = itemsLevels.find((item) => item.value === value)
    return foundItem ? foundItem.label : undefined
  }

  const onSubmit = (data: LanguagesFormSchema) => {
    setProffLanguages(data as IFormLanguages)
    setOpenModal(false)
    setOpenDrawer(false)
  }

  const onError = (errors) => {
    //console.log(errors)
  }

  const getContent = () => (
    <div className="flex flex-col gap-8 font-inter text-secondary-500 text-center">
      <span className="text-xl font-semibold">
        {editingLanguageIndex === proffLanguages.languages.length
          ? 'Añadir idioma'
          : 'Editar idioma'}
      </span>
      <div className="grid xs:grid-cols-1 sm:grid-cols-2 xs:gap-5 sm:gap-3">
        <div className="flex flex-col gap-1 w-full">
          <FloatingSelect
            options={arrayLanguages}
            value={watch(`languages.${editingLanguageIndex}.language`) || ''}
            onChange={handleChangeData}
            label="Idioma"
            className="w-full border"
            name="language"
            background="bg-white"
          />
          {errors?.languages?.[editingLanguageIndex]?.language && (
            <span className="text-xs text-destructive-500 ml-2">
              {errors.languages[editingLanguageIndex].language.message}
            </span>
          )}
        </div>
        <LevelSelector
          name="levelLanguage"
          onChange={handleLevelChange}
          initialLevel={
            watch(`languages.${editingLanguageIndex}.levelLanguage`) || 'basic'
          }
        />
      </div>
    </div>
  )

  return (
    <ContainerSectionMyProfile>
      {isLoading ? (
        <div>Cargando...</div>
      ) : (
        <>
          {proffLanguages?.languages.map((lng, index) => (
            <CardAnimatedBorderGradient key={index} className="rounded-lg p-3">
              <div className="flex gap-4">
                <div className="flex items-center">
                  <IconGripVertical stroke={1.5} />
                </div>
                <div className="flex justify-between w-full">
                  <div className="flex flex-col gap-1 text-secondary-500 font-inter">
                    <span className="font-medium">
                      {findLabelByValueLanguages(lng.language)}
                    </span>
                    <span className="text-sm">
                      {findLabelByValueLevels(lng.levelLanguage)}
                    </span>
                  </div>
                  <div className="flex gap-4 items-center">
                    <IconTrash
                      stroke={1.5}
                      onClick={() => deleteLanguage(index)}
                      className="text-secondary-500 cursor-pointer"
                      size={22}
                    />
                    <IconEdit
                      stroke={1.5}
                      className="text-secondary-500 cursor-pointer"
                      onClick={() => editLanguage(index)}
                    />
                  </div>
                </div>
              </div>
            </CardAnimatedBorderGradient>
          ))}
          <Button
            variant="link"
            className="text-primary py-0 justify-start"
            onClick={addLanguage}
          >
            + Añade un idioma que domines
          </Button>
        </>
      )}
      {isMobile ? (
        <Drawer open={openDrawer} onOpenChange={setOpenDrawer}>
          <DrawerContent className="p-4 h-[80vh] overflow-y-auto">
            <DrawerTitle className="hideen" />
            <div className="flex justify-end">
              <IconX
                size={18}
                stroke={1}
                onClick={() => setOpenDrawer(!openDrawer)}
              />
            </div>
            <div className="flex flex-col gap-8 mt-3">
              {getContent()}
              <div className="flex justify-between">
                <Button variant="secondary" size="md">
                  Cancelar
                </Button>
                <Button
                  variant="primary"
                  size="md"
                  onClick={handleSubmit(onSubmit)}
                >
                  Guardar
                </Button>
              </div>
            </div>
          </DrawerContent>
        </Drawer>
      ) : (
        <AlertDialog open={openModal} onOpenChange={setOpenModal}>
          <AlertDialogTrigger className="hidden" />
          <AlertDialogContent style={{ gap: 0 }}>
            <AlertDialogTitle className="hidden" />
            <div className="flex justify-end">
              <IconX
                stroke={1.5}
                size={20}
                className="cursor-pointer text-secondary-500"
                onClick={() => setOpenModal(false)}
              />
            </div>
            <div className="flex flex-col gap-8">
              {getContent()}
              <AlertDialogFooter className="flex xs:flex-row xs:justify-between sm:justify-around w-full">
                <AlertDialogCancel>Cancelar</AlertDialogCancel>
                <AlertDialogAction onClick={handleSubmit(onSubmit, onError)}>
                  Guardar
                </AlertDialogAction>
              </AlertDialogFooter>
            </div>
          </AlertDialogContent>
        </AlertDialog>
      )}
    </ContainerSectionMyProfile>
  )
}
