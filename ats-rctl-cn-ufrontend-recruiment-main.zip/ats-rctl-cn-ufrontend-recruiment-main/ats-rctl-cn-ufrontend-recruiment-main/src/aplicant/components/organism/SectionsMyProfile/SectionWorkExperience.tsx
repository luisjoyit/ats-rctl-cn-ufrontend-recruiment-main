import TitleMyProfile from '../TitleMyProfile'
import { Button } from '@/components/ui/button'
import ContainerSectionMyProfile from '../../atoms/ContainerSectionMyProfile'
import { useEffect, useState } from 'react'

import { useGraphQL } from '@/hooks/useGraphQery'
// import { getWorkExperiencesByUserId } from '@/aplicant/service/userCv.service'
import { useQueryClient } from '@tanstack/react-query'
import CardAnimatedBorderGradient from '@/components/ui/CardPulseBorder'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogFooter,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog'
import {
  IconEdit,
  IconGripVertical,
  IconTrash,
  IconX,
} from '@tabler/icons-react'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import FloatingSelect from '@/components/FloatingSelect'
import { MonthYearPicker } from '@/components/MonthYearPicker'
import { useForm } from 'react-hook-form'
import {
  experienceFormSchema,
  ExperienceFormSchema,
} from '@/aplicant/validations/ProfileExperienceSchema'
import { zodResolver } from '@hookform/resolvers/zod'
import useMediaQuery from '@/hooks/useMediaQuery'
import { Drawer, DrawerContent, DrawerTitle } from '@/components/ui/drawer'

const dataCountries = [
  {
    value: 'peru',
    label: 'Peru',
  },
  {
    value: 'bolivia',
    label: 'Bolivia',
  },
  {
    value: 'chile',
    label: 'Chile',
  },
]

const dataExperience = [
  {
    job: 'Backend Developer',
    company: 'Joyit',
    dateStart: '01/2024',
    dateEnd: '06/2024',
    country: 'peru',
    description:
      'Cooperación con los desarrolladores frontend para la integración de nuevos elementos orientados al usuario. Diseo y escritura de APIs. Aplicación de estándares de diseño, codificación y docmuentación.',
  },
]

interface IExp {
  job: string
  company: string
  dateStart: string
  dateEnd: string
  country: string
  description: string
}
export interface IFormExperience {
  experiences: IExp[]
}

const dataInitial = {
  job: '',
  company: '',
  dateStart: '',
  dateEnd: '',
  country: '',
  description: '',
}

export default function SectionWorkExperience() {
  const [itemsExperiences, setItemsExperiences] = useState<IFormExperience>({
    experiences: dataExperience || [dataInitial],
  })
  const [openModal, setOpenModal] = useState(false)
  const [openDrawer, setOpenDrawer] = useState(false)
  const isMobile = useMediaQuery('(max-width: 640px)')

  const [editingExperienceIndex, setEditingExperienceIndex] = useState<
    number | null
  >(null)
  const {
    setValue,
    watch,
    handleSubmit,
    reset,
    clearErrors,
    register,
    formState: { errors },
  } = useForm<ExperienceFormSchema>({
    resolver: zodResolver(experienceFormSchema),
    defaultValues: {
      experiences: itemsExperiences.experiences || [dataInitial],
    },
    mode: 'onChange',
  })

  const addExperience = () => {
    setEditingExperienceIndex(itemsExperiences.experiences.length)
    reset({
      experiences: [...itemsExperiences.experiences, dataInitial],
    })
    setOpenModal(true)
    setOpenDrawer(true)
  }

  const editExperience = (index: number) => {
    setEditingExperienceIndex(index)
    reset({ experiences: itemsExperiences.experiences })
    setOpenModal(true)
    setOpenDrawer(true)
  }

  const deleteExperience = (index: number) => {
    const newExperience = [...itemsExperiences.experiences]
    newExperience.splice(index, 1)
    setItemsExperiences({ experiences: newExperience })
  }

  const queryClient = useQueryClient()

  //todo: remove this
  const isLoading = false
  // const { data: worksExp, isLoading } = useGraphQL(
  //   getWorkExperiencesByUserId(),
  //   keycloak.token,
  //   {
  //     userId: 1,
  //   },
  // )

  const onSubmit = (data: IFormExperience) => {
    setItemsExperiences(data as IFormExperience)
    setOpenModal(false)
    setOpenDrawer(false)
  }

  const handleChangeData = (name: 'country', value: string) => {
    setValue(`experiences.${editingExperienceIndex}.${name}`, value as any)
    clearErrors(`experiences.${editingExperienceIndex}.${name}`)
  }

  const handleDate = (name: 'dateStart' | 'dateEnd', value: string) => {
    setValue(`experiences.${editingExperienceIndex}.${name}`, value)
    clearErrors(`experiences.${editingExperienceIndex}.${name}`)
  }

  const onError = (errors) => {
    // console.log(errors)
  }

  const getContent = () => (
    <>
      <div className="flex flex-col gap-4 font-inter text-secondary-500 text-center">
        <span className="text-xl font-semibold">
          {itemsExperiences.experiences.length - 1 < editingExperienceIndex
            ? 'Experiencia profesional'
            : 'Editar experiencia'}
        </span>
      </div>
      <div className="flex flex-col gap-4">
        <div className="grid xs:grid-cols-1 sm:grid-cols-2 xs:gap-5 sm:gap-3">
          <div className="w-full flex flex-col gap-1">
            <Input
              name="job"
              variant="floatingLabel"
              label="Puesto de trabajo *"
              {...register(`experiences.${editingExperienceIndex}.job`)}
            />
            {errors?.experiences?.[editingExperienceIndex]?.job && (
              <span className="text-xs text-destructive-500 ml-2">
                {errors.experiences[editingExperienceIndex].job.message}
              </span>
            )}
          </div>
          <div className="w-full flex flex-col gap-1">
            <Input
              name="company"
              variant="floatingLabel"
              label="Empresa *"
              {...register(`experiences.${editingExperienceIndex}.company`)}
            />
            {errors?.experiences?.[editingExperienceIndex]?.company && (
              <span className="text-xs text-destructive-500 ml-2">
                {errors.experiences[editingExperienceIndex].company.message}
              </span>
            )}
          </div>
        </div>
        <div className="flex flex-col gap-2 w-full">
          <h2 className="text-xs">Fecha de inicio y fin</h2>
          <div className="grid xs:grid-cols-1 sm:grid-cols-2 xs:gap-5 sm:gap-3">
            <div className="w-full flex flex-col gap-1">
              <div className="flex gap-2">
                <MonthYearPicker
                  name="dateStart"
                  placeholder="Inicio mm/yyyy *"
                  value={
                    watch(`experiences.${editingExperienceIndex}.dateStart`) ||
                    ''
                  }
                  onChange={(e) => handleDate('dateStart', e.target.value)}
                />
                <MonthYearPicker
                  name="dateEnd"
                  placeholder="Fin mm/yyyy *"
                  value={
                    watch(`experiences.${editingExperienceIndex}.dateEnd`) || ''
                  }
                  onChange={(e) => handleDate('dateEnd', e.target.value)}
                />
              </div>
              {errors?.experiences?.[editingExperienceIndex]?.dateStart && (
                <span className="text-xs text-destructive-500 ml-2">
                  {errors.experiences[editingExperienceIndex].dateStart.message}
                </span>
              )}
              {errors?.experiences?.[editingExperienceIndex]?.dateEnd && (
                <span className="text-xs text-destructive-500 ml-2">
                  {errors.experiences[editingExperienceIndex].dateEnd.message}
                </span>
              )}
            </div>
            <div className="w-full flex flex-col gap-1">
              <FloatingSelect
                name="country"
                onChange={handleChangeData}
                value={
                  watch(`experiences.${editingExperienceIndex}.country`) || ''
                }
                options={dataCountries}
                label="País *"
                className="border w-full"
                background="bg-white"
              />
              {errors?.experiences?.[editingExperienceIndex]?.country && (
                <span className="text-xs text-destructive-500 ml-2">
                  {errors.experiences[editingExperienceIndex].country.message}
                </span>
              )}
            </div>
          </div>
        </div>
        <div className="w-full flex flex-col gap-1">
          <Textarea
            name="description"
            placeholder="Describe 3 principales funciones que realizaste."
            className="xs:p-2"
            {...register(`experiences.${editingExperienceIndex}.description`)}
          />
          {errors?.experiences?.[editingExperienceIndex]?.description && (
            <span className="text-xs text-destructive-500 ml-2">
              {errors.experiences[editingExperienceIndex].description.message}
            </span>
          )}
        </div>
      </div>
    </>
  )

  return (
    <ContainerSectionMyProfile>
      <div className="flex flex-col gap-6">
        <CardAnimatedBorderGradient className="shadow-none border-x border-b border-t-0">
          <div className="flex flex-col gap-6">
            <TitleMyProfile className="font-inter font-semibold text-secondary-500 text-base">
              Experiencia profesional
            </TitleMyProfile>
            {isLoading ? (
              <p>Cargando...</p>
            ) : (
              <>
                {itemsExperiences?.experiences.map((exp, id) => (
                  <CardAnimatedBorderGradient
                    className="rounded-lg p-3"
                    key={id}
                  >
                    <div className="flex gap-4">
                      <div className="flex items-center">
                        <IconGripVertical stroke={1.5} />
                      </div>
                      <div className="flex justify-between w-full">
                        <div className="flex flex-col gap-1 font-inter">
                          <span className="font-medium">{exp.job}</span>
                          <span className="text-sm text-secondary-500">
                            {exp.company}
                          </span>
                          <span className="text-sm text-muted-300">
                            {exp.dateStart} - {exp.dateEnd}
                          </span>
                        </div>
                        <div className="flex gap-4 items-center">
                          <IconTrash
                            stroke={1.5}
                            onClick={() => deleteExperience(id)}
                            className="text-secondary-500 cursor-pointer"
                            size={22}
                          />
                          <IconEdit
                            stroke={1.5}
                            className="text-secondary-500 cursor-pointer"
                            onClick={() => editExperience(id)}
                          />
                        </div>
                      </div>
                    </div>
                  </CardAnimatedBorderGradient>
                ))}
                <button
                  className="text-primary hover:text-primary-700 font-medium w-fit text-start text-sm"
                  type="button"
                  onClick={addExperience}
                >
                  + Agrega una experiencia profesional
                </button>
              </>
            )}
          </div>
        </CardAnimatedBorderGradient>
      </div>
      {isMobile ? (
        <Drawer open={openDrawer} onOpenChange={setOpenDrawer}>
          <DrawerContent className="p-4 h-[80vh] overflow-y-auto">
            <DrawerTitle className="hideen" />
            <div className="flex justify-end">
              <IconX
                size={18}
                stroke={1}
                onClick={() => setOpenDrawer(!openDrawer)}
              />
            </div>
            <div className="flex flex-col gap-8 mt-3">
              {getContent()}
              <div className="flex justify-between">
                <Button variant="secondary" size="md">
                  Cancelar
                </Button>
                <Button
                  variant="primary"
                  size="md"
                  onClick={handleSubmit(onSubmit)}
                >
                  Guardar
                </Button>
              </div>
            </div>
          </DrawerContent>
        </Drawer>
      ) : (
        <AlertDialog open={openModal} onOpenChange={setOpenModal}>
          <AlertDialogTrigger className="hidden" />
          <AlertDialogContent style={{ gap: 0 }}>
            <AlertDialogTitle className="hidden" />
            <div className="flex justify-end">
              <IconX
                stroke={1.5}
                size={20}
                className="cursor-pointer text-secondary-500"
                onClick={() => setOpenModal(false)}
              />
            </div>
            <div className="flex flex-col gap-8">
              {getContent()}
              <AlertDialogFooter className="flex xs:flex-row xs:justify-between sm:justify-around w-full">
                <AlertDialogCancel>Cancelar</AlertDialogCancel>
                <AlertDialogAction onClick={handleSubmit(onSubmit, onError)}>
                  Guardar
                </AlertDialogAction>
              </AlertDialogFooter>
            </div>
          </AlertDialogContent>
        </AlertDialog>
      )}
    </ContainerSectionMyProfile>
  )
}
