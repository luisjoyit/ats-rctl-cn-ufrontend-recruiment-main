import { useState } from 'react'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogFooter,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog'
import { IconEdit, IconX } from '@tabler/icons-react'
import { Input } from '@/components/ui/input'
import {
  contactInfoFormSchema,
  ContactInfoFormSchema,
} from '@/aplicant/validations/ProfileContactSchema'
import { zodResolver } from '@hookform/resolvers/zod'
import { useForm } from 'react-hook-form'
import useMediaQuery from '@/hooks/useMediaQuery'
import { Drawer, DrawerContent, DrawerTitle } from '@/components/ui/drawer'
import { Button } from '@/components/ui/button'

export interface IFormContactInfo {
  email: string
  phone: string
}

interface IContactInfo {
  dataContact: IFormContactInfo
  setDataContact: (newData: IFormContactInfo) => void
}

const FormContactInfo = ({ dataContact, setDataContact }: IContactInfo) => {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<ContactInfoFormSchema>({
    resolver: zodResolver(contactInfoFormSchema),
    defaultValues: {
      email: dataContact.email,
      phone: dataContact.phone,
    },
    mode: 'onChange',
  })
  const [openModal, setOpenModal] = useState(false)
  const [openDrawer, setOpenDrawer] = useState(false)
  const isMobile = useMediaQuery('(max-width: 640px)')

  const onSubmit = (data: ContactInfoFormSchema) => {
    setDataContact(data as IFormContactInfo)
    setOpenModal(false)
    setOpenDrawer(false)
  }

  const getContent = () => (
    <div className="flex flex-col gap-6">
      <div className="flex flex-col gap-1">
        <Input
          name="email"
          placeholder="Email"
          variant="floatingLabel"
          label="Correo electrónico *"
          type="text"
          className="text-sm w-full"
          {...register('email')}
        />
        {errors.email && (
          <span className="text-xs text-destructive-500 ml-2">
            {errors.email.message}
          </span>
        )}
      </div>
      <div className="flex flex-col gap-1">
        <Input
          name="phone"
          placeholder="Teléfono"
          variant="floatingLabel"
          label="Teléfono *"
          type="text"
          className="text-sm w-full"
          {...register('phone')}
        />
        {errors.phone && (
          <span className="text-xs text-destructive-500 ml-2">
            {errors.phone.message}
          </span>
        )}
      </div>
    </div>
  )

  return (
    <>
      {isMobile ? (
        <>
          <IconEdit
            stroke={1.5}
            className="text-secondary-500 cursor-pointer"
            onClick={() => setOpenDrawer(true)}
          />
          <Drawer
            open={openDrawer}
            onOpenChange={setOpenDrawer}
            //onClose={}
          >
            <DrawerContent className="p-4 h-[80vh] overflow-y-auto">
              <DrawerTitle className="hidden" />
              <div className="flex justify-end">
                <IconX
                  size={18}
                  stroke={1}
                  onClick={() => setOpenDrawer(!openDrawer)}
                />
              </div>
              <div className="flex flex-col gap-8 mt-3">
                <span className="font-inter text-secondary-500 text-xl font-semibold text-center">
                  Información de contacto
                </span>
                {getContent()}
                <div className="flex justify-between">
                  <Button variant="secondary" size="md">
                    Cancelar
                  </Button>
                  <Button
                    variant="primary"
                    size="md"
                    onClick={handleSubmit(onSubmit)}
                  >
                    Guardar
                  </Button>
                </div>
              </div>
            </DrawerContent>
          </Drawer>
        </>
      ) : (
        <AlertDialog open={openModal} onOpenChange={setOpenModal}>
          <AlertDialogTrigger>
            <IconEdit
              stroke={1.5}
              className="text-secondary-500 cursor-pointer"
              onClick={() => setOpenModal(true)}
            />
          </AlertDialogTrigger>
          <AlertDialogContent style={{ gap: 0 }}>
            <AlertDialogTitle className="hidden" />
            <div className="flex justify-end">
              <IconX
                stroke={1.5}
                size={20}
                className="cursor-pointer text-secondary-500"
                onClick={() => setOpenModal(false)}
              />
            </div>
            <div className="flex flex-col gap-8">
              <span className="font-inter text-secondary-500 text-xl font-semibold text-center">
                Información de contacto
              </span>
              {getContent()}
              <AlertDialogFooter className="flex xs:flex-row xs:justify-between sm:justify-around w-full">
                <AlertDialogCancel>Cancelar</AlertDialogCancel>
                <AlertDialogAction onClick={handleSubmit(onSubmit)}>
                  Guardar
                </AlertDialogAction>
              </AlertDialogFooter>
            </div>
          </AlertDialogContent>
        </AlertDialog>
      )}
    </>
  )
}

export default FormContactInfo
