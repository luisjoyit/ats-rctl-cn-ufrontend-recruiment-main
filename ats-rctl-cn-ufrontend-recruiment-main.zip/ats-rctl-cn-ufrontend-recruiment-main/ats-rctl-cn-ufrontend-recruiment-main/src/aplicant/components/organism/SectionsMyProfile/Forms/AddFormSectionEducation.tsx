// import {
//   createEducationsUserCv,
//   createWorkExperienceUserCv,
// } from '@/aplicant/service/userCv.service'

import { Input } from '@/components/ui/input'
import { useGraphQLMutation } from '@/hooks/userMutation'

import { IconX } from '@tabler/icons-react'
import { QueryClient } from '@tanstack/react-query'
import { useEffect, useRef, useState } from 'react'
import { toast } from 'sonner'
import { MonthYearPicker } from '@/components/MonthYearPicker'
import FloatingSelect from '@/components/FloatingSelect'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogFooter,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog'
import useMediaQuery from '@/hooks/useMediaQuery'
import { Drawer, DrawerContent, DrawerTitle } from '@/components/ui/drawer'
import { Button } from '@/components/ui/button'

const typeEducation = [
  {
    value: 'bach',
    label: 'Bachillerato',
  },
  {
    value: 'tec',
    label: 'Técnico',
  },
  {
    value: 'lic',
    label: 'Licenciatura',
  },
  {
    value: 'esp',
    label: 'Especialización',
  },
  {
    value: 'maest',
    label: 'Maestría',
  },
  {
    value: 'doc',
    label: 'Doctorado',
  },
  {
    value: 'online',
    label: 'Curso Online',
  },
  {
    value: 'dip',
    label: 'Diplomado',
  },
  {
    value: 'taller',
    label: 'Taller',
  },
  {
    value: 'boot',
    label: 'Bootcamp',
  },
  {
    value: 'prog',
    label: 'Programa de Intercambio',
  },
]

interface IEduc {
  name: string
  institution: string
  dateStart: string
  dateEnd: string
  typeEduc: string
}

export interface IFormEducation {
  education: IEduc[]
}

export default function AddFormSectionEducation({
  open,
  setOpen,
  itemsEducations,
  setItemsEducations,
  indexEdit,
  register,
  setValue,
  clearErrors,
  handleSubmit,
  watch,
  errors,
}) {
  const formRef = useRef(null)
  // const { mutate } = useGraphQLMutation(
  //   createEducationsUserCv(),
  //   keycloak.token,
  //   {
  //     onSuccess: (data) => {
  //       queryClient.invalidateQueries({
  //         queryKey: ['education', { userId: 1 }],
  //       })
  //       toast.success('Se guardo correctamente')
  //       handleClickHiddenForm()
  //     },
  //     onError: (error) => {
  //       toast.error('Ocurrio un error al guardar los datos')
  //     },
  //   },
  // )

  const isMobile = useMediaQuery('(max-width: 640px)')

  const handleChangeData = (name: 'typeEduc', value: string) => {
    setValue(`education.${indexEdit}.${name}`, value as any)
    clearErrors(`education.${indexEdit}.${name}`)
  }

  const handleDate = (name: 'dateStart' | 'dateEnd', value: string) => {
    setValue(`education.${indexEdit}.${name}`, value)
    clearErrors(`education.${indexEdit}.${name}`)
  }

  const onSubmit = (data: IFormEducation) => {
    setItemsEducations(data as IFormEducation)
    setOpen(false)
  }

  const onError = (errors) => {
    // console.log(errors)
  }

  const getContent = () => (
    <>
      <div className="flex flex-col gap-4 font-inter text-secondary-500 text-center">
        <span className="text-xl font-semibold">Formación académica</span>
      </div>
      <div className="flex flex-col gap-4">
        <div className="grid xs:grid-cols-1 sm:grid-cols-2 xs:gap-5 sm:gap-3">
          <div className="w-full flex flex-col gap-1">
            <Input
              name="name"
              variant="floatingLabel"
              label="Nombre de Curso/Programa *"
              {...register(`education.${indexEdit}.name`)}
            />
            {errors?.education?.[indexEdit]?.name && (
              <span className="text-xs text-destructive-500 ml-2">
                {errors.education[indexEdit].name.message}
              </span>
            )}
          </div>
          <div className="w-full flex flex-col gap-1">
            <Input
              name="institution"
              variant="floatingLabel"
              label="Institución Educativa *"
              {...register(`education.${indexEdit}.institution`)}
            />
            {errors?.education?.[indexEdit]?.institution && (
              <span className="text-xs text-destructive-500 ml-2">
                {errors.education[indexEdit].institution.message}
              </span>
            )}
          </div>
        </div>
        <div className="flex flex-col gap-2 w-full">
          <h2 className="text-xs">Fecha de inicio y fin</h2>
          <div className="grid xs:grid-cols-1 sm:grid-cols-2 xs:gap-5 sm:gap-3">
            <div className="w-full flex flex-col gap-1">
              <div className="flex gap-2">
                <MonthYearPicker
                  name="dateStart"
                  placeholder="Inicio mm/yyyy *"
                  value={watch(`education.${indexEdit}.dateStart`) || ''}
                  onChange={(e) => handleDate('dateStart', e.target.value)}
                />
                <MonthYearPicker
                  name="dateEnd"
                  placeholder="Fin mm/yyyy *"
                  value={watch(`education.${indexEdit}.dateEnd`) || ''}
                  onChange={(e) => handleDate('dateEnd', e.target.value)}
                />
              </div>
              {errors?.education?.[indexEdit]?.dateStart && (
                <span className="text-xs text-destructive-500 ml-2">
                  {errors.education[indexEdit].dateStart.message}
                </span>
              )}
              {errors?.education?.[indexEdit]?.dateEnd && (
                <span className="text-xs text-destructive-500 ml-2">
                  {errors.education[indexEdit].dateEnd.message}
                </span>
              )}
            </div>
            <div className="w-full flex flex-col gap-1">
              <FloatingSelect
                name="typeEduc"
                onChange={handleChangeData}
                value={watch(`education.${indexEdit}.typeEduc`) || ''}
                options={typeEducation}
                label="Tipo *"
                className="border w-full"
                background="bg-white"
              />
              {errors?.education?.[indexEdit]?.typeEduc && (
                <span className="text-xs text-destructive-500 ml-2">
                  {errors.education[indexEdit].typeEduc.message}
                </span>
              )}
            </div>
          </div>
        </div>
      </div>
    </>
  )

  return (
    <>
      {isMobile ? (
        <Drawer open={open} onOpenChange={setOpen}>
          <DrawerContent className="p-4 h-[80vh] overflow-y-auto">
            <DrawerTitle className="hideen" />
            <div className="flex justify-end">
              <IconX size={18} stroke={1} onClick={() => setOpen(!open)} />
            </div>
            <div className="flex flex-col gap-8 mt-3">
              {getContent()}
              <div className="flex justify-between">
                <Button variant="secondary" size="md">
                  Cancelar
                </Button>
                <Button
                  variant="primary"
                  size="md"
                  onClick={handleSubmit(onSubmit)}
                >
                  Guardar
                </Button>
              </div>
            </div>
          </DrawerContent>
        </Drawer>
      ) : (
        <AlertDialog open={open} onOpenChange={setOpen}>
          <AlertDialogTrigger className="hidden" />
          <AlertDialogContent style={{ gap: 0 }}>
            <AlertDialogTitle className="hidden" />
            <div className="flex justify-end">
              <IconX
                stroke={1.5}
                size={20}
                className="cursor-pointer text-secondary-500"
                onClick={() => setOpen(false)}
              />
            </div>
            <div className="flex flex-col gap-8">
              {getContent()}
              <AlertDialogFooter className="flex xs:flex-row xs:justify-between sm:justify-around w-full">
                <AlertDialogCancel>Cancelar</AlertDialogCancel>
                <AlertDialogAction onClick={handleSubmit(onSubmit, onError)}>
                  Guardar
                </AlertDialogAction>
              </AlertDialogFooter>
            </div>
          </AlertDialogContent>
        </AlertDialog>
      )}
    </>
  )
}
