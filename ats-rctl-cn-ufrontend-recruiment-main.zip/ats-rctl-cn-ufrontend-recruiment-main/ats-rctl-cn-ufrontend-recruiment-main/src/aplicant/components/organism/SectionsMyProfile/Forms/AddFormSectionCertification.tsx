import CardAnimatedBorderGradient from '@/components/ui/CardPulseBorder'
import { Input } from '@/components/ui/input'
import {
  IconEdit,
  IconGripVertical,
  IconTrash,
  IconUpload,
  IconX,
} from '@tabler/icons-react'
import { QueryClient } from '@tanstack/react-query'
import { useRef, useState } from 'react'
import { MonthYearPicker } from '@/components/MonthYearPicker'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import {
  certificationFormSchema,
  CertificationFormSchema,
} from '@/aplicant/validations/ProfileEducationSchema'
import TitleMyProfile from '../../TitleMyProfile'
import { Button } from '@/components/ui/button'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogFooter,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog'
import useMediaQuery from '@/hooks/useMediaQuery'
import { Drawer, DrawerContent, DrawerTitle } from '@/components/ui/drawer'

interface ICert {
  name: string
  institution: string
  dateStart: string
  dateEnd: string
  urlCertificate: string
  fileCertificate: File | null
}

interface IFormCertification {
  certificates: ICert[]
}

const dataCertificate = [
  {
    name: 'Certificacion en Diseño UX/UI',
    institution: 'Coursera',
    dateStart: '01/2024',
    dateEnd: '06/2024',
    urlCertificate: '',
    fileCertificate: null,
  },
]

const dataInitial = {
  name: '',
  institution: '',
  dateStart: '',
  dateEnd: '',
  urlCertificate: '',
  fileCertificate: null,
}

export default function AddFormSectionCertification() {
  const [itemsCertificates, setItemsCertificates] =
    useState<IFormCertification>({
      certificates: dataCertificate || [dataInitial],
    })

  const [open, setOpen] = useState(false)
  const isMobile = useMediaQuery('(max-width: 640px)')

  const [editingCertificateIndex, setEditingCertificateIndex] = useState<
    number | null
  >(null)

  const inputRef = useRef(null)

  const [fileName, setFileName] = useState('')

  const handleChangeFile = (e) => {
    const file = e.target.files?.[0]
    if (file) {
      setValue(`certificates.${editingCertificateIndex}.fileCertificate`, file)
      const fileName = file.name
      setFileName(fileName)
    }
  }

  const handleButtonUpload = () => {
    inputRef.current.click()
  }

  const {
    reset,
    register,
    setValue,
    clearErrors,
    handleSubmit,
    watch,
    formState: { errors },
  } = useForm<CertificationFormSchema>({
    resolver: zodResolver(certificationFormSchema),
    defaultValues: {
      certificates: itemsCertificates.certificates || [dataInitial],
    },
    mode: 'onChange',
  })

  const addCertification = () => {
    setEditingCertificateIndex(itemsCertificates.certificates.length)
    reset({
      certificates: [...itemsCertificates.certificates, dataInitial],
    })
    setOpen(true)
  }

  const editCertification = (index: number) => {
    setEditingCertificateIndex(index)
    reset({ certificates: itemsCertificates.certificates })
    setOpen(true)
  }

  const deleteCertification = (index: number) => {
    const newCertificate = [...itemsCertificates.certificates]
    newCertificate.splice(index, 1)
    setItemsCertificates({ certificates: newCertificate })
  }

  const handleDate = (name: 'dateStart' | 'dateEnd', value: string) => {
    setValue(`certificates.${editingCertificateIndex}.${name}`, value)
    clearErrors(`certificates.${editingCertificateIndex}.${name}`)
  }

  const onSubmit = (data: IFormCertification) => {
    setItemsCertificates(data as IFormCertification)
    setOpen(false)
  }

  const onError = (errors) => {
    //console.log(errors)
  }

  const getContent = () => (
    <>
      <div className="flex flex-col gap-4 font-inter text-secondary-500 text-center">
        <span className="text-xl font-semibold">
          {dataCertificate.length - 1 < editingCertificateIndex
            ? 'Nuevo Certificado'
            : 'Editar Certificado'}
        </span>
      </div>
      <div className="flex flex-col gap-4">
        <div className="grid xs:grid-cols-1 sm:grid-cols-2 xs:gap-5 sm:gap-3">
          <div className="w-full flex flex-col gap-1">
            <Input
              name="name"
              variant="floatingLabel"
              label="Nombre de Curso/Programa *"
              {...register(`certificates.${editingCertificateIndex}.name`)}
            />
            {errors?.certificates?.[editingCertificateIndex]?.name && (
              <span className="text-xs text-destructive-500 ml-2">
                {errors.certificates[editingCertificateIndex].name.message}
              </span>
            )}
          </div>
          <div className="w-full flex flex-col gap-1">
            <Input
              name="institution"
              variant="floatingLabel"
              label="Institución Educativa *"
              {...register(
                `certificates.${editingCertificateIndex}.institution`,
              )}
            />
            {errors?.certificates?.[editingCertificateIndex]?.institution && (
              <span className="text-xs text-destructive-500 ml-2">
                {
                  errors.certificates[editingCertificateIndex].institution
                    .message
                }
              </span>
            )}
          </div>
        </div>
        <div className="flex flex-col gap-2 w-full">
          <h2 className="text-xs">Fecha de inicio y fin</h2>
          <div className="grid xs:grid-cols-1 sm:grid-cols-2 xs:gap-5 sm:gap-3">
            <div className="w-full flex flex-col gap-1">
              <div className="flex gap-2">
                <MonthYearPicker
                  name="dateStart"
                  placeholder="Inicio mm/yyyy *"
                  value={
                    watch(
                      `certificates.${editingCertificateIndex}.dateStart`,
                    ) || ''
                  }
                  onChange={(e) => handleDate('dateStart', e.target.value)}
                />
                <MonthYearPicker
                  name="dateEnd"
                  placeholder="Fin mm/yyyy *"
                  value={
                    watch(`certificates.${editingCertificateIndex}.dateEnd`) ||
                    ''
                  }
                  onChange={(e) => handleDate('dateEnd', e.target.value)}
                />
              </div>
              {errors?.certificates?.[editingCertificateIndex]?.dateStart && (
                <span className="text-xs text-destructive-500 ml-2">
                  {
                    errors.certificates[editingCertificateIndex].dateStart
                      .message
                  }
                </span>
              )}
              {errors?.certificates?.[editingCertificateIndex]?.dateEnd && (
                <span className="text-xs text-destructive-500 ml-2">
                  {errors.certificates[editingCertificateIndex].dateEnd.message}
                </span>
              )}
            </div>
            <div className="w-full flex flex-col gap-1">
              <Input
                name="urlCertificate"
                variant="floatingLabel"
                label="Url de certificación *"
                {...register(
                  `certificates.${editingCertificateIndex}.urlCertificate`,
                )}
              />
              {errors?.certificates?.[editingCertificateIndex]
                ?.urlCertificate && (
                <span className="text-xs text-destructive-500 ml-2">
                  {
                    errors.certificates[editingCertificateIndex].urlCertificate
                      .message
                  }
                </span>
              )}
            </div>
          </div>
        </div>
        <div className="grid grid-cols-1">
          <button
            type="button"
            className="h-[101px] border-dashed border bg-accent-50 flex flex-col items-center justify-center gap-3 rounded-lg"
            onClick={handleButtonUpload}
          >
            <input
              type="file"
              ref={inputRef}
              className="hidden"
              accept="image/*,.pdf"
              onChange={handleChangeFile}
            />
            <IconUpload stroke={1.5} size={18} className="cursor-pointer" />
            <h2 className="text-xs text-secondary-500">
              {fileName === '' ? 'Subir certificado' : fileName}
            </h2>
          </button>
        </div>
      </div>
    </>
  )

  return (
    <CardAnimatedBorderGradient>
      <div className="flex flex-col gap-6">
        <TitleMyProfile className="font-inter font-semibold text-secondary-500 text-base">
          Certificaciones
        </TitleMyProfile>
        <>
          {itemsCertificates?.certificates.map((element, id) => (
            <CardAnimatedBorderGradient className="rounded-lg p-3" key={id}>
              <div className="flex gap-4">
                <div className="flex items-center">
                  <IconGripVertical stroke={1.5} />
                </div>
                <div className="flex justify-between w-full">
                  <div className="flex flex-col gap-1 font-inter">
                    <span className="font-medium">{element.name}</span>
                    <span className="text-sm text-secondary-500">
                      {element.institution}
                    </span>
                    <span className="text-sm text-muted-300">
                      {element.dateStart} - {element.dateEnd}
                    </span>
                  </div>
                  <div className="flex gap-4 items-center">
                    <IconTrash
                      stroke={1.5}
                      onClick={() => deleteCertification(id)}
                      className="text-secondary-500 cursor-pointer"
                      size={22}
                    />
                    <IconEdit
                      stroke={1.5}
                      className="text-secondary-500 cursor-pointer"
                      onClick={() => editCertification(id)}
                    />
                  </div>
                </div>
              </div>
            </CardAnimatedBorderGradient>
          ))}
          <button
            className="text-primary hover:text-primary-700 font-medium w-fit text-start text-sm"
            type="button"
            onClick={addCertification}
          >
            + Agrega una certificación
          </button>
        </>
      </div>
      {isMobile ? (
        <Drawer open={open} onOpenChange={setOpen}>
          <DrawerContent className="p-4 h-[90vh] overflow-y-auto">
            <DrawerTitle className="hideen" />
            <div className="flex justify-end">
              <IconX size={18} stroke={1} onClick={() => setOpen(!open)} />
            </div>
            <div className="flex flex-col gap-8 mt-3">
              {getContent()}
              <div className="flex justify-between">
                <Button variant="secondary" size="md">
                  Cancelar
                </Button>
                <Button
                  variant="primary"
                  size="md"
                  onClick={handleSubmit(onSubmit)}
                >
                  Guardar
                </Button>
              </div>
            </div>
          </DrawerContent>
        </Drawer>
      ) : (
        <AlertDialog open={open} onOpenChange={setOpen}>
          <AlertDialogTrigger className="hidden" />
          <AlertDialogContent style={{ gap: 0 }}>
            <AlertDialogTitle className="hidden" />
            <div className="flex justify-end">
              <IconX
                stroke={1.5}
                size={20}
                className="cursor-pointer text-secondary-500"
                onClick={() => setOpen(false)}
              />
            </div>
            <div className="flex flex-col gap-8">
              {getContent()}
              <AlertDialogFooter className="flex xs:flex-row xs:justify-between sm:justify-around w-full">
                <AlertDialogCancel>Cancelar</AlertDialogCancel>
                <AlertDialogAction onClick={handleSubmit(onSubmit, onError)}>
                  Guardar
                </AlertDialogAction>
              </AlertDialogFooter>
            </div>
          </AlertDialogContent>
        </AlertDialog>
      )}
    </CardAnimatedBorderGradient>
  )
}
