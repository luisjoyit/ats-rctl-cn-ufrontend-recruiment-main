import TitleMyProfile from '../TitleMyProfile'
import ContainerSectionMyProfile from '../../atoms/ContainerSectionMyProfile'

import { useGraphQL } from '@/hooks/useGraphQery'
// import { getProfileTypes } from '@/service/profileType.service'
// import { getYearsExperience } from '@/service/yearsExperience.service'
// import {
//   createOrUpdateUserCv,
//   getUserCV,
// } from '@/aplicant/service/userCv.service'
import { useGraphQLMutation } from '@/hooks/userMutation'
import { useState } from 'react'
import { yearsExperienceService } from '@/service'
import FloatingSelect from '@/components/FloatingSelect'
import CardAnimatedBorderGradient from '@/components/ui/CardPulseBorder'
import {
  IFormStackTech,
  FormTechnologyStack,
} from './Forms/FormTechnologyStack'
import FormProfessionalSummary, {
  IFormSummary,
} from './Forms/FormProfessionalSummary'
import FormSalaryPreference, {
  IFormSalarity,
} from './Forms/FormSalaryPreference'
import FormModality, { IFormModality } from './Forms/FormModality'

import { Languages } from 'lucide-react'
import { IconEdit } from '@tabler/icons-react'
import { FormLanguages, IFormLanguages } from './Forms/FormLanguages'

const dataProfessional = {
  profileType: 'UX/UI Designer',
  yearsExperience: 4,
  levelSeniority: 'senior',
  // professionalSummary:
  //   '¡Soy una diseñadora UX/UI apasionada y creativa con más de cinco años de experiencia en la industria! Mi enfoque centrado en el usuario ha impulsado el éxito de numerosos proyectos, destacando por mi capacidad para fusionar diseño estético con funcionalidad excepcional.',
  professionalSummary: '',
  stackTech: ['figma', 'framer', 'jira'],
  rangeSalarity: [500, 1500],
  adHonoren: false,
  modality: ['freelance', 'remote'],
  languages: [
    {
      language: 'english',
      levelLanguage: 'basic',
    },
  ],
}

const dataYears = [
  {
    value: '1',
    label: '1',
  },
  {
    value: '2',
    label: '2',
  },
  {
    value: '3',
    label: '3',
  },
  {
    value: '4',
    label: '4',
  },
  {
    value: '5',
    label: '5',
  },
  {
    value: '6',
    label: '6',
  },
  {
    value: '7',
    label: '7',
  },
  {
    value: '8',
    label: '8',
  },
  {
    value: '9',
    label: '9',
  },
  {
    value: '10',
    label: '+ 10',
  },
]

const dataProfile = [
  {
    value: 'mobile',
    label: 'Mobile',
  },
  {
    value: 'frontend',
    label: 'Frontend',
  },
  {
    value: 'backend',
    label: 'Backend',
  },
  {
    value: 'data',
    label: 'Data',
  },
  {
    value: 'itmanagement',
    label: 'IT Management',
  },
]

const dataLevelSeniority = [
  {
    value: 'junior',
    label: 'Junior',
  },
  {
    value: 'semiSenior',
    label: 'Semi-senior',
  },
  {
    value: 'senior',
    label: 'Senior',
  },
  {
    value: 'lead',
    label: 'Lead',
  },
  {
    value: 'principal',
    label: 'Principal',
  },
]

interface IFormProffesionalRole {
  profileType: string
  yearsExperience: number
  levelSeniority: string
}

export default function SectionProffesionalResume() {
  //todo: remove this
  const isLoading = false
  // const { data: profiteTypeData } = useGraphQL(
  //   getProfileTypes(),
  //   keycloak.token,
  // )
  // const { data: yearsExpData } = useGraphQL(
  //   getYearsExperience(),
  //   keycloak.token,
  // )

  // const { data: userCvData, isLoading } = useGraphQL(
  //   getUserCV(),
  //   keycloak.token,
  //   {
  //     userId: 1,
  //   },
  // )

  // const profileTypes = profiteTypeData?.profileTypes.map((profile) => {
  //   return {
  //     value: profile.id,
  //     label: profile.name,
  //   }
  // })

  // const yearsTypes = yearsExpData?.yearsExperiences.map((profile) => {
  //   return {
  //     value: profile.id,
  //     label: profile.years,
  //   }
  // })

  // const { mutate } = useGraphQLMutation(createOrUpdateUserCv(), keycloak.token)

  const [dataProfessionalRole, setDataProfessionalRole] =
    useState<IFormProffesionalRole>({
      profileType: dataProfessional?.profileType || '',
      yearsExperience: dataProfessional?.yearsExperience || 1,
      levelSeniority: dataProfessional?.levelSeniority || '',
    })

  //Actualización de campos rol, años y levelSeniority
  const handleChange = (name: string, value: string) => {
    setDataProfessionalRole((prevState) => ({
      ...prevState,
      [name]: name === 'yearsExperience' ? Number(value) : value,
    }))
  }

  const [summary, setSummary] = useState<IFormSummary>({
    professionalSummary: dataProfessional?.professionalSummary || '',
  })

  const [dataProfessionalStack, setDataProfessionalStack] =
    useState<IFormStackTech>({
      stackTech: dataProfessional?.stackTech || [],
    })

  const [dataProfessionalSalarity, setDataProfessionalSalarity] =
    useState<IFormSalarity>({
      rangeSalarity: dataProfessional?.rangeSalarity || [],
      adHonoren: dataProfessional?.adHonoren || false,
    })

  const [dataProfessionalModality, setDataProfessionalModality] =
    useState<IFormModality>({
      modality: dataProfessional?.modality || [],
    })

  const [dataProfessionalLanguages, setDataProfessionalLanguages] =
    useState<IFormLanguages>({
      languages: dataProfessional?.languages || [
        { language: '', levelLanguage: '' },
      ],
    })

  const [openDrawerSalarity, setOpenDrawerSalarity] = useState(false)
  const [openDrawerModality, setOpenDrawerModality] = useState(false)

  return (
    <ContainerSectionMyProfile>
      <div className="flex flex-col gap-6">
        <CardAnimatedBorderGradient className="shadow-none border-x border-b border-t-0">
          <div className="flex flex-col gap-6">
            <TitleMyProfile className="font-inter font-semibold text-secondary-500 text-base">
              Rol profesional
            </TitleMyProfile>
            <form
              onSubmit={(e) => e.preventDefault()}
              className="grid xs:grid-cols-1 sm:grid-cols-3 xs:gap-3 sm:gap-4"
            >
              <div>
                <FloatingSelect
                  options={dataProfile}
                  value={String(dataProfessionalRole.profileType)}
                  onChange={handleChange}
                  label="Rol"
                  className="w-full border"
                  name="profileType"
                  background="bg-white"
                />
              </div>
              <div>
                <FloatingSelect
                  options={dataYears}
                  value={String(dataProfessionalRole.yearsExperience)}
                  onChange={handleChange}
                  label="Años de Exp."
                  className="w-full border"
                  name="yearsExperience"
                  background="bg-white"
                />
              </div>
              <div>
                <FloatingSelect
                  options={dataLevelSeniority}
                  value={String(dataProfessionalRole.levelSeniority)}
                  onChange={handleChange}
                  label="Nivel de seniority"
                  className="w-full border"
                  name="levelSeniority"
                  background="bg-white"
                />
              </div>
            </form>
          </div>
        </CardAnimatedBorderGradient>
        <CardAnimatedBorderGradient>
          <div className="flex flex-col xs:gap-3 sm:gap-6">
            <div className="flex justify-between">
              <h1 className="font-inter font-semibold text-secondary-500">
                Resumen Profesional
              </h1>
              <div className="xs:block sm:hidden">
                {summary.professionalSummary !== '' && (
                  <FormProfessionalSummary
                    trigger="icon"
                    dataSummary={summary}
                    setDataSummary={setSummary}
                  />
                )}
              </div>
            </div>
            {summary.professionalSummary === '' ? (
              <FormProfessionalSummary
                trigger="button"
                dataSummary={summary}
                setDataSummary={setSummary}
              />
            ) : (
              <div className="flex gap-3">
                <div className="border xs:w-full sm:w-[90%] rounded-[11px] p-4">
                  <p className="text-sm">{summary.professionalSummary}</p>
                </div>
                <div className="w-auto xs:hidden sm:flex justify-end items-center flex-1">
                  <FormProfessionalSummary
                    trigger="icon"
                    dataSummary={summary}
                    setDataSummary={setSummary}
                  />
                </div>
              </div>
            )}
          </div>
        </CardAnimatedBorderGradient>
        <CardAnimatedBorderGradient>
          <div className="flex flex-col gap-6">
            <h1 className="font-inter font-semibold text-secondary-500">
              Stack Tech
            </h1>
            <FormTechnologyStack
              dataProfessionalStack={dataProfessionalStack}
              setDataProfessionalStack={setDataProfessionalStack}
            />
          </div>
        </CardAnimatedBorderGradient>
        <CardAnimatedBorderGradient>
          <div className="flex flex-col gap-6">
            <div className="flex justify-between">
              <h1 className="font-inter font-semibold text-secondary-500">
                Preferencia Salarial
              </h1>
              <IconEdit
                stroke={1.5}
                className="text-secondary-500 cursor-pointer xs:flex sm:hidden"
                onClick={() => setOpenDrawerSalarity(true)}
              />
            </div>
            <FormSalaryPreference
              dataSalarity={dataProfessionalSalarity}
              setDataSalarity={setDataProfessionalSalarity}
              openDrawer={openDrawerSalarity}
              setOpenDrawer={setOpenDrawerSalarity}
            />
          </div>
        </CardAnimatedBorderGradient>
        <CardAnimatedBorderGradient>
          <div className="flex flex-col gap-6">
            <div className="flex justify-between">
              <h1 className="font-inter font-semibold text-secondary-500">
                Modalidad
              </h1>
              <IconEdit
                stroke={1.5}
                className="text-secondary-500 cursor-pointer xs:flex sm:hidden"
                onClick={() => setOpenDrawerModality(true)}
              />
            </div>
            <FormModality
              modality={dataProfessionalModality}
              setModality={setDataProfessionalModality}
              openDrawer={openDrawerModality}
              setOpenDrawer={setOpenDrawerModality}
            />
          </div>
        </CardAnimatedBorderGradient>
        <CardAnimatedBorderGradient>
          <div className="flex flex-col gap-6">
            <h1 className="font-inter font-semibold text-secondary-500">
              Idiomas
            </h1>
            <FormLanguages
              proffLanguages={dataProfessionalLanguages}
              setProffLanguages={setDataProfessionalLanguages}
            />
          </div>
        </CardAnimatedBorderGradient>
      </div>
    </ContainerSectionMyProfile>
  )
}
