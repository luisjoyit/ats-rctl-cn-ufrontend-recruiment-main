import {
  modalityFormSchema,
  ModalityFormSchema,
} from '@/aplicant/validations/ProfileProffesionalSchema'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogFooter,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog'
import { Button } from '@/components/ui/button'
import { Drawer, DrawerContent, DrawerTitle } from '@/components/ui/drawer'
import useMediaQuery from '@/hooks/useMediaQuery'
import { zodResolver } from '@hookform/resolvers/zod'
import { IconEdit, IconX } from '@tabler/icons-react'
import { useState } from 'react'
import { useForm } from 'react-hook-form'

const itmesModalities = [
  {
    value: 'remote',
    label: 'Remote',
  },
  {
    value: 'freelance',
    label: 'Freelance',
  },
  {
    value: 'inPerson',
    label: 'Presencial',
  },
  {
    value: 'hibryd',
    label: 'Híbrido',
  },
  {
    value: 'preProffesional',
    label: 'Prácticas Pre-Profesionales',
  },
  {
    value: 'proffesional',
    label: 'Prácticas Profesionales',
  },
]

export interface IFormModality {
  modality: string[]
}

const FormModality = ({ modality, setModality, openDrawer, setOpenDrawer }) => {
  const {
    setValue,
    watch,
    handleSubmit,
    formState: { errors },
  } = useForm<ModalityFormSchema>({
    resolver: zodResolver(modalityFormSchema),
    defaultValues: {
      modality: modality.modality || [],
    },
    mode: 'onChange',
  })
  const [openModal, setOpenModal] = useState(false)
  const isMobile = useMediaQuery('(max-width: 640px)')

  const watchedModality = watch('modality', modality.modality || [])

  const findLabelByValueModalities = (value: string): string | undefined => {
    const foundItem = itmesModalities.find((item) => item.value === value)
    return foundItem ? foundItem.label : undefined
  }

  const handleModalityChange = (value: string) => {
    const currentValues = watchedModality || []
    const newValues = currentValues.includes(value)
      ? currentValues.filter((item) => item !== value)
      : [...currentValues, value]
    setValue('modality', newValues)
    setModality({ modality: newValues })
  }

  const handleDeleteModality = (value: string) => {
    const updatedModalities = watchedModality.filter((item) => item !== value)
    setValue('modality', updatedModalities)
    setModality({ modality: updatedModalities })
  }

  const onSubmit = (data: ModalityFormSchema) => {
    setModality(data as IFormModality)
    setOpenModal(false)
    setOpenDrawer(false)
  }

  const getContent = () => (
    <div className="flex flex-col gap-8 font-inter text-secondary-500 text-center">
      <span className="text-xl font-semibold">
        Selecciona tu modalidad preferida
      </span>
      <div className="flex flex-wrap gap-3">
        {itmesModalities.map((item, index) => (
          <button
            key={index}
            type="button"
            className={`h-[31px] text-xs font-inter rounded-[50px] px-3 flex justify-center items-center ${watchedModality.includes(item.value) ? 'bg-secondary-500 text-white' : 'bg-accent-200 text-secondary-500'}`}
            onClick={() => handleModalityChange(item.value)} // Cambiar selección
          >
            {item.label}
          </button>
        ))}
      </div>
    </div>
  )

  return (
    <div>
      {modality?.modality.length !== 0 ? (
        <div className="flex justify-between gap-3">
          <div className="flex flex-wrap gap-4">
            {modality?.modality.map((item, index) => (
              <div
                key={index}
                className="flex h-[37px] px-5 justify-between items-center gap-3 bg-accent-200 rounded-[50px]"
              >
                <span>{findLabelByValueModalities(item)}</span>
                <IconX
                  size={14}
                  className="text-secondary-500 cursor-pointer"
                  onClick={() => handleDeleteModality(item)}
                />
              </div>
            ))}
          </div>
          <div>
            <IconEdit
              stroke={1.5}
              className="text-secondary-500 cursor-pointer  xs:hidden sm:flex"
              onClick={() => setOpenModal(true)}
            />
          </div>
        </div>
      ) : (
        <button
          className="text-primary hover:text-primary-700 font-medium w-auto text-start text-sm"
          onClick={() => setOpenModal(true)}
        >
          + Elige tus modalidades de trabajo preferidas
        </button>
      )}
      {isMobile ? (
        <Drawer open={openDrawer} onOpenChange={setOpenDrawer}>
          <DrawerContent className="p-4 h-[80vh] overflow-y-auto">
            <DrawerTitle className="hideen" />
            <div className="flex justify-end">
              <IconX
                size={18}
                stroke={1}
                onClick={() => setOpenDrawer(!openDrawer)}
              />
            </div>
            <div className="flex flex-col gap-8 mt-3">
              {getContent()}
              <div className="flex justify-between">
                <Button variant="secondary" size="md">
                  Cancelar
                </Button>
                <Button
                  variant="primary"
                  size="md"
                  onClick={handleSubmit(onSubmit)}
                >
                  Guardar
                </Button>
              </div>
            </div>
          </DrawerContent>
        </Drawer>
      ) : (
        <AlertDialog open={openModal} onOpenChange={setOpenModal}>
          <AlertDialogTrigger className="hidden" />
          <AlertDialogContent style={{ gap: 0 }}>
            <AlertDialogTitle className="hidden" />
            <div className="flex justify-end">
              <IconX
                stroke={1.5}
                size={20}
                className="cursor-pointer text-secondary-500"
                onClick={() => setOpenModal(false)}
              />
            </div>
            <div className="flex flex-col gap-8">
              {getContent()}
              <AlertDialogFooter className="flex xs:flex-row xs:justify-between sm:justify-around w-full">
                <AlertDialogCancel>Cancelar</AlertDialogCancel>
                <AlertDialogAction onClick={handleSubmit(onSubmit)}>
                  Guardar
                </AlertDialogAction>
              </AlertDialogFooter>
            </div>
          </AlertDialogContent>
        </AlertDialog>
      )}
    </div>
  )
}

export default FormModality
