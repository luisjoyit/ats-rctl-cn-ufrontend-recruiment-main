import TitleMyProfile from '../TitleMyProfile'
import { Button } from '@/components/ui/button'
import ContainerSectionMyProfile from '../../atoms/ContainerSectionMyProfile'
import AddFormSectionEducation, {
  IFormEducation,
} from './Forms/AddFormSectionEducation'
import { useQueryClient } from '@tanstack/react-query'
import { useEffect, useState } from 'react'
import { useGraphQL } from '@/hooks/useGraphQery'
// import { getEducationsByUserId } from '@/aplicant/service/userCv.service'
import CardAnimatedBorderGradient from '@/components/ui/CardPulseBorder'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import {
  educationFormSchema,
  EducationFormSchema,
} from '@/aplicant/validations/ProfileEducationSchema'
import { IconEdit, IconGripVertical, IconTrash } from '@tabler/icons-react'
import AddFormSectionCertification from './Forms/AddFormSectionCertification'

const dataEducation = [
  {
    name: 'Diseño UX/UI',
    institution: 'Platzi',
    dateStart: '01/2024',
    dateEnd: '06/2024',
    typeEduc: 'online',
  },
]

const dataInitial = {
  name: '',
  institution: '',
  dateStart: '',
  dateEnd: '',
  typeEduc: '',
}

export default function SectionEducation() {
  const queryClient = useQueryClient()

  // todo: remove this
  const isLoading = false
  // const { data, isLoading } = useGraphQL(
  //   getEducationsByUserId(),
  //   keycloak.token,
  //   {
  //     userId: 1,
  //   },
  // )

  const [itemsEducations, setItemsEducations] = useState<IFormEducation>({
    education: dataEducation || [dataInitial],
  })
  const [open, setOpen] = useState(false)

  const [editingEducationIndex, setEditingEducationIndex] = useState<
    number | null
  >(null)
  const {
    reset,
    register,
    setValue,
    clearErrors,
    handleSubmit,
    watch,
    formState: { errors },
  } = useForm<EducationFormSchema>({
    resolver: zodResolver(educationFormSchema),
    defaultValues: {
      education: itemsEducations.education || [dataInitial],
    },
    mode: 'onChange',
  })

  const addEducation = () => {
    setEditingEducationIndex(itemsEducations.education.length)
    reset({
      education: [...itemsEducations.education, dataInitial],
    })
    setOpen(true)
  }

  const editEducation = (index: number) => {
    setEditingEducationIndex(index)
    reset({ education: itemsEducations.education })
    setOpen(true)
  }

  const deleteEducation = (index: number) => {
    const newEducation = [...itemsEducations.education]
    newEducation.splice(index, 1)
    setItemsEducations({ education: newEducation })
  }

  return (
    <ContainerSectionMyProfile>
      <div className="flex flex-col gap-6">
        <CardAnimatedBorderGradient className="shadow-none border-x border-b border-t-0">
          <div className="flex flex-col gap-6">
            <TitleMyProfile className="font-inter font-semibold text-secondary-500 text-base">
              Educación
            </TitleMyProfile>
            <>
              {itemsEducations?.education.map((element, id) => (
                <CardAnimatedBorderGradient className="rounded-lg p-3" key={id}>
                  <div className="flex gap-4">
                    <div className="flex items-center">
                      <IconGripVertical stroke={1.5} />
                    </div>
                    <div className="flex justify-between w-full">
                      <div className="flex flex-col gap-1 font-inter">
                        <span className="font-medium">{element.name}</span>
                        <span className="text-sm text-secondary-500">
                          {element.institution}
                        </span>
                        <span className="text-sm text-muted-300">
                          {element.dateStart} - {element.dateEnd}
                        </span>
                      </div>
                      <div className="flex gap-4 items-center">
                        <IconTrash
                          stroke={1.5}
                          onClick={() => deleteEducation(id)}
                          className="text-secondary-500 cursor-pointer"
                          size={22}
                        />
                        <IconEdit
                          stroke={1.5}
                          className="text-secondary-500 cursor-pointer"
                          onClick={() => editEducation(id)}
                        />
                      </div>
                    </div>
                  </div>
                </CardAnimatedBorderGradient>
              ))}
              <button
                className="text-primary hover:text-primary-700 font-medium w-fit text-start text-sm"
                type="button"
                onClick={addEducation}
              >
                + Añade un campo de educación
              </button>
            </>
          </div>
        </CardAnimatedBorderGradient>
        <AddFormSectionCertification />
      </div>
      <AddFormSectionEducation
        open={open}
        setOpen={setOpen}
        itemsEducations={itemsEducations}
        setItemsEducations={setItemsEducations}
        indexEdit={editingEducationIndex}
        register={register}
        setValue={setValue}
        clearErrors={clearErrors}
        handleSubmit={handleSubmit}
        watch={watch}
        errors={errors}
      />
    </ContainerSectionMyProfile>
  )
}
