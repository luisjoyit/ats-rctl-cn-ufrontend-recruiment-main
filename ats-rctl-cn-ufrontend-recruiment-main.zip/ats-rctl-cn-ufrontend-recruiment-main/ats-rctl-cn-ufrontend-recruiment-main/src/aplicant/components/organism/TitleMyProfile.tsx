import { cn } from '@/lib/utils'

interface TitleMyProfileProps
  extends React.HTMLAttributes<HTMLHeadingElement> {}

export default function TitleMyProfile({
  className,
  children,
  ...props
}: TitleMyProfileProps) {
  return (
    <h1
      className={cn(
        'font-medium text-xl font-inter text-secondary dark:text-white',
        className,
      )}
      {...props}
    >
      {children}
    </h1>
  )
}
