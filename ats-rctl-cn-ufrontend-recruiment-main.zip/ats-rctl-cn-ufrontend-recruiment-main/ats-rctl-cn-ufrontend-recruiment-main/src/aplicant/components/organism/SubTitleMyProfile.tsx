import { cn } from '@/lib/utils'

interface SubTitleMyProfileProps
  extends React.HTMLAttributes<HTMLParagraphElement> {
  line1: string
  line2?: string
}

export default function SubTitleMyProfile({
  className,
  line1,
  line2,
  ...props
}: SubTitleMyProfileProps) {
  return (
    <p
      className={cn(
        'font-inter text-xs text-secundary-500 dark:text-white grid opacity-80',
        className,
      )}
      {...props}
    >
      <span>{line1}</span>
      <span>{line2}</span>
    </p>
  )
}
