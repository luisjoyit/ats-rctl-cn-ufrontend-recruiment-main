import React from 'react'

//@ts-ignore
import { t, useLanguage } from '@joyit/layout'
import ListLasAplicationDashboard from '../molecules/ListLasAplicationDashboard'
import { useNavigate } from 'react-router-dom'
import logoAirbnb from '../../../../public/logos/airbnb.webp'
import logoRappi from '../../../../public/logos/rappi.webp'
import logoInterbank from '../../../../public/logos/interbank.webp'
import logoCulqui from '../../../../public/logos/ImgCulqi.webp'
import { IconBriefcase, IconSearch } from '@tabler/icons-react'

const applications = [
  {
    job: 'UX/UI Designer',
    company: 'Interbank',
    state: 'Postulado',
    salary: 2000,
    date: '04 Jul 2024',
    modality: 'Remoto',
    city: 'CDMX',
    time: 'Part-time',
    logo: logoInterbank,
  },
  {
    job: 'Frontend Developer',
    company: 'Rappi',
    state: 'En proceso',
    salary: 1500,
    date: '04 Jul 2024',
    modality: 'Remoto',
    city: 'Lima',
    time: 'Full-time',
    logo: logoRappi,
  },
  {
    job: 'Backend Developer',
    company: 'Airbnb',
    state: 'En proceso',
    salary: 2500,
    date: '04 Jul 2024',
    modality: 'Remoto',
    city: 'CDMX',
    time: 'Híbrido',
    logo: logoAirbnb,
  },
  {
    job: 'Devops',
    company: 'Culqui',
    state: 'Postulado',
    salary: 0,
    date: '04 Jul 2024',
    modality: 'Remoto',
    city: 'CDMX',
    time: 'Part-time',
    logo: logoCulqui,
  },
  {
    job: 'Arquitecto de Infraestructura Cloud',
    company: 'Culqui',
    state: 'Rechazado',
    salary: 2000,
    date: '04 Jul 2024',
    modality: 'Remoto',
    city: 'CDMX',
    time: 'Part-time',
    logo: logoRappi,
  },
  {
    job: 'UX Designer',
    company: 'Google',
    state: 'Seleccionado',
    salary: 2000,
    date: '04 Jul 2024',
    modality: 'Remoto',
    city: 'CDM',
    time: 'Part-time',
    logo: '',
  },
]

const LastApplicationsSection: React.FC = () => {
  const navigate = useNavigate()
  return (
    <div className="w-full font-inter">
      <div className="flex justify-between items-center mb-5">
        <h2 className="text-2xl font-semibold text-[#18181B] dark:text-foreground">
          {t('dashboard.profileviews.latestapplications.ÚltimasPostulaciones')}
        </h2>
        {applications.length !== 0 && (
          <button
            className="font-semibold text-sm text-[#18181B]"
            onClick={() => navigate('/applicants/candidate/applications')}
          >
            {t('dashboard.profileviews.latestapplications.VerTodas')}
          </button>
        )}
      </div>
      <div className="bg-primary-foreground rounded-[16px] flex flex-col gap-3">
        <div className="grid bg-primary-foreground gap-2">
          {applications.length === 0 ? (
            <div className="rounded-2xl bg-[#F9FAFB] flex items-center justify-center h-[384px]">
              <div className="flex flex-col gap-2 items-center justify-center">
                <div className="flex items-center justify-center">
                  <IconBriefcase
                    stroke={1}
                    className="text-[#64748B] size-16 "
                  />
                </div>
                <span className="font-semibold text-lg text-[#18181B]">
                  Aún no has postulado a un empleo
                </span>
                <button className="bg-[#2563EB] rounded-full py-2 px-3 flex gap-2 items-center justify-center text-[#EFF6FF] text-sm font-medium">
                  <IconSearch
                    stroke={1.5}
                    className="text-[#EFF6FF]"
                    size={16}
                  />
                  Buscar empleo
                </button>
              </div>
            </div>
          ) : (
            <>
              {applications.slice(0, 5).map((app, index) => (
                <ListLasAplicationDashboard key={index} job={app} />
              ))}
            </>
          )}
        </div>
      </div>
    </div>
  )
}

export default LastApplicationsSection
