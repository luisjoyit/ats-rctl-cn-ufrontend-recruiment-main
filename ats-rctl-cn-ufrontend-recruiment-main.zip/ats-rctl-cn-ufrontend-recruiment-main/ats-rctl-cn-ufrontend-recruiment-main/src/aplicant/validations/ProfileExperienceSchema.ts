import { z } from 'zod'

export const experienceFormSchema = z.object({
  experiences: z.array(
    z
      .object({
        job: z.string().min(5, 'El puesto de trabajo es requerido'),
        company: z.string().min(5, 'El nombre de la empresa es requerido'),
        dateStart: z
          .string()
          .regex(
            /^(0[1-9]|1[0-2])[-/]\d{4}$/,
            'La fecha de inicio es requerida',
            //'La fecha de inicio debe estar en el formato MM-AAAA o MM/AAAA',
          )
          .min(7, 'La fecha de inicio es requerida'),
        dateEnd: z
          .string()
          .regex(
            /^(0[1-9]|1[0-2])[-/]\d{4}$/,
            'La fecha de término es requerida',
            //'La fecha de término debe estar en el formato MM-AAAA o MM/AAAA',
          )
          .min(7, 'La fecha de término es requerida'),
        country: z.string().min(3, 'El país es requerido'),
        description: z
          .string()
          .min(10, 'Ingrese una descripción válida')
          .optional(),
      })
      .refine(
        (data) => {
          // Convertimos las fechas a formato Date para poder compararlas
          const [startMonth, startYear] = data.dateStart
            .split(/[-/]/)
            .map(Number)
          const [endMonth, endYear] = data.dateEnd.split(/[-/]/).map(Number)
          const startDate = new Date(startYear, startMonth - 1)
          const endDate = new Date(endYear, endMonth - 1)
          return startDate <= endDate
        },
        {
          message: 'La fecha de inicio debe ser anterior a la fecha de término',
          path: ['dateStart'], // Indicamos dónde queremos que aparezca el error
        },
      ),
  ),
})

export type ExperienceFormSchema = z.infer<typeof experienceFormSchema>
