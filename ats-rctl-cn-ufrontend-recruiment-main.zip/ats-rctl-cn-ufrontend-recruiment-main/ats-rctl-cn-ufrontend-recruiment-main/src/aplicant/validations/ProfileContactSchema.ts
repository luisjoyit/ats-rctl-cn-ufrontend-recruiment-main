import { z } from 'zod'

export const personalInfoFormSchema = z.object({
  name: z.string().min(3, 'El nombre de perfil es requerido'),
  lastName: z.string().min(3, 'El apellido es requerido'),
  country: z.string().min(3, 'El país es requerido'),
  location: z.string().min(5, 'La ubicación es requerida'),
})

export type PersonalInfoFormSchema = z.infer<typeof personalInfoFormSchema>

export const contactInfoFormSchema = z.object({
  email: z.string().email({ message: 'Correo electrónico incorrecto' }),
  phone: z.string().min(9, { message: 'Número de teléfono incorrecto' }),
})

export type ContactInfoFormSchema = z.infer<typeof contactInfoFormSchema>

export const networksInfoFormSchema = z.object({
  linkLinkedin: z
    .union([
      z
        .string()
        .url({ message: 'El enlace de LinkedIn no es válido' })
        .regex(/^https:\/\/(www\.)?linkedin\.com\/in\/[a-zA-Z0-9-]+\/$/, {
          message: 'El enlace de LinkedIn debe ser válido',
          //'El enlace de LinkedIn debe comenzar con https://www.linkedin.com/in/USERNAME'
        }),
      z.literal(''),
    ])
    .optional(),

  linkGithub: z
    .union([
      z
        .string()
        .url({ message: 'El enlace de GitHub no es válido' })
        .regex(/^https:\/\/(www\.)?github\.com\/[a-zA-Z0-9-]+$/, {
          message: 'El enlace de GitHub debe ser válido',
          //'El enlace de GitHub debe comenzar con https://github.com/USERNAME'
        }),
      z.literal(''),
    ])
    .optional(),

  linkWhatsapp: z
    .union([
      z
        .string()
        .url({ message: 'El enlace de WhatsApp no es válido' })
        .regex(/^https:\/\/wa\.me\/\d+$/, {
          message: 'El enlace de WhatsApp debe ser válido.',
          //'El enlace de WhatsApp debe ser válido y comenzar con https://wa.me/',
        }),
      z.literal(''),
    ])
    .optional(),
})

export type NetworksInfoFormSchema = z.infer<typeof networksInfoFormSchema>
