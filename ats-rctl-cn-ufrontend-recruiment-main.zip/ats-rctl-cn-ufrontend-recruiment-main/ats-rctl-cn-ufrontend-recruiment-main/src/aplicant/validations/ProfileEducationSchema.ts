import { z } from 'zod'

export const educationFormSchema = z.object({
  education: z.array(
    z
      .object({
        name: z.string().min(5, 'Nombre de Curso/Programa es requerido'),
        institution: z.string().min(5, 'Nombre de la institución es requerida'),
        dateStart: z
          .string()
          .regex(
            /^(0[1-9]|1[0-2])[-/]\d{4}$/,
            'La fecha de inicio es requerida',
            //'La fecha de inicio debe estar en el formato MM-AAAA o MM/AAAA',
          )
          .min(7, 'La fecha de inicio es requerida'),
        dateEnd: z
          .string()
          .regex(
            /^(0[1-9]|1[0-2])[-/]\d{4}$/,
            'La fecha de término es requerida',
            //'La fecha de término debe estar en el formato MM-AAAA o MM/AAAA',
          )
          .min(7, 'La fecha de término es requerida'),
        typeEduc: z.string().min(3, 'El tipo de educación es requerido'),
      })
      .refine(
        (data) => {
          // Convertimos las fechas a formato Date para poder compararlas
          const [startMonth, startYear] = data.dateStart
            .split(/[-/]/)
            .map(Number)
          const [endMonth, endYear] = data.dateEnd.split(/[-/]/).map(Number)
          const startDate = new Date(startYear, startMonth - 1)
          const endDate = new Date(endYear, endMonth - 1)
          return startDate <= endDate
        },
        {
          message: 'La fecha de inicio debe ser anterior a la fecha de término',
          path: ['dateStart'], // Indicamos dónde queremos que aparezca el error
        },
      ),
  ),
})

export type EducationFormSchema = z.infer<typeof educationFormSchema>

export const certificationFormSchema = z.object({
  certificates: z.array(
    z
      .object({
        name: z.string().min(5, 'Nombre de Curso/Programa es requerido'),
        institution: z.string().min(5, 'Nombre de la institución es requerida'),
        dateStart: z
          .string()
          .regex(
            /^(0[1-9]|1[0-2])[-/]\d{4}$/,
            'La fecha de inicio es requerida',
            //'La fecha de inicio debe estar en el formato MM-AAAA o MM/AAAA',
          )
          .min(7, 'La fecha de inicio es requerida'),
        dateEnd: z
          .string()
          .regex(
            /^(0[1-9]|1[0-2])[-/]\d{4}$/,
            'La fecha de término es requerida',
            //'La fecha de término debe estar en el formato MM-AAAA o MM/AAAA',
          )
          .min(7, 'La fecha de término es requerida'),
        urlCertificate: z
          .union([z.string().url('Debe ser una URL válida'), z.literal('')])
          .optional(),
        fileCertificate: z.instanceof(File).optional().nullable(),
      })
      .refine(
        (data) => {
          // Convertimos las fechas a formato Date para poder compararlas
          const [startMonth, startYear] = data.dateStart
            .split(/[-/]/)
            .map(Number)
          const [endMonth, endYear] = data.dateEnd.split(/[-/]/).map(Number)
          const startDate = new Date(startYear, startMonth - 1)
          const endDate = new Date(endYear, endMonth - 1)
          return startDate <= endDate
        },
        {
          message: 'La fecha de inicio debe ser anterior a la fecha de término',
          path: ['dateStart'], // Indicamos dónde queremos que aparezca el error
        },
      ),
  ),
})

export type CertificationFormSchema = z.infer<typeof certificationFormSchema>
