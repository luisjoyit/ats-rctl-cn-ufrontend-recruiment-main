import { z } from 'zod'

export const summaryFormSchema = z.object({
  professionalSummary: z
    .string()
    .min(15, 'Se requiere un breve resumen profesional.'),
})

export type SummaryFormSchema = z.infer<typeof summaryFormSchema>

export const stackTechFormSchema = z.object({
  stackTech: z.array(z.string()).optional(),
})

export type StackTechFormSchema = z.infer<typeof stackTechFormSchema>

export const salarityFormSchema = z.object({
  rangeSalarity: z
    .array(z.number().min(0, 'El salario debe ser mayor a 0'))
    .length(2)
    .optional(),
  adHonorem: z.boolean().optional(),
})

export type SalarityFormSchema = z.infer<typeof salarityFormSchema>

export const modalityFormSchema = z.object({
  modality: z.array(z.string()).optional(),
})

export type ModalityFormSchema = z.infer<typeof modalityFormSchema>

export const languagesFormSchema = z.object({
  languages: z
    .array(
      z.object({
        language: z.string().min(1, 'Seleccion del idioma es requerido'),
        levelLanguage: z.string().min(1, 'El nivel del idioma es requerido'),
      }),
    )
    .optional(),
})

export type LanguagesFormSchema = z.infer<typeof languagesFormSchema>
