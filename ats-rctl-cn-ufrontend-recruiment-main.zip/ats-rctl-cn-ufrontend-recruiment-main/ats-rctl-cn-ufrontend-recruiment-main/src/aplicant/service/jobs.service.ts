import { graphql } from '@/gql'

class JobsService {
  getAllJobs() {
    const allJobs = graphql(`
      query GetAllJobsFilter(
        $page: Int!
        $size: Int!
        $minSalary: BigDecimal
        $maxSalary: BigDecimal
        $workmode: WorkMode
        $levelOfExperienceId: BigInteger
        $profileTypeId: BigInteger
        $countryId: BigInteger
        $technologyStack: [String]
      ) {
        GetAllJobsFilter(
          page: $page
          size: $size
          minSalary: $minSalary
          maxSalary: $maxSalary
          workmode: $workmode
          levelOfExperienceId: $levelOfExperienceId
          profileTypeId: $profileTypeId
          countryId: $countryId
          technologyStack: $technologyStack
        ) {
          currentPage
          elementPerPage
          totalItems
          totalPage
          jobs {
            createdAt
            description
            description_functions
            description_functions_additional_requirements
            endTime
            id
            maxSalary
            minSalary
            name
            openPositions
            salary
            startTime
            updateAt
            verified_profiles
            visibility_name_company
            workMode
            active
            technologyStacks {
              id
              name
            }
            levelOfExperience {
              id
              name
            }
            company {
              description
              imageUrl
              name
            }
            country {
              description
              img_url
              name
            }
          }
        }
      }
    `)
    return allJobs
  }

  getJobById() {
    const jobById = graphql(`
      query GetJobById($id: BigInteger) {
        GetJobById(id: $id) {
          createdAt
          description
          description_functions
          description_functions_additional_requirements
          endTime
          id
          maxSalary
          minSalary
          name
          openPositions
          salary
          startTime
          updateAt
          verified_profiles
          visibility_name_company
          workMode
          active
          levelOfExperience {
            id
            name
          }
          company {
            description
            id
            imageUrl
            name
            updateAt
          }
          technologyStacks {
            id
            name
          }
        }
      }
    `)
    return jobById
  }
}

export default new JobsService()
