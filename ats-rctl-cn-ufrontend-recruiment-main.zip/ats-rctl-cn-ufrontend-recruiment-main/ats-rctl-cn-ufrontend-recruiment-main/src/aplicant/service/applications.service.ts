// import { graphql } from '@/gql'

// class ApplicationsService {
//   GetAllJobApplicationByUser() {
//     const alljobsApplications = graphql(`
//       query GetAllJobApplicationByUserFilter(
//         $idUser: Int!
//         $currentPage: Int!
//         $elementPerPage: Int!
//         $latest: Boolean!
//         $modality_id: Int!
//       ) {
//         GetAllJobApplicationByUserFilter(
//           user_id: $idUser
//           currentPage: $currentPage
//           elementPerPage: $elementPerPage
//           latest: $latest
//           modality_id: $modality_id
//         ) {
//           currentPage
//           totalPage
//           totalItems
//           elementPerPage
//           jobApplicationList {
//             jobEntity {
//               title
//               company {
//                 name
//                 imageUrl
//               }
//               #       workModality {
//               #         name
//               #       }
//               salary
//               createdAt
//             }
//           }
//         }
//       }
//     `)
//     return alljobsApplications
//   }

//   createJobApplication() {
//     const createJobApplications = graphql(`
//       mutation CreateApplication($jobId: BigInteger!, $userId: Int!) {
//         CreateApplication(application: { jobId: $jobId, userId: $userId }) {
//           id
//           createdAt
//           updateAt
//         }
//       }
//     `)
//     return createJobApplications
//   }
// }
// export default new ApplicationsService()
