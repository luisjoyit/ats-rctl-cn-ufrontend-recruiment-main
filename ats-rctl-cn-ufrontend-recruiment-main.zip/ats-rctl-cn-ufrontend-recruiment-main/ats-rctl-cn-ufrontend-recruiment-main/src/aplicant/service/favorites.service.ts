// import { graphql } from '@/gql'

// class FavoriteService {
//   getJobsFavorites() {
//     const getFavorites = graphql(`
//       query GetJobsFavoritesByUserFilter(
//         $currentPage: Int!
//         $elementPerPage: Int!
//         $userId: Int!
//         $modality_id: Int!
//         $level_exp_id: Int!
//         $more_relevant: Boolean!
//         $newer: Boolean!
//         $oldest: Boolean!
//         $categorie_id: BigInteger
//         $country_id: BigInteger
//       ) {
//         GetJobsFavoritesByUserFilter(
//           currentPage: $currentPage
//           user_id: $userId
//           elementPerPage: $elementPerPage
//           level_exp_id: $level_exp_id
//           modality_id: $modality_id
//           mas_relevante: $more_relevant
//           mas_nuevo: $newer
//           mas_antiguo: $oldest
//           categorie_id: $categorie_id
//           country_id: $country_id
//         ) {
//           currentPage
//           elementPerPage
//           totalItems
//           totalPage
//           latest
//           favoriteEntityList {
//             created
//             id
//             job {
//               id
//               title
//               company {
//                 id
//                 name
//               }
//               createdAt
//               # workModality {
//               #   id
//               #   name
//               # }
//               country {
//                 id
//                 name
//               }
//               city {
//                 id
//                 name
//               }
//             }
//           }
//         }
//       }
//     `)
//     return getFavorites
//   }
//   createJobFavorite() {
//     const createFavorite = graphql(`
//       mutation CreateJobFavoriteByUser($user_id: Int!, $job_id: BigInteger!) {
//         CreateJobFavoriteByUser(user_id: $user_id, job_id: $job_id) {
//           id
//         }
//       }
//     `)
//     return createFavorite
//   }

//   deleteJobFavorite() {
//     const deleteFavorite = graphql(`
//       mutation DeleteJobFavoriteByUser($user_id: Int!, $job_id: BigInteger!) {
//         DeleteJobFavoriteByUser(user_id: $user_id, job_id: $job_id)
//       }
//     `)
//     return deleteFavorite
//   }
// }

// export default new FavoriteService()

// // export function toggleJobFavorite() {
// //   const toggleFavorite = graphql(`
// //     mutation updateJobFavorite(
// //       $isFavorite: Boolean!
// //       $jobId: Int!
// //       $userId: Int!
// //     ) {
// //       updateJobFavorite(
// //         isFavorite: $isFavorite
// //         jobId: $jobId
// //         userId: $userId
// //       ) {
// //         userJobFavorite {
// //           id
// //           isFavorite
// //         }
// //       }
// //     }
// //   `)
// //   return toggleFavorite
// // }
