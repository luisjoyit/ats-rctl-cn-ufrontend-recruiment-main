// import { graphql } from '@/gql'

// export function getUserCV() {
//   const getUserCV = graphql(`
//     query userCv($userId: Int!) {
//       userCv(userId: $userId) {
//         professionalSummary
//         yearsOfExperience {
//           id
//           years
//         }
//         profileType {
//           id
//           name
//         }
//       }
//     }
//   `)
//   return getUserCV
// }

// export function createOrUpdateUserCv() {
//   const createUserCv = graphql(`
//     mutation createOrUpdateUserCv(
//       $userId: Int!
//       $profileTypeId: Int
//       $yearsExperienceId: Int
//       $professionalSummary: String
//     ) {
//       createOrUpdateUserCv(
//         userId: $userId
//         profileTypeId: $profileTypeId
//         yearsExperienceId: $yearsExperienceId
//         professionalSummary: $professionalSummary
//       ) {
//         userCv {
//           professionalSummary
//           yearsOfExperience {
//             id
//             years
//           }
//           profileType {
//             id
//             name
//           }
//         }
//       }
//     }
//   `)
//   return createUserCv
// }

// export function getWorkExperiencesByUserId() {
//   const getWorkExperience = graphql(`
//     query workExperience($userId: Int!) {
//       workExperience(id: $userId) {
//         id
//         companyName
//         position
//         description
//         startDate
//         endDate
//       }
//     }
//   `)
//   return getWorkExperience
// }

// export function createWorkExperienceUserCv() {
//   const createWorksExperience = graphql(`
//     mutation createWorkExperience(
//       $userCvId: Int!
//       $jobTitle: String!
//       $companyName: String!
//       $startDate: Date!
//       $endDate: Date
//       $description: String
//     ) {
//       createWorkExperience(
//         userCvId: $userCvId
//         jobTitle: $jobTitle
//         companyName: $companyName
//         startDate: $startDate
//         endDate: $endDate
//         description: $description
//       ) {
//         workExperience {
//           companyName
//           description
//           endDate
//           id
//           position
//           startDate
//         }
//       }
//     }
//   `)
//   return createWorksExperience
// }

// export function createEducationsUserCv() {
//   const createEducation = graphql(`
//     mutation createEducation(
//       $userCvId: Int!
//       $degree: String!
//       $institutionName: String!
//       $startDate: Date!
//       $endDate: Date
//       $description: String
//     ) {
//       createEducation(
//         degree: $degree
//         endDate: $endDate
//         institutionName: $institutionName
//         startDate: $startDate
//         userCvId: $userCvId
//         description: $description
//       ) {
//         education {
//           degree
//           description
//           endDate
//           id
//           institutionName
//           startDate
//         }
//       }
//     }
//   `)
//   return createEducation
// }

// export function getEducationsByUserId() {
//   const getEducations = graphql(`
//     query education($userId: Int!) {
//       education(id: $userId) {
//         id
//         institutionName
//         degree
//         startDate
//         endDate
//         description
//       }
//     }
//   `)
//   return getEducations
// }
