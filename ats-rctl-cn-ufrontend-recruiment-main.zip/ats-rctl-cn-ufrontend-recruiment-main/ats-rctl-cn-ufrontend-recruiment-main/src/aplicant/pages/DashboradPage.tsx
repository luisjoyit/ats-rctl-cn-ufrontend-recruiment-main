import { Input } from '@/components/ui/input'
import Dashboard from '../components/templates/Dashboard'

export default function DashboardPage() {
  return (
    <>
      <Dashboard />
    </>
  )
}
