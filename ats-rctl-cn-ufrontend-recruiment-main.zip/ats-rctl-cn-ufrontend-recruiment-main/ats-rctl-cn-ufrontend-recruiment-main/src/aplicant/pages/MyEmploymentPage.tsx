import MyEmployment from '../components/templates/MyEmployment'

export default function MyEmploymentPage() {
  return <MyEmployment />
}
