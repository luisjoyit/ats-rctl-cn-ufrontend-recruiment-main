import { OfferDetail } from '../components/templates/OfferDetail'

export default function OfferDetailPage() {
  return <OfferDetail />
}
