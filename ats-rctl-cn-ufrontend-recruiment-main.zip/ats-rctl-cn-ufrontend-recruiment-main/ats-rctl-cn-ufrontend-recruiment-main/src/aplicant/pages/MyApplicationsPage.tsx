import MyApplications from '../components/templates/MyApplications'

export default function MyApplicationsPage() {
  return <MyApplications />
}
