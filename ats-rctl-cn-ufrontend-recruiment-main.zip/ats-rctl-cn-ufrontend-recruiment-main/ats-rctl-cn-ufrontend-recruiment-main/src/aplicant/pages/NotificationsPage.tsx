import Notifications from '../components/templates/Notifications'

export default function NotificationsPage() {
  return <Notifications />
}
