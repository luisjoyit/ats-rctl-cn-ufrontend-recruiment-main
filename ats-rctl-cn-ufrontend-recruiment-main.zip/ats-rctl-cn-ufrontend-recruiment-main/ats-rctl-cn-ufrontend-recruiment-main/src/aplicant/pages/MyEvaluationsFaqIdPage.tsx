import MyEvaluationsFaqId from '../components/templates/MyEvaluationsFaqId'

export default function MyEvaluationsFaqIdPage() {
  return <MyEvaluationsFaqId />
}
