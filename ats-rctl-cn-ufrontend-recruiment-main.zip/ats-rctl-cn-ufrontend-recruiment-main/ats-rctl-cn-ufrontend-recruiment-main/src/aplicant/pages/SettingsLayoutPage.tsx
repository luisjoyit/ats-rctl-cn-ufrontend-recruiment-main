import SettingsLayout from '../components/templates/SettingsLayout'

export default function SettingsLayoutPage() {
  return <SettingsLayout />
}
