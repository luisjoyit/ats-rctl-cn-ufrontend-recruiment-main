import MyPortfolio from '../components/templates/MyPortfolio'

export default function MyPortfolioPage() {
  return <MyPortfolio />
}
