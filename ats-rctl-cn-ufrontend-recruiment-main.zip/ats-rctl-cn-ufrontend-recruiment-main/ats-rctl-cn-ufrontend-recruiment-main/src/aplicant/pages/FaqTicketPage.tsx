import FaqTicket from '../components/templates/FaqTicket'

export default function FaqTicketPage() {
  return <FaqTicket />
}
