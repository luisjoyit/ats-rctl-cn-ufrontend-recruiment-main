import FaqUpdate from '../components/templates/FaqUpdate'

export default function FaqUpdatePage() {
  return <FaqUpdate />
}
