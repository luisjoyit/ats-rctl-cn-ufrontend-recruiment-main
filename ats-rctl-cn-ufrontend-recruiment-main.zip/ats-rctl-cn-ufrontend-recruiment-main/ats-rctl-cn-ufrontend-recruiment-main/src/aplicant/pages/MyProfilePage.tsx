import Editor from '@/components/editorText/editor'
import MyProfile from '../components/templates/MyProfile'
import { useState } from 'react'

export default function MyProfilePage() {
  const [value, setValue] = useState('hello world ')

  return (
    <>
      <MyProfile />
      {/* <Editor
        content={value}
        onChange={setValue}
        placeholder="Write your post here..."
      /> */}
    </>
  )
}
