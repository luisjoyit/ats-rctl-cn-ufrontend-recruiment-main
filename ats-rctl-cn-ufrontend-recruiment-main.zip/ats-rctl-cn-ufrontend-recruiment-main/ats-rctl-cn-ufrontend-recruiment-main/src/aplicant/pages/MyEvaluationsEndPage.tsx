import MyEvaluationsEnd from '../components/templates/MyEvaluationsEnd'

export default function MyEvaluationsEndPage() {
  return <MyEvaluationsEnd />
}
