import FaqAffairs from '../components/templates/FaqAffairs'

export default function FaqAffairsPage() {
  return <FaqAffairs />
}
