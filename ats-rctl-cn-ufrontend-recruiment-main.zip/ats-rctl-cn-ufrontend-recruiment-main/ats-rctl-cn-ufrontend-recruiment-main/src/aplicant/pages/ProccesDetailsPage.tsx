import ProccesDetails from '../components/templates/ProccesDetails'

export default function ProccesDetailsPage() {
  return <ProccesDetails />
}
