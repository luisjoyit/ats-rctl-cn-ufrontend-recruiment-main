import Faq from '../components/templates/Faq'

export default function FaqPage() {
  return <Faq />
}
