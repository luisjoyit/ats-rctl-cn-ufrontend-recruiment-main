import Favorite from '../components/templates/Favorite'

export default function MyFavoritePage() {
  return <Favorite />
}
