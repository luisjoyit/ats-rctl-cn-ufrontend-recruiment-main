import FaqName from '../components/templates/FaqName'

export default function FaqNamePage() {
  return <FaqName />
}
