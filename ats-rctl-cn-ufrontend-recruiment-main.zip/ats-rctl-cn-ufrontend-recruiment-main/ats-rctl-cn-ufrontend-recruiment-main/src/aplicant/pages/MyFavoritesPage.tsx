import { Favorites } from '../components/templates/Favorites'

export default function FavoritesPage() {
  return <Favorites />
}
