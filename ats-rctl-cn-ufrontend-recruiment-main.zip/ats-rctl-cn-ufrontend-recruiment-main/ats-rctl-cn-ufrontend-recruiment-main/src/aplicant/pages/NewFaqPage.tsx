import NewFaq from '../components/templates/NewFaq'

export default function NewFaqPage() {
  return <NewFaq />
}
