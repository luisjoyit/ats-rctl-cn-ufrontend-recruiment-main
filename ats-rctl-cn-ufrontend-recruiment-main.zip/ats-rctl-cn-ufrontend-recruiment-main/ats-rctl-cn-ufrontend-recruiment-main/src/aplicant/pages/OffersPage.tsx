import Offers from '../components/templates/Offers'

export default function OffersPage() {
  return <Offers />
}
