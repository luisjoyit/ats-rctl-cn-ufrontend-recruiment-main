import { OfferId } from '../components/templates/OfferId'

export default function OfferIdPage() {
  return <OfferId />
}
