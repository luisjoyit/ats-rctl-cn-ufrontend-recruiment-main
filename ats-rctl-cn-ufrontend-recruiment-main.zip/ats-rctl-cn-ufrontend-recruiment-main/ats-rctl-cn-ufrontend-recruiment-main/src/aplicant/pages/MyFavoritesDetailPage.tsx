import { FavoriteDetail } from '../components/templates/FavoriteDetail'

export default function MyFavoritesDetailPage() {
  return <FavoriteDetail />
}
