import MyEvaluationId from '../components/templates/MyEvaluationId'

export default function MyEvaluationIdPage() {
  return <MyEvaluationId />
}
