import MyCurriculum from '../components/templates/MyCurriculum'

export default function MyCurriculumPage() {
  return <MyCurriculum />
}
