import SettingsOption from '../components/templates/SettingsOption'

export default function SettingOptionPage() {
  return <SettingsOption />
}
