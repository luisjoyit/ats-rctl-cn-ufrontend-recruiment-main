import { graphql } from '@/gql'
class ProfileTypeService {
  getProfileTypes() {
    const allProfiles = graphql(`
      query GetAllProfileTypes {
        GetAllProfileTypes {
          id
          description
        }
      }
    `)
    return allProfiles
  }
}

export default new ProfileTypeService()
