import { graphql } from '@/gql'
class LanguageService {
  getLanguages() {
    const allLanguages = graphql(`
      query GetAllLanguages {
        getAllLanguages {
          description
          id
        }
      }
    `)
    return allLanguages
  }
}

export default new LanguageService()
