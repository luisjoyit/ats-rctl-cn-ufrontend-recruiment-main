import { graphql } from '@/gql'
class ModalityService {
  getModalities() {
    const allModalities = graphql(`
      query GetAllWorkType {
        GetAllWorkType {
          id
          name
        }
      }
    `)
    return allModalities
  }
}

export default new ModalityService()
