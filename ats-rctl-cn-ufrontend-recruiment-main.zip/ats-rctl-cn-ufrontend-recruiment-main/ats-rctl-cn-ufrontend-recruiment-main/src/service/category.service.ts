import { graphql } from '@/gql'
class CategoryService {
  getCategories() {
    const allCategories = graphql(`
      query GetAllCategories {
        getAllCategories {
          id
          name
        }
      }
    `)
    return allCategories
  }
}

export default new CategoryService()
