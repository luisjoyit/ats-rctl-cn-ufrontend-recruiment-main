import { graphql } from '@/gql'

class BenefitService {
  getBenefits() {
    const allBenefits = graphql(`
      query GetAllBenefits {
        GetAllBenefits {
          created_at
          description
          id
          name
          prefix
          updated_at
        }
      }
    `)
    return allBenefits
  }
}

export default new BenefitService()
