import { graphql } from '@/gql'
class CountryService {
  getCountries() {
    const allCountries = graphql(`
      query GetAllCountries {
        GetAllCountries {
          createdAt
          description
          id
          name
          updatedAt
        }
      }
    `)

    return allCountries
  }
}

// img_url

export default new CountryService()
