import { graphql } from '@/gql'
class StackTecknologiesService {
  getStackTecknologies() {
    const allStacks = graphql(`
      query GetAllTechnologyStack {
        GetAllTechnologyStack {
          createdAt
          id
          name
          updateAt
        }
      }
    `)
    return allStacks
  }
}

export default new StackTecknologiesService()
