import { graphql } from '@/gql'

class YearsExperienceService {
  getYearsExperience() {
    const allYears = graphql(`
      query GetAllLevelExperience {
        GetAllLevelExperience {
          id
          name
        }
      }
    `)
    return allYears
  }
}
export default new YearsExperienceService()
