import { create } from 'zustand'
import { persist } from 'zustand/middleware'

type favoriteJobState = {
  toggleHearth: Record<string, boolean>
  toggleHearthHandler: (id: string) => void
}

const useFavoriteJobStore = create(
  persist<favoriteJobState>(
    (set) => ({
      toggleHearth: {},
      toggleHearthHandler: (id) =>
        set((state) => ({
          toggleHearth: {
            ...state.toggleHearth,
            [id]: !state.toggleHearth[id],
          },
        })),
    }),
    { name: 'favorite-repos' },
  ),
)

export default useFavoriteJobStore
