// local
// export const GRAPHQL_ENDPOINT =
//   process.env.GRAPHQL_ENDPOINT || 'http://localhost:8000/graphql'
// produccion
export const GRAPHQL_ENDPOINT =
  process.env.GRAPHQL_ENDPOINT ??
  'https://api-dev.joyit.io/graphql/recruitment/v1'
// export const GRAPHQL_ENDPOINT =
//   process.env.GRAPHQL_ENDPOINT || 'http://localhost:8000/graphql'
