export const MyCurriculum = {
  profile: {
    profileImage:
      'https://pymstatic.com/5844/conversions/personas-emocionales-wide_webp.webp',
    countryFlag:
      'https://upload.wikimedia.org/wikipedia/commons/thumb/c/cf/Flag_of_Peru.svg/200px-Flag_of_Peru.svg.png',
    fullName: 'Liset del Pilar Cárdenas Charcape',
    profile: 'UX/UI Designer',
    summary:
      '¡Soy una diseñadora UX/UI apasionada y creativa con más de cinco años de experiencia en la industria! Mi enfoque centrado en el usuario ha impulsado el éxito de numerosos proyectos, destacando por mi capacidad para fusionar diseño estético con funcionalidad excepcional.',
  },
  contact: {
    email: 'lisetcardenas007@gmail.com',
    phone: '+51 943132859',
    linkedin: 'linkedin.com/in/lisetcardenas/',
  },
  education: [
    {
      degree: 'Backend Developer',
      institution: 'Coder House',
      period: 'Ene 2018 - Dic 2019',
    },
    {
      degree: 'Backend Developer',
      institution: 'Coder House',
      period: 'Ene 2018 - Dic 2019',
    },
  ],
  certificates: [
    'Microsoft Certified Solutions Developer',
    'Certified Secure Software Lifecycle Professional (CSSLP)',
  ],
  skills: [
    {
      name: 'Adobe Photoshop',
      level: 3,
    },
    {
      name: 'Adobe Illustrator',
      level: 4,
    },
    {
      name: 'Figma',
      level: 2,
    },
    {
      name: 'Figma',
      level: 1,
    },
  ],
  experience: [
    {
      position: 'Backend Developer',
      company: 'Joyit S.A.C.',
      period: 'Ene 2024 - Actualidad',
      responsibilities: [
        'Desarrollo de API',
        'Gestión de bases de datos',
        'Implementación de lógica de negocio',
        'Seguridad',
        'Escalabilidad y rendimiento',
      ],
    },
    {
      position: 'Backend Developer',
      company: 'Joyit S.A.C.',
      period: 'Ene 2024 - Actualidad',
      responsibilities: [
        'Integración de servicios externos',
        'Mantenimiento y depuración',
        'Colaboración en la arquitectura',
        'Documentación',
      ],
    },
    {
      position: 'Backend Developer',
      company: 'Joyit S.A.C.',
      period: 'Ene 2024 - Actualidad',
      responsibilities: [
        'Integración de servicios externos',
        'Automatización de tareas',
        'Mantenimiento y depuración',
        'Colaboración en la arquitectura',
      ],
    },
  ],
  portfolio: [
    {
      title: 'ATS UX/UI Project 1',
      year: '2024',
      description:
        'Enfoque centrado en el usuario para optimizar la navegación, simplificar el proceso de solicitud y mejorar la interacción general del usuario con la plataforma.',
      image:
        'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQPU8uzibwZhh4yJtdNP3rxv55-iJXs7EjftD7IyvMc8ufphis7ob-jU_tBLMsHibqAApo&usqp=CAU',
    },
    {
      title: 'ATS UX/UI Project 2',
      year: '2024',
      description:
        'Enfoque centrado en el usuario para optimizar la navegación, simplificar el proceso de solicitud y mejorar la interacción general del usuario con la plataforma. simplificar el proceso de solicitud y mejorar la interacción general del usuario con la plataforma.',
      image:
        'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQPU8uzibwZhh4yJtdNP3rxv55-iJXs7EjftD7IyvMc8ufphis7ob-jU_tBLMsHibqAApo&usqp=CAU',
    },
    {
      title: 'ATS UX/UI Project 3',
      year: '2024',
      description:
        'Enfoque centrado en el usuario para optimizar la navegación, simplificar el proceso de solicitud y mejorar la interacción general del usuario con la plataforma.',
      image:
        'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQPU8uzibwZhh4yJtdNP3rxv55-iJXs7EjftD7IyvMc8ufphis7ob-jU_tBLMsHibqAApo&usqp=CAU',
    },
  ],
  evaluations: [
    {
      name: 'Test de Inglés',
      percent: 98,
    },
    {
      name: 'Coding Challenge',
      percent: 85,
    },
    {
      name: 'Test Psicométrico',
      percent: 95,
    },
    {
      name: 'Test de Inglés',
      percent: 98,
    },
  ],
}
