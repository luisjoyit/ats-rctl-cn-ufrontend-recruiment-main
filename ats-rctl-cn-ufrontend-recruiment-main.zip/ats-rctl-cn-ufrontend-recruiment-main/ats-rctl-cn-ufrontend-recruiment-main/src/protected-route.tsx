//@ts-ignore
import { useKeycloakHook, useUserRole } from '@joyit/user-management'
import { Outlet } from 'react-router-dom'

type RolesUser = 'applicant' | 'recruiter' | 'public'

interface ProtectedLayoutProps {
  roles: RolesUser[]
}

export const ProtectedLayout = ({ roles }: ProtectedLayoutProps) => {
  const { viewUser } = useUserRole()
  const { isUserLoggedIn, login } = useKeycloakHook()

  const hasAccess = isUserLoggedIn && roles?.includes(viewUser)

  if (!isUserLoggedIn) {
    return (
      <>
        not logged in <br />
        <button onClick={login} className="text-blue-400">
          Login
        </button>
      </>
    )
  }

  if (!hasAccess) {
    return "You don't have access to this page"
  }

  return <Outlet />
}
