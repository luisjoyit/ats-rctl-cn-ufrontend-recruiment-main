/* eslint-disable */
import { TypedDocumentNode as DocumentNode } from '@graphql-typed-document-node/core'
export type Maybe<T> = T | null
export type InputMaybe<T> = Maybe<T>
export type Exact<T extends { [key: string]: unknown }> = {
  [K in keyof T]: T[K]
}
export type MakeOptional<T, K extends keyof T> = Omit<T, K> & {
  [SubKey in K]?: Maybe<T[SubKey]>
}
export type MakeMaybe<T, K extends keyof T> = Omit<T, K> & {
  [SubKey in K]: Maybe<T[SubKey]>
}
export type MakeEmpty<
  T extends { [key: string]: unknown },
  K extends keyof T,
> = { [_ in K]?: never }
export type Incremental<T> =
  | T
  | {
      [P in keyof T]?: P extends ' $fragmentName' | '__typename' ? T[P] : never
    }
/** All built-in and custom scalars, mapped to their actual values */
export type Scalars = {
  ID: { input: string; output: string }
  String: { input: string; output: string }
  Boolean: { input: boolean; output: boolean }
  Int: { input: number; output: number }
  Float: { input: number; output: number }
  /** Scalar for BigDecimal */
  BigDecimal: { input: any; output: any }
  /** Scalar for BigInteger */
  BigInteger: { input: any; output: any }
  /** Scalar for Date */
  Date: { input: any; output: any }
  /** Scalar for DateTime */
  DateTime: { input: any; output: any }
  /** Scalar for Time */
  Time: { input: any; output: any }
  /** Scalar for Void */
  Void: { input: any; output: any }
}

export type ApplicantProfileEntity = {
  __typename?: 'ApplicantProfileEntity'
  certifications?: Maybe<Array<Maybe<CertificationEntity>>>
  contactInformation?: Maybe<ContactInformationEntity>
  educations?: Maybe<Array<Maybe<EducationEntity>>>
  id?: Maybe<Scalars['Int']['output']>
  image_url?: Maybe<Scalars['String']['output']>
  level_languages?: Maybe<Array<Maybe<LevelLanguageEntity>>>
  modalitys?: Maybe<Array<Maybe<ModalityEntity>>>
  personalInformation?: Maybe<PersonalInformationEntity>
  portfolios?: Maybe<Array<Maybe<PortfolioEntity>>>
  professionalNetworks?: Maybe<ProfessionalNetworksEntity>
  professionalRole?: Maybe<ProfessionalRoleEntity>
  professionalSummary?: Maybe<SummaryEntity>
  salaryPreference?: Maybe<SalaryPreferenceEntity>
  softSkills?: Maybe<Array<Maybe<SkillEntity>>>
  technologyStacks?: Maybe<Array<Maybe<TechnologyStackEntity>>>
  user?: Maybe<UserEntity>
  view: Scalars['Int']['output']
  workExperience?: Maybe<Array<Maybe<WorkExperienceEntity>>>
}

export type ApplicantProfileEntityInput = {
  certifications?: InputMaybe<Array<InputMaybe<CertificationEntityInput>>>
  contactInformation?: InputMaybe<ContactInformationEntityInput>
  educations?: InputMaybe<Array<InputMaybe<EducationEntityInput>>>
  id?: InputMaybe<Scalars['Int']['input']>
  image_url?: InputMaybe<Scalars['String']['input']>
  level_languages?: InputMaybe<Array<InputMaybe<LevelLanguageEntityInput>>>
  modalitys?: InputMaybe<Array<InputMaybe<ModalityEntityInput>>>
  personalInformation?: InputMaybe<PersonalInformationEntityInput>
  portfolios?: InputMaybe<Array<InputMaybe<PortfolioEntityInput>>>
  professionalNetworks?: InputMaybe<ProfessionalNetworksEntityInput>
  professionalRole?: InputMaybe<ProfessionalRoleEntityInput>
  professionalSummary?: InputMaybe<SummaryEntityInput>
  salaryPreference?: InputMaybe<SalaryPreferenceEntityInput>
  softSkills?: InputMaybe<Array<InputMaybe<SkillEntityInput>>>
  technologyStacks?: InputMaybe<Array<InputMaybe<TechnologyStackEntityInput>>>
  user?: InputMaybe<UserEntityInput>
  view: Scalars['Int']['input']
  workExperience?: InputMaybe<Array<InputMaybe<WorkExperienceEntityInput>>>
}

export type ApplicationPages = {
  __typename?: 'ApplicationPages'
  currentPage: Scalars['Int']['output']
  elementPerPage: Scalars['Int']['output']
  jobApplicationList?: Maybe<Array<Maybe<JobApplicationEntity>>>
  latest: Scalars['Boolean']['output']
  totalItems: Scalars['Int']['output']
  totalPage: Scalars['Int']['output']
}

export type AreaEntity = {
  __typename?: 'AreaEntity'
  description?: Maybe<Scalars['String']['output']>
  id: Scalars['Int']['output']
  offerEntitySet?: Maybe<Array<Maybe<OfferEntity>>>
}

export type AreaEntityInput = {
  description?: InputMaybe<Scalars['String']['input']>
  id: Scalars['Int']['input']
  offerEntitySet?: InputMaybe<Array<InputMaybe<OfferEntityInput>>>
}

export type BenefitsEntity = {
  __typename?: 'BenefitsEntity'
  /** ISO-8601 */
  created_at?: Maybe<Scalars['DateTime']['output']>
  description?: Maybe<Scalars['String']['output']>
  id?: Maybe<Scalars['BigInteger']['output']>
  jobs?: Maybe<Array<Maybe<JobEntity>>>
  name?: Maybe<Scalars['String']['output']>
  prefix?: Maybe<Scalars['String']['output']>
  /** ISO-8601 */
  updated_at?: Maybe<Scalars['DateTime']['output']>
}

export type BenefitsEntityInput = {
  /** ISO-8601 */
  created_at?: InputMaybe<Scalars['DateTime']['input']>
  description?: InputMaybe<Scalars['String']['input']>
  id?: InputMaybe<Scalars['BigInteger']['input']>
  jobs?: InputMaybe<Array<InputMaybe<JobEntityInput>>>
  name?: InputMaybe<Scalars['String']['input']>
  prefix?: InputMaybe<Scalars['String']['input']>
  /** ISO-8601 */
  updated_at?: InputMaybe<Scalars['DateTime']['input']>
}

export type Category = {
  __typename?: 'Category'
  /** ISO-8601 */
  created_at?: Maybe<Scalars['DateTime']['output']>
  id?: Maybe<Scalars['BigInteger']['output']>
  name?: Maybe<Scalars['String']['output']>
  /** ISO-8601 */
  updated_at?: Maybe<Scalars['DateTime']['output']>
}

export type CategoryEntity = {
  __typename?: 'CategoryEntity'
  /** ISO-8601 */
  created_at?: Maybe<Scalars['DateTime']['output']>
  id?: Maybe<Scalars['BigInteger']['output']>
  name?: Maybe<Scalars['String']['output']>
  /** ISO-8601 */
  updated_at?: Maybe<Scalars['DateTime']['output']>
}

export type CategoryInput = {
  /** ISO-8601 */
  created_at?: InputMaybe<Scalars['DateTime']['input']>
  id?: InputMaybe<Scalars['BigInteger']['input']>
  name?: InputMaybe<Scalars['String']['input']>
  /** ISO-8601 */
  updated_at?: InputMaybe<Scalars['DateTime']['input']>
}

export type Certification = {
  __typename?: 'Certification'
  cv?: Maybe<UserProfile>
  /** ISO-8601 */
  end_date?: Maybe<Scalars['Date']['output']>
  id?: Maybe<Scalars['BigInteger']['output']>
  /** ISO-8601 */
  initiate_date?: Maybe<Scalars['Date']['output']>
  institution_name?: Maybe<Scalars['String']['output']>
  name?: Maybe<Scalars['String']['output']>
  url_certificate?: Maybe<Scalars['String']['output']>
}

export type CertificationEntity = {
  __typename?: 'CertificationEntity'
  applicantProfile?: Maybe<ApplicantProfileEntity>
  /** ISO-8601 */
  end_date?: Maybe<Scalars['Date']['output']>
  id?: Maybe<Scalars['BigInteger']['output']>
  /** ISO-8601 */
  initiate_date?: Maybe<Scalars['Date']['output']>
  institution_name?: Maybe<Scalars['String']['output']>
  name?: Maybe<Scalars['String']['output']>
  url_certificate: Scalars['String']['output']
}

export type CertificationEntityInput = {
  applicantProfile?: InputMaybe<ApplicantProfileEntityInput>
  /** ISO-8601 */
  end_date?: InputMaybe<Scalars['Date']['input']>
  id?: InputMaybe<Scalars['BigInteger']['input']>
  /** ISO-8601 */
  initiate_date?: InputMaybe<Scalars['Date']['input']>
  institution_name?: InputMaybe<Scalars['String']['input']>
  name?: InputMaybe<Scalars['String']['input']>
  url_certificate: Scalars['String']['input']
}

export type CertificationInput = {
  cv?: InputMaybe<UserProfileInput>
  /** ISO-8601 */
  end_date?: InputMaybe<Scalars['Date']['input']>
  id?: InputMaybe<Scalars['BigInteger']['input']>
  /** ISO-8601 */
  initiate_date?: InputMaybe<Scalars['Date']['input']>
  institution_name?: InputMaybe<Scalars['String']['input']>
  name?: InputMaybe<Scalars['String']['input']>
  url_certificate?: InputMaybe<Scalars['String']['input']>
}

export type City = {
  __typename?: 'City'
  /** ISO-8601 */
  createdAt?: Maybe<Scalars['DateTime']['output']>
  id?: Maybe<Scalars['BigInteger']['output']>
  name: Scalars['String']['output']
  /** ISO-8601 */
  updateAt?: Maybe<Scalars['DateTime']['output']>
}

export type CityEntity = {
  __typename?: 'CityEntity'
  /** ISO-8601 */
  createdAt?: Maybe<Scalars['DateTime']['output']>
  id?: Maybe<Scalars['BigInteger']['output']>
  name?: Maybe<Scalars['String']['output']>
  /** ISO-8601 */
  updateAt?: Maybe<Scalars['DateTime']['output']>
}

export type CityEntityInput = {
  /** ISO-8601 */
  createdAt?: InputMaybe<Scalars['DateTime']['input']>
  id?: InputMaybe<Scalars['BigInteger']['input']>
  name?: InputMaybe<Scalars['String']['input']>
  /** ISO-8601 */
  updateAt?: InputMaybe<Scalars['DateTime']['input']>
}

export type CityInput = {
  /** ISO-8601 */
  createdAt?: InputMaybe<Scalars['DateTime']['input']>
  id?: InputMaybe<Scalars['BigInteger']['input']>
  name: Scalars['String']['input']
  /** ISO-8601 */
  updateAt?: InputMaybe<Scalars['DateTime']['input']>
}

export type Company = {
  __typename?: 'Company'
  /** ISO-8601 */
  createdAt?: Maybe<Scalars['DateTime']['output']>
  description: Scalars['String']['output']
  id?: Maybe<Scalars['BigInteger']['output']>
  imageUrl: Scalars['String']['output']
  locationId: Scalars['BigInteger']['output']
  name: Scalars['String']['output']
  /** ISO-8601 */
  updateAt?: Maybe<Scalars['DateTime']['output']>
}

export type CompanyEntity = {
  __typename?: 'CompanyEntity'
  /** ISO-8601 */
  createdAt?: Maybe<Scalars['DateTime']['output']>
  description?: Maybe<Scalars['String']['output']>
  employers?: Maybe<Array<Maybe<EmployerEntity>>>
  id?: Maybe<Scalars['BigInteger']['output']>
  imageUrl?: Maybe<Scalars['String']['output']>
  interviews?: Maybe<Array<Maybe<InterviewEntity>>>
  location?: Maybe<LocationEntity>
  name?: Maybe<Scalars['String']['output']>
  /** ISO-8601 */
  updateAt?: Maybe<Scalars['DateTime']['output']>
}

export type CompanyEntityInput = {
  /** ISO-8601 */
  createdAt?: InputMaybe<Scalars['DateTime']['input']>
  description?: InputMaybe<Scalars['String']['input']>
  employers?: InputMaybe<Array<InputMaybe<EmployerEntityInput>>>
  id?: InputMaybe<Scalars['BigInteger']['input']>
  imageUrl?: InputMaybe<Scalars['String']['input']>
  interviews?: InputMaybe<Array<InputMaybe<InterviewEntityInput>>>
  location?: InputMaybe<LocationEntityInput>
  name?: InputMaybe<Scalars['String']['input']>
  /** ISO-8601 */
  updateAt?: InputMaybe<Scalars['DateTime']['input']>
}

export type CompanyInput = {
  /** ISO-8601 */
  createdAt?: InputMaybe<Scalars['DateTime']['input']>
  description: Scalars['String']['input']
  id?: InputMaybe<Scalars['BigInteger']['input']>
  imageUrl: Scalars['String']['input']
  locationId: Scalars['BigInteger']['input']
  name: Scalars['String']['input']
  /** ISO-8601 */
  updateAt?: InputMaybe<Scalars['DateTime']['input']>
}

export type ContactInformation = {
  __typename?: 'ContactInformation'
  correo?: Maybe<Scalars['String']['output']>
  id?: Maybe<Scalars['Int']['output']>
  phone: Scalars['Int']['output']
  userProfile?: Maybe<UserProfile>
}

export type ContactInformationEntity = {
  __typename?: 'ContactInformationEntity'
  applicantProfile?: Maybe<ApplicantProfileEntity>
  correo?: Maybe<Scalars['String']['output']>
  id?: Maybe<Scalars['Int']['output']>
  phone: Scalars['Int']['output']
}

export type ContactInformationEntityInput = {
  applicantProfile?: InputMaybe<ApplicantProfileEntityInput>
  correo?: InputMaybe<Scalars['String']['input']>
  id?: InputMaybe<Scalars['Int']['input']>
  phone: Scalars['Int']['input']
}

export type ContactInformationInput = {
  correo?: InputMaybe<Scalars['String']['input']>
  id?: InputMaybe<Scalars['Int']['input']>
  phone: Scalars['Int']['input']
  userProfile?: InputMaybe<UserProfileInput>
}

export type Country = {
  __typename?: 'Country'
  /** ISO-8601 */
  createdAt?: Maybe<Scalars['DateTime']['output']>
  description?: Maybe<Scalars['String']['output']>
  id?: Maybe<Scalars['BigInteger']['output']>
  img_url?: Maybe<Scalars['String']['output']>
  name?: Maybe<Scalars['String']['output']>
  /** ISO-8601 */
  updatedAt?: Maybe<Scalars['DateTime']['output']>
}

export type CountryEntity = {
  __typename?: 'CountryEntity'
  /** ISO-8601 */
  createdAt?: Maybe<Scalars['DateTime']['output']>
  description?: Maybe<Scalars['String']['output']>
  id?: Maybe<Scalars['BigInteger']['output']>
  img_url?: Maybe<Scalars['String']['output']>
  name?: Maybe<Scalars['String']['output']>
  /** ISO-8601 */
  updatedAt?: Maybe<Scalars['DateTime']['output']>
}

export type CountryEntityInput = {
  /** ISO-8601 */
  createdAt?: InputMaybe<Scalars['DateTime']['input']>
  description?: InputMaybe<Scalars['String']['input']>
  id?: InputMaybe<Scalars['BigInteger']['input']>
  img_url?: InputMaybe<Scalars['String']['input']>
  name?: InputMaybe<Scalars['String']['input']>
  /** ISO-8601 */
  updatedAt?: InputMaybe<Scalars['DateTime']['input']>
}

export type CurrencyEntity = {
  __typename?: 'CurrencyEntity'
  description?: Maybe<Scalars['String']['output']>
  id: Scalars['Int']['output']
  offerEntitySet?: Maybe<Array<Maybe<OfferEntity>>>
}

export type CurrencyEntityInput = {
  description?: InputMaybe<Scalars['String']['input']>
  id: Scalars['Int']['input']
  offerEntitySet?: InputMaybe<Array<InputMaybe<OfferEntityInput>>>
}

export type Education = {
  __typename?: 'Education'
  course?: Maybe<Scalars['String']['output']>
  /** ISO-8601 */
  end_date?: Maybe<Scalars['Date']['output']>
  id?: Maybe<Scalars['Int']['output']>
  /** ISO-8601 */
  initiate_date?: Maybe<Scalars['Date']['output']>
  institution?: Maybe<Scalars['String']['output']>
  type?: Maybe<Scalars['String']['output']>
}

export type EducationEntity = {
  __typename?: 'EducationEntity'
  applicantProfile?: Maybe<ApplicantProfileEntity>
  course?: Maybe<Scalars['String']['output']>
  /** ISO-8601 */
  end_date?: Maybe<Scalars['Date']['output']>
  id?: Maybe<Scalars['Int']['output']>
  /** ISO-8601 */
  initiate_date?: Maybe<Scalars['Date']['output']>
  institution: Scalars['String']['output']
  type?: Maybe<Scalars['String']['output']>
}

export type EducationEntityInput = {
  applicantProfile?: InputMaybe<ApplicantProfileEntityInput>
  course?: InputMaybe<Scalars['String']['input']>
  /** ISO-8601 */
  end_date?: InputMaybe<Scalars['Date']['input']>
  id?: InputMaybe<Scalars['Int']['input']>
  /** ISO-8601 */
  initiate_date?: InputMaybe<Scalars['Date']['input']>
  institution: Scalars['String']['input']
  type?: InputMaybe<Scalars['String']['input']>
}

export type EducationInput = {
  course?: InputMaybe<Scalars['String']['input']>
  /** ISO-8601 */
  end_date?: InputMaybe<Scalars['Date']['input']>
  id?: InputMaybe<Scalars['Int']['input']>
  /** ISO-8601 */
  initiate_date?: InputMaybe<Scalars['Date']['input']>
  institution?: InputMaybe<Scalars['String']['input']>
  type?: InputMaybe<Scalars['String']['input']>
}

export type EmployerEntity = {
  __typename?: 'EmployerEntity'
  company?: Maybe<CompanyEntity>
  id?: Maybe<Scalars['BigInteger']['output']>
  jobs?: Maybe<Array<Maybe<JobEntity>>>
  user?: Maybe<UserEntity>
}

export type EmployerEntityInput = {
  company?: InputMaybe<CompanyEntityInput>
  id?: InputMaybe<Scalars['BigInteger']['input']>
  jobs?: InputMaybe<Array<InputMaybe<JobEntityInput>>>
  user?: InputMaybe<UserEntityInput>
}

export type EvaluationEntity = {
  __typename?: 'EvaluationEntity'
  active: Scalars['Boolean']['output']
  duration: Scalars['Float']['output']
  /** ISO-8601 */
  finish_date?: Maybe<Scalars['DateTime']['output']>
  id?: Maybe<Scalars['BigInteger']['output']>
  name?: Maybe<Scalars['String']['output']>
  num_participants: Scalars['Int']['output']
  /** ISO-8601 */
  start_date?: Maybe<Scalars['DateTime']['output']>
  test?: Maybe<TestEntity>
  user?: Maybe<Array<Maybe<UserEntity>>>
}

export type EvaluationEntityInput = {
  active: Scalars['Boolean']['input']
  duration: Scalars['Float']['input']
  /** ISO-8601 */
  finish_date?: InputMaybe<Scalars['DateTime']['input']>
  id?: InputMaybe<Scalars['BigInteger']['input']>
  name?: InputMaybe<Scalars['String']['input']>
  num_participants: Scalars['Int']['input']
  /** ISO-8601 */
  start_date?: InputMaybe<Scalars['DateTime']['input']>
  test?: InputMaybe<TestEntityInput>
  user?: InputMaybe<Array<InputMaybe<UserEntityInput>>>
}

export type EvaluationInput = {
  active: Scalars['Boolean']['input']
  duration: Scalars['Float']['input']
  /** ISO-8601 */
  finish_date?: InputMaybe<Scalars['DateTime']['input']>
  id?: InputMaybe<Scalars['BigInteger']['input']>
  name?: InputMaybe<Scalars['String']['input']>
  num_participants: Scalars['Int']['input']
  /** ISO-8601 */
  start_date?: InputMaybe<Scalars['DateTime']['input']>
  test?: InputMaybe<TestInput>
  user_id?: InputMaybe<Scalars['String']['input']>
}

export type FaqEntity = {
  __typename?: 'FaqEntity'
  description?: Maybe<Scalars['String']['output']>
  id?: Maybe<Scalars['BigInteger']['output']>
  question?: Maybe<Scalars['String']['output']>
  type: Scalars['String']['output']
}

export type Favorite = {
  __typename?: 'Favorite'
  id?: Maybe<Scalars['BigInteger']['output']>
  job?: Maybe<Job>
  user?: Maybe<User>
}

export type FavoriteEntity = {
  __typename?: 'FavoriteEntity'
  /** ISO-8601 */
  created?: Maybe<Scalars['DateTime']['output']>
  id?: Maybe<Scalars['BigInteger']['output']>
  job?: Maybe<JobEntity>
  user?: Maybe<UserEntity>
}

export type FavoriteEntityInput = {
  /** ISO-8601 */
  created?: InputMaybe<Scalars['DateTime']['input']>
  id?: InputMaybe<Scalars['BigInteger']['input']>
  job?: InputMaybe<JobEntityInput>
  user?: InputMaybe<UserEntityInput>
}

export type FavoriteInput = {
  id?: InputMaybe<Scalars['BigInteger']['input']>
  job?: InputMaybe<JobInput>
  user?: InputMaybe<UserInput>
}

export type FavoritePages = {
  __typename?: 'FavoritePages'
  currentPage: Scalars['Int']['output']
  elementPerPage: Scalars['Int']['output']
  favoriteEntityList?: Maybe<Array<Maybe<FavoriteEntity>>>
  latest: Scalars['Boolean']['output']
  totalItems: Scalars['Int']['output']
  totalPage: Scalars['Int']['output']
}

export type HiringEntity = {
  __typename?: 'HiringEntity'
  form: Scalars['Boolean']['output']
  id?: Maybe<Scalars['String']['output']>
  provider?: Maybe<Scalars['String']['output']>
}

export type HiringEntityInput = {
  form: Scalars['Boolean']['input']
  id?: InputMaybe<Scalars['String']['input']>
  provider?: InputMaybe<Scalars['String']['input']>
}

export type Interview = {
  __typename?: 'Interview'
  company_id: Scalars['BigInteger']['output']
  end: Scalars['String']['output']
  id?: Maybe<Scalars['BigInteger']['output']>
  interviewer: Scalars['String']['output']
  link: Scalars['String']['output']
  position: Scalars['String']['output']
  reschedules?: Maybe<Array<Maybe<Reschedules>>>
  start: Scalars['String']['output']
}

export type InterviewEntity = {
  __typename?: 'InterviewEntity'
  company?: Maybe<CompanyEntity>
  companyEntity?: Maybe<CompanyEntity>
  /** ISO-8601 */
  createdAt?: Maybe<Scalars['DateTime']['output']>
  end_time?: Maybe<Scalars['String']['output']>
  id?: Maybe<Scalars['BigInteger']['output']>
  interviewer?: Maybe<Scalars['String']['output']>
  job?: Maybe<JobEntity>
  link?: Maybe<Scalars['String']['output']>
  position?: Maybe<Scalars['String']['output']>
  reschedulesEntityList?: Maybe<Array<Maybe<ReschedulesEntity>>>
  start_time?: Maybe<Scalars['String']['output']>
  /** ISO-8601 */
  updateAt?: Maybe<Scalars['DateTime']['output']>
  user?: Maybe<UserEntity>
}

export type InterviewEntityInput = {
  company?: InputMaybe<CompanyEntityInput>
  /** ISO-8601 */
  createdAt?: InputMaybe<Scalars['DateTime']['input']>
  end_time?: InputMaybe<Scalars['String']['input']>
  id?: InputMaybe<Scalars['BigInteger']['input']>
  interviewer?: InputMaybe<Scalars['String']['input']>
  job?: InputMaybe<JobEntityInput>
  link?: InputMaybe<Scalars['String']['input']>
  position?: InputMaybe<Scalars['String']['input']>
  reschedulesEntityList?: InputMaybe<Array<InputMaybe<ReschedulesEntityInput>>>
  start_time?: InputMaybe<Scalars['String']['input']>
  /** ISO-8601 */
  updateAt?: InputMaybe<Scalars['DateTime']['input']>
  user?: InputMaybe<UserEntityInput>
}

export type InterviewInput = {
  company_id: Scalars['BigInteger']['input']
  end: Scalars['String']['input']
  id?: InputMaybe<Scalars['BigInteger']['input']>
  interviewer: Scalars['String']['input']
  link: Scalars['String']['input']
  position: Scalars['String']['input']
  reschedules?: InputMaybe<Array<InputMaybe<ReschedulesInput>>>
  start: Scalars['String']['input']
}

export type Job = {
  __typename?: 'Job'
  benefitsIds?: Maybe<Array<Maybe<Scalars['BigInteger']['output']>>>
  companyId: Scalars['BigInteger']['output']
  countryId: Scalars['BigInteger']['output']
  /** ISO-8601 */
  createdAt?: Maybe<Scalars['DateTime']['output']>
  description?: Maybe<Scalars['String']['output']>
  description_functions?: Maybe<Scalars['String']['output']>
  description_functions_additional_requirements?: Maybe<
    Scalars['String']['output']
  >
  employeerId?: Maybe<Scalars['BigInteger']['output']>
  /** ISO-8601 */
  endTime?: Maybe<Scalars['Time']['output']>
  id?: Maybe<Scalars['BigInteger']['output']>
  languageId?: Maybe<Scalars['Int']['output']>
  levelOfExperienceId?: Maybe<Scalars['Int']['output']>
  maxSalary?: Maybe<Scalars['BigDecimal']['output']>
  minSalary?: Maybe<Scalars['BigDecimal']['output']>
  name?: Maybe<Scalars['String']['output']>
  openPositions: Scalars['Int']['output']
  profileTypesId?: Maybe<Scalars['Int']['output']>
  questions?: Maybe<Array<Maybe<QuestionEntity>>>
  /** ISO-8601 */
  startTime?: Maybe<Scalars['Time']['output']>
  technologyStackIds?: Maybe<Array<Maybe<Scalars['Int']['output']>>>
  /** ISO-8601 */
  updateAt?: Maybe<Scalars['DateTime']['output']>
  verified_profiles?: Maybe<Scalars['Boolean']['output']>
  visibility_name_company?: Maybe<Scalars['Boolean']['output']>
  workMode?: Maybe<WorkMode>
}

export type JobApplication = {
  __typename?: 'JobApplication'
  /** ISO-8601 */
  createdAt?: Maybe<Scalars['DateTime']['output']>
  id?: Maybe<Scalars['Int']['output']>
  jobId: Scalars['BigInteger']['output']
  /** ISO-8601 */
  updateAt?: Maybe<Scalars['DateTime']['output']>
  userId: Scalars['String']['output']
}

export type JobApplicationEntity = {
  __typename?: 'JobApplicationEntity'
  /** ISO-8601 */
  createdAt?: Maybe<Scalars['DateTime']['output']>
  id?: Maybe<Scalars['Int']['output']>
  jobEntity?: Maybe<JobEntity>
  state?: Maybe<StateEntity>
  /** ISO-8601 */
  updateAt?: Maybe<Scalars['DateTime']['output']>
  user?: Maybe<UserEntity>
}

export type JobApplicationEntityInput = {
  /** ISO-8601 */
  createdAt?: InputMaybe<Scalars['DateTime']['input']>
  id?: InputMaybe<Scalars['Int']['input']>
  jobEntity?: InputMaybe<JobEntityInput>
  state?: InputMaybe<StateEntityInput>
  /** ISO-8601 */
  updateAt?: InputMaybe<Scalars['DateTime']['input']>
  user?: InputMaybe<UserEntityInput>
}

export type JobApplicationInput = {
  /** ISO-8601 */
  createdAt?: InputMaybe<Scalars['DateTime']['input']>
  id?: InputMaybe<Scalars['Int']['input']>
  jobId: Scalars['BigInteger']['input']
  /** ISO-8601 */
  updateAt?: InputMaybe<Scalars['DateTime']['input']>
  userId: Scalars['String']['input']
}

export type JobEntity = {
  __typename?: 'JobEntity'
  active: Scalars['Boolean']['output']
  benefits?: Maybe<Array<Maybe<BenefitsEntity>>>
  company?: Maybe<CompanyEntity>
  country?: Maybe<CountryEntity>
  /** ISO-8601 */
  createdAt?: Maybe<Scalars['DateTime']['output']>
  description?: Maybe<Scalars['String']['output']>
  description_functions?: Maybe<Scalars['String']['output']>
  description_functions_additional_requirements?: Maybe<
    Scalars['String']['output']
  >
  employer?: Maybe<EmployerEntity>
  /** ISO-8601 */
  endTime?: Maybe<Scalars['Time']['output']>
  id?: Maybe<Scalars['BigInteger']['output']>
  language?: Maybe<LanguageEntity>
  levelOfExperience?: Maybe<LevelOfExperienceEntity>
  maxSalary?: Maybe<Scalars['BigDecimal']['output']>
  minSalary?: Maybe<Scalars['BigDecimal']['output']>
  name?: Maybe<Scalars['String']['output']>
  openPositions: Scalars['Int']['output']
  profileType?: Maybe<ProfileTypeEntity>
  questions?: Maybe<Array<Maybe<QuestionEntity>>>
  salary: Scalars['Float']['output']
  /** ISO-8601 */
  startTime?: Maybe<Scalars['Time']['output']>
  technologyStacks?: Maybe<Array<Maybe<TechnologyStackEntity>>>
  /** ISO-8601 */
  updateAt?: Maybe<Scalars['DateTime']['output']>
  verified_profiles?: Maybe<Scalars['Boolean']['output']>
  visibility_name_company?: Maybe<Scalars['Boolean']['output']>
  workMode?: Maybe<WorkMode>
}

export type JobEntityInput = {
  active: Scalars['Boolean']['input']
  benefits?: InputMaybe<Array<InputMaybe<BenefitsEntityInput>>>
  company?: InputMaybe<CompanyEntityInput>
  country?: InputMaybe<CountryEntityInput>
  /** ISO-8601 */
  createdAt?: InputMaybe<Scalars['DateTime']['input']>
  description?: InputMaybe<Scalars['String']['input']>
  description_functions?: InputMaybe<Scalars['String']['input']>
  description_functions_additional_requirements?: InputMaybe<
    Scalars['String']['input']
  >
  employer?: InputMaybe<EmployerEntityInput>
  /** ISO-8601 */
  endTime?: InputMaybe<Scalars['Time']['input']>
  id?: InputMaybe<Scalars['BigInteger']['input']>
  language?: InputMaybe<LanguageEntityInput>
  levelOfExperience?: InputMaybe<LevelOfExperienceEntityInput>
  maxSalary?: InputMaybe<Scalars['BigDecimal']['input']>
  minSalary?: InputMaybe<Scalars['BigDecimal']['input']>
  name?: InputMaybe<Scalars['String']['input']>
  openPositions: Scalars['Int']['input']
  profileType?: InputMaybe<ProfileTypeEntityInput>
  questions?: InputMaybe<Array<InputMaybe<QuestionEntityInput>>>
  salary: Scalars['Float']['input']
  /** ISO-8601 */
  startTime?: InputMaybe<Scalars['Time']['input']>
  technologyStacks?: InputMaybe<Array<InputMaybe<TechnologyStackEntityInput>>>
  /** ISO-8601 */
  updateAt?: InputMaybe<Scalars['DateTime']['input']>
  verified_profiles?: InputMaybe<Scalars['Boolean']['input']>
  visibility_name_company?: InputMaybe<Scalars['Boolean']['input']>
  workMode?: InputMaybe<WorkMode>
}

export type JobInput = {
  benefitsIds?: InputMaybe<Array<InputMaybe<Scalars['BigInteger']['input']>>>
  companyId: Scalars['BigInteger']['input']
  countryId: Scalars['BigInteger']['input']
  /** ISO-8601 */
  createdAt?: InputMaybe<Scalars['DateTime']['input']>
  description?: InputMaybe<Scalars['String']['input']>
  description_functions?: InputMaybe<Scalars['String']['input']>
  description_functions_additional_requirements?: InputMaybe<
    Scalars['String']['input']
  >
  employeerId?: InputMaybe<Scalars['BigInteger']['input']>
  /** ISO-8601 */
  endTime?: InputMaybe<Scalars['Time']['input']>
  id?: InputMaybe<Scalars['BigInteger']['input']>
  languageId?: InputMaybe<Scalars['Int']['input']>
  levelOfExperienceId?: InputMaybe<Scalars['Int']['input']>
  maxSalary?: InputMaybe<Scalars['BigDecimal']['input']>
  minSalary?: InputMaybe<Scalars['BigDecimal']['input']>
  name?: InputMaybe<Scalars['String']['input']>
  openPositions: Scalars['Int']['input']
  profileTypesId?: InputMaybe<Scalars['Int']['input']>
  questions?: InputMaybe<Array<InputMaybe<QuestionEntityInput>>>
  /** ISO-8601 */
  startTime?: InputMaybe<Scalars['Time']['input']>
  technologyStackIds?: InputMaybe<Array<InputMaybe<Scalars['Int']['input']>>>
  /** ISO-8601 */
  updateAt?: InputMaybe<Scalars['DateTime']['input']>
  verified_profiles?: InputMaybe<Scalars['Boolean']['input']>
  visibility_name_company?: InputMaybe<Scalars['Boolean']['input']>
  workMode?: InputMaybe<WorkMode>
}

export type JobPages = {
  __typename?: 'JobPages'
  currentPage: Scalars['Int']['output']
  elementPerPage: Scalars['Int']['output']
  jobs?: Maybe<Array<Maybe<JobEntity>>>
  totalItems: Scalars['Int']['output']
  totalPage: Scalars['Int']['output']
}

export type LanguageEntity = {
  __typename?: 'LanguageEntity'
  description?: Maybe<Scalars['String']['output']>
  id?: Maybe<Scalars['Int']['output']>
  offerEntities?: Maybe<Array<Maybe<OfferEntity>>>
}

export type LanguageEntityInput = {
  description?: InputMaybe<Scalars['String']['input']>
  id?: InputMaybe<Scalars['Int']['input']>
  offerEntities?: InputMaybe<Array<InputMaybe<OfferEntityInput>>>
}

export type LevelLanguage = {
  __typename?: 'LevelLanguage'
  /** ISO-8601 */
  created_at?: Maybe<Scalars['DateTime']['output']>
  id?: Maybe<Scalars['BigInteger']['output']>
  language: Scalars['Int']['output']
  level?: Maybe<Scalars['String']['output']>
  /** ISO-8601 */
  updated_at?: Maybe<Scalars['DateTime']['output']>
}

export type LevelLanguageEntity = {
  __typename?: 'LevelLanguageEntity'
  applicantProfile?: Maybe<ApplicantProfileEntity>
  /** ISO-8601 */
  created_at?: Maybe<Scalars['DateTime']['output']>
  id?: Maybe<Scalars['BigInteger']['output']>
  language?: Maybe<LanguageEntity>
  level?: Maybe<Scalars['String']['output']>
  /** ISO-8601 */
  updated_at?: Maybe<Scalars['DateTime']['output']>
}

export type LevelLanguageEntityInput = {
  applicantProfile?: InputMaybe<ApplicantProfileEntityInput>
  /** ISO-8601 */
  created_at?: InputMaybe<Scalars['DateTime']['input']>
  id?: InputMaybe<Scalars['BigInteger']['input']>
  language?: InputMaybe<LanguageEntityInput>
  level?: InputMaybe<Scalars['String']['input']>
  /** ISO-8601 */
  updated_at?: InputMaybe<Scalars['DateTime']['input']>
}

export type LevelLanguageInput = {
  /** ISO-8601 */
  created_at?: InputMaybe<Scalars['DateTime']['input']>
  id?: InputMaybe<Scalars['BigInteger']['input']>
  language: Scalars['Int']['input']
  level?: InputMaybe<Scalars['String']['input']>
  /** ISO-8601 */
  updated_at?: InputMaybe<Scalars['DateTime']['input']>
}

export type LevelOfExperienceEntity = {
  __typename?: 'LevelOfExperienceEntity'
  /** ISO-8601 */
  created_at?: Maybe<Scalars['Date']['output']>
  id?: Maybe<Scalars['Int']['output']>
  name?: Maybe<Scalars['String']['output']>
  offerEntitySet?: Maybe<Array<Maybe<OfferEntity>>>
  /** ISO-8601 */
  updated_at?: Maybe<Scalars['Date']['output']>
}

export type LevelOfExperienceEntityInput = {
  /** ISO-8601 */
  created_at?: InputMaybe<Scalars['Date']['input']>
  id?: InputMaybe<Scalars['Int']['input']>
  name?: InputMaybe<Scalars['String']['input']>
  offerEntitySet?: InputMaybe<Array<InputMaybe<OfferEntityInput>>>
  /** ISO-8601 */
  updated_at?: InputMaybe<Scalars['Date']['input']>
}

export type LocationEntity = {
  __typename?: 'LocationEntity'
  city?: Maybe<CityEntity>
  country?: Maybe<CountryEntity>
  description?: Maybe<Scalars['String']['output']>
  id?: Maybe<Scalars['BigInteger']['output']>
}

export type LocationEntityInput = {
  city?: InputMaybe<CityEntityInput>
  country?: InputMaybe<CountryEntityInput>
  description?: InputMaybe<Scalars['String']['input']>
  id?: InputMaybe<Scalars['BigInteger']['input']>
}

export type ModalityEntity = {
  __typename?: 'ModalityEntity'
  applicantsProfile?: Maybe<Array<Maybe<ApplicantProfileEntity>>>
  id?: Maybe<Scalars['Int']['output']>
  name?: Maybe<Scalars['String']['output']>
  offerEntitySet?: Maybe<Array<Maybe<OfferEntity>>>
}

export type ModalityEntityInput = {
  applicantsProfile?: InputMaybe<Array<InputMaybe<ApplicantProfileEntityInput>>>
  id?: InputMaybe<Scalars['Int']['input']>
  name?: InputMaybe<Scalars['String']['input']>
  offerEntitySet?: InputMaybe<Array<InputMaybe<OfferEntityInput>>>
}

/** Mutation root */
export type Mutation = {
  __typename?: 'Mutation'
  CreateApplication?: Maybe<JobApplication>
  CreateCertification?: Maybe<CertificationEntity>
  CreateCity?: Maybe<City>
  CreateCompany?: Maybe<Company>
  CreateContactInformationByUserProfile?: Maybe<Scalars['Boolean']['output']>
  CreateEducation?: Maybe<EducationEntity>
  CreateEvaluation?: Maybe<Scalars['Boolean']['output']>
  CreateInterview?: Maybe<Interview>
  CreateJob?: Maybe<Scalars['Boolean']['output']>
  CreateJobFavoriteByUser?: Maybe<Favorite>
  CreateLevelLanguageByUserProfile?: Maybe<Scalars['Boolean']['output']>
  CreatePersonalInformationByUserProfile?: Maybe<Scalars['Boolean']['output']>
  CreatePortfolio?: Maybe<Portfolio>
  CreateProfessionalNetworkByUserProfile?: Maybe<Scalars['Boolean']['output']>
  CreateProfessionalSummary?: Maybe<Summary>
  CreateProfileType?: Maybe<ProfileType>
  CreateQuestion?: Maybe<Question>
  CreateReschedule?: Maybe<Reschedules>
  CreateSalaryPreferenceByUserProfile?: Maybe<Scalars['Boolean']['output']>
  CreateTechnologyStackByUserProfile?: Maybe<Scalars['String']['output']>
  CreateUser?: Maybe<UserEntity>
  CreateUserProfile?: Maybe<Scalars['String']['output']>
  CreateWorkExperience?: Maybe<WorkExperienceEntity>
  DeleteCertificationByProfile?: Maybe<Scalars['Boolean']['output']>
  DeleteEducationByProfile?: Maybe<Scalars['Boolean']['output']>
  DeleteJobFavoriteByUser?: Maybe<Scalars['String']['output']>
  DeleteLevelLanguageByProfile?: Maybe<Scalars['Boolean']['output']>
  DeleteSoftSkillByUserProfile?: Maybe<Scalars['Boolean']['output']>
  DeleteTechnologyByProfile?: Maybe<Scalars['Boolean']['output']>
  DeleteWorkExpByProfile?: Maybe<Scalars['Boolean']['output']>
  GetViewsProfile?: Maybe<Scalars['String']['output']>
  UpdateUser?: Maybe<Scalars['Boolean']['output']>
  UpdateUserProfile?: Maybe<Scalars['Boolean']['output']>
  UpdatedPersonalInformationByUserProfile?: Maybe<Scalars['Boolean']['output']>
  UpdatedProfessionalNetworkByUserProfile?: Maybe<Scalars['Boolean']['output']>
  UpdatedSalaryPreferenceByUserProfile?: Maybe<Scalars['Boolean']['output']>
  createLanguageByUserProfile?: Maybe<Scalars['String']['output']>
  createSoftSkillByUserProfile?: Maybe<Scalars['String']['output']>
  deleteCityById?: Maybe<Scalars['Void']['output']>
  deleteJobById?: Maybe<Scalars['Void']['output']>
  hardcodedValue?: Maybe<Scalars['String']['output']>
  updateCity?: Maybe<Scalars['Void']['output']>
  updatedContactInformationByUserProfile?: Maybe<Scalars['Boolean']['output']>
}

/** Mutation root */
export type MutationCreateApplicationArgs = {
  application?: InputMaybe<JobApplicationInput>
}

/** Mutation root */
export type MutationCreateCertificationArgs = {
  certificationEntity?: InputMaybe<CertificationEntityInput>
}

/** Mutation root */
export type MutationCreateCityArgs = {
  city?: InputMaybe<CityInput>
}

/** Mutation root */
export type MutationCreateCompanyArgs = {
  company?: InputMaybe<CompanyInput>
}

/** Mutation root */
export type MutationCreateContactInformationByUserProfileArgs = {
  contactInformation?: InputMaybe<ContactInformationInput>
  profile_id: Scalars['Int']['input']
}

/** Mutation root */
export type MutationCreateEducationArgs = {
  educationEntity?: InputMaybe<EducationEntityInput>
}

/** Mutation root */
export type MutationCreateEvaluationArgs = {
  evaluation?: InputMaybe<EvaluationInput>
}

/** Mutation root */
export type MutationCreateInterviewArgs = {
  interview?: InputMaybe<InterviewInput>
}

/** Mutation root */
export type MutationCreateJobArgs = {
  job?: InputMaybe<JobInput>
}

/** Mutation root */
export type MutationCreateJobFavoriteByUserArgs = {
  job_id?: InputMaybe<Scalars['BigInteger']['input']>
  user_id?: InputMaybe<Scalars['String']['input']>
}

/** Mutation root */
export type MutationCreateLevelLanguageByUserProfileArgs = {
  levelLanguage?: InputMaybe<LevelLanguageInput>
  profile_id: Scalars['Int']['input']
}

/** Mutation root */
export type MutationCreatePersonalInformationByUserProfileArgs = {
  personalInformation?: InputMaybe<PersonalInformationInput>
  profile_id: Scalars['Int']['input']
}

/** Mutation root */
export type MutationCreatePortfolioArgs = {
  city_id?: InputMaybe<Scalars['BigInteger']['input']>
  country_id?: InputMaybe<Scalars['BigInteger']['input']>
  portfolio?: InputMaybe<PortfolioInput>
  userprofile_id?: InputMaybe<Scalars['Int']['input']>
}

/** Mutation root */
export type MutationCreateProfessionalNetworkByUserProfileArgs = {
  professionalNetworks?: InputMaybe<ProfessionalNetworksInput>
  profile_id: Scalars['Int']['input']
}

/** Mutation root */
export type MutationCreateProfessionalSummaryArgs = {
  profileType_id?: InputMaybe<Scalars['Int']['input']>
  summary?: InputMaybe<SummaryInput>
  userProfile_id?: InputMaybe<Scalars['Int']['input']>
  yearOfExp_id?: InputMaybe<Scalars['Int']['input']>
}

/** Mutation root */
export type MutationCreateProfileTypeArgs = {
  profileType?: InputMaybe<ProfileTypeInput>
}

/** Mutation root */
export type MutationCreateQuestionArgs = {
  question?: InputMaybe<QuestionInput>
}

/** Mutation root */
export type MutationCreateRescheduleArgs = {
  localDateTime?: InputMaybe<Scalars['DateTime']['input']>
  reschedules?: InputMaybe<ReschedulesInput>
}

/** Mutation root */
export type MutationCreateSalaryPreferenceByUserProfileArgs = {
  profile_id: Scalars['Int']['input']
  salaryPreference?: InputMaybe<SalaryPreferenceInput>
}

/** Mutation root */
export type MutationCreateTechnologyStackByUserProfileArgs = {
  technologyStackId?: InputMaybe<Array<InputMaybe<Scalars['Int']['input']>>>
  userProfileId?: InputMaybe<Scalars['Int']['input']>
}

/** Mutation root */
export type MutationCreateUserArgs = {
  userEntity?: InputMaybe<UserEntityInput>
}

/** Mutation root */
export type MutationCreateUserProfileArgs = {
  language_id?: InputMaybe<Scalars['Int']['input']>
  profiletype_id?: InputMaybe<Scalars['Int']['input']>
  skill_id?: InputMaybe<Scalars['Int']['input']>
  technology_id?: InputMaybe<Scalars['Int']['input']>
  userProfile?: InputMaybe<UserProfileInput>
  user_id?: InputMaybe<Scalars['String']['input']>
}

/** Mutation root */
export type MutationCreateWorkExperienceArgs = {
  workExperienceEntity?: InputMaybe<WorkExperienceEntityInput>
}

/** Mutation root */
export type MutationDeleteCertificationByProfileArgs = {
  certification_id: Scalars['BigInteger']['input']
  profile_id: Scalars['Int']['input']
}

/** Mutation root */
export type MutationDeleteEducationByProfileArgs = {
  education_id: Scalars['Int']['input']
  profile_id: Scalars['Int']['input']
}

/** Mutation root */
export type MutationDeleteJobFavoriteByUserArgs = {
  job_id?: InputMaybe<Scalars['BigInteger']['input']>
  user_id?: InputMaybe<Scalars['String']['input']>
}

/** Mutation root */
export type MutationDeleteLevelLanguageByProfileArgs = {
  level_language_id: Scalars['BigInteger']['input']
  profile_id: Scalars['Int']['input']
}

/** Mutation root */
export type MutationDeleteSoftSkillByUserProfileArgs = {
  profile_id: Scalars['Int']['input']
  skill_id: Scalars['Int']['input']
}

/** Mutation root */
export type MutationDeleteTechnologyByProfileArgs = {
  profile_id: Scalars['Int']['input']
  technology_id: Scalars['Int']['input']
}

/** Mutation root */
export type MutationDeleteWorkExpByProfileArgs = {
  profile_id: Scalars['Int']['input']
  workexp_id: Scalars['Int']['input']
}

/** Mutation root */
export type MutationGetViewsProfileArgs = {
  user_id?: InputMaybe<Scalars['String']['input']>
  user_id2?: InputMaybe<Scalars['String']['input']>
}

/** Mutation root */
export type MutationUpdateUserArgs = {
  user?: InputMaybe<UserInput>
}

/** Mutation root */
export type MutationUpdateUserProfileArgs = {
  userProfileEntity?: InputMaybe<UserProfileInput>
}

/** Mutation root */
export type MutationUpdatedPersonalInformationByUserProfileArgs = {
  personalInformation?: InputMaybe<PersonalInformationInput>
  profile_id: Scalars['Int']['input']
}

/** Mutation root */
export type MutationUpdatedProfessionalNetworkByUserProfileArgs = {
  professionalNetworks?: InputMaybe<ProfessionalNetworksInput>
  profile_id: Scalars['Int']['input']
}

/** Mutation root */
export type MutationUpdatedSalaryPreferenceByUserProfileArgs = {
  profile_id: Scalars['Int']['input']
  salaryPreference?: InputMaybe<SalaryPreferenceInput>
}

/** Mutation root */
export type MutationCreateLanguageByUserProfileArgs = {
  id_language: Scalars['Int']['input']
  id_profile: Scalars['Int']['input']
}

/** Mutation root */
export type MutationCreateSoftSkillByUserProfileArgs = {
  skill_id?: InputMaybe<Scalars['Int']['input']>
  userProfile_id?: InputMaybe<Scalars['Int']['input']>
}

/** Mutation root */
export type MutationDeleteCityByIdArgs = {
  id?: InputMaybe<Scalars['BigInteger']['input']>
}

/** Mutation root */
export type MutationDeleteJobByIdArgs = {
  id?: InputMaybe<Scalars['BigInteger']['input']>
}

/** Mutation root */
export type MutationUpdateCityArgs = {
  id?: InputMaybe<Scalars['BigInteger']['input']>
  name?: InputMaybe<Scalars['String']['input']>
}

/** Mutation root */
export type MutationUpdatedContactInformationByUserProfileArgs = {
  contactInformation?: InputMaybe<ContactInformationInput>
  profile_id: Scalars['Int']['input']
}

export type OfferEntity = {
  __typename?: 'OfferEntity'
  areaEntity?: Maybe<AreaEntity>
  countryEntity?: Maybe<CountryEntity>
  /** ISO-8601 */
  createdAt?: Maybe<Scalars['DateTime']['output']>
  currencyEntity?: Maybe<CurrencyEntity>
  description?: Maybe<Scalars['String']['output']>
  hiringEntity?: Maybe<HiringEntity>
  id?: Maybe<Scalars['String']['output']>
  languageEntity?: Maybe<Array<Maybe<LanguageEntity>>>
  levelOfExperienceEntity?: Maybe<LevelOfExperienceEntity>
  locationEntity?: Maybe<LocationEntity>
  maxAge: Scalars['Int']['output']
  minAge: Scalars['Int']['output']
  minStudyGradeEntity?: Maybe<StudyGradeEntity>
  modalityEntity?: Maybe<ModalityEntity>
  /** ISO-8601 */
  modifiedAt?: Maybe<Scalars['DateTime']['output']>
  position?: Maybe<Scalars['String']['output']>
  skillEntities?: Maybe<Array<Maybe<SkillEntity>>>
  subAreaEntity?: Maybe<SubAreaEntity>
  sueldoMaximo: Scalars['Int']['output']
  sueldoMinimo: Scalars['Int']['output']
  typoOfContractEntity?: Maybe<TypeOfContractEntity>
  workingHoursEntity?: Maybe<WorkingHoursEntity>
  yearsOfExp: Scalars['Int']['output']
}

export type OfferEntityInput = {
  areaEntity?: InputMaybe<AreaEntityInput>
  countryEntity?: InputMaybe<CountryEntityInput>
  /** ISO-8601 */
  createdAt?: InputMaybe<Scalars['DateTime']['input']>
  currencyEntity?: InputMaybe<CurrencyEntityInput>
  description?: InputMaybe<Scalars['String']['input']>
  hiringEntity?: InputMaybe<HiringEntityInput>
  id?: InputMaybe<Scalars['String']['input']>
  languageEntity?: InputMaybe<Array<InputMaybe<LanguageEntityInput>>>
  levelOfExperienceEntity?: InputMaybe<LevelOfExperienceEntityInput>
  locationEntity?: InputMaybe<LocationEntityInput>
  maxAge: Scalars['Int']['input']
  minAge: Scalars['Int']['input']
  minStudyGradeEntity?: InputMaybe<StudyGradeEntityInput>
  modalityEntity?: InputMaybe<ModalityEntityInput>
  /** ISO-8601 */
  modifiedAt?: InputMaybe<Scalars['DateTime']['input']>
  position?: InputMaybe<Scalars['String']['input']>
  skillEntities?: InputMaybe<Array<InputMaybe<SkillEntityInput>>>
  subAreaEntity?: InputMaybe<SubAreaEntityInput>
  sueldoMaximo: Scalars['Int']['input']
  sueldoMinimo: Scalars['Int']['input']
  typoOfContractEntity?: InputMaybe<TypeOfContractEntityInput>
  workingHoursEntity?: InputMaybe<WorkingHoursEntityInput>
  yearsOfExp: Scalars['Int']['input']
}

export type OptionEntity = {
  __typename?: 'OptionEntity'
  id?: Maybe<Scalars['BigInteger']['output']>
  optionText?: Maybe<Scalars['String']['output']>
  question?: Maybe<QuestionEntity>
}

export type OptionEntityInput = {
  id?: InputMaybe<Scalars['BigInteger']['input']>
  optionText?: InputMaybe<Scalars['String']['input']>
  question?: InputMaybe<QuestionEntityInput>
}

export type OptionQuestionEntity = {
  __typename?: 'OptionQuestionEntity'
  id?: Maybe<Scalars['BigInteger']['output']>
  option_text?: Maybe<Scalars['String']['output']>
  question?: Maybe<QuestionTestEntity>
}

export type OptionQuestionEntityInput = {
  id?: InputMaybe<Scalars['BigInteger']['input']>
  option_text?: InputMaybe<Scalars['String']['input']>
  question?: InputMaybe<QuestionTestEntityInput>
}

export type OptionQuestionInput = {
  id?: InputMaybe<Scalars['BigInteger']['input']>
  option_text?: InputMaybe<Scalars['String']['input']>
}

export type Options = {
  __typename?: 'Options'
  optionText?: Maybe<Scalars['String']['output']>
}

export type OptionsInput = {
  optionText?: InputMaybe<Scalars['String']['input']>
}

export type PersonalInformation = {
  __typename?: 'PersonalInformation'
  country: Scalars['BigInteger']['output']
  firstNames?: Maybe<Scalars['String']['output']>
  id?: Maybe<Scalars['Int']['output']>
  lastNames?: Maybe<Scalars['String']['output']>
  location?: Maybe<Scalars['String']['output']>
  userProfile?: Maybe<UserProfile>
}

export type PersonalInformationEntity = {
  __typename?: 'PersonalInformationEntity'
  applicantProfile?: Maybe<ApplicantProfileEntity>
  country?: Maybe<CountryEntity>
  firstNames?: Maybe<Scalars['String']['output']>
  id?: Maybe<Scalars['Int']['output']>
  lastNames?: Maybe<Scalars['String']['output']>
  location?: Maybe<Scalars['String']['output']>
}

export type PersonalInformationEntityInput = {
  applicantProfile?: InputMaybe<ApplicantProfileEntityInput>
  country?: InputMaybe<CountryEntityInput>
  firstNames?: InputMaybe<Scalars['String']['input']>
  id?: InputMaybe<Scalars['Int']['input']>
  lastNames?: InputMaybe<Scalars['String']['input']>
  location?: InputMaybe<Scalars['String']['input']>
}

export type PersonalInformationInput = {
  country: Scalars['BigInteger']['input']
  firstNames?: InputMaybe<Scalars['String']['input']>
  id?: InputMaybe<Scalars['Int']['input']>
  lastNames?: InputMaybe<Scalars['String']['input']>
  location?: InputMaybe<Scalars['String']['input']>
  userProfile?: InputMaybe<UserProfileInput>
}

export type Portfolio = {
  __typename?: 'Portfolio'
  description?: Maybe<Scalars['String']['output']>
  id?: Maybe<Scalars['BigInteger']['output']>
  img_link?: Maybe<Scalars['String']['output']>
  project_link?: Maybe<Scalars['String']['output']>
  project_title?: Maybe<Scalars['String']['output']>
  repo_link?: Maybe<Scalars['String']['output']>
  userprofile?: Maybe<UserProfile>
  year?: Maybe<Scalars['String']['output']>
}

export type PortfolioEntity = {
  __typename?: 'PortfolioEntity'
  applicantProfile?: Maybe<ApplicantProfileEntity>
  description?: Maybe<Scalars['String']['output']>
  id?: Maybe<Scalars['BigInteger']['output']>
  img_link?: Maybe<Scalars['String']['output']>
  project_link?: Maybe<Scalars['String']['output']>
  project_title?: Maybe<Scalars['String']['output']>
  repo_link?: Maybe<Scalars['String']['output']>
  year?: Maybe<Scalars['String']['output']>
}

export type PortfolioEntityInput = {
  applicantProfile?: InputMaybe<ApplicantProfileEntityInput>
  description?: InputMaybe<Scalars['String']['input']>
  id?: InputMaybe<Scalars['BigInteger']['input']>
  img_link?: InputMaybe<Scalars['String']['input']>
  project_link?: InputMaybe<Scalars['String']['input']>
  project_title?: InputMaybe<Scalars['String']['input']>
  repo_link?: InputMaybe<Scalars['String']['input']>
  year?: InputMaybe<Scalars['String']['input']>
}

export type PortfolioInput = {
  description?: InputMaybe<Scalars['String']['input']>
  id?: InputMaybe<Scalars['BigInteger']['input']>
  img_link?: InputMaybe<Scalars['String']['input']>
  project_link?: InputMaybe<Scalars['String']['input']>
  project_title?: InputMaybe<Scalars['String']['input']>
  repo_link?: InputMaybe<Scalars['String']['input']>
  userprofile?: InputMaybe<UserProfileInput>
  year?: InputMaybe<Scalars['String']['input']>
}

export type ProfessionalNetworks = {
  __typename?: 'ProfessionalNetworks'
  github?: Maybe<Scalars['String']['output']>
  id?: Maybe<Scalars['Int']['output']>
  linkedin?: Maybe<Scalars['String']['output']>
  userProfile?: Maybe<UserProfile>
  whatsapp?: Maybe<Scalars['String']['output']>
}

export type ProfessionalNetworksEntity = {
  __typename?: 'ProfessionalNetworksEntity'
  github?: Maybe<Scalars['String']['output']>
  id?: Maybe<Scalars['Int']['output']>
  linkedin?: Maybe<Scalars['String']['output']>
  whatsapp?: Maybe<Scalars['String']['output']>
}

export type ProfessionalNetworksEntityInput = {
  github?: InputMaybe<Scalars['String']['input']>
  id?: InputMaybe<Scalars['Int']['input']>
  linkedin?: InputMaybe<Scalars['String']['input']>
  whatsapp?: InputMaybe<Scalars['String']['input']>
}

export type ProfessionalNetworksInput = {
  github?: InputMaybe<Scalars['String']['input']>
  id?: InputMaybe<Scalars['Int']['input']>
  linkedin?: InputMaybe<Scalars['String']['input']>
  userProfile?: InputMaybe<UserProfileInput>
  whatsapp?: InputMaybe<Scalars['String']['input']>
}

export type ProfessionalRole = {
  __typename?: 'ProfessionalRole'
  id?: Maybe<Scalars['Int']['output']>
  levelSeniority?: Maybe<Scalars['String']['output']>
  rol?: Maybe<Scalars['String']['output']>
  userProfile?: Maybe<UserProfile>
  years: Scalars['Int']['output']
}

export type ProfessionalRoleEntity = {
  __typename?: 'ProfessionalRoleEntity'
  applicantProfile?: Maybe<ApplicantProfileEntity>
  id?: Maybe<Scalars['Int']['output']>
  levelSeniority?: Maybe<Scalars['String']['output']>
  rol?: Maybe<Scalars['String']['output']>
  years: Scalars['Int']['output']
}

export type ProfessionalRoleEntityInput = {
  applicantProfile?: InputMaybe<ApplicantProfileEntityInput>
  id?: InputMaybe<Scalars['Int']['input']>
  levelSeniority?: InputMaybe<Scalars['String']['input']>
  rol?: InputMaybe<Scalars['String']['input']>
  years: Scalars['Int']['input']
}

export type ProfessionalRoleInput = {
  id?: InputMaybe<Scalars['Int']['input']>
  levelSeniority?: InputMaybe<Scalars['String']['input']>
  rol?: InputMaybe<Scalars['String']['input']>
  userProfile?: InputMaybe<UserProfileInput>
  years: Scalars['Int']['input']
}

export type ProfileType = {
  __typename?: 'ProfileType'
  description?: Maybe<Scalars['String']['output']>
  id?: Maybe<Scalars['Int']['output']>
  userprofile_id?: Maybe<Scalars['Int']['output']>
}

export type ProfileTypeEntity = {
  __typename?: 'ProfileTypeEntity'
  description?: Maybe<Scalars['String']['output']>
  id?: Maybe<Scalars['Int']['output']>
}

export type ProfileTypeEntityInput = {
  description?: InputMaybe<Scalars['String']['input']>
  id?: InputMaybe<Scalars['Int']['input']>
}

export type ProfileTypeInput = {
  description?: InputMaybe<Scalars['String']['input']>
  id?: InputMaybe<Scalars['Int']['input']>
  userprofile_id?: InputMaybe<Scalars['Int']['input']>
}

/** Query root */
export type Query = {
  __typename?: 'Query'
  GetALlQuestions?: Maybe<Array<Maybe<Question>>>
  GetActiveJobsDays?: Maybe<Scalars['String']['output']>
  GetAllApplicants?: Maybe<ApplicationPages>
  GetAllBenefits?: Maybe<Array<Maybe<BenefitsEntity>>>
  GetAllCertifications?: Maybe<Array<Maybe<CertificationEntity>>>
  GetAllCompanies?: Maybe<Array<Maybe<CompanyEntity>>>
  GetAllCountries?: Maybe<Array<Maybe<Country>>>
  GetAllEducations?: Maybe<Array<Maybe<EducationEntity>>>
  GetAllEvaluations?: Maybe<Array<Maybe<EvaluationEntity>>>
  GetAllFaqCandidate?: Maybe<Array<Maybe<FaqEntity>>>
  GetAllFaqCompany?: Maybe<Array<Maybe<FaqEntity>>>
  GetAllInterviews?: Maybe<Array<Maybe<Interview>>>
  GetAllJobApplicationByUserFilter?: Maybe<ApplicationPages>
  GetAllJobs?: Maybe<JobPages>
  GetAllJobsFilter?: Maybe<JobPages>
  GetAllLevelExperience?: Maybe<Array<Maybe<LevelOfExperienceEntity>>>
  GetAllLevelLanguage?: Maybe<Array<Maybe<LevelLanguage>>>
  GetAllOffers?: Maybe<Array<Maybe<OfferEntity>>>
  GetAllPortfolio?: Maybe<Array<Maybe<PortfolioEntity>>>
  GetAllProfileTypes?: Maybe<Array<Maybe<ProfileTypeEntity>>>
  GetAllReschedules?: Maybe<Array<Maybe<Reschedules>>>
  GetAllSoftSkills?: Maybe<Array<Maybe<SkillEntity>>>
  GetAllSoftSkillsByUserProfile?: Maybe<Array<Maybe<SkillEntity>>>
  GetAllTechnologyStack?: Maybe<Array<Maybe<TechnologyStackEntity>>>
  GetAllUsers?: Maybe<Array<Maybe<UserEntity>>>
  GetAllUsersProfile?: Maybe<Array<Maybe<ApplicantProfileEntity>>>
  GetAllWorkExperience?: Maybe<Array<Maybe<WorkExperienceEntity>>>
  GetAllWorkType?: Maybe<Array<Maybe<ModalityEntity>>>
  GetAllYearsOfExperience?: Maybe<Array<Maybe<YearsOfExperienceEntity>>>
  GetApplicantById?: Maybe<JobApplicationEntity>
  GetApplicantData?: Maybe<ApplicantProfileEntity>
  GetApplicantDays?: Maybe<Scalars['String']['output']>
  GetContactInformationByUserProfile?: Maybe<ContactInformation>
  GetEvaluationsByUser?: Maybe<Array<Maybe<EvaluationEntity>>>
  GetInterviewsWeeks?: Maybe<Scalars['String']['output']>
  GetJobById?: Maybe<JobEntity>
  GetJobForDescription?: Maybe<JobPages>
  GetJobPublishedByRecruitIdAndJobId?: Maybe<Job>
  GetJobsCandidatesPublishedByRecruiterIdAndJobId?: Maybe<
    Array<Maybe<JobApplicationEntity>>
  >
  GetJobsFavoritesByUserFilter?: Maybe<FavoritePages>
  GetLanguageById?: Maybe<LanguageEntity>
  GetLanguageByUserProfile?: Maybe<Array<Maybe<LevelLanguage>>>
  GetNumberInterviewsMonth?: Maybe<Scalars['BigInteger']['output']>
  GetNumberPostulations?: Maybe<Scalars['BigInteger']['output']>
  GetPersonalInformationByUserProfile?: Maybe<PersonalInformation>
  GetPositionToBeFilled?: Maybe<Scalars['String']['output']>
  GetProfessionalNetworkByUserProfile?: Maybe<ProfessionalNetworks>
  GetSalaryPreferenceByUserProfile?: Maybe<SalaryPreference>
  GetStatusProfile?: Maybe<Scalars['String']['output']>
  GetUserById?: Maybe<UserEntity>
  allJob?: Maybe<Array<Maybe<Job>>>
  createCategory?: Maybe<Scalars['String']['output']>
  deleteCategory?: Maybe<Scalars['String']['output']>
  getAllCategories?: Maybe<Array<Maybe<CategoryEntity>>>
  getAllCity?: Maybe<Array<Maybe<CityEntity>>>
  getAllCityPaginated?: Maybe<Array<Maybe<CityEntity>>>
  getAllLanguages?: Maybe<Array<Maybe<LanguageEntity>>>
  getAllLocations?: Maybe<Array<Maybe<LocationEntity>>>
  getAllRangeTime?: Maybe<Array<Maybe<RangeTime>>>
  getCategory?: Maybe<Category>
  getCityById?: Maybe<City>
  updateCategory?: Maybe<Scalars['String']['output']>
}

/** Query root */
export type QueryGetAllApplicantsArgs = {
  categorieId?: InputMaybe<Array<InputMaybe<Scalars['BigInteger']['input']>>>
  countryId: Scalars['Int']['input']
  currentPage: Scalars['Int']['input']
  elementPerPage: Scalars['Int']['input']
  estado_id?: InputMaybe<Scalars['BigInteger']['input']>
  latest: Scalars['Boolean']['input']
  levelExpId: Scalars['Int']['input']
  masAntiguo: Scalars['Boolean']['input']
  masNuevo: Scalars['Boolean']['input']
  masRelevante: Scalars['Boolean']['input']
  modalityId: Scalars['Int']['input']
}

/** Query root */
export type QueryGetAllJobApplicationByUserFilterArgs = {
  categorie_ids?: InputMaybe<Array<InputMaybe<Scalars['BigInteger']['input']>>>
  currentPage: Scalars['Int']['input']
  elementPerPage: Scalars['Int']['input']
  estado_id?: InputMaybe<Scalars['BigInteger']['input']>
  latest: Scalars['Boolean']['input']
  modality_id: Scalars['Int']['input']
  user_id?: InputMaybe<Scalars['String']['input']>
}

/** Query root */
export type QueryGetAllJobsArgs = {
  currentPage: Scalars['Int']['input']
  elementPage: Scalars['Int']['input']
}

/** Query root */
export type QueryGetAllJobsFilterArgs = {
  countryId?: InputMaybe<Scalars['BigInteger']['input']>
  levelOfExperienceId?: InputMaybe<Scalars['BigInteger']['input']>
  maxSalary?: InputMaybe<Scalars['BigDecimal']['input']>
  minSalary?: InputMaybe<Scalars['BigDecimal']['input']>
  page: Scalars['Int']['input']
  profileTypeId?: InputMaybe<Scalars['BigInteger']['input']>
  size: Scalars['Int']['input']
  technologyStack?: InputMaybe<Array<InputMaybe<Scalars['String']['input']>>>
  workmode?: InputMaybe<WorkMode>
}

/** Query root */
export type QueryGetAllSoftSkillsByUserProfileArgs = {
  id_userProfile: Scalars['Int']['input']
}

/** Query root */
export type QueryGetApplicantByIdArgs = {
  user_Id?: InputMaybe<Scalars['String']['input']>
}

/** Query root */
export type QueryGetApplicantDataArgs = {
  user_id?: InputMaybe<Scalars['String']['input']>
}

/** Query root */
export type QueryGetContactInformationByUserProfileArgs = {
  profile_id: Scalars['Int']['input']
}

/** Query root */
export type QueryGetEvaluationsByUserArgs = {
  user_id?: InputMaybe<Scalars['String']['input']>
}

/** Query root */
export type QueryGetJobByIdArgs = {
  id?: InputMaybe<Scalars['BigInteger']['input']>
}

/** Query root */
export type QueryGetJobForDescriptionArgs = {
  currentPage: Scalars['Int']['input']
  description?: InputMaybe<Scalars['String']['input']>
  elementPerpage: Scalars['Int']['input']
}

/** Query root */
export type QueryGetJobPublishedByRecruitIdAndJobIdArgs = {
  jobId?: InputMaybe<Scalars['BigInteger']['input']>
  recruitId?: InputMaybe<Scalars['String']['input']>
}

/** Query root */
export type QueryGetJobsCandidatesPublishedByRecruiterIdAndJobIdArgs = {
  jobId?: InputMaybe<Scalars['BigInteger']['input']>
  recruitId?: InputMaybe<Scalars['String']['input']>
}

/** Query root */
export type QueryGetJobsFavoritesByUserFilterArgs = {
  benefits_ids?: InputMaybe<Array<InputMaybe<Scalars['BigInteger']['input']>>>
  categorie_id?: InputMaybe<Scalars['BigInteger']['input']>
  country_id?: InputMaybe<Scalars['BigInteger']['input']>
  currentPage: Scalars['Int']['input']
  elementPerPage: Scalars['Int']['input']
  level_exp_id: Scalars['Int']['input']
  mas_antiguo: Scalars['Boolean']['input']
  mas_nuevo: Scalars['Boolean']['input']
  mas_relevante: Scalars['Boolean']['input']
  modality_id: Scalars['Int']['input']
  range_salary?: InputMaybe<Array<InputMaybe<Scalars['Int']['input']>>>
  user_id?: InputMaybe<Scalars['String']['input']>
}

/** Query root */
export type QueryGetLanguageByIdArgs = {
  id: Scalars['Int']['input']
}

/** Query root */
export type QueryGetLanguageByUserProfileArgs = {
  profile_id: Scalars['Int']['input']
}

/** Query root */
export type QueryGetNumberInterviewsMonthArgs = {
  month: Scalars['Int']['input']
  user_Id: Scalars['String']['input']
  year: Scalars['Int']['input']
}

/** Query root */
export type QueryGetNumberPostulationsArgs = {
  month: Scalars['Int']['input']
  user_id: Scalars['String']['input']
  year: Scalars['Int']['input']
}

/** Query root */
export type QueryGetPersonalInformationByUserProfileArgs = {
  profile_id: Scalars['Int']['input']
}

/** Query root */
export type QueryGetProfessionalNetworkByUserProfileArgs = {
  profile_id: Scalars['Int']['input']
}

/** Query root */
export type QueryGetSalaryPreferenceByUserProfileArgs = {
  profile_id: Scalars['Int']['input']
}

/** Query root */
export type QueryGetStatusProfileArgs = {
  user_id?: InputMaybe<Scalars['String']['input']>
}

/** Query root */
export type QueryGetUserByIdArgs = {
  user_id?: InputMaybe<Scalars['String']['input']>
}

/** Query root */
export type QueryCreateCategoryArgs = {
  category?: InputMaybe<CategoryInput>
}

/** Query root */
export type QueryDeleteCategoryArgs = {
  id?: InputMaybe<Scalars['String']['input']>
}

/** Query root */
export type QueryGetAllCityPaginatedArgs = {
  page: Scalars['Int']['input']
  size: Scalars['Int']['input']
}

/** Query root */
export type QueryGetCategoryArgs = {
  id?: InputMaybe<Scalars['String']['input']>
}

/** Query root */
export type QueryGetCityByIdArgs = {
  id?: InputMaybe<Scalars['BigInteger']['input']>
}

/** Query root */
export type QueryUpdateCategoryArgs = {
  id?: InputMaybe<Scalars['String']['input']>
  newCategory?: InputMaybe<Scalars['String']['input']>
}

export type Question = {
  __typename?: 'Question'
  correctOptionId: Scalars['Int']['output']
  firstQuestion: Scalars['Boolean']['output']
  lastQuestion: Scalars['Boolean']['output']
  nextQuestionId: Scalars['Int']['output']
  options: Array<Maybe<Options>>
  questionText: Scalars['String']['output']
}

export type QuestionEntity = {
  __typename?: 'QuestionEntity'
  id?: Maybe<Scalars['BigInteger']['output']>
  job?: Maybe<JobEntity>
  options?: Maybe<Array<Maybe<OptionEntity>>>
  questionText?: Maybe<Scalars['String']['output']>
  type?: Maybe<QuestionType>
}

export type QuestionEntityInput = {
  id?: InputMaybe<Scalars['BigInteger']['input']>
  job?: InputMaybe<JobEntityInput>
  options?: InputMaybe<Array<InputMaybe<OptionEntityInput>>>
  questionText?: InputMaybe<Scalars['String']['input']>
  type?: InputMaybe<QuestionType>
}

export type QuestionInput = {
  correctOptionId: Scalars['Int']['input']
  firstQuestion: Scalars['Boolean']['input']
  lastQuestion: Scalars['Boolean']['input']
  nextQuestionId: Scalars['Int']['input']
  options: Array<InputMaybe<OptionsInput>>
  questionText: Scalars['String']['input']
}

export type QuestionTestEntity = {
  __typename?: 'QuestionTestEntity'
  correct_optionId: Scalars['Int']['output']
  id?: Maybe<Scalars['BigInteger']['output']>
  options?: Maybe<Array<Maybe<OptionQuestionEntity>>>
  question_text?: Maybe<Scalars['String']['output']>
  question_type?: Maybe<Scalars['String']['output']>
  test?: Maybe<TestEntity>
}

export type QuestionTestEntityInput = {
  correct_optionId: Scalars['Int']['input']
  id?: InputMaybe<Scalars['BigInteger']['input']>
  options?: InputMaybe<Array<InputMaybe<OptionQuestionEntityInput>>>
  question_text?: InputMaybe<Scalars['String']['input']>
  question_type?: InputMaybe<Scalars['String']['input']>
  test?: InputMaybe<TestEntityInput>
}

export type QuestionTestInput = {
  correct_optionId: Scalars['Int']['input']
  id?: InputMaybe<Scalars['BigInteger']['input']>
  options?: InputMaybe<Array<InputMaybe<OptionQuestionInput>>>
  question_text?: InputMaybe<Scalars['String']['input']>
  question_type?: InputMaybe<Scalars['String']['input']>
}

export enum QuestionType {
  MultipleChoice = 'MULTIPLE_CHOICE',
  ShortAnswer = 'SHORT_ANSWER',
}

export type RangeTime = {
  __typename?: 'RangeTime'
  /** ISO-8601 */
  created_at?: Maybe<Scalars['DateTime']['output']>
  id?: Maybe<Scalars['BigInteger']['output']>
  name?: Maybe<Scalars['String']['output']>
  /** ISO-8601 */
  updated_at?: Maybe<Scalars['DateTime']['output']>
}

export type Reschedules = {
  __typename?: 'Reschedules'
  /** ISO-8601 */
  date: Scalars['Date']['output']
  /** ISO-8601 */
  hours?: Maybe<Array<Maybe<Scalars['DateTime']['output']>>>
  id?: Maybe<Scalars['BigInteger']['output']>
  interview_id: Scalars['BigInteger']['output']
}

export type ReschedulesEntity = {
  __typename?: 'ReschedulesEntity'
  /** ISO-8601 */
  date?: Maybe<Scalars['Date']['output']>
  /** ISO-8601 */
  hours?: Maybe<Array<Maybe<Scalars['DateTime']['output']>>>
  id?: Maybe<Scalars['BigInteger']['output']>
  interview?: Maybe<InterviewEntity>
}

export type ReschedulesEntityInput = {
  /** ISO-8601 */
  date?: InputMaybe<Scalars['Date']['input']>
  /** ISO-8601 */
  hours?: InputMaybe<Array<InputMaybe<Scalars['DateTime']['input']>>>
  id?: InputMaybe<Scalars['BigInteger']['input']>
  interview?: InputMaybe<InterviewEntityInput>
}

export type ReschedulesInput = {
  /** ISO-8601 */
  date: Scalars['Date']['input']
  /** ISO-8601 */
  hours?: InputMaybe<Array<InputMaybe<Scalars['DateTime']['input']>>>
  id?: InputMaybe<Scalars['BigInteger']['input']>
  interview_id: Scalars['BigInteger']['input']
}

export type SalaryPreference = {
  __typename?: 'SalaryPreference'
  end: Scalars['Int']['output']
  id?: Maybe<Scalars['Int']['output']>
  initial: Scalars['Int']['output']
  userProfile?: Maybe<UserProfile>
}

export type SalaryPreferenceEntity = {
  __typename?: 'SalaryPreferenceEntity'
  end_range: Scalars['Int']['output']
  id?: Maybe<Scalars['Int']['output']>
  initial: Scalars['Int']['output']
}

export type SalaryPreferenceEntityInput = {
  end_range: Scalars['Int']['input']
  id?: InputMaybe<Scalars['Int']['input']>
  initial: Scalars['Int']['input']
}

export type SalaryPreferenceInput = {
  end: Scalars['Int']['input']
  id?: InputMaybe<Scalars['Int']['input']>
  initial: Scalars['Int']['input']
  userProfile?: InputMaybe<UserProfileInput>
}

export type SkillEntity = {
  __typename?: 'SkillEntity'
  applicantProfiles?: Maybe<Array<Maybe<ApplicantProfileEntity>>>
  description: Scalars['String']['output']
  id?: Maybe<Scalars['Int']['output']>
  offerEntities?: Maybe<Array<Maybe<OfferEntity>>>
}

export type SkillEntityInput = {
  applicantProfiles?: InputMaybe<Array<InputMaybe<ApplicantProfileEntityInput>>>
  description: Scalars['String']['input']
  id?: InputMaybe<Scalars['Int']['input']>
  offerEntities?: InputMaybe<Array<InputMaybe<OfferEntityInput>>>
}

export type StateEntity = {
  __typename?: 'StateEntity'
  /** ISO-8601 */
  created_at?: Maybe<Scalars['DateTime']['output']>
  id?: Maybe<Scalars['BigInteger']['output']>
  state?: Maybe<Scalars['String']['output']>
}

export type StateEntityInput = {
  /** ISO-8601 */
  created_at?: InputMaybe<Scalars['DateTime']['input']>
  id?: InputMaybe<Scalars['BigInteger']['input']>
  state?: InputMaybe<Scalars['String']['input']>
}

export type StudyGradeEntity = {
  __typename?: 'StudyGradeEntity'
  description?: Maybe<Scalars['String']['output']>
  id: Scalars['Int']['output']
  offerEntitySet?: Maybe<Array<Maybe<OfferEntity>>>
}

export type StudyGradeEntityInput = {
  description?: InputMaybe<Scalars['String']['input']>
  id: Scalars['Int']['input']
  offerEntitySet?: InputMaybe<Array<InputMaybe<OfferEntityInput>>>
}

export type SubAreaEntity = {
  __typename?: 'SubAreaEntity'
  areaEntity?: Maybe<AreaEntity>
  description?: Maybe<Scalars['String']['output']>
  id: Scalars['Int']['output']
  offerEntitySet?: Maybe<Array<Maybe<OfferEntity>>>
}

export type SubAreaEntityInput = {
  areaEntity?: InputMaybe<AreaEntityInput>
  description?: InputMaybe<Scalars['String']['input']>
  id: Scalars['Int']['input']
  offerEntitySet?: InputMaybe<Array<InputMaybe<OfferEntityInput>>>
}

export type Summary = {
  __typename?: 'Summary'
  id?: Maybe<Scalars['BigInteger']['output']>
  professional_summary?: Maybe<Scalars['String']['output']>
  profileType?: Maybe<ProfileType>
  yearsOfExperience?: Maybe<YearsOfExperience>
}

export type SummaryEntity = {
  __typename?: 'SummaryEntity'
  id?: Maybe<Scalars['BigInteger']['output']>
  professional_summary?: Maybe<Scalars['String']['output']>
  profileType?: Maybe<ProfileTypeEntity>
  yearsOfExperience?: Maybe<YearsOfExperienceEntity>
}

export type SummaryEntityInput = {
  id?: InputMaybe<Scalars['BigInteger']['input']>
  professional_summary?: InputMaybe<Scalars['String']['input']>
  profileType?: InputMaybe<ProfileTypeEntityInput>
  yearsOfExperience?: InputMaybe<YearsOfExperienceEntityInput>
}

export type SummaryInput = {
  id?: InputMaybe<Scalars['BigInteger']['input']>
  professional_summary?: InputMaybe<Scalars['String']['input']>
  profileType?: InputMaybe<ProfileTypeInput>
  yearsOfExperience?: InputMaybe<YearsOfExperienceInput>
}

export type TechnologyStackEntity = {
  __typename?: 'TechnologyStackEntity'
  /** ISO-8601 */
  createdAt?: Maybe<Scalars['DateTime']['output']>
  id?: Maybe<Scalars['Int']['output']>
  name?: Maybe<Scalars['String']['output']>
  /** ISO-8601 */
  updateAt?: Maybe<Scalars['DateTime']['output']>
}

export type TechnologyStackEntityInput = {
  /** ISO-8601 */
  createdAt?: InputMaybe<Scalars['DateTime']['input']>
  id?: InputMaybe<Scalars['Int']['input']>
  name?: InputMaybe<Scalars['String']['input']>
  /** ISO-8601 */
  updateAt?: InputMaybe<Scalars['DateTime']['input']>
}

export type TestEntity = {
  __typename?: 'TestEntity'
  evaluation?: Maybe<EvaluationEntity>
  id?: Maybe<Scalars['BigInteger']['output']>
  instruction?: Maybe<Scalars['String']['output']>
  questions?: Maybe<Array<Maybe<QuestionTestEntity>>>
  total_question: Scalars['Int']['output']
}

export type TestEntityInput = {
  evaluation?: InputMaybe<EvaluationEntityInput>
  id?: InputMaybe<Scalars['BigInteger']['input']>
  instruction?: InputMaybe<Scalars['String']['input']>
  questions?: InputMaybe<Array<InputMaybe<QuestionTestEntityInput>>>
  total_question: Scalars['Int']['input']
}

export type TestInput = {
  id?: InputMaybe<Scalars['BigInteger']['input']>
  instruction?: InputMaybe<Scalars['String']['input']>
  questions?: InputMaybe<Array<InputMaybe<QuestionTestInput>>>
  total_question: Scalars['Int']['input']
}

export type TypeOfContractEntity = {
  __typename?: 'TypeOfContractEntity'
  description?: Maybe<Scalars['String']['output']>
  id: Scalars['Int']['output']
  offerEntitySet?: Maybe<Array<Maybe<OfferEntity>>>
}

export type TypeOfContractEntityInput = {
  description?: InputMaybe<Scalars['String']['input']>
  id: Scalars['Int']['input']
  offerEntitySet?: InputMaybe<Array<InputMaybe<OfferEntityInput>>>
}

export type User = {
  __typename?: 'User'
  city_id?: Maybe<Scalars['BigInteger']['output']>
  country_id?: Maybe<Scalars['BigInteger']['output']>
  /** ISO-8601 */
  created_at?: Maybe<Scalars['Date']['output']>
  email?: Maybe<Scalars['String']['output']>
  favoriteList?: Maybe<Array<Maybe<Favorite>>>
  jobApplicationsList?: Maybe<Array<Maybe<JobApplication>>>
  name?: Maybe<Scalars['String']['output']>
  password?: Maybe<Scalars['String']['output']>
  /** ISO-8601 */
  updated_at?: Maybe<Scalars['Date']['output']>
  userProfile?: Maybe<UserProfile>
  user_id?: Maybe<Scalars['String']['output']>
}

export type UserEntity = {
  __typename?: 'UserEntity'
  applicant?: Maybe<ApplicantProfileEntity>
  /** ISO-8601 */
  created_at?: Maybe<Scalars['Date']['output']>
  email?: Maybe<Scalars['String']['output']>
  employer?: Maybe<EmployerEntity>
  evaluations?: Maybe<Array<Maybe<EvaluationEntity>>>
  favorites?: Maybe<Array<Maybe<FavoriteEntity>>>
  jobApplications?: Maybe<Array<Maybe<JobApplicationEntity>>>
  name?: Maybe<Scalars['String']['output']>
  profile?: Maybe<ApplicantProfileEntity>
  /** ISO-8601 */
  updated_at?: Maybe<Scalars['Date']['output']>
  userType?: Maybe<UserType>
  user_id?: Maybe<Scalars['String']['output']>
}

export type UserEntityInput = {
  applicant?: InputMaybe<ApplicantProfileEntityInput>
  /** ISO-8601 */
  created_at?: InputMaybe<Scalars['Date']['input']>
  email?: InputMaybe<Scalars['String']['input']>
  employer?: InputMaybe<EmployerEntityInput>
  evaluations?: InputMaybe<Array<InputMaybe<EvaluationEntityInput>>>
  favorites?: InputMaybe<Array<InputMaybe<FavoriteEntityInput>>>
  jobApplications?: InputMaybe<Array<InputMaybe<JobApplicationEntityInput>>>
  name?: InputMaybe<Scalars['String']['input']>
  profile?: InputMaybe<ApplicantProfileEntityInput>
  /** ISO-8601 */
  updated_at?: InputMaybe<Scalars['Date']['input']>
  userType?: InputMaybe<UserType>
  user_id?: InputMaybe<Scalars['String']['input']>
}

export type UserInput = {
  city_id?: InputMaybe<Scalars['BigInteger']['input']>
  country_id?: InputMaybe<Scalars['BigInteger']['input']>
  /** ISO-8601 */
  created_at?: InputMaybe<Scalars['Date']['input']>
  email?: InputMaybe<Scalars['String']['input']>
  favoriteList?: InputMaybe<Array<InputMaybe<FavoriteInput>>>
  jobApplicationsList?: InputMaybe<Array<InputMaybe<JobApplicationInput>>>
  name?: InputMaybe<Scalars['String']['input']>
  password?: InputMaybe<Scalars['String']['input']>
  /** ISO-8601 */
  updated_at?: InputMaybe<Scalars['Date']['input']>
  userProfile?: InputMaybe<UserProfileInput>
  user_id?: InputMaybe<Scalars['String']['input']>
}

export type UserProfile = {
  __typename?: 'UserProfile'
  certification?: Maybe<Certification>
  contactInformation?: Maybe<ContactInformation>
  education?: Maybe<Education>
  id?: Maybe<Scalars['Int']['output']>
  image_url?: Maybe<Scalars['String']['output']>
  levelLanguage?: Maybe<LevelLanguage>
  modality_ids?: Maybe<Array<Maybe<Scalars['Int']['output']>>>
  personalInformation?: Maybe<PersonalInformation>
  portfolio?: Maybe<Portfolio>
  professionalNetworks?: Maybe<ProfessionalNetworks>
  professionalRole?: Maybe<ProfessionalRole>
  professionalSummary?: Maybe<Summary>
  salaryPreference?: Maybe<SalaryPreference>
  softSkill_ids?: Maybe<Array<Maybe<Scalars['Int']['output']>>>
  technology_ids?: Maybe<Array<Maybe<Scalars['Int']['output']>>>
  user?: Maybe<User>
  workExperience?: Maybe<WorkExperience>
}

export type UserProfileInput = {
  certification?: InputMaybe<CertificationInput>
  contactInformation?: InputMaybe<ContactInformationInput>
  education?: InputMaybe<EducationInput>
  id?: InputMaybe<Scalars['Int']['input']>
  image_url?: InputMaybe<Scalars['String']['input']>
  levelLanguage?: InputMaybe<LevelLanguageInput>
  modality_ids?: InputMaybe<Array<InputMaybe<Scalars['Int']['input']>>>
  personalInformation?: InputMaybe<PersonalInformationInput>
  portfolio?: InputMaybe<PortfolioInput>
  professionalNetworks?: InputMaybe<ProfessionalNetworksInput>
  professionalRole?: InputMaybe<ProfessionalRoleInput>
  professionalSummary?: InputMaybe<SummaryInput>
  salaryPreference?: InputMaybe<SalaryPreferenceInput>
  softSkill_ids?: InputMaybe<Array<InputMaybe<Scalars['Int']['input']>>>
  technology_ids?: InputMaybe<Array<InputMaybe<Scalars['Int']['input']>>>
  user?: InputMaybe<UserInput>
  workExperience?: InputMaybe<WorkExperienceInput>
}

export enum UserType {
  Applicant = 'APPLICANT',
  Employer = 'EMPLOYER',
}

export type WorkExperience = {
  __typename?: 'WorkExperience'
  company?: Maybe<Scalars['String']['output']>
  country_id?: Maybe<Scalars['BigInteger']['output']>
  description?: Maybe<Scalars['String']['output']>
  /** ISO-8601 */
  end_date?: Maybe<Scalars['Date']['output']>
  id?: Maybe<Scalars['Int']['output']>
  /** ISO-8601 */
  initiate_date?: Maybe<Scalars['Date']['output']>
  position?: Maybe<Scalars['String']['output']>
}

export type WorkExperienceEntity = {
  __typename?: 'WorkExperienceEntity'
  applicantProfile?: Maybe<ApplicantProfileEntity>
  company: Scalars['String']['output']
  country?: Maybe<CountryEntity>
  description?: Maybe<Scalars['String']['output']>
  /** ISO-8601 */
  end_date?: Maybe<Scalars['Date']['output']>
  id?: Maybe<Scalars['Int']['output']>
  /** ISO-8601 */
  initiate_date?: Maybe<Scalars['Date']['output']>
  position: Scalars['String']['output']
}

export type WorkExperienceEntityInput = {
  applicantProfile?: InputMaybe<ApplicantProfileEntityInput>
  company: Scalars['String']['input']
  country?: InputMaybe<CountryEntityInput>
  description?: InputMaybe<Scalars['String']['input']>
  /** ISO-8601 */
  end_date?: InputMaybe<Scalars['Date']['input']>
  id?: InputMaybe<Scalars['Int']['input']>
  /** ISO-8601 */
  initiate_date?: InputMaybe<Scalars['Date']['input']>
  position: Scalars['String']['input']
}

export type WorkExperienceInput = {
  company?: InputMaybe<Scalars['String']['input']>
  country_id?: InputMaybe<Scalars['BigInteger']['input']>
  description?: InputMaybe<Scalars['String']['input']>
  /** ISO-8601 */
  end_date?: InputMaybe<Scalars['Date']['input']>
  id?: InputMaybe<Scalars['Int']['input']>
  /** ISO-8601 */
  initiate_date?: InputMaybe<Scalars['Date']['input']>
  position?: InputMaybe<Scalars['String']['input']>
}

export enum WorkMode {
  Hibrido = 'HIBRIDO',
  Presencial = 'PRESENCIAL',
  Remoto = 'REMOTO',
}

export type WorkingHoursEntity = {
  __typename?: 'WorkingHoursEntity'
  description?: Maybe<Scalars['String']['output']>
  id: Scalars['Int']['output']
  offerEntitySet?: Maybe<Array<Maybe<OfferEntity>>>
}

export type WorkingHoursEntityInput = {
  description?: InputMaybe<Scalars['String']['input']>
  id: Scalars['Int']['input']
  offerEntitySet?: InputMaybe<Array<InputMaybe<OfferEntityInput>>>
}

export type YearsOfExperience = {
  __typename?: 'YearsOfExperience'
  /** ISO-8601 */
  created_at?: Maybe<Scalars['Date']['output']>
  id?: Maybe<Scalars['Int']['output']>
  /** ISO-8601 */
  updated_at?: Maybe<Scalars['Date']['output']>
  years?: Maybe<Scalars['String']['output']>
}

export type YearsOfExperienceEntity = {
  __typename?: 'YearsOfExperienceEntity'
  /** ISO-8601 */
  created_at?: Maybe<Scalars['Date']['output']>
  id?: Maybe<Scalars['Int']['output']>
  /** ISO-8601 */
  updated_at?: Maybe<Scalars['Date']['output']>
  years?: Maybe<Scalars['String']['output']>
}

export type YearsOfExperienceEntityInput = {
  /** ISO-8601 */
  created_at?: InputMaybe<Scalars['Date']['input']>
  id?: InputMaybe<Scalars['Int']['input']>
  /** ISO-8601 */
  updated_at?: InputMaybe<Scalars['Date']['input']>
  years?: InputMaybe<Scalars['String']['input']>
}

export type YearsOfExperienceInput = {
  /** ISO-8601 */
  created_at?: InputMaybe<Scalars['Date']['input']>
  id?: InputMaybe<Scalars['Int']['input']>
  /** ISO-8601 */
  updated_at?: InputMaybe<Scalars['Date']['input']>
  years?: InputMaybe<Scalars['String']['input']>
}

export type GetAllJobsFilterQueryVariables = Exact<{
  page: Scalars['Int']['input']
  size: Scalars['Int']['input']
  minSalary?: InputMaybe<Scalars['BigDecimal']['input']>
  maxSalary?: InputMaybe<Scalars['BigDecimal']['input']>
  workmode?: InputMaybe<WorkMode>
  levelOfExperienceId?: InputMaybe<Scalars['BigInteger']['input']>
  profileTypeId?: InputMaybe<Scalars['BigInteger']['input']>
  countryId?: InputMaybe<Scalars['BigInteger']['input']>
  technologyStack?: InputMaybe<
    | Array<InputMaybe<Scalars['String']['input']>>
    | InputMaybe<Scalars['String']['input']>
  >
}>

export type GetAllJobsFilterQuery = {
  __typename?: 'Query'
  GetAllJobsFilter?: {
    __typename?: 'JobPages'
    currentPage: number
    elementPerPage: number
    totalItems: number
    totalPage: number
    jobs?: Array<{
      __typename?: 'JobEntity'
      createdAt?: any | null
      description?: string | null
      description_functions?: string | null
      description_functions_additional_requirements?: string | null
      endTime?: any | null
      id?: any | null
      maxSalary?: any | null
      minSalary?: any | null
      name?: string | null
      openPositions: number
      salary: number
      startTime?: any | null
      updateAt?: any | null
      verified_profiles?: boolean | null
      visibility_name_company?: boolean | null
      workMode?: WorkMode | null
      active: boolean
      technologyStacks?: Array<{
        __typename?: 'TechnologyStackEntity'
        id?: number | null
        name?: string | null
      } | null> | null
      levelOfExperience?: {
        __typename?: 'LevelOfExperienceEntity'
        id?: number | null
        name?: string | null
      } | null
      company?: {
        __typename?: 'CompanyEntity'
        description?: string | null
        imageUrl?: string | null
        name?: string | null
      } | null
      country?: {
        __typename?: 'CountryEntity'
        description?: string | null
        img_url?: string | null
        name?: string | null
      } | null
    } | null> | null
  } | null
}

export type GetJobByIdQueryVariables = Exact<{
  id?: InputMaybe<Scalars['BigInteger']['input']>
}>

export type GetJobByIdQuery = {
  __typename?: 'Query'
  GetJobById?: {
    __typename?: 'JobEntity'
    createdAt?: any | null
    description?: string | null
    description_functions?: string | null
    description_functions_additional_requirements?: string | null
    endTime?: any | null
    id?: any | null
    maxSalary?: any | null
    minSalary?: any | null
    name?: string | null
    openPositions: number
    salary: number
    startTime?: any | null
    updateAt?: any | null
    verified_profiles?: boolean | null
    visibility_name_company?: boolean | null
    workMode?: WorkMode | null
    active: boolean
    levelOfExperience?: {
      __typename?: 'LevelOfExperienceEntity'
      id?: number | null
      name?: string | null
    } | null
    company?: {
      __typename?: 'CompanyEntity'
      description?: string | null
      id?: any | null
      imageUrl?: string | null
      name?: string | null
      updateAt?: any | null
    } | null
    technologyStacks?: Array<{
      __typename?: 'TechnologyStackEntity'
      id?: number | null
      name?: string | null
    } | null> | null
  } | null
}

export type CreateJobMutationVariables = Exact<{
  job?: InputMaybe<JobInput>
}>

export type CreateJobMutation = {
  __typename?: 'Mutation'
  CreateJob?: boolean | null
}

export type GetAllBenefitsQueryVariables = Exact<{ [key: string]: never }>

export type GetAllBenefitsQuery = {
  __typename?: 'Query'
  GetAllBenefits?: Array<{
    __typename?: 'BenefitsEntity'
    created_at?: any | null
    description?: string | null
    id?: any | null
    name?: string | null
    prefix?: string | null
    updated_at?: any | null
  } | null> | null
}

export type GetAllCategoriesQueryVariables = Exact<{ [key: string]: never }>

export type GetAllCategoriesQuery = {
  __typename?: 'Query'
  getAllCategories?: Array<{
    __typename?: 'CategoryEntity'
    id?: any | null
    name?: string | null
  } | null> | null
}

export type GetAllCountriesQueryVariables = Exact<{ [key: string]: never }>

export type GetAllCountriesQuery = {
  __typename?: 'Query'
  GetAllCountries?: Array<{
    __typename?: 'Country'
    createdAt?: any | null
    description?: string | null
    id?: any | null
    name?: string | null
    updatedAt?: any | null
  } | null> | null
}

export type GetAllLanguagesQueryVariables = Exact<{ [key: string]: never }>

export type GetAllLanguagesQuery = {
  __typename?: 'Query'
  getAllLanguages?: Array<{
    __typename?: 'LanguageEntity'
    description?: string | null
    id?: number | null
  } | null> | null
}

export type GetAllWorkTypeQueryVariables = Exact<{ [key: string]: never }>

export type GetAllWorkTypeQuery = {
  __typename?: 'Query'
  GetAllWorkType?: Array<{
    __typename?: 'ModalityEntity'
    id?: number | null
    name?: string | null
  } | null> | null
}

export type GetAllProfileTypesQueryVariables = Exact<{ [key: string]: never }>

export type GetAllProfileTypesQuery = {
  __typename?: 'Query'
  GetAllProfileTypes?: Array<{
    __typename?: 'ProfileTypeEntity'
    id?: number | null
    description?: string | null
  } | null> | null
}

export type GetAllTechnologyStackQueryVariables = Exact<{
  [key: string]: never
}>

export type GetAllTechnologyStackQuery = {
  __typename?: 'Query'
  GetAllTechnologyStack?: Array<{
    __typename?: 'TechnologyStackEntity'
    createdAt?: any | null
    id?: number | null
    name?: string | null
    updateAt?: any | null
  } | null> | null
}

export type GetAllLevelExperienceQueryVariables = Exact<{
  [key: string]: never
}>

export type GetAllLevelExperienceQuery = {
  __typename?: 'Query'
  GetAllLevelExperience?: Array<{
    __typename?: 'LevelOfExperienceEntity'
    id?: number | null
    name?: string | null
  } | null> | null
}

export const GetAllJobsFilterDocument = {
  kind: 'Document',
  definitions: [
    {
      kind: 'OperationDefinition',
      operation: 'query',
      name: { kind: 'Name', value: 'GetAllJobsFilter' },
      variableDefinitions: [
        {
          kind: 'VariableDefinition',
          variable: { kind: 'Variable', name: { kind: 'Name', value: 'page' } },
          type: {
            kind: 'NonNullType',
            type: { kind: 'NamedType', name: { kind: 'Name', value: 'Int' } },
          },
        },
        {
          kind: 'VariableDefinition',
          variable: { kind: 'Variable', name: { kind: 'Name', value: 'size' } },
          type: {
            kind: 'NonNullType',
            type: { kind: 'NamedType', name: { kind: 'Name', value: 'Int' } },
          },
        },
        {
          kind: 'VariableDefinition',
          variable: {
            kind: 'Variable',
            name: { kind: 'Name', value: 'minSalary' },
          },
          type: {
            kind: 'NamedType',
            name: { kind: 'Name', value: 'BigDecimal' },
          },
        },
        {
          kind: 'VariableDefinition',
          variable: {
            kind: 'Variable',
            name: { kind: 'Name', value: 'maxSalary' },
          },
          type: {
            kind: 'NamedType',
            name: { kind: 'Name', value: 'BigDecimal' },
          },
        },
        {
          kind: 'VariableDefinition',
          variable: {
            kind: 'Variable',
            name: { kind: 'Name', value: 'workmode' },
          },
          type: {
            kind: 'NamedType',
            name: { kind: 'Name', value: 'WorkMode' },
          },
        },
        {
          kind: 'VariableDefinition',
          variable: {
            kind: 'Variable',
            name: { kind: 'Name', value: 'levelOfExperienceId' },
          },
          type: {
            kind: 'NamedType',
            name: { kind: 'Name', value: 'BigInteger' },
          },
        },
        {
          kind: 'VariableDefinition',
          variable: {
            kind: 'Variable',
            name: { kind: 'Name', value: 'profileTypeId' },
          },
          type: {
            kind: 'NamedType',
            name: { kind: 'Name', value: 'BigInteger' },
          },
        },
        {
          kind: 'VariableDefinition',
          variable: {
            kind: 'Variable',
            name: { kind: 'Name', value: 'countryId' },
          },
          type: {
            kind: 'NamedType',
            name: { kind: 'Name', value: 'BigInteger' },
          },
        },
        {
          kind: 'VariableDefinition',
          variable: {
            kind: 'Variable',
            name: { kind: 'Name', value: 'technologyStack' },
          },
          type: {
            kind: 'ListType',
            type: {
              kind: 'NamedType',
              name: { kind: 'Name', value: 'String' },
            },
          },
        },
      ],
      selectionSet: {
        kind: 'SelectionSet',
        selections: [
          {
            kind: 'Field',
            name: { kind: 'Name', value: 'GetAllJobsFilter' },
            arguments: [
              {
                kind: 'Argument',
                name: { kind: 'Name', value: 'page' },
                value: {
                  kind: 'Variable',
                  name: { kind: 'Name', value: 'page' },
                },
              },
              {
                kind: 'Argument',
                name: { kind: 'Name', value: 'size' },
                value: {
                  kind: 'Variable',
                  name: { kind: 'Name', value: 'size' },
                },
              },
              {
                kind: 'Argument',
                name: { kind: 'Name', value: 'minSalary' },
                value: {
                  kind: 'Variable',
                  name: { kind: 'Name', value: 'minSalary' },
                },
              },
              {
                kind: 'Argument',
                name: { kind: 'Name', value: 'maxSalary' },
                value: {
                  kind: 'Variable',
                  name: { kind: 'Name', value: 'maxSalary' },
                },
              },
              {
                kind: 'Argument',
                name: { kind: 'Name', value: 'workmode' },
                value: {
                  kind: 'Variable',
                  name: { kind: 'Name', value: 'workmode' },
                },
              },
              {
                kind: 'Argument',
                name: { kind: 'Name', value: 'levelOfExperienceId' },
                value: {
                  kind: 'Variable',
                  name: { kind: 'Name', value: 'levelOfExperienceId' },
                },
              },
              {
                kind: 'Argument',
                name: { kind: 'Name', value: 'profileTypeId' },
                value: {
                  kind: 'Variable',
                  name: { kind: 'Name', value: 'profileTypeId' },
                },
              },
              {
                kind: 'Argument',
                name: { kind: 'Name', value: 'countryId' },
                value: {
                  kind: 'Variable',
                  name: { kind: 'Name', value: 'countryId' },
                },
              },
              {
                kind: 'Argument',
                name: { kind: 'Name', value: 'technologyStack' },
                value: {
                  kind: 'Variable',
                  name: { kind: 'Name', value: 'technologyStack' },
                },
              },
            ],
            selectionSet: {
              kind: 'SelectionSet',
              selections: [
                { kind: 'Field', name: { kind: 'Name', value: 'currentPage' } },
                {
                  kind: 'Field',
                  name: { kind: 'Name', value: 'elementPerPage' },
                },
                { kind: 'Field', name: { kind: 'Name', value: 'totalItems' } },
                { kind: 'Field', name: { kind: 'Name', value: 'totalPage' } },
                {
                  kind: 'Field',
                  name: { kind: 'Name', value: 'jobs' },
                  selectionSet: {
                    kind: 'SelectionSet',
                    selections: [
                      {
                        kind: 'Field',
                        name: { kind: 'Name', value: 'createdAt' },
                      },
                      {
                        kind: 'Field',
                        name: { kind: 'Name', value: 'description' },
                      },
                      {
                        kind: 'Field',
                        name: { kind: 'Name', value: 'description_functions' },
                      },
                      {
                        kind: 'Field',
                        name: {
                          kind: 'Name',
                          value:
                            'description_functions_additional_requirements',
                        },
                      },
                      {
                        kind: 'Field',
                        name: { kind: 'Name', value: 'endTime' },
                      },
                      { kind: 'Field', name: { kind: 'Name', value: 'id' } },
                      {
                        kind: 'Field',
                        name: { kind: 'Name', value: 'maxSalary' },
                      },
                      {
                        kind: 'Field',
                        name: { kind: 'Name', value: 'minSalary' },
                      },
                      { kind: 'Field', name: { kind: 'Name', value: 'name' } },
                      {
                        kind: 'Field',
                        name: { kind: 'Name', value: 'openPositions' },
                      },
                      {
                        kind: 'Field',
                        name: { kind: 'Name', value: 'salary' },
                      },
                      {
                        kind: 'Field',
                        name: { kind: 'Name', value: 'startTime' },
                      },
                      {
                        kind: 'Field',
                        name: { kind: 'Name', value: 'updateAt' },
                      },
                      {
                        kind: 'Field',
                        name: { kind: 'Name', value: 'verified_profiles' },
                      },
                      {
                        kind: 'Field',
                        name: {
                          kind: 'Name',
                          value: 'visibility_name_company',
                        },
                      },
                      {
                        kind: 'Field',
                        name: { kind: 'Name', value: 'workMode' },
                      },
                      {
                        kind: 'Field',
                        name: { kind: 'Name', value: 'active' },
                      },
                      {
                        kind: 'Field',
                        name: { kind: 'Name', value: 'technologyStacks' },
                        selectionSet: {
                          kind: 'SelectionSet',
                          selections: [
                            {
                              kind: 'Field',
                              name: { kind: 'Name', value: 'id' },
                            },
                            {
                              kind: 'Field',
                              name: { kind: 'Name', value: 'name' },
                            },
                          ],
                        },
                      },
                      {
                        kind: 'Field',
                        name: { kind: 'Name', value: 'levelOfExperience' },
                        selectionSet: {
                          kind: 'SelectionSet',
                          selections: [
                            {
                              kind: 'Field',
                              name: { kind: 'Name', value: 'id' },
                            },
                            {
                              kind: 'Field',
                              name: { kind: 'Name', value: 'name' },
                            },
                          ],
                        },
                      },
                      {
                        kind: 'Field',
                        name: { kind: 'Name', value: 'company' },
                        selectionSet: {
                          kind: 'SelectionSet',
                          selections: [
                            {
                              kind: 'Field',
                              name: { kind: 'Name', value: 'description' },
                            },
                            {
                              kind: 'Field',
                              name: { kind: 'Name', value: 'imageUrl' },
                            },
                            {
                              kind: 'Field',
                              name: { kind: 'Name', value: 'name' },
                            },
                          ],
                        },
                      },
                      {
                        kind: 'Field',
                        name: { kind: 'Name', value: 'country' },
                        selectionSet: {
                          kind: 'SelectionSet',
                          selections: [
                            {
                              kind: 'Field',
                              name: { kind: 'Name', value: 'description' },
                            },
                            {
                              kind: 'Field',
                              name: { kind: 'Name', value: 'img_url' },
                            },
                            {
                              kind: 'Field',
                              name: { kind: 'Name', value: 'name' },
                            },
                          ],
                        },
                      },
                    ],
                  },
                },
              ],
            },
          },
        ],
      },
    },
  ],
} as unknown as DocumentNode<
  GetAllJobsFilterQuery,
  GetAllJobsFilterQueryVariables
>
export const GetJobByIdDocument = {
  kind: 'Document',
  definitions: [
    {
      kind: 'OperationDefinition',
      operation: 'query',
      name: { kind: 'Name', value: 'GetJobById' },
      variableDefinitions: [
        {
          kind: 'VariableDefinition',
          variable: { kind: 'Variable', name: { kind: 'Name', value: 'id' } },
          type: {
            kind: 'NamedType',
            name: { kind: 'Name', value: 'BigInteger' },
          },
        },
      ],
      selectionSet: {
        kind: 'SelectionSet',
        selections: [
          {
            kind: 'Field',
            name: { kind: 'Name', value: 'GetJobById' },
            arguments: [
              {
                kind: 'Argument',
                name: { kind: 'Name', value: 'id' },
                value: {
                  kind: 'Variable',
                  name: { kind: 'Name', value: 'id' },
                },
              },
            ],
            selectionSet: {
              kind: 'SelectionSet',
              selections: [
                { kind: 'Field', name: { kind: 'Name', value: 'createdAt' } },
                { kind: 'Field', name: { kind: 'Name', value: 'description' } },
                {
                  kind: 'Field',
                  name: { kind: 'Name', value: 'description_functions' },
                },
                {
                  kind: 'Field',
                  name: {
                    kind: 'Name',
                    value: 'description_functions_additional_requirements',
                  },
                },
                { kind: 'Field', name: { kind: 'Name', value: 'endTime' } },
                { kind: 'Field', name: { kind: 'Name', value: 'id' } },
                { kind: 'Field', name: { kind: 'Name', value: 'maxSalary' } },
                { kind: 'Field', name: { kind: 'Name', value: 'minSalary' } },
                { kind: 'Field', name: { kind: 'Name', value: 'name' } },
                {
                  kind: 'Field',
                  name: { kind: 'Name', value: 'openPositions' },
                },
                { kind: 'Field', name: { kind: 'Name', value: 'salary' } },
                { kind: 'Field', name: { kind: 'Name', value: 'startTime' } },
                { kind: 'Field', name: { kind: 'Name', value: 'updateAt' } },
                {
                  kind: 'Field',
                  name: { kind: 'Name', value: 'verified_profiles' },
                },
                {
                  kind: 'Field',
                  name: { kind: 'Name', value: 'visibility_name_company' },
                },
                { kind: 'Field', name: { kind: 'Name', value: 'workMode' } },
                { kind: 'Field', name: { kind: 'Name', value: 'active' } },
                {
                  kind: 'Field',
                  name: { kind: 'Name', value: 'levelOfExperience' },
                  selectionSet: {
                    kind: 'SelectionSet',
                    selections: [
                      { kind: 'Field', name: { kind: 'Name', value: 'id' } },
                      { kind: 'Field', name: { kind: 'Name', value: 'name' } },
                    ],
                  },
                },
                {
                  kind: 'Field',
                  name: { kind: 'Name', value: 'company' },
                  selectionSet: {
                    kind: 'SelectionSet',
                    selections: [
                      {
                        kind: 'Field',
                        name: { kind: 'Name', value: 'description' },
                      },
                      { kind: 'Field', name: { kind: 'Name', value: 'id' } },
                      {
                        kind: 'Field',
                        name: { kind: 'Name', value: 'imageUrl' },
                      },
                      { kind: 'Field', name: { kind: 'Name', value: 'name' } },
                      {
                        kind: 'Field',
                        name: { kind: 'Name', value: 'updateAt' },
                      },
                    ],
                  },
                },
                {
                  kind: 'Field',
                  name: { kind: 'Name', value: 'technologyStacks' },
                  selectionSet: {
                    kind: 'SelectionSet',
                    selections: [
                      { kind: 'Field', name: { kind: 'Name', value: 'id' } },
                      { kind: 'Field', name: { kind: 'Name', value: 'name' } },
                    ],
                  },
                },
              ],
            },
          },
        ],
      },
    },
  ],
} as unknown as DocumentNode<GetJobByIdQuery, GetJobByIdQueryVariables>
export const CreateJobDocument = {
  kind: 'Document',
  definitions: [
    {
      kind: 'OperationDefinition',
      operation: 'mutation',
      name: { kind: 'Name', value: 'CreateJob' },
      variableDefinitions: [
        {
          kind: 'VariableDefinition',
          variable: { kind: 'Variable', name: { kind: 'Name', value: 'job' } },
          type: {
            kind: 'NamedType',
            name: { kind: 'Name', value: 'JobInput' },
          },
        },
      ],
      selectionSet: {
        kind: 'SelectionSet',
        selections: [
          {
            kind: 'Field',
            name: { kind: 'Name', value: 'CreateJob' },
            arguments: [
              {
                kind: 'Argument',
                name: { kind: 'Name', value: 'job' },
                value: {
                  kind: 'Variable',
                  name: { kind: 'Name', value: 'job' },
                },
              },
            ],
          },
        ],
      },
    },
  ],
} as unknown as DocumentNode<CreateJobMutation, CreateJobMutationVariables>
export const GetAllBenefitsDocument = {
  kind: 'Document',
  definitions: [
    {
      kind: 'OperationDefinition',
      operation: 'query',
      name: { kind: 'Name', value: 'GetAllBenefits' },
      selectionSet: {
        kind: 'SelectionSet',
        selections: [
          {
            kind: 'Field',
            name: { kind: 'Name', value: 'GetAllBenefits' },
            selectionSet: {
              kind: 'SelectionSet',
              selections: [
                { kind: 'Field', name: { kind: 'Name', value: 'created_at' } },
                { kind: 'Field', name: { kind: 'Name', value: 'description' } },
                { kind: 'Field', name: { kind: 'Name', value: 'id' } },
                { kind: 'Field', name: { kind: 'Name', value: 'name' } },
                { kind: 'Field', name: { kind: 'Name', value: 'prefix' } },
                { kind: 'Field', name: { kind: 'Name', value: 'updated_at' } },
              ],
            },
          },
        ],
      },
    },
  ],
} as unknown as DocumentNode<GetAllBenefitsQuery, GetAllBenefitsQueryVariables>
export const GetAllCategoriesDocument = {
  kind: 'Document',
  definitions: [
    {
      kind: 'OperationDefinition',
      operation: 'query',
      name: { kind: 'Name', value: 'GetAllCategories' },
      selectionSet: {
        kind: 'SelectionSet',
        selections: [
          {
            kind: 'Field',
            name: { kind: 'Name', value: 'getAllCategories' },
            selectionSet: {
              kind: 'SelectionSet',
              selections: [
                { kind: 'Field', name: { kind: 'Name', value: 'id' } },
                { kind: 'Field', name: { kind: 'Name', value: 'name' } },
              ],
            },
          },
        ],
      },
    },
  ],
} as unknown as DocumentNode<
  GetAllCategoriesQuery,
  GetAllCategoriesQueryVariables
>
export const GetAllCountriesDocument = {
  kind: 'Document',
  definitions: [
    {
      kind: 'OperationDefinition',
      operation: 'query',
      name: { kind: 'Name', value: 'GetAllCountries' },
      selectionSet: {
        kind: 'SelectionSet',
        selections: [
          {
            kind: 'Field',
            name: { kind: 'Name', value: 'GetAllCountries' },
            selectionSet: {
              kind: 'SelectionSet',
              selections: [
                { kind: 'Field', name: { kind: 'Name', value: 'createdAt' } },
                { kind: 'Field', name: { kind: 'Name', value: 'description' } },
                { kind: 'Field', name: { kind: 'Name', value: 'id' } },
                { kind: 'Field', name: { kind: 'Name', value: 'name' } },
                { kind: 'Field', name: { kind: 'Name', value: 'updatedAt' } },
              ],
            },
          },
        ],
      },
    },
  ],
} as unknown as DocumentNode<
  GetAllCountriesQuery,
  GetAllCountriesQueryVariables
>
export const GetAllLanguagesDocument = {
  kind: 'Document',
  definitions: [
    {
      kind: 'OperationDefinition',
      operation: 'query',
      name: { kind: 'Name', value: 'GetAllLanguages' },
      selectionSet: {
        kind: 'SelectionSet',
        selections: [
          {
            kind: 'Field',
            name: { kind: 'Name', value: 'getAllLanguages' },
            selectionSet: {
              kind: 'SelectionSet',
              selections: [
                { kind: 'Field', name: { kind: 'Name', value: 'description' } },
                { kind: 'Field', name: { kind: 'Name', value: 'id' } },
              ],
            },
          },
        ],
      },
    },
  ],
} as unknown as DocumentNode<
  GetAllLanguagesQuery,
  GetAllLanguagesQueryVariables
>
export const GetAllWorkTypeDocument = {
  kind: 'Document',
  definitions: [
    {
      kind: 'OperationDefinition',
      operation: 'query',
      name: { kind: 'Name', value: 'GetAllWorkType' },
      selectionSet: {
        kind: 'SelectionSet',
        selections: [
          {
            kind: 'Field',
            name: { kind: 'Name', value: 'GetAllWorkType' },
            selectionSet: {
              kind: 'SelectionSet',
              selections: [
                { kind: 'Field', name: { kind: 'Name', value: 'id' } },
                { kind: 'Field', name: { kind: 'Name', value: 'name' } },
              ],
            },
          },
        ],
      },
    },
  ],
} as unknown as DocumentNode<GetAllWorkTypeQuery, GetAllWorkTypeQueryVariables>
export const GetAllProfileTypesDocument = {
  kind: 'Document',
  definitions: [
    {
      kind: 'OperationDefinition',
      operation: 'query',
      name: { kind: 'Name', value: 'GetAllProfileTypes' },
      selectionSet: {
        kind: 'SelectionSet',
        selections: [
          {
            kind: 'Field',
            name: { kind: 'Name', value: 'GetAllProfileTypes' },
            selectionSet: {
              kind: 'SelectionSet',
              selections: [
                { kind: 'Field', name: { kind: 'Name', value: 'id' } },
                { kind: 'Field', name: { kind: 'Name', value: 'description' } },
              ],
            },
          },
        ],
      },
    },
  ],
} as unknown as DocumentNode<
  GetAllProfileTypesQuery,
  GetAllProfileTypesQueryVariables
>
export const GetAllTechnologyStackDocument = {
  kind: 'Document',
  definitions: [
    {
      kind: 'OperationDefinition',
      operation: 'query',
      name: { kind: 'Name', value: 'GetAllTechnologyStack' },
      selectionSet: {
        kind: 'SelectionSet',
        selections: [
          {
            kind: 'Field',
            name: { kind: 'Name', value: 'GetAllTechnologyStack' },
            selectionSet: {
              kind: 'SelectionSet',
              selections: [
                { kind: 'Field', name: { kind: 'Name', value: 'createdAt' } },
                { kind: 'Field', name: { kind: 'Name', value: 'id' } },
                { kind: 'Field', name: { kind: 'Name', value: 'name' } },
                { kind: 'Field', name: { kind: 'Name', value: 'updateAt' } },
              ],
            },
          },
        ],
      },
    },
  ],
} as unknown as DocumentNode<
  GetAllTechnologyStackQuery,
  GetAllTechnologyStackQueryVariables
>
export const GetAllLevelExperienceDocument = {
  kind: 'Document',
  definitions: [
    {
      kind: 'OperationDefinition',
      operation: 'query',
      name: { kind: 'Name', value: 'GetAllLevelExperience' },
      selectionSet: {
        kind: 'SelectionSet',
        selections: [
          {
            kind: 'Field',
            name: { kind: 'Name', value: 'GetAllLevelExperience' },
            selectionSet: {
              kind: 'SelectionSet',
              selections: [
                { kind: 'Field', name: { kind: 'Name', value: 'id' } },
                { kind: 'Field', name: { kind: 'Name', value: 'name' } },
              ],
            },
          },
        ],
      },
    },
  ],
} as unknown as DocumentNode<
  GetAllLevelExperienceQuery,
  GetAllLevelExperienceQueryVariables
>
