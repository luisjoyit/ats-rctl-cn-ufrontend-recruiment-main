/* eslint-disable */
import * as types from './graphql'
import { TypedDocumentNode as DocumentNode } from '@graphql-typed-document-node/core'

/**
 * Map of all GraphQL operations in the project.
 *
 * This map has several performance disadvantages:
 * 1. It is not tree-shakeable, so it will include all operations in the project.
 * 2. It is not minifiable, so the string of a GraphQL query will be multiple times inside the bundle.
 * 3. It does not support dead code elimination, so it will add unused operations.
 *
 * Therefore it is highly recommended to use the babel or swc plugin for production.
 */
const documents = {
  '\n      query GetAllJobsFilter(\n        $page: Int!\n        $size: Int!\n        $minSalary: BigDecimal\n        $maxSalary: BigDecimal\n        $workmode: WorkMode\n        $levelOfExperienceId: BigInteger\n        $profileTypeId: BigInteger\n        $countryId: BigInteger\n        $technologyStack: [String]\n      ) {\n        GetAllJobsFilter(\n          page: $page\n          size: $size\n          minSalary: $minSalary\n          maxSalary: $maxSalary\n          workmode: $workmode\n          levelOfExperienceId: $levelOfExperienceId\n          profileTypeId: $profileTypeId\n          countryId: $countryId\n          technologyStack: $technologyStack\n        ) {\n          currentPage\n          elementPerPage\n          totalItems\n          totalPage\n          jobs {\n            createdAt\n            description\n            description_functions\n            description_functions_additional_requirements\n            endTime\n            id\n            maxSalary\n            minSalary\n            name\n            openPositions\n            salary\n            startTime\n            updateAt\n            verified_profiles\n            visibility_name_company\n            workMode\n            active\n            technologyStacks {\n              id\n              name\n            }\n            levelOfExperience {\n              id\n              name\n            }\n            company {\n              description\n              imageUrl\n              name\n            }\n            country {\n              description\n              img_url\n              name\n            }\n          }\n        }\n      }\n    ':
    types.GetAllJobsFilterDocument,
  '\n      query GetJobById($id: BigInteger) {\n        GetJobById(id: $id) {\n          createdAt\n          description\n          description_functions\n          description_functions_additional_requirements\n          endTime\n          id\n          maxSalary\n          minSalary\n          name\n          openPositions\n          salary\n          startTime\n          updateAt\n          verified_profiles\n          visibility_name_company\n          workMode\n          active\n          levelOfExperience {\n            id\n            name\n          }\n          company {\n            description\n            id\n            imageUrl\n            name\n            updateAt\n          }\n          technologyStacks {\n            id\n            name\n          }\n        }\n      }\n    ':
    types.GetJobByIdDocument,
  '\n      mutation CreateJob($job: JobInput) {\n        CreateJob(job: $job)\n      }\n    ':
    types.CreateJobDocument,
  '\n      query GetAllBenefits {\n        GetAllBenefits {\n          created_at\n          description\n          id\n          name\n          prefix\n          updated_at\n        }\n      }\n    ':
    types.GetAllBenefitsDocument,
  '\n      query GetAllCategories {\n        getAllCategories {\n          id\n          name\n        }\n      }\n    ':
    types.GetAllCategoriesDocument,
  '\n      query GetAllCountries {\n        GetAllCountries {\n          createdAt\n          description\n          id\n          name\n          updatedAt\n        }\n      }\n    ':
    types.GetAllCountriesDocument,
  '\n      query GetAllLanguages {\n        getAllLanguages {\n          description\n          id\n        }\n      }\n    ':
    types.GetAllLanguagesDocument,
  '\n      query GetAllWorkType {\n        GetAllWorkType {\n          id\n          name\n        }\n      }\n    ':
    types.GetAllWorkTypeDocument,
  '\n      query GetAllProfileTypes {\n        GetAllProfileTypes {\n          id\n          description\n        }\n      }\n    ':
    types.GetAllProfileTypesDocument,
  '\n      query GetAllTechnologyStack {\n        GetAllTechnologyStack {\n          createdAt\n          id\n          name\n          updateAt\n        }\n      }\n    ':
    types.GetAllTechnologyStackDocument,
  '\n      query GetAllLevelExperience {\n        GetAllLevelExperience {\n          id\n          name\n        }\n      }\n    ':
    types.GetAllLevelExperienceDocument,
}

/**
 * The graphql function is used to parse GraphQL queries into a document that can be used by GraphQL clients.
 *
 *
 * @example
 * ```ts
 * const query = graphql(`query GetUser($id: ID!) { user(id: $id) { name } }`);
 * ```
 *
 * The query argument is unknown!
 * Please regenerate the types.
 */
export function graphql(source: string): unknown

/**
 * The graphql function is used to parse GraphQL queries into a document that can be used by GraphQL clients.
 */
export function graphql(
  source: '\n      query GetAllJobsFilter(\n        $page: Int!\n        $size: Int!\n        $minSalary: BigDecimal\n        $maxSalary: BigDecimal\n        $workmode: WorkMode\n        $levelOfExperienceId: BigInteger\n        $profileTypeId: BigInteger\n        $countryId: BigInteger\n        $technologyStack: [String]\n      ) {\n        GetAllJobsFilter(\n          page: $page\n          size: $size\n          minSalary: $minSalary\n          maxSalary: $maxSalary\n          workmode: $workmode\n          levelOfExperienceId: $levelOfExperienceId\n          profileTypeId: $profileTypeId\n          countryId: $countryId\n          technologyStack: $technologyStack\n        ) {\n          currentPage\n          elementPerPage\n          totalItems\n          totalPage\n          jobs {\n            createdAt\n            description\n            description_functions\n            description_functions_additional_requirements\n            endTime\n            id\n            maxSalary\n            minSalary\n            name\n            openPositions\n            salary\n            startTime\n            updateAt\n            verified_profiles\n            visibility_name_company\n            workMode\n            active\n            technologyStacks {\n              id\n              name\n            }\n            levelOfExperience {\n              id\n              name\n            }\n            company {\n              description\n              imageUrl\n              name\n            }\n            country {\n              description\n              img_url\n              name\n            }\n          }\n        }\n      }\n    ',
): (typeof documents)['\n      query GetAllJobsFilter(\n        $page: Int!\n        $size: Int!\n        $minSalary: BigDecimal\n        $maxSalary: BigDecimal\n        $workmode: WorkMode\n        $levelOfExperienceId: BigInteger\n        $profileTypeId: BigInteger\n        $countryId: BigInteger\n        $technologyStack: [String]\n      ) {\n        GetAllJobsFilter(\n          page: $page\n          size: $size\n          minSalary: $minSalary\n          maxSalary: $maxSalary\n          workmode: $workmode\n          levelOfExperienceId: $levelOfExperienceId\n          profileTypeId: $profileTypeId\n          countryId: $countryId\n          technologyStack: $technologyStack\n        ) {\n          currentPage\n          elementPerPage\n          totalItems\n          totalPage\n          jobs {\n            createdAt\n            description\n            description_functions\n            description_functions_additional_requirements\n            endTime\n            id\n            maxSalary\n            minSalary\n            name\n            openPositions\n            salary\n            startTime\n            updateAt\n            verified_profiles\n            visibility_name_company\n            workMode\n            active\n            technologyStacks {\n              id\n              name\n            }\n            levelOfExperience {\n              id\n              name\n            }\n            company {\n              description\n              imageUrl\n              name\n            }\n            country {\n              description\n              img_url\n              name\n            }\n          }\n        }\n      }\n    ']
/**
 * The graphql function is used to parse GraphQL queries into a document that can be used by GraphQL clients.
 */
export function graphql(
  source: '\n      query GetJobById($id: BigInteger) {\n        GetJobById(id: $id) {\n          createdAt\n          description\n          description_functions\n          description_functions_additional_requirements\n          endTime\n          id\n          maxSalary\n          minSalary\n          name\n          openPositions\n          salary\n          startTime\n          updateAt\n          verified_profiles\n          visibility_name_company\n          workMode\n          active\n          levelOfExperience {\n            id\n            name\n          }\n          company {\n            description\n            id\n            imageUrl\n            name\n            updateAt\n          }\n          technologyStacks {\n            id\n            name\n          }\n        }\n      }\n    ',
): (typeof documents)['\n      query GetJobById($id: BigInteger) {\n        GetJobById(id: $id) {\n          createdAt\n          description\n          description_functions\n          description_functions_additional_requirements\n          endTime\n          id\n          maxSalary\n          minSalary\n          name\n          openPositions\n          salary\n          startTime\n          updateAt\n          verified_profiles\n          visibility_name_company\n          workMode\n          active\n          levelOfExperience {\n            id\n            name\n          }\n          company {\n            description\n            id\n            imageUrl\n            name\n            updateAt\n          }\n          technologyStacks {\n            id\n            name\n          }\n        }\n      }\n    ']
/**
 * The graphql function is used to parse GraphQL queries into a document that can be used by GraphQL clients.
 */
export function graphql(
  source: '\n      mutation CreateJob($job: JobInput) {\n        CreateJob(job: $job)\n      }\n    ',
): (typeof documents)['\n      mutation CreateJob($job: JobInput) {\n        CreateJob(job: $job)\n      }\n    ']
/**
 * The graphql function is used to parse GraphQL queries into a document that can be used by GraphQL clients.
 */
export function graphql(
  source: '\n      query GetAllBenefits {\n        GetAllBenefits {\n          created_at\n          description\n          id\n          name\n          prefix\n          updated_at\n        }\n      }\n    ',
): (typeof documents)['\n      query GetAllBenefits {\n        GetAllBenefits {\n          created_at\n          description\n          id\n          name\n          prefix\n          updated_at\n        }\n      }\n    ']
/**
 * The graphql function is used to parse GraphQL queries into a document that can be used by GraphQL clients.
 */
export function graphql(
  source: '\n      query GetAllCategories {\n        getAllCategories {\n          id\n          name\n        }\n      }\n    ',
): (typeof documents)['\n      query GetAllCategories {\n        getAllCategories {\n          id\n          name\n        }\n      }\n    ']
/**
 * The graphql function is used to parse GraphQL queries into a document that can be used by GraphQL clients.
 */
export function graphql(
  source: '\n      query GetAllCountries {\n        GetAllCountries {\n          createdAt\n          description\n          id\n          name\n          updatedAt\n        }\n      }\n    ',
): (typeof documents)['\n      query GetAllCountries {\n        GetAllCountries {\n          createdAt\n          description\n          id\n          name\n          updatedAt\n        }\n      }\n    ']
/**
 * The graphql function is used to parse GraphQL queries into a document that can be used by GraphQL clients.
 */
export function graphql(
  source: '\n      query GetAllLanguages {\n        getAllLanguages {\n          description\n          id\n        }\n      }\n    ',
): (typeof documents)['\n      query GetAllLanguages {\n        getAllLanguages {\n          description\n          id\n        }\n      }\n    ']
/**
 * The graphql function is used to parse GraphQL queries into a document that can be used by GraphQL clients.
 */
export function graphql(
  source: '\n      query GetAllWorkType {\n        GetAllWorkType {\n          id\n          name\n        }\n      }\n    ',
): (typeof documents)['\n      query GetAllWorkType {\n        GetAllWorkType {\n          id\n          name\n        }\n      }\n    ']
/**
 * The graphql function is used to parse GraphQL queries into a document that can be used by GraphQL clients.
 */
export function graphql(
  source: '\n      query GetAllProfileTypes {\n        GetAllProfileTypes {\n          id\n          description\n        }\n      }\n    ',
): (typeof documents)['\n      query GetAllProfileTypes {\n        GetAllProfileTypes {\n          id\n          description\n        }\n      }\n    ']
/**
 * The graphql function is used to parse GraphQL queries into a document that can be used by GraphQL clients.
 */
export function graphql(
  source: '\n      query GetAllTechnologyStack {\n        GetAllTechnologyStack {\n          createdAt\n          id\n          name\n          updateAt\n        }\n      }\n    ',
): (typeof documents)['\n      query GetAllTechnologyStack {\n        GetAllTechnologyStack {\n          createdAt\n          id\n          name\n          updateAt\n        }\n      }\n    ']
/**
 * The graphql function is used to parse GraphQL queries into a document that can be used by GraphQL clients.
 */
export function graphql(
  source: '\n      query GetAllLevelExperience {\n        GetAllLevelExperience {\n          id\n          name\n        }\n      }\n    ',
): (typeof documents)['\n      query GetAllLevelExperience {\n        GetAllLevelExperience {\n          id\n          name\n        }\n      }\n    ']

export function graphql(source: string) {
  return (documents as any)[source] ?? {}
}

export type DocumentType<TDocumentNode extends DocumentNode<any, any>> =
  TDocumentNode extends DocumentNode<infer TType, any> ? TType : never
