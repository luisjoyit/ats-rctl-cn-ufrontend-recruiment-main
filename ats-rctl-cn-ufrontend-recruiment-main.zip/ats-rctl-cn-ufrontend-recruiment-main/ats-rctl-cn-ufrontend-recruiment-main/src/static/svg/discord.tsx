import React from 'react'

interface DiscordSvgProps {
  iconColor: string
}

const DiscordSvg: React.FC<DiscordSvgProps> = ({ iconColor }) => {
  return (
    <svg
      width="178"
      height="137"
      viewBox="0 0 178 137"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <mask
        id="mask0_1040_3819"
        style={{ maskType: 'alpha' }}
        maskUnits="userSpaceOnUse"
        x="0"
        y="0"
        width="178"
        height="137"
      >
        <path
          d="M150.082 11.4742C138.608 6.15688 126.387 2.23886 113.514 0C111.928 2.79858 110.062 6.6233 108.849 9.70174C95.2297 7.64945 81.7032 7.64945 68.3633 9.70174C67.0573 6.6233 65.1916 2.79858 63.6057 0C50.7323 2.23886 38.5118 6.15688 27.0376 11.4742C3.9027 46.3631 -2.34746 80.4125 0.730978 113.902C16.1232 125.376 30.9556 132.28 45.6015 136.851C49.2397 131.906 52.4114 126.589 55.21 121.085C49.8927 119.126 44.8553 116.607 40.0977 113.716C41.4037 112.783 42.6164 111.757 43.8291 110.824C73.0276 124.444 104.652 124.444 133.477 110.824C134.69 111.85 135.902 112.783 137.208 113.716C132.451 116.607 127.32 119.033 122.096 121.085C124.895 126.589 128.066 131.906 131.705 136.851C146.35 132.28 161.276 125.376 176.575 113.902C180.213 75.0019 170.325 41.3257 150.268 11.4742H150.082ZM59.128 93.3793C50.3591 93.3793 43.1761 85.2634 43.1761 75.2818C43.1761 65.3002 50.1726 57.1843 59.128 57.1843C68.0835 57.1843 75.1732 65.3002 75.0799 75.2818C75.0799 85.1701 68.0835 93.3793 59.128 93.3793ZM117.991 93.3793C109.223 93.3793 102.04 85.2634 102.04 75.2818C102.04 65.3002 109.036 57.1843 117.991 57.1843C126.947 57.1843 134.037 65.3002 133.943 75.2818C133.943 85.1701 126.947 93.3793 117.991 93.3793Z"
          fill={iconColor}
        />
      </mask>
      <g mask="url(#mask0_1040_3819)">
        <g filter="url(#filter0_d_1040_3819)">
          <path
            d="M-146 -58C-146 -74.5685 -132.569 -88 -116 -88H104C120.569 -88 134 -74.5685 134 -58V130C134 146.569 120.569 160 104 160H-116C-132.569 160 -146 146.569 -146 130V-58Z"
            fill={iconColor}
          />
        </g>
      </g>
      <defs>
        <filter
          id="filter0_d_1040_3819"
          x="-156"
          y="-95"
          width="300"
          height="268"
          filterUnits="userSpaceOnUse"
          color-interpolation-filters="sRGB"
        >
          <feFlood flood-opacity="0" result="BackgroundImageFix" />
          <feColorMatrix
            in="SourceAlpha"
            type="matrix"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset dy="3" />
          <feGaussianBlur stdDeviation="5" />
          <feComposite in2="hardAlpha" operator="out" />
          <feColorMatrix
            type="matrix"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.25 0"
          />
          <feBlend
            mode="normal"
            in2="BackgroundImageFix"
            result="effect1_dropShadow_1040_3819"
          />
          <feBlend
            mode="normal"
            in="SourceGraphic"
            in2="effect1_dropShadow_1040_3819"
            result="shape"
          />
        </filter>
      </defs>
    </svg>
  )
}

export default DiscordSvg
