import React from 'react'

interface ShowPasswordSVGProps {
  onClick?: () => void
  className?: string
}

const ShowPasswordSVG: React.FC<ShowPasswordSVGProps> = ({
  onClick,
  className,
}) => (
  <svg
    width="14"
    height="11"
    viewBox="0 0 14 11"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      d="M7.1145 1C4.60957 1 2.73851 2.62693 1.62608 3.95956C0.791307 4.9596 0.791307 6.37373 1.62608 7.3738C2.73851 8.7064 4.60957 10.3333 7.1145 10.3333C9.61943 10.3333 11.4905 8.7064 12.6029 7.3738C13.4377 6.37373 13.4377 4.9596 12.6029 3.95956C11.4905 2.62693 9.61943 1 7.1145 1Z"
      stroke="#F7FAFF"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    <path
      d="M7.11328 7.66699C8.21788 7.66699 9.11328 6.77159 9.11328 5.66699C9.11328 4.56239 8.21788 3.66699 7.11328 3.66699C6.00868 3.66699 5.11328 4.56239 5.11328 5.66699C5.11328 6.77159 6.00868 7.66699 7.11328 7.66699Z"
      stroke="#F7FAFF"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
)

export default ShowPasswordSVG
