import { useMutation, UseMutationOptions } from '@tanstack/react-query'
import { TypedDocumentNode } from '@graphql-typed-document-node/core'
import { GRAPHQL_ENDPOINT } from '../constants'
import request, { Variables } from 'graphql-request'
//@ts-ignore
import { useKeycloakHookAuth } from '@joyit/user-management'

export function useGraphQLMutation<TResult, TVariables>(
  document: TypedDocumentNode<TResult, TVariables>,
  options?: UseMutationOptions<TResult, Error, TVariables>,
) {
  const { oidcTokens } = useKeycloakHookAuth()
  return useMutation({
    mutationFn: async (variables: TVariables) => {
      return request(GRAPHQL_ENDPOINT, document, variables as Variables, {
        Authorization: `Bearer ${oidcTokens.accessToken}`,
      })
    },
    ...options, // Asegúrate de incluir las opciones aquí
  })
}
