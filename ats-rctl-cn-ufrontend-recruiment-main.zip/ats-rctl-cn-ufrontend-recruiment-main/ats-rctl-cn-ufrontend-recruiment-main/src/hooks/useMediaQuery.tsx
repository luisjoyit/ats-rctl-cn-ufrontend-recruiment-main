import { useEffect, useState } from 'react'

export default function useMediaQuery(query: string): boolean {
  const [matches, setMatches] = useState(window.matchMedia(query).matches)

  useEffect(() => {
    const updateMatches = () => {
      setMatches(window.matchMedia(query).matches)
    }

    window.addEventListener('resize', updateMatches)

    return () => {
      window.removeEventListener('resize', updateMatches)
    }
  }, [query])

  return matches
}
