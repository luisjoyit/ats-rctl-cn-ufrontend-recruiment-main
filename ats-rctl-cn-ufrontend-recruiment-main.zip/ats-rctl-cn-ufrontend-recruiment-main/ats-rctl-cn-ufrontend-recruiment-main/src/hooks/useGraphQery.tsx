import { useQuery } from '@tanstack/react-query'
import { type TypedDocumentNode } from '@graphql-typed-document-node/core'
import { GRAPHQL_ENDPOINT } from '../constants'
import request from 'graphql-request'

//@ts-ignore
import { useKeycloakHook } from '@joyit/user-management'
function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms))
}

export function useGraphQL<TResult, TVariables>(
  document: TypedDocumentNode<TResult, TVariables>,
  ...[variables]: TVariables extends Record<string, never> ? [] : [TVariables]
) {
  const { oidcTokens } = useKeycloakHook()

  return useQuery({
    queryKey: [(document.definitions[0] as any).name.value, variables],
    queryFn: async ({ queryKey }) => {
      await delay(1000)
      return request(
        GRAPHQL_ENDPOINT,
        document,
        queryKey[1] ? queryKey[1] : undefined,
        { Authorization: `Bearer ${oidcTokens?.accessToken}` },
      )
    },
  })
}
