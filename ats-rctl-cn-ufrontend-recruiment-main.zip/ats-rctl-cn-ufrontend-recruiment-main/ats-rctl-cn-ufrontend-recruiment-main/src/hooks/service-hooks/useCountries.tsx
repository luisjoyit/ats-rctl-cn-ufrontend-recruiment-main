import { countryService } from '@/service'
import { useGraphQL } from '../useGraphQery'

function useCountries() {
  const { data, isLoading, error } = useGraphQL(countryService.getCountries())

  const dataCountries = data?.GetAllCountries
    ? data?.GetAllCountries.map((item) => ({
        value: item.id.toString(),
        label: item.description,
      }))
    : []

  return { dataCountries, isLoading, error }
}

export default useCountries
