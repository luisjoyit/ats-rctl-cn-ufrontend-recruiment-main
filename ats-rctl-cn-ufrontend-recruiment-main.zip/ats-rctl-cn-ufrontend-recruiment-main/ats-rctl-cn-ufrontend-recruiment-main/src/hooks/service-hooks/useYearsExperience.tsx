import { yearsExperienceService } from '@/service'
import { useGraphQL } from '../useGraphQery'

function useYearsEsperiences() {
  const { data, isLoading, error } = useGraphQL(
    yearsExperienceService.getYearsExperience(),
  )

  const dataYearsEsperiencess = data?.GetAllLevelExperience
    ? data?.GetAllLevelExperience.map((item) => ({
        value: item.id.toString(),
        label: item.name,
      }))
    : []

  return { dataYearsEsperiencess, isLoading, error }
}

export default useYearsEsperiences
