import { profileTypeService } from '@/service'
import { useGraphQL } from '../useGraphQery'

function useProfileTypes() {
  const { data, isLoading, error } = useGraphQL(
    profileTypeService.getProfileTypes(),
  )

  const dataProfileTypes = data?.GetAllProfileTypes
    ? data.GetAllProfileTypes.map((item) => ({
        value: item.id.toString(),
        label: item.description,
      }))
    : []

  return { dataProfileTypes, isLoading, error }
}

export default useProfileTypes
