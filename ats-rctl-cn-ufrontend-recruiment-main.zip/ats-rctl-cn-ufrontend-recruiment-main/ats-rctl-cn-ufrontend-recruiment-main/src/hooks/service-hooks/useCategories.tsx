import { categoryService } from '@/service'
import { useGraphQL } from '../useGraphQery'

function useCategories() {
  const { data, isLoading, error } = useGraphQL(categoryService.getCategories())

  const dataCategories = data?.getAllCategories
    ? data.getAllCategories.map((item) => ({
        value: item.id.toString(),
        label: item.name,
      }))
    : []

  return { dataCategories, isLoading, error }
}

export default useCategories
