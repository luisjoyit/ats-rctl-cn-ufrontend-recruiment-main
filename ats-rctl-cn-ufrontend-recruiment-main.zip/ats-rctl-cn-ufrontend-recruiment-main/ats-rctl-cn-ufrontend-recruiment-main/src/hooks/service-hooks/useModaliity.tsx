import { modalityService } from '@/service'
import { useGraphQL } from '../useGraphQery'

function useModalities() {
  const { data, isLoading, error } = useGraphQL(modalityService.getModalities())

  const dataModalities = data?.GetAllWorkType
    ? data.GetAllWorkType.map((item) => ({
        value: item.id.toString(),
        label: item.name,
      }))
    : []

  return { dataModalities, isLoading, error }
}

export default useModalities
