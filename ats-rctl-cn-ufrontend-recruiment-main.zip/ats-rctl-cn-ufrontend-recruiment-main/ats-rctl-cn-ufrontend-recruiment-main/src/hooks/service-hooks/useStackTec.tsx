import { stacksTeckNologiesService } from '@/service'
import { useGraphQL } from '../useGraphQery'

function useStacksTechs() {
  const { data, isLoading, error } = useGraphQL(
    stacksTeckNologiesService.getStackTecknologies(),
  )

  const dataStacksTechs = data?.GetAllTechnologyStack
    ? data.GetAllTechnologyStack.map((item) => ({
        value: item.id.toString(),
        label: item.name,
      }))
    : []

  return { dataStacksTechs, isLoading, error }
}

export default useStacksTechs
