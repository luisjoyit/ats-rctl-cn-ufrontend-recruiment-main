import { languageService } from '@/service'
import { useGraphQL } from '../useGraphQery'

function useLanguages() {
  const { data, isLoading, error } = useGraphQL(languageService.getLanguages())

  const dataLanguages = data?.getAllLanguages
    ? data.getAllLanguages.map((item) => ({
        value: item.id.toString(),
        label: item.description,
      }))
    : []

  return { dataLanguages, isLoading, error }
}

export default useLanguages
