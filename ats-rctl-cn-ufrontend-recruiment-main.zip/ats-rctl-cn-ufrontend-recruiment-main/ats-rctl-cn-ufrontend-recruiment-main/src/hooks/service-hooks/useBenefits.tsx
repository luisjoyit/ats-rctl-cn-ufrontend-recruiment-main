import { benefitsService } from '@/service'
import { useGraphQL } from '../useGraphQery'
import {
  IconBriefcase,
  IconCertificate,
  IconDeviceImacHeart,
  IconMoodDollar,
  IconShieldCheckered,
  IconTicket,
  IconTruck,
} from '@tabler/icons-react'
import { cva } from 'class-variance-authority'

type prefix = 'SM' | 'TRP' | 'CC' | 'VD' | 'BD' | 'BC' | 'ST'

const IconVariant = cva('text-secondary-500 xs:size-4 sm:size-5 lg:size-6')

const iconsBenefits: Record<prefix, JSX.Element> = {
  SM: <IconShieldCheckered stroke={1.5} className={IconVariant()} />,
  TRP: <IconBriefcase stroke={1.5} className={IconVariant()} />,
  CC: <IconCertificate stroke={1.5} className={IconVariant()} />,
  VD: <IconTicket stroke={1.5} className={IconVariant()} />,
  BD: <IconMoodDollar stroke={1.5} className={IconVariant()} />,
  BC: <IconDeviceImacHeart stroke={1.5} className={IconVariant()} />,
  ST: <IconTruck stroke={1.5} className={IconVariant()} />,
}

interface dataBenefits {
  id: string
  title: string
  description: string
  icon: JSX.Element
}

function useBenefits() {
  const { data, isLoading, error } = useGraphQL(benefitsService.getBenefits())

  const dataBenefits: dataBenefits[] = data?.GetAllBenefits
    ? data.GetAllBenefits.map((item) => ({
        id: item.id.toString(),
        title: item.name,
        description: item.description,
        icon: iconsBenefits[item.prefix as prefix],
      }))
    : []

  return { dataBenefits, lengthBenefits: dataBenefits.length, isLoading, error }
}

export default useBenefits
