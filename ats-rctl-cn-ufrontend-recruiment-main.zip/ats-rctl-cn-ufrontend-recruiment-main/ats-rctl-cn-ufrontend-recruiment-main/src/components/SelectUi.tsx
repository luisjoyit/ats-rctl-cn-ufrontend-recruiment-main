import React, { useState } from 'react'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { SetURLSearchParams, useSearchParams } from 'react-router-dom'
import { cn } from '@/lib/utils'
import { ChevronDownIcon, ChevronUpIcon } from '@radix-ui/react-icons'
import { UseFormSetValue, UseFormTrigger } from 'react-hook-form'
interface Item {
  value: string
  label: string
}

interface ISelectUi {
  placeholder: string
  setSelectValue?: SetURLSearchParams
  searchParams?: URLSearchParams
  name: string
  items: Item[]
  className?: string
  defaultValue?: string
  value?: any
  onChange?: (name: string, value: string) => void
  icon?: React.ReactNode
  setValue?: UseFormSetValue<any>
  onlyValue?: boolean
  disabled?: boolean
  trigger?: UseFormTrigger<any>
}

export default function SelectUi({
  placeholder,
  items,
  name,
  setSelectValue = () => {},
  searchParams = new URLSearchParams(),
  className,
  defaultValue,
  value,
  onChange,
  icon,
  setValue,
  onlyValue,
  trigger,
  disabled,
}: ISelectUi) {
  const [open, setOpen] = useState(false)

  const handleValueChange = (value: string) => {
    const selectedItem = items.find((item) => item.value === value) || {
      value: '',
      label: '',
    }
    const updatedParams = new URLSearchParams(searchParams)
    updatedParams.set(name, value)
    setSelectValue(updatedParams)
    onChange && onChange(name, value)
    onlyValue
      ? setValue && setValue(name, value)
      : setValue && setValue(name, selectedItem)
    trigger && trigger(name)
  }

  return (
    <Select
      onOpenChange={setOpen}
      onValueChange={handleValueChange}
      name={name}
      defaultValue={defaultValue}
      value={value}
      disabled={disabled}
    >
      <SelectTrigger
        className={cn('w-[180px]', value === '' && 'text-muted-300', className)}
      >
        {icon && icon}
        <SelectValue placeholder={placeholder} />
        {open ? (
          <ChevronUpIcon className="ml-2 size-4 opacity-50" />
        ) : (
          <ChevronDownIcon className="ml-2 size-4 opacity-50" />
        )}
      </SelectTrigger>
      <SelectContent>
        {items.map((item, i) => (
          <SelectItem key={i} value={item.value}>
            {item.label}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  )
}
