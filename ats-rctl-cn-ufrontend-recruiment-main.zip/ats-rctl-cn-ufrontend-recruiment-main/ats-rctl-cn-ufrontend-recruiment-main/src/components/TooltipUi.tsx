import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip'
import React from 'react'

interface ITooltipUi {
  Icon: React.ElementType
  label: string
  sizeIcon?: number
}
const TooltipUi = ({ Icon, label, sizeIcon = 16 }: ITooltipUi) => {
  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <Icon
            stroke={1.5}
            size={sizeIcon}
            className="text-secondary-500 dark:text-white"
          />
        </TooltipTrigger>
        <TooltipContent>
          <span>{label}</span>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  )
}

export default TooltipUi
