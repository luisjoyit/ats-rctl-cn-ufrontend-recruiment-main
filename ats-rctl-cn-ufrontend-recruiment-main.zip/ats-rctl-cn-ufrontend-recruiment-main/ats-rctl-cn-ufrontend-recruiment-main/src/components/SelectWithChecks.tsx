import React, { useEffect, useState } from 'react'
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Checkbox } from '@/components/ui/checkbox'
import { ChevronDownIcon, ChevronUpIcon } from '@radix-ui/react-icons'
import { UseFormSetValue } from 'react-hook-form'

interface Item {
  value: string
  label: string
}

interface ISelectWithChecks {
  placeholder: string
  name: string
  items: Item[]
  className?: string
  defaultValue: string
  onChange?: (name: string, value: string) => void
  setValue?: UseFormSetValue<any>
}

const SelectWithChecks = ({
  placeholder,
  name,
  items,
  className,
  defaultValue,
  onChange,
  setValue,
}: ISelectWithChecks) => {
  const [selectedOption, setSelectedOption] = useState(defaultValue)
  const [open, setOpen] = useState(false)

  const handleOptionChange = (value: string) => {
    setSelectedOption(value)
    setValue && setValue(name, value)
    onChange && onChange(name, value)
  }
  const selectedLabel =
    items.find((option) => option.value === selectedOption)?.label ||
    placeholder

  return (
    <Select
      onValueChange={handleOptionChange}
      name={name}
      defaultValue={defaultValue}
      onOpenChange={setOpen}
    >
      <SelectTrigger className={className}>
        <SelectValue placeholder={placeholder}>{selectedLabel}</SelectValue>
        {open ? (
          <ChevronUpIcon className="ml-2 size-4 opacity-50" />
        ) : (
          <ChevronDownIcon className="ml-2 size-4 opacity-50" />
        )}
      </SelectTrigger>
      <SelectContent>
        <SelectGroup>
          {items.map((item, index) => (
            <SelectItem
              key={index}
              value={item.value}
              className="data-[state=checked]:bg-primary-foreground data-[state=checked]:text-secondary-500"
            >
              <div className="flex items-center">
                <Checkbox
                  checked={selectedOption === item.value}
                  id={`checkbox-${index}`}
                />
                <label htmlFor={`checkbox-${index}`} className="ml-2">
                  {item.label}
                </label>
              </div>
            </SelectItem>
          ))}
        </SelectGroup>
      </SelectContent>
    </Select>
  )
}

export default SelectWithChecks
