import { useState } from 'react'
import { MagicMotion } from 'react-magic-motion'
import BadgeUi from './BadgeUi'

type objTags = {
  id: number
  name: string
}
interface tagsProps {
  tags: objTags[]
}

export default function Tags({ tags }: tagsProps) {
  const [stacks, setStacks] = useState(tags)

  const handleClickDelete = (id: number) => {
    setStacks(stacks.filter((stack) => stack.id !== id))
  }

  return (
    <MagicMotion>
      <li className="flex flex-wrap gap-2">
        {stacks.map((stack) => (
          <ul key={stack.id}>
            <BadgeUi
              name={stack.name}
              onClick={() => handleClickDelete(stack.id)}
              filter
            />
          </ul>
        ))}
      </li>
    </MagicMotion>
  )
}
