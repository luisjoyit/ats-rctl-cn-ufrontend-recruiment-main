'use client'

import React, { useEffect, useState } from 'react'
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover'
import {
  IconChevronDown,
  IconChevronLeft,
  IconChevronRight,
  IconChevronUp,
} from '@tabler/icons-react'
import { Input } from './ui/input'

interface MonthYearProps {
  name: string
  placeholder?: string
  value?: string
  onChange?: (event: { target: { name: string; value: string } }) => void
  trigger?: string
  returnInLetters?: boolean
}

const formatDate = (date: Date | null, returnInLetters: boolean = false) => {
  if (!date) return ''
  const month = returnInLetters
    ? date.toLocaleString('default', { month: 'long' })
    : (date.getMonth() + 1).toString().padStart(2, '0')
  const year = date.getFullYear()
  return returnInLetters ? `${month} ${year}` : `${month}/${year}`
}

export function MonthYearPicker({
  name,
  placeholder = 'mm/yyyy',
  value,
  onChange,
  trigger = 'input',
  returnInLetters = false,
}: MonthYearProps) {
  const [selectedMonth, setSelectedMonth] = useState<Date | null>(null)
  const [isOpen, setIsOpen] = useState(false)
  const [currentYear, setCurrentYear] = useState<number>(
    new Date().getFullYear(),
  )

  useEffect(() => {
    if (value) {
      const [month, year] = value.split('/')
      setSelectedMonth(new Date(parseInt(year, 10), parseInt(month, 10) - 1))
      setCurrentYear(parseInt(year, 10))
    }
  }, [value])

  const handleMonthClick = (month: number) => {
    const newDate = new Date(currentYear, month - 1)
    setSelectedMonth(newDate)
    setIsOpen(false)
    onChange?.({
      target: {
        name,
        value: formatDate(newDate, returnInLetters),
      },
    })
  }

  const handleYearChange = (direction: 'prev' | 'next') => {
    setCurrentYear((prevYear) => prevYear + (direction === 'next' ? 1 : -1))
  }

  const months = [
    'Jan',
    'Feb',
    'Mar',
    'Apr',
    'May',
    'Jun',
    'Jul',
    'Aug',
    'Sep',
    'Oct',
    'Nov',
    'Dec',
  ]

  return (
    <Popover open={isOpen} onOpenChange={() => setIsOpen(!isOpen)}>
      <PopoverTrigger asChild>
        {trigger === 'input' ? (
          <Input
            type="text"
            name={name}
            value={selectedMonth && formatDate(selectedMonth, returnInLetters)}
            placeholder={placeholder}
            className="cursor-pointer"
            onClick={() => setIsOpen(true)}
          />
        ) : (
          <button className='h-[31px] w-[132px] px-2 bg-accent-200 text-secondary-500 text-xs font-medium rounded-lg flex justify-around items-center gap-3"'>
            {selectedMonth
              ? formatDate(selectedMonth, returnInLetters)
              : 'Seleccione'}
            {isOpen ? (
              <IconChevronUp stroke={1} size={20} />
            ) : (
              <IconChevronDown stroke={1} size={20} />
            )}
          </button>
        )}
      </PopoverTrigger>
      <PopoverContent
        className="relative mt-2 p-3 rounded-[6px] bg-white shadow-cards"
        align="center"
        side="bottom"
        sideOffset={4}
      >
        <div className="flex flex-col font-inter text-secondary-500">
          <div className="flex items-center justify-between mb-2">
            <button className="p-2" onClick={() => handleYearChange('prev')}>
              <IconChevronLeft stroke={1.5} size={18} />
            </button>
            <span className="font-medium">{currentYear}</span>
            <button className="p-2" onClick={() => handleYearChange('next')}>
              <IconChevronRight stroke={1.5} size={18} />
            </button>
          </div>
          <div className="grid grid-cols-3 gap-1">
            {months.map((month, index) => (
              <button
                key={index}
                className={`p-2 border rounded text-center hover:bg-secondary-500 hover:text-white text-xs
                  ${selectedMonth && selectedMonth.getMonth() === index ? 'bg-secondary-500 text-white' : ''}`}
                onClick={() => handleMonthClick(index + 1)}
              >
                {month}
              </button>
            ))}
          </div>
        </div>
      </PopoverContent>
    </Popover>
  )
}
