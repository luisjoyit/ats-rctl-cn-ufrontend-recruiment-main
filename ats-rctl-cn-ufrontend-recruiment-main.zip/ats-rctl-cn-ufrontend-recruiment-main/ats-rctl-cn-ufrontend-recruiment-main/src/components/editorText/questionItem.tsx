import { useState } from 'react'
import {
  IconCopy,
  IconTrash,
  IconCircleDot,
  IconAlignJustified,
  IconGripVertical,
  IconCircle,
} from '@tabler/icons-react'
import SelectUi from '../SelectUi'
import {
  FieldErrors,
  UseFormRegister,
  UseFormSetValue,
  UseFormTrigger,
} from 'react-hook-form'
import { JobFormSchema } from '@/company/validations/jobFormSchema'

interface Question {
  id?: number
  titleQuestion?: string
  typeAnswer?: string
  answers?: string[]
}

interface QuestionItemProps {
  question: Question
  index: number
  deleteQuestion: (id: number) => void
  register: UseFormRegister<JobFormSchema>
  errors: FieldErrors<JobFormSchema>
  setValue: UseFormSetValue<JobFormSchema>
  trigger: UseFormTrigger<JobFormSchema>
}

const QuestionItem = ({
  question,
  index,
  deleteQuestion,
  register,
  errors,
  setValue,
  trigger,
}: QuestionItemProps) => {
  const [selectedType, setSelectedType] = useState(
    question?.typeAnswer || 'SHORT_ANSWER',
  )

  const listAnswers = question?.answers

  const changeTypeAnswer = (name, value) => {
    setSelectedType(value)
    setValue(`questions.${index}.typeAnswer`, value)

    if (value === 'SHORT_ANSWER') {
      setValue(`questions.${index}.answers`, [])
    }
  }

  const addOption = () => {
    setValue(`questions.${index}.answers`, [...listAnswers, ''])
    trigger(`questions.${index}`)
  }

  const handleAnswerChange = (
    e: React.ChangeEvent<HTMLInputElement>,
    index: number,
  ) => {
    const newAnswers = [...listAnswers]
    newAnswers[index] = e.target.value
    setValue(`questions.${index}.answers`, newAnswers)
  }

  const getIcon = () => {
    if (selectedType === 'SHORT_ANSWER') {
      return <IconCircleDot className="mr-2 text-secondary-500" size={16} />
    }
    if (selectedType === 'MULTIPLE_CHOICE') {
      return (
        <IconAlignJustified className="mr-2 text-secondary-500" size={16} />
      )
    }
    return null
  }

  return (
    <div className="flex items-center">
      <button
        className="mr-2 mt-3 cursor-pointer hidden md:block"
        onClick={() => deleteQuestion(question.id)}
      >
        <IconGripVertical stroke={2} />
      </button>
      <div className="flex flex-col py-4 xs:px-4 md:px-7 border rounded-[30px] xs:w-full md:w-3/4 gap-3">
        <div className="flex xs:flex-col md:flex-row justify-between xs:items-start md:items-center xs:gap-4 md:gap-8">
          <div className="flex flex-col gap-1 w-full">
            <input
              type="text"
              placeholder="Describa la pregunta"
              className="w-full block border-0 border-b-[0.5px] border-accent-700 focus:ring-0 outline-none bg-transparent"
              name="titleQuestion"
              {...register(`questions.${index}.titleQuestion` as const, {
                required: 'La pregunta es obligatoria',
              })}
            />
            {errors?.questions?.[index]?.titleQuestion && (
              <span className="text-xs text-destructive-500">
                {errors.questions[index]?.titleQuestion?.message}
              </span>
            )}
          </div>
          <div className="inline-flex items-center">
            <SelectUi
              name="typeAnswer"
              items={[
                { value: 'SHORT_ANSWER', label: 'Respuesta Corta' },
                { value: 'MULTIPLE_CHOICE', label: 'Varias opciones' },
              ]}
              value={selectedType}
              onChange={changeTypeAnswer}
              placeholder="Pregunta"
              icon={getIcon()}
              className="shadow-input h-[37px] w-[230px] justify-between"
            />
          </div>
        </div>
        <div>
          {selectedType === 'SHORT_ANSWER' ? (
            <div className="w-3/4 border-b-[0.5px] border-accent-700 text-accent-600 text-sm">
              Texto de Respuesta corta
            </div>
          ) : (
            <div className="flex flex-col gap-2">
              {listAnswers.map((answer, answerIndex) => (
                <div key={answerIndex} className="flex flex-col gap-1">
                  <div className="flex flex-row gap-2 w-full items-center">
                    <IconCircle
                      stroke={1.5}
                      size={15}
                      className="text-secondary-500 dark:text-white"
                    />
                    <input
                      type="text"
                      className="mt-1 block w-full border-b-[0.5px] border-accent-700 focus:ring-0 outline-none bg-transparent"
                      name=""
                      placeholder={`Opción ${answerIndex + 1}`}
                      value={answer}
                      onChange={(e) => handleAnswerChange(e, answerIndex)}
                      {...register(`questions.${index}.answers.${answerIndex}`)} // Registro para validaciones
                    />
                  </div>
                  {errors?.questions?.[index]?.answers?.[answerIndex]
                    ?.message && (
                    <span className="text-xs text-destructive-500">
                      {errors.questions[index].answers[answerIndex]?.message}
                    </span>
                  )}
                </div>
              ))}
              <div className="flex flex-row gap-2 w-full items-center">
                <IconCircle
                  stroke={1.5}
                  size={15}
                  className="text-secondary-500 dark:text-white"
                />
                <span
                  className="text-accent-700 cursor-pointer"
                  role="button"
                  tabIndex={0}
                  onClick={addOption}
                >
                  + Añadir opción
                </span>
              </div>
              {errors?.questions?.[index]?.root?.message && (
                <span className="text-xs text-destructive-500">
                  {errors.questions[index].root.message}
                </span>
              )}
            </div>
          )}
        </div>
        <div className="w-full justify-end flex gap-3">
          <button className="p-1 border rounded-lg">
            <IconCopy size={16} stroke={2} />
          </button>
          <button
            className="p-1 border rounded-lg"
            onClick={() => deleteQuestion(question.id)}
          >
            <IconTrash size={16} stroke={2} />
          </button>
        </div>
      </div>
    </div>
  )
}

export default QuestionItem
