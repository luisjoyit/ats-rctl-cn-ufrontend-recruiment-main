import { Button } from '@/components/ui/button'
import useMediaQuery from '@/hooks/useMediaQuery'
import { IconSparkles } from '@tabler/icons-react'
import { UseFormSetValue, UseFormTrigger } from 'react-hook-form'

interface IEditorDemo {
  placeholder?: string
  name?: string
  isHeaderEnd?: boolean
  value?: string
  onChange?: (value: string) => void
  buttonSecondaryIA?: boolean
  setValue?: UseFormSetValue<any>
  trigger?: UseFormTrigger<any>
}

export default function EditorDemo({
  placeholder,
  name = 'textArea',
  isHeaderEnd,
  value,
  onChange,
  buttonSecondaryIA,
  setValue,
  trigger,
}: IEditorDemo) {
  const handleChange = (e) => {
    onChange && onChange(e.target.value)
    setValue && setValue(name, e.target.value)
    trigger && trigger(name)
  }

  const isMobile = useMediaQuery('(max-width:640px)')

  return (
    <div
      className={`border rounded-[11px] bg-primary-foreground flex ${isHeaderEnd ? 'flex-col-reverse' : 'flex-col'}`}
    >
      <div className="header flex items-center justify-between p-2">
        <div className="flex border rounded-lg p-0.5 bg-white">
          {['B', 'I', 'U', 'S', '•', '=', '🔗'].map((button, buttonIndex) => (
            <button
              key={buttonIndex}
              className={`p-1 text-xs xs:w-4 sm:w-6 h-6 flex items-center justify-center`}
            >
              {button}
            </button>
          ))}
        </div>
        <Button
          variant={buttonSecondaryIA ? 'secondary' : 'primary'}
          size="sm"
          className="flex flex-row justify-between xs:w-auto sm:w-[134px] px-3"
        >
          {isMobile ? 'Mejorar' : 'Mejorar con IA'}
          <IconSparkles style={{ fill: 'white' }} size={18} />
        </Button>
      </div>
      <textarea
        className="w-full p-2 rounded-[11px] focus:outline-none bottom-0 font-inter text-xs resize-none"
        name={name}
        placeholder={placeholder ? placeholder : '"Escribe aquí..."'}
        rows={4}
        value={value}
        onChange={handleChange}
      />
    </div>
  )
}
