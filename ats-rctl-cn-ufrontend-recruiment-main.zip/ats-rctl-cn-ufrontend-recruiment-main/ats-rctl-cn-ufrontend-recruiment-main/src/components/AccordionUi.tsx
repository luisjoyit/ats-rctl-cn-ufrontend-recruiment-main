import { AccordionContent } from '@radix-ui/react-accordion'
import { Accordion, AccordionItem, AccordionTrigger } from './ui/accordion'
import { cn } from '@/lib/utils'

interface AccordionItemsProps {
  value: string
  accordionTrigger: React.ReactNode
  accordionContent: React.ReactNode
}

interface AccordionUiProps {
  accordionItems: AccordionItemsProps[]
  className?: string
}

export default function AccordionUi({
  accordionItems,
  className,
}: AccordionUiProps) {
  return (
    <Accordion type="single" collapsible className="w-full">
      {accordionItems.map((item, i) => (
        <AccordionItem
          value={item.value}
          className={cn(
            'px-5 bg-white rounded-xl',
            i === accordionItems.length - 1 ? '' : 'mb-5',
            className,
          )}
          key={i}
        >
          <AccordionTrigger>{item.accordionTrigger}</AccordionTrigger>
          <AccordionContent>{item.accordionContent}</AccordionContent>
        </AccordionItem>
      ))}
    </Accordion>
  )
}
