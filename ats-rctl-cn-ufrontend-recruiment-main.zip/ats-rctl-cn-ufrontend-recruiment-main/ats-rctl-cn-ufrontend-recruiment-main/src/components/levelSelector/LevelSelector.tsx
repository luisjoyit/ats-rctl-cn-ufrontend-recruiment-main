import { useEffect, useState } from 'react'

interface ILevelSelectorProps {
  name: string
  onChange: (level: string) => void
  initialLevel?: string
}

interface ILevels {
  value: string
  label: string
}

export const levels: ILevels[] = [
  { value: 'basic', label: 'Básico' },
  { value: 'intermediate', label: 'Intermedio' },
  { value: 'advanced', label: 'Avanzado' },
  { value: 'expert', label: 'Experto' },
]

export default function LevelSelector({
  name,
  onChange,
  initialLevel,
}: ILevelSelectorProps) {
  const [selectedLevel, setSelectedLevel] = useState<string | null>(null)

  useEffect(() => {
    const initial =
      levels.find((level) => level.value === initialLevel)?.label || null
    setSelectedLevel(initial)
  }, [initialLevel])

  const handleLevelClick = (levelLabel: string) => {
    setSelectedLevel(levelLabel)
    const selectedValue =
      levels.find((level) => level.label === levelLabel)?.value || ''
    onChange(selectedValue)
  }

  return (
    <div className="w-full font-inter flex flex-col gap-2">
      <div className="w-full font-inter grid grid-cols-4 gap-2">
        {levels.map((level, index) => (
          <div
            key={index}
            className={`flex flex-col rounded-[11px] cursor-pointer w-auto max-w-[68px] h-[36px] 
              ${selectedLevel && levels.findIndex((l) => l.label === selectedLevel) >= index ? 'bg-secondary-500' : 'bg-[#EDF4FF]'}`}
            tabIndex={0}
            role="button"
            onClick={() => handleLevelClick(level.label)}
          />
        ))}
      </div>
      {selectedLevel && (
        <span className="text-secondary-500 font-medium text-xs">{`Nivel: ${selectedLevel}`}</span>
      )}
    </div>
  )
}
