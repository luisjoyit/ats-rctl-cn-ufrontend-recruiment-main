import { IconSearch } from '@tabler/icons-react'
import { cn } from '@/lib/utils'
import { Input } from './ui/input'

interface InputSearchProps {
  placeholder?: string
  className?: string
  icon?: React.ReactNode
  heightInput?: string
  name?: string
  value?: any
  onChange?: (name: string, value: any) => void
}

export default function InputWithIcon({
  placeholder = '',
  className,
  icon = <IconSearch stroke={1.5} className="w-full h-full" />,
  heightInput,
  name,
  value,
  onChange,
}: InputSearchProps) {
  return (
    <div className={cn('relative min-w-10 lg:w-[27rem]', className)}>
      <span className="absolute top-0 bottom-0 w-4 h-4 my-auto left-4 antialiased text-secondary-500 z-20">
        {icon}
      </span>
      <Input
        type="text"
        name={name}
        className={`py-2 !pl-10 !pr-4 rounded-lg focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-transparent sm:block border border-muted-100 w-full ${heightInput}`}
        placeholder={placeholder}
        value={value}
        onChange={(e) => onChange?.(name || '', e.target.value)}
      />
    </div>
  )
}
