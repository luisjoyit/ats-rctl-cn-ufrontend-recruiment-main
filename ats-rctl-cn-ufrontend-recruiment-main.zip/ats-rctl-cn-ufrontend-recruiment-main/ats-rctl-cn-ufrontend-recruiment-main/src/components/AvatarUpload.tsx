import { ChangeEvent, useRef, useState } from 'react'
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar'
import { IconEdit } from '@tabler/icons-react'
import { cn } from '@/lib/utils'

function getImageData(event: ChangeEvent<HTMLInputElement>) {
  if (!event.target.files || event.target.files.length === 0) {
    return { files: null, displayUrl: '' }
  }
  // FileList is immutable, so we need to create a new one
  const dataTransfer = new DataTransfer()

  // Add newly uploaded images
  Array.from(event.target.files!).forEach((image) =>
    dataTransfer.items.add(image),
  )

  const files = dataTransfer.files
  const displayUrl = URL.createObjectURL(event.target.files![0])

  return { files, displayUrl }
}

interface AvatarUploadProps {
  className?: string
}

export default function AvatarUpload({ className }: AvatarUploadProps) {
  const [preview, setPreview] = useState('')
  const inputRef = useRef(null)

  const handleIconClick = () => {
    inputRef.current.click()
  }

  return (
    <div className="relative inline-block">
      <Avatar
        className={cn(
          'w-24 h-24 relative border-[3px] border-primary-foreground',
          className,
        )}
      >
        <AvatarImage src={preview} />
        <AvatarFallback>BU</AvatarFallback>
      </Avatar>
      <input
        type="file"
        ref={inputRef}
        className="hidden"
        onChange={(event) => {
          const { files, displayUrl } = getImageData(event)
          setPreview(displayUrl)
        }}
      />
      <div
        className="absolute bottom-3 right-0 cursor-pointer bg-white rounded-full p-1"
        role="button"
        tabIndex={0}
        aria-label="Upload Avatar"
        onClick={handleIconClick}
      >
        <IconEdit stroke={2} size={17} className="text-gray-500" />{' '}
        {/* Ícono fuera del círculo */}
      </div>
    </div>
  )
}
