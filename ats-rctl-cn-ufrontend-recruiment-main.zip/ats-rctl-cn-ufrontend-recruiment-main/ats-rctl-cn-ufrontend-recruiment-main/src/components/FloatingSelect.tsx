import React, { useState } from 'react'
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { cn } from '@/lib/utils'
import { ChevronDownIcon, ChevronUpIcon } from '@radix-ui/react-icons'

interface FloatingSelectProps {
  options: { value: string; label: string }[]
  value: string
  name: string
  onChange: (name: string, value: string) => void
  label: string
  className?: string
  background?: string
}

const FloatingSelect: React.FC<FloatingSelectProps> = ({
  options,
  value,
  name,
  onChange,
  label,
  className,
  background,
}) => {
  const [isFocused, setIsFocused] = useState(false)

  const [open, setOpen] = useState(false)

  // Encuentra el label correspondiente al value seleccionado
  const selectedOptionLabel =
    options.find((option) => option.value === value)?.label || ''

  return (
    <div className="relative">
      <label
        className={`text-accent-800 absolute top-2 transition-all ${isFocused || value ? `font-inter text-xs start-2 top-2 z-0 origin-[0] -translate-y-4 scale-90 transform rounded-lg px-2 text-accent-800 duration-300 ${background && background}` : 'hidden'}`}
      >
        {label}
      </label>
      <Select
        value={value}
        onValueChange={(selectedValue) => onChange(name, selectedValue)}
        onOpenChange={setOpen}
      >
        <SelectTrigger
          onFocus={() => setIsFocused(true)}
          onBlur={() => setIsFocused(false)}
          className={cn(
            'h-[37px] rounded-[11px] bg-primary-foreground',
            className,
          )}
        >
          {selectedOptionLabel || (
            <span className="text-secondary-500">{label}</span>
          )}
          {open ? (
            <ChevronUpIcon className="ml-2 size-4 opacity-50" />
          ) : (
            <ChevronDownIcon className="ml-2 size-4 opacity-50" />
          )}
        </SelectTrigger>
        <SelectContent>
          {options.map((option) => (
            <SelectItem key={option.value} value={option.value}>
              {option.label}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  )
}

export default FloatingSelect
