import { useState } from 'react'
import { Input } from '@/components/ui/input'
import { IconX } from '@tabler/icons-react'
import { UseFormTrigger } from 'react-hook-form'

interface InputWithSuggestionProps {
  items: {
    value: string
    label: string
  }[]
  placeholder?: string
  className?: string
  setValue?: (field: string, value: any) => void
  trigger?: UseFormTrigger<any>
  name?: string
}

const InputWithSuggestion = ({
  items,
  placeholder = 'Buscar ...',
  className,
  setValue,
  trigger,
  name,
}: InputWithSuggestionProps) => {
  const [query, setQuery] = useState('')
  const [suggestions, setSuggestions] = useState<
    { value: string; label: string }[]
  >([])
  const [selected, setSelected] = useState<{
    value: string
    label: string
  } | null>(null)

  // Función para manejar el cambio en el input
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value
    setQuery(value)

    // Filtrar las sugerencias basadas en la entrada del usuario
    if (value.length > 0) {
      const filteredSuggestions = items.filter((item) =>
        item.label.toLowerCase().includes(value.toLowerCase()),
      )
      setSuggestions(filteredSuggestions)
    } else {
      setSuggestions([])
    }
  }

  // Función para manejar la selección de una sugerencia
  const handleSelect = (item: { value: string; label: string }) => {
    setQuery(item.label)
    setSelected(item)
    setSuggestions([])

    if (setValue && name) {
      setValue(name, item)
      trigger(name)
    }
  }

  const handleClear = () => {
    setQuery('')
    setSelected(null)
    setSuggestions([])

    if (setValue && name) {
      setValue(name, { value: '', label: '' })
    }
  }

  return (
    <div className="w-auto relative">
      <div className="flex items-center">
        <Input
          value={query}
          onChange={handleInputChange}
          placeholder={placeholder}
          className={`w-[337px] h-[37px] rounded-lg ${className}`}
        />
        {query && (
          <button onClick={handleClear} className="ml-2">
            <IconX className="text-secondary-500 size-4" />
          </button>
        )}
      </div>

      {/* Mostrar sugerencias */}
      {suggestions.length > 0 && (
        <ul className="absolute z-10 bg-white border border-gray-300 w-full mt-1 rounded-lg shadow-lg">
          {suggestions.map((item, index) => (
            <li
              key={index}
              onClick={() => handleSelect(item)}
              className="px-4 py-2 cursor-pointer hover:bg-gray-100 text-sm font-inter"
            >
              {item.label}
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}

export default InputWithSuggestion
