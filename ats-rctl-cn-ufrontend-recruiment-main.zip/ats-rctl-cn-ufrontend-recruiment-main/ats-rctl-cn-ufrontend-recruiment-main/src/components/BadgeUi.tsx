import { Badge, badgeVariants } from './ui/badge'
import { IconX } from '@tabler/icons-react'
import { VariantProps } from 'class-variance-authority'

interface BadgeProps
  extends React.HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof badgeVariants> {
  name: string
  filter?: boolean
  onClick: () => void
}

export default function BadgeUi({
  name,
  filter,
  onClick,
  className,
  ...rest
}: BadgeProps) {
  return (
    <Badge
      variant="outline"
      className={`px-2 bg-primary-foreground rounded-[11px] shadow-[0px_0px_1px_0px_#00000040] h-9 w-auto gap-2 ${filter && 'bg-accent-200 rounded-[50px] hover:bg-accent-400 h-[31px] shadow-none border-0 px-4'}`}
    >
      <span className="text-secondary-500 text-xs font-inter font-normal">
        {name}
      </span>
      <button
        className={`h-4 w-4 animate-out duration-300 rounded-full flex items-center justify-center ${!filter && 'bg-[#EDF4FF]'}`}
        onClick={onClick}
      >
        <IconX size={10} className="text-secondary-500" />
      </button>
    </Badge>
  )
}
