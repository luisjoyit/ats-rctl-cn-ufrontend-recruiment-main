import * as React from 'react'
import { Slot } from '@radix-ui/react-slot'
import { cva, type VariantProps } from 'class-variance-authority'

import { cn } from '@/lib/utils'

const buttonVariants = cva(
  'inline-flex items-center justify-center whitespace-nowrap rounded-lg font-medium font-inter ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 px-2 py-2',
  {
    variants: {
      variant: {
        primary: 'bg-secondary hover:bg-secondary-600 text-primary-foreground',
        secondary:
          'bg-transparent dark:bg-primary-foreground hover:bg-backgroundF-100 text-secondary-500 dark:hover:text-secondary-500 border-[1px] border-secondary-500',
        tertiary:
          'text-secondary cursor-pointer hover:text-secondary-600 dark:hover:text-white',
        default: 'bg-primary-10 text-primary-foreground hover:bg-primary/90',
        destructive:
          'bg-destructive text-destructive-foreground hover:bg-destructive/90',
        outline:
          'border border-input bg-background hover:bg-accent hover:text-accent-foreground dark:border-transparent',
        ghost: 'hover:bg-accent hover:text-accent-foreground',
        link: 'text-primary underline-offset-4 hover:underline',
      },
      size: {
        default: 'h-10 px-2 py-2',
        sm: 'h-[31px] w-[118px] text-xs',
        md: 'h-[37px] w-[140px] text-sm',
        lg: 'h-[39px] w-[154px] text-regular',
        icon: 'h-10 w-10',
      },
    },
    defaultVariants: {
      variant: 'primary',
      size: 'md',
    },
  },
)

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean
  icon?: React.ReactNode
  iconPosition?: 'left' | 'right'
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  (
    {
      className,
      variant,
      size,
      asChild = false,
      icon,
      iconPosition = 'left',
      children,
      ...props
    },
    ref,
  ) => {
    const Comp = asChild ? Slot : 'button'

    const iconSizeClasses = {
      sm: 'h-4 w-4',
      md: 'h-4.5 w-4.5',
      lg: 'h-5 w-5',
    }

    const iconClass = iconSizeClasses[size] || iconSizeClasses.md

    return (
      <Comp
        className={cn(buttonVariants({ variant, size, className }))}
        ref={ref}
        {...props}
      >
        {icon && iconPosition === 'left' && (
          <span className={`mr-3 flex items-center ${iconClass}`}>{icon}</span>
        )}
        {children}
        {icon && iconPosition === 'right' && (
          <span className={`ml-3 flex items-center ${iconClass}`}>{icon}</span>
        )}
      </Comp>
    )
  },
)
Button.displayName = 'Button'

export { Button, buttonVariants }
