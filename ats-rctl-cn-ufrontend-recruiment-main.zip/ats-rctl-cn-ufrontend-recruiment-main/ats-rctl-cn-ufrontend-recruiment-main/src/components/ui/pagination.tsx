import * as React from 'react'
import { ChevronLeft, ChevronRight, MoreHorizontal } from 'lucide-react'

import { cn } from '@/lib/utils'
import { ButtonProps, buttonVariants } from '@/components/ui/button'

type PaginationProps = {
  totalItems: number
  itemsPerPage: number
  currentPage: number
  onPageChange: (pageNumber: number) => void
  showEllipsis?: boolean
  showPreviousNext?: boolean
  maxItemsBeforeEllipsis?: number
  className?: string
  pagLinkClassName?: string
  pPreviousText?: string
  pNextText?: string
}

const Pagination = ({
  totalItems,
  itemsPerPage,
  currentPage,
  onPageChange,
  showEllipsis = true,
  showPreviousNext = true,
  maxItemsBeforeEllipsis = 3,
  className,
  pagLinkClassName = 'bg-secondary-500 dark:bg-secondary-100 text-secondary-foreground border-transparent font-bold rounded-lg',
  pPreviousText,
  pNextText,
  ...props
}: PaginationProps) => {
  const totalPages = Math.ceil(totalItems / itemsPerPage)
  const isFirstPage = currentPage === 1
  const isLastPage = currentPage === totalPages

  const handlePreviousClick = () => {
    if (currentPage > 1) {
      onPageChange(currentPage - 1)
    }
  }

  const handleNextClick = () => {
    if (currentPage < totalPages) {
      onPageChange(currentPage + 1)
    }
  }

  const handlePageItemClick = (pageNumber: number) => {
    onPageChange(pageNumber)
  }

  const renderPaginationItems = () => {
    const paginationItems = []
    const maxItemsBeforeEllipsis = 2 // Número de botones a mostrar antes/después de la página actual
    const maxPagesToShowBeforeEllipsis = maxItemsBeforeEllipsis * 2 + 1 // Páginas visibles antes de mostrar elipsis

    for (let i = 1; i <= totalPages; i++) {
      if (
        i === 1 || // Siempre mostrar la primera página
        i === totalPages || // Siempre mostrar la última página
        (i >= currentPage - maxItemsBeforeEllipsis &&
          i <= currentPage + maxItemsBeforeEllipsis)
      ) {
        paginationItems.push(
          <PaginationItem
            key={i}
            onClick={() => handlePageItemClick(i)}
            isActive={i === currentPage}
          >
            <PaginationLink
              className={
                i === currentPage ? pagLinkClassName : 'border-transparent'
              }
            >
              {i}
            </PaginationLink>
          </PaginationItem>,
        )
      } else if (
        (i === currentPage - maxItemsBeforeEllipsis - 1 ||
          i === currentPage + maxItemsBeforeEllipsis + 1) &&
        paginationItems[paginationItems.length - 1] !==
        <PaginationEllipsis key={`ellipsis-${i}`} />
      ) {
        // Añadir puntos suspensivos
        paginationItems.push(<PaginationEllipsis key={`ellipsis-${i}`} />)
      }
    }

    return paginationItems
  }

  return (
    <nav
      role="navigation"
      aria-label="pagination"
      className={cn('mx-auto flex w-full justify-center', className)}
      {...props}
    >
      {showPreviousNext && (
        <PaginationPrevious
          onClick={handlePreviousClick}
          disabled={isFirstPage}
          preText=""
        />
      )}
      <PaginationContent>{renderPaginationItems()}</PaginationContent>
      {showPreviousNext && (
        <PaginationNext
          onClick={handleNextClick}
          disabled={isLastPage}
          nexText=""
        />
      )}
    </nav>
  )
}

Pagination.displayName = 'Pagination'

const PaginationContent = React.forwardRef<
  HTMLUListElement,
  React.ComponentProps<'ul'>
>(({ className, ...props }, ref) => (
  <ul
    ref={ref}
    className={cn('flex flex-row items-center gap-1', className)}
    {...props}
  />
))
PaginationContent.displayName = 'PaginationContent'

type PaginationItemProps = {
  isActive?: boolean
  onClick?: () => void
}

const PaginationItem = ({
  isActive,
  onClick,
  children,
}: React.PropsWithChildren<PaginationItemProps>) => (
  <li
    className={cn('cursor-pointer', { 'font-bold': isActive })}
    onClick={onClick}
  >
    {children}
  </li>
)

PaginationItem.displayName = 'PaginationItem'

type PaginationLinkProps = {
  disabled?: boolean
} & Pick<ButtonProps, 'size'> &
  React.ComponentProps<'a'>

const PaginationLink = ({
  disabled,
  className,
  size = 'icon',
  ...props
}: PaginationLinkProps) => (
  <a
    className={cn(
      buttonVariants({
        variant: disabled ? 'ghost' : 'outline',
        size,
        className: 'bg-accent-200 border-transparent rounded-lg',
      }),
      className,
    )}
    {...props}
  />
)

PaginationLink.displayName = 'PaginationLink'

const PaginationPrevious = ({
  onClick,
  disabled,
  className,
  preText = 'Previous',
}: React.ComponentProps<typeof PaginationLink> & {
  onClick: () => void
  disabled: boolean
  preText?: string
}) => (
  <PaginationLink
    aria-label="Go to previous page"
    size="default"
    onClick={onClick}
    disabled={disabled}
    className={cn('gap-1 pr-2.5 mr-4 cursor-pointer', className)}
  >
    <ChevronLeft className="h-4 w-4" />
    <span>{preText}</span>
  </PaginationLink>
)

PaginationPrevious.displayName = 'PaginationPrevious'

const PaginationNext = ({
  onClick,
  disabled,
  className,
  nexText = 'Next',
}: React.ComponentProps<typeof PaginationLink> & {
  onClick: () => void
  disabled: boolean
  nexText?: string
}) => (
  <PaginationLink
    aria-label="Go to next page"
    size="default"
    onClick={onClick}
    disabled={disabled}
    className={cn('gap-1 pr-2.5 ml-4 cursor-pointer', className)}
  >
    <span>{nexText}</span>
    <ChevronRight className="h-4 w-4" />
  </PaginationLink>
)

PaginationNext.displayName = 'PaginationNext'

const PaginationEllipsis = ({ className }: React.ComponentProps<'span'>) => (
  <span
    aria-hidden
    className={cn('flex h-9 w-9 items-center justify-center', className)}
  >
    <MoreHorizontal className="h-4 w-4" />
    <span className="sr-only">More pages</span>
  </span>
)

PaginationEllipsis.displayName = 'PaginationEllipsis'

export {
  Pagination,
  PaginationContent,
  PaginationEllipsis,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
}
