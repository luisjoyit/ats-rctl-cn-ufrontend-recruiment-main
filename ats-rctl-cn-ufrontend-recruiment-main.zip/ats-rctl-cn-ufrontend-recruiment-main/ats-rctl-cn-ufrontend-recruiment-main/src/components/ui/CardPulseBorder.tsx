import { cn } from '@/lib/utils'

interface CardAnimatedBorderGradientProps {
  children: React.ReactNode
  className?: string
}

const CardAnimatedBorderGradient = ({
  className,
  children,
}: CardAnimatedBorderGradientProps) => {
  return (
    <div
      className={cn(
        'relative overflow-hidden w-full rounded-b-[11px] bg-primary-foreground xs:px-4 xs:py-4 sm:px-8 sm:py-8 text-secondary-500 shadow-[0px_0px_2px_0px_#00000040]',
        className,
      )}
    >
      {/*<span className="absolute inset-[-1000%] animate-[spin_7s_linear_infinite] shadow-[0px_0px_1px_0px_#00000040]" />*/}
      <div className="h-full w-full">{children}</div>
    </div>
  )
}

export default CardAnimatedBorderGradient
//'relative overflow-hidden rounded-[11px] p-[1px]'
