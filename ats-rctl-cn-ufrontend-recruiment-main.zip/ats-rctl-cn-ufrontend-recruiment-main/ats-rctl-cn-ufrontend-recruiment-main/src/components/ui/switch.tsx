'use client'

import * as React from 'react'
import * as SwitchPrimitives from '@radix-ui/react-switch'

import { cn } from '@/lib/utils'

interface SwitchProps
  extends React.ComponentPropsWithoutRef<typeof SwitchPrimitives.Root> {
  selectedBg?: string
  unselectedBg?: string
  width?: string
  height?: string
  thumbSize?: string
  circleColor?: string
  className?: string
  border?: string
  checked?: boolean
  onCheckedChange?: (checked: boolean) => void
}

const Switch = React.forwardRef<
  React.ElementRef<typeof SwitchPrimitives.Root>,
  SwitchProps
>(
  (
    {
      selectedBg = 'bg-secondary-500',
      unselectedBg = 'bg-accent-400 dark:bg-[#DCE4E5]',
      width = 'w-[30px]',
      height = 'h-4.5',
      circleColor = 'bg-primary-foreground',
      thumbSize = 'w-3.5 h-3.5',
      border = 'transparent',
      className,
      checked = false,
      onCheckedChange,
      ...props
    },
    ref,
  ) => {
    return (
      <SwitchPrimitives.Root
        className={cn(
          `peer inline-flex shrink-0 cursor-pointer items-center rounded-full border-2 data-[state=checked]:border-transparent data-[state-checked]:border-solid transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background disabled:cursor-not-allowed dark:data-[state=unchecked]:border-[#DCE4E5]`,
          checked ? selectedBg : unselectedBg,
          width,
          height,
          className,
        )}
        checked={checked}
        onCheckedChange={onCheckedChange}
        {...props}
        ref={ref}
      >
        <SwitchPrimitives.Thumb
          className={cn(
            'pointer-events-none block rounded-full shadow-lg ring-0 transition-transform',
            thumbSize,
            circleColor,
            'data-[state=checked]:translate-x-full data-[state=unchecked]:translate-x-0',
          )}
        />
      </SwitchPrimitives.Root>
    )
  },
)

Switch.displayName = 'Switch'

export { Switch }
