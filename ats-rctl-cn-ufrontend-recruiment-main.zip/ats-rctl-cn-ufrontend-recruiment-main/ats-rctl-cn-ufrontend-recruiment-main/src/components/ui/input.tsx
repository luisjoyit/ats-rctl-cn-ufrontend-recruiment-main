// input.tsx
import * as React from 'react'
import { cva, type VariantProps } from 'class-variance-authority'
import { cn } from '@/lib/utils'
import { Label } from '@/components/ui/label'

const inputVariants = cva(
  'flex h-[37px] w-full border bg-primary-foreground dark:bg-primary-foreground text-secondary-500 dark:text-secondary-500 rounded-[11px] px-3 py-2 text-sm file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:muted-300 dark:placeholder-muted-300 focus-visible:outline-none focus-visible:ring-[0px] disabled:cursor-not-allowed disabled:opacity-50 group-hover/input:shadow-none transition duration-400',
  {
    variants: {
      variant: {
        default: '',
        floatingLabel: 'peer',
        // Se puede agregar más variantes
      },
    },
    defaultVariants: {
      variant: 'default',
    },
  },
)

export interface InputProps
  extends React.InputHTMLAttributes<HTMLInputElement>,
    VariantProps<typeof inputVariants> {
  suffix?: React.ReactNode
  label?: string
  tooltipContent?: React.ReactNode
  preffix?: React.ReactNode
}

const Input = React.forwardRef<HTMLInputElement, InputProps>(
  (
    {
      className,
      variant,
      suffix,
      label,
      tooltipContent,
      preffix,
      id,
      ...props
    },
    ref,
  ) => {
    return (
      <div className="relative w-full">
        {preffix && (
          <span className="absolute inset-y-0 left-2.5 flex items-center pointer-events-auto cursor-pointer text-sm">
            {preffix}
          </span>
        )}
        <input
          placeholder={variant === 'floatingLabel' ? ' ' : undefined}
          className={cn(
            inputVariants({ variant, className }),
            preffix && '!pl-5',
          )}
          ref={ref}
          id={id}
          {...props}
        />
        {variant === 'floatingLabel' && label && (
          <Label
            htmlFor={id}
            className="peer-focus:secondary peer-focus:dark:secondary absolute start-2 top-2 z-10 origin-[0] -translate-y-4 scale-90 transform rounded-lg bg-primary-foreground px-2 text-xs text-accent-800 duration-300 peer-placeholder-shown:z-0 peer-placeholder-shown:pointer-events-none peer-placeholder-shown:top-1/2 peer-placeholder-shown:-translate-y-1/2 peer-placeholder-shown:scale-100 peer-focus:z-10 peer-focus:top-2 peer-focus:-translate-y-4 peer-focus:scale-90 peer-focus:px-1 peer-focus:text-[#284080] dark:bg-white dark:text-accent-800 rtl:peer-focus:left-auto rtl:peer-focus:translate-x-1/4 font-medium"
          >
            {label}
          </Label>
        )}
        {suffix && (
          <span className="absolute inset-y-0 right-0 flex items-center pointer-events-auto cursor-pointer">
            {suffix}
          </span>
        )}
      </div>
    )
  },
)

Input.displayName = 'Input'

export { Input, inputVariants }
