import { Button } from '@/components/ui/button'

interface ButtonCalendarProps {
  label: string
  onClick?: (e: React.MouseEvent<HTMLButtonElement>) => void
}

export default function ButtonCalendar({
  label,
  onClick,
}: ButtonCalendarProps) {
  return (
    <Button
      className={`
                bg-[#E9EAF5] h-[26px]
                rounded-[30px] 
                font-medium font-inter
                text-xs text-[#263658] 
                hover:bg-primary
                hover:text-white
                w-auto min-w-10
            `}
      onClick={onClick}
    >
      {label}
    </Button>
  )
}
