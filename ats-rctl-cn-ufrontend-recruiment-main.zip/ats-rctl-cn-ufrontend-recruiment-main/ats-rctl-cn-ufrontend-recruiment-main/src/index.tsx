import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { BrowserRouter, Routes, Route, Outlet } from 'react-router-dom'
import { Toaster } from 'sonner'

import ApplicantPage from './aplicant'
import CompanyPages from './company'

const queryClient = new QueryClient()

export function RecruitmentApp() {
  const getIsAuthenticated = localStorage.getItem('isLogged')
  if (getIsAuthenticated === 'false' || getIsAuthenticated === null) {
    window.location.href = '/login'
  }
  return (
    <section>
      <Toaster richColors />
      <QueryClientProvider client={queryClient}>
        <BrowserRouter basename="/recruitment">
          <Routes>
            <Route path="applicants/*" element={<ApplicantPage />} />
            <Route path="company/*" element={<CompanyPages />} />
          </Routes>
        </BrowserRouter>
      </QueryClientProvider>
    </section>
  )
}
