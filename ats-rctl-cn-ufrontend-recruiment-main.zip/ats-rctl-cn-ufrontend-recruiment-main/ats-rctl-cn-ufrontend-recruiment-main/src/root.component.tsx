import './index.css'

export default function Root(props) {
  return (
    <section>
      <div>
        <p>Welcome to recruitment page! You should not see this message.</p>
      </div>
    </section>
  )
}
